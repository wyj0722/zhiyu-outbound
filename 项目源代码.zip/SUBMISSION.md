# 智语外呼 · 比赛源码包

五类模拟资审工单通过真实浏览器 WebRTC 进行语音对话。业务事实、样张、商家录音和工具回执均使用演示数据。最终独立复测通过 10 通，其中拒绝 5 通均无回执，确认 5 通均在重试后保留一条回执。

## 双击启动网页演示

1. 在 Windows x64 机器上解压整个 ZIP，双击 `双击启动.cmd`。包内附带便携 Python 3.12 和 pip。
2. 首次启动请保持网络连接。启动器下载 Python 依赖和本机语音模型，等语音服务就绪后打开默认浏览器。
3. 选择工单，点击「发起呼叫」，按浏览器提示允许使用麦克风。运行地址显示在启动窗口中，默认从本机 8844 端口开始查找空闲端口。

启动器优先读取当前进程已配置的 `DEEPSEEK_API_KEY`，其次读取 Windows 用户环境变量。有 Key 时启动 DeepSeek 工单模式，需要能访问 DeepSeek 服务且账户有可用额度。空 Key 时自动启动规则演示，可使用浏览器语音和本机模拟工单。

运行库和启动日志保存在解压目录下的 `.runtime/judge-launch/`。依赖和权重安装后，后续启动会复用本地文件。需明确使用规则模式时可在 PowerShell 运行以下命令。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\start_judge.ps1 -Rules
```

## 离线复核已有结果

如评审机器已有 Python 3.12 或更新版本，在解压目录运行以下命令。脚本只依赖 Python 标准库。启动器解压便携 Python 后，也可用 `.\.runtime\judge-python\python.exe` 替代命令中的 `python`。

```powershell
python -B tools/audit_submission.py
```

脚本核验两版源码快照和 13 段 WAV 的 SHA-256，从逐轮记录重算可听首响分位数，并交叉校验 10 通回放与留存的 SQLite 核对记录。归档中的 WAV 路径使用包内相对路径，转写、耗时和工具结果照录。

## 重新运行完整五工单验收

请先在当前 PowerShell 进程或 Windows 用户环境变量中配置自己的 `DEEPSEEK_API_KEY`。验收模型使用 `deepseek-flash`。新一轮回放需要新的数据库文件名和新的输出文件名。启动隔离实例并等待语音服务就绪。

```powershell
$env:JD_DEEPSEEK_MODEL = 'deepseek-flash'
$env:JD_STAMP_ASR = 'sensevoice'
$env:JD_VAD_MODE = 'silero'
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\start_judge.ps1 -NoBrowser -Port 8844 -Database .runtime/submission-replay.sqlite3
```

在另一终端进入解压目录，使用 Node.js、Playwright 和已安装的浏览器回放原始 13 段录音。测试脚本会自动查找 Edge。使用 Chrome 时，通过 `JD_BROWSER_PATH` 提供 Chrome 可执行文件完整路径。启动器另选端口时，请把命令中的地址换成它显示的实际地址。

```powershell
npm install --ignore-scripts
node tests/verify_five_work_orders.cjs http://127.0.0.1:8844 results/acceptance-new.json acceptance-wavs
```

## 目录

- `jd_mock/` 包含服务端、前端、默认领域词表、策略和 Mock 工单逻辑。
- `acceptance-wavs/` 包含同批 13 段合成普通话 WAV。
- `tests/`、`tools/` 包含验收脚本、单元测试和结果复核工具。
- `results/webrtc-five-20261124/` 为首测证据。
- `results/webrtc-five-20261124-retest-final/` 为终版证据，含逐轮 `acceptance.json`、前后对照 `comparison.json`、冻结与运行配置记录。
- `results/rsi-dialogue/final/` 为既有独立合成文字实验。可运行 `python -B tools/run_dialogue_rsi.py --verify results/rsi-dialogue/final` 离线复核该历史归档。
- `vendor/` 为官方便携 Python 和 pip wheel。两份发行文件内均保留其许可证，`checksums.json` 提供下载来源和 SHA-256。

首响从商家录音的最后一个有声窗口结束计到浏览器收到首个可听答复。首测测到 18 个业务轮，终版测到 23 个，直接前后对比使用两版均测到的 18 个轮次。终版全量 P50 为 1.920 秒，P95 为 2.802 秒。此处为本地固定回放自测，实际云端响应时间会随网络和服务负载变化。
