"""Prepare the isolated Windows environment used by the double-click launcher."""

import argparse
import hashlib
from http.client import HTTPException
from importlib import metadata
from pathlib import Path
import re
import subprocess
import sys
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
PACKAGES = ROOT / ".runtime" / "judge-packages"
MODELS = ROOT / ".runtime" / "models"
PIP = ROOT / "vendor" / "pip-26.0.1-py3-none-any.whl"
PIP_SHA256 = "bdb1b08f4274833d62c1aa29e20907365a2ceb950410df15fc9521bad440122b"
sys.path.insert(0, str(ROOT))

from jd_mock import speech_assets


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def package_name(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def install_dependencies():
    requirements = ROOT / "requirements.txt"
    pinned = dict(line.split("==", 1) for line in requirements.read_text(encoding="utf-8").splitlines()
                  if line.strip())
    installed = {package_name(dist.metadata["Name"]): dist.version
                 for dist in metadata.distributions(path=[str(PACKAGES)]) if dist.metadata["Name"]}
    if all(installed.get(package_name(name)) == version for name, version in pinned.items()):
        print("Python dependencies ready.", flush=True)
        return
    if not PIP.is_file() or sha256(PIP) != PIP_SHA256:
        raise ValueError("Bundled pip wheel is missing or failed its checksum. Re-extract the ZIP.")
    PACKAGES.mkdir(parents=True, exist_ok=True)
    run_pip = "import runpy,sys; sys.path.insert(0,sys.argv.pop(1)); runpy.run_module('pip',run_name='__main__')"
    print("Installing Python dependencies into the workbench folder ...", flush=True)
    subprocess.run(
        [sys.executable, "-B", "-c", run_pip, str(PIP), "install",
         "--disable-pip-version-check", "--no-input", "--only-binary=:all:", "--upgrade",
         "--target", str(PACKAGES), "-r", str(requirements)],
        cwd=ROOT, check=True,
    )


def transfer(url, partial, name):
    offset = partial.stat().st_size if partial.exists() else 0
    headers = {"User-Agent": "jd-workbench-judge-bootstrap/1.0"}
    if offset:
        headers["Range"] = f"bytes={offset}-"
    request = Request(url, headers=headers)
    with urlopen(request, timeout=35) as response:
        resumed = offset > 0 and response.status == 206
        if resumed and not response.headers.get("Content-Range", "").startswith(f"bytes {offset}-"):
            partial.unlink(missing_ok=True)
            raise ValueError("Unexpected resume position.")
        if not resumed:
            offset = 0
        length = response.headers.get("Content-Length")
        announced_total = offset + int(length) if length and length.isdecimal() else None
        received = offset
        last_update = time.monotonic()
        print(f"{name}: starting at {offset / 1_000_000:.1f} MB.", flush=True)
        with partial.open("ab" if resumed else "wb") as target:
            while chunk := response.read1(128 * 1024):
                target.write(chunk)
                received += len(chunk)
                now = time.monotonic()
                if now - last_update >= 3:
                    total = f" / {announced_total / 1_000_000:.1f} MB" if announced_total else ""
                    print(f"{name}: {received / 1_000_000:.1f} MB{total}", flush=True)
                    last_update = now
        if announced_total is not None and received != announced_total:
            raise OSError("Download ended early.")


def download_verified(name, url, checksum):
    final = MODELS / name
    if final.is_file() and sha256(final) == checksum:
        return
    partial = final.with_suffix(final.suffix + ".part")
    for attempt in range(1, 4):
        try:
            if not partial.is_file() or sha256(partial) != checksum:
                transfer(url, partial, name)
            if sha256(partial) != checksum:
                partial.unlink()
                raise ValueError("SHA-256 mismatch.")
            partial.replace(final)
            print(f"Verified {name}", flush=True)
            return
        except (OSError, HTTPException, ValueError) as error:
            if isinstance(error, HTTPError) and error.code == 416:
                partial.unlink(missing_ok=True)
            print(f"{name}: attempt {attempt}/3 did not finish ({type(error).__name__}: {error}).", flush=True)
            if attempt == 3:
                raise RuntimeError(f"Unable to prepare {name}. Check the network and double-click again.") from error
            time.sleep(3)


def install_models(mode):
    MODELS.mkdir(parents=True, exist_ok=True)
    models = (speech_assets.ASR, speech_assets.TTS)
    if mode == "deepseek":
        models += (speech_assets.STAMP_ASR,)
    for asset in models:
        if not asset.is_installed(MODELS):
            name = f"{asset.name}.tar.bz2"
            download_verified(name, f"{speech_assets.RELEASE_ROOT}/{asset.release}/{name}", asset.sha256)
        speech_assets.install_model(MODELS, asset)
    if not speech_assets.silero_vad_installed(MODELS):
        name = speech_assets.SILERO_VAD_FILENAME
        download_verified(name, f"{speech_assets.RELEASE_ROOT}/asr-models/{name}", speech_assets.SILERO_VAD_SHA256)
    speech_assets.install_silero_vad(MODELS)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("rules", "deepseek"), required=True)
    args = parser.parse_args()
    install_dependencies()
    install_models(args.mode)
    if args.mode == "deepseek":
        sys.path.insert(0, str(PACKAGES))
        from jd_mock.strategy import warm_embedding_model

        print("Preparing the local strategy embedding model ...", flush=True)
        print("Strategy embedding dimensions:", warm_embedding_model(), flush=True)
    print("Workbench environment ready.", flush=True)


if __name__ == "__main__":
    try:
        main()
    except (OSError, RuntimeError, subprocess.CalledProcessError, ValueError) as error:
        print(str(error), file=sys.stderr, flush=True)
        sys.exit(1)
