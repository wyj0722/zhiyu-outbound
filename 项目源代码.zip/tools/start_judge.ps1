﻿[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)][int]$Port = 8844,
    [string]$Database,
    [string]$Python,
    [switch]$Rules,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$runtime = Join-Path $project '.runtime'
$runDirectory = Join-Path $runtime 'judge-launch'
$portableDirectory = Join-Path $runtime 'judge-python'
$setup = Join-Path $PSScriptRoot 'judge_setup.py'

function Get-PathId([string]$Path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Path.ToUpperInvariant())
        return [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-', '').Substring(0, 24)
    } finally {
        $sha.Dispose()
    }
}

function Find-Python {
    if ($Python) {
        return (Get-Command $Python -CommandType Application | Select-Object -First 1).Source
    }
    $portable = Join-Path $portableDirectory 'python.exe'
    if (Test-Path -LiteralPath $portable -PathType Leaf) { return $portable }
    $archive = Join-Path $project 'vendor/python-3.12-windows-amd64.zip'
    if (Test-Path -LiteralPath $archive -PathType Leaf) {
        $expectedHash = '4acbed6dd1c744b0376e3b1cf57ce906f9dc9e95e68824584c8099a63025a3c3'
        $sha = [Security.Cryptography.SHA256]::Create()
        $archiveStream = [IO.File]::OpenRead($archive)
        try { $actualHash = [BitConverter]::ToString($sha.ComputeHash($archiveStream)).Replace('-', '') }
        finally { $archiveStream.Dispose(); $sha.Dispose() }
        if ($actualHash -ine $expectedHash) {
            throw '便携 Python 压缩包校验失败。请重新解压提交包。'
        }
        if (Test-Path -LiteralPath $portableDirectory) {
            throw '便携 Python 目录不完整。请将压缩包重新解压到新目录后再启动。'
        }
        Write-Host '正在解压便携 Python…'
        $staging = Join-Path $runtime ("judge-python-" + [Guid]::NewGuid().ToString('N'))
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::ExtractToDirectory($archive, $staging)
        $paths = @('python312.zip', '.', '..\..', '..\judge-packages', '..\strategy-packages', 'import site')
        [IO.File]::WriteAllLines((Join-Path $staging 'python312._pth'), $paths, [Text.Encoding]::ASCII)
        if (!(Test-Path -LiteralPath (Join-Path $staging 'python.exe') -PathType Leaf)) {
            throw '便携 Python 压缩包不完整。请重新解压提交包。'
        }
        Move-Item -LiteralPath $staging -Destination $portableDirectory
        return $portable
    }
    $installed = Get-Command python.exe -CommandType Application -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($installed) { return $installed.Source }
    throw '找不到便携 Python。请完整解压提交包，或指定本机 64 位 Python 3.12。'
}

function Find-LoopbackPort([int]$StartPort) {
    for ($number = $StartPort; $number -le [Math]::Min(65535, $StartPort + 30); $number++) {
        $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $number)
        $listener.ExclusiveAddressUse = $true
        try {
            $listener.Start()
            return $number
        } catch [Net.Sockets.SocketException] {
            continue
        } finally {
            $listener.Stop()
        }
    }
    throw '附近的回环端口均被占用。请用 -Port 参数指定其他起始端口。'
}

function Get-LocalService([string]$Path, [string]$Interpreter) {
    if (!(Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    try {
        $saved = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
        $process = Get-Process -Id ([int]$saved.process_id) -ErrorAction Stop
        if ($process.Path -ieq $Interpreter -and
            [string]$process.StartTime.ToUniversalTime().Ticks -eq [string]$saved.start_ticks -and
            [int]$saved.port -ge 1024 -and [int]$saved.port -le 65535) {
            return @{ Process = $process; Port = [int]$saved.port }
        }
    } catch {
        # An old state file can outlive the server or be interrupted mid-write.
    }
}

function Read-Health([string]$Url) {
    $request = [Net.WebRequest]::Create("$Url/api/health")
    $request.Proxy = $null
    $request.Timeout = 2000
    $request.ReadWriteTimeout = 2000
    try {
        $response = $request.GetResponse()
        try {
            $reader = [IO.StreamReader]::new($response.GetResponseStream(), [Text.Encoding]::UTF8)
            try { return ($reader.ReadToEnd() | ConvertFrom-Json) }
            finally { $reader.Dispose() }
        } finally {
            $response.Dispose()
        }
    } catch [Net.WebException] {
        return $null
    }
}

$lock = [Threading.Mutex]::new($false, ('Local\JD-Judge-' + (Get-PathId $project)))
$locked = $false
$server = $null
$ready = $false
$restore = @{}
try {
    try { $locked = $lock.WaitOne(0) }
    catch [Threading.AbandonedMutexException] { $locked = $true }
    if (!$locked) {
        Write-Host '另一启动窗口正在准备环境。就绪后会自动打开工作台。'
        return
    }
    if (![Environment]::Is64BitOperatingSystem) { throw '请在 64 位 Windows 上运行。' }
    [IO.Directory]::CreateDirectory($runDirectory) | Out-Null
    $interpreter = Find-Python
    $key = if (!$Rules) {
        $configured = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'Process')
        if ([string]::IsNullOrWhiteSpace($configured)) {
            $configured = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'User')
        }
        $configured
    }
    $mode = if ([string]::IsNullOrWhiteSpace($key)) { 'rules' } else { 'deepseek' }
    $defaultDatabase = Join-Path $runDirectory 'calls.sqlite3'
    if ($Database) {
        if (![IO.Path]::IsPathRooted($Database)) { $Database = Join-Path $project $Database }
        $Database = [IO.Path]::GetFullPath($Database)
    } else {
        $Database = $defaultDatabase
    }
    $suffix = if ($Database -ieq $defaultDatabase) { '' } else { '-' + (Get-PathId $Database) }
    $state = Join-Path $runDirectory "service$suffix-$mode.json"
    $stdout = Join-Path $runDirectory "service$suffix-$mode.out.log"
    $stderr = Join-Path $runDirectory "service$suffix-$mode.err.log"
    $prior = Get-LocalService $state $interpreter

    if ($mode -eq 'deepseek') {
        Write-Host 'DeepSeek 模式使用当前 Windows 环境中的 Key。'
    } else {
        Write-Host '当前以免 Key 的规则模式演示。'
    }
    if ($prior) {
        $process = $prior.Process
        $activePort = $prior.Port
    } else {
        $packages = Join-Path $runtime 'judge-packages'
        $variables = @{
            DEEPSEEK_API_KEY = $null
            PYTHONPATH = $packages
            PYTHONUTF8 = '1'
            PYTHONNOUSERSITE = '1'
        }
        foreach ($name in $variables.Keys) {
            $restore[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
            [Environment]::SetEnvironmentVariable($name, $variables[$name], 'Process')
        }
        Push-Location -LiteralPath $project
        try {
            & $interpreter -I -c "import sys,struct; sys.exit(0 if sys.version_info[:2]==(3,12) and struct.calcsize('P')==8 else 2)"
            if ($LASTEXITCODE -ne 0) { throw '请使用 64 位 Python 3.12。' }
            Write-Host '正在检查依赖与语音模型。首次运行需要联网下载，请保留此窗口。'
            & $interpreter -X utf8 -B $setup --mode $mode
            if ($LASTEXITCODE -ne 0) { throw '运行环境准备失败。请检查此窗口中的错误，确认网络后双击重试。' }
        } finally {
            Pop-Location
        }
        $activePort = Find-LoopbackPort $Port
        $dialogue = if ($mode -eq 'deepseek') { 'model' } else { 'rules' }
        $provider = if ($mode -eq 'deepseek') { 'deepseek' } else { 'local' }
        [Environment]::SetEnvironmentVariable('DEEPSEEK_API_KEY', $key, 'Process')
        $arguments = @('-X', 'utf8', '-B', '-m', 'jd_mock.server', '--host', '127.0.0.1',
            '--port', $activePort, '--db', ('"' + $Database + '"'),
            '--dialogue-mode', $dialogue, '--llm-provider', $provider)
        $server = Start-Process -FilePath $interpreter -ArgumentList $arguments -WorkingDirectory $project `
            -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
        $process = $server
        $current = @{
            process_id = $server.Id
            port = $activePort
            start_ticks = [string]$server.StartTime.ToUniversalTime().Ticks
        }
        $current | ConvertTo-Json -Compress | Set-Content -LiteralPath $state -Encoding UTF8
    }

    $url = "http://127.0.0.1:$activePort"
    Write-Host '正在预热语音模型，请等候工作台就绪。'
    $deadline = [DateTime]::UtcNow.AddMinutes(8)
    do {
        if ($process.HasExited) { throw "服务退出。请查看 $stderr" }
        $health = Read-Health $url
        if ($health -and $health.voice_transport -eq 'webrtc' -and $health.llm_provider -eq $mode) {
            if (!$health.speech_ready) { throw "语音服务加载失败。请查看 $stderr" }
            if ($mode -eq 'deepseek' -and $health.stamp_warmup.source -ne 'model') {
                throw "DeepSeek 验证未通过。请检查当前 Key 和网络，启动日志位于 $stderr"
            }
            $ready = $true
            break
        }
        Start-Sleep -Milliseconds 1500
    } while ([DateTime]::UtcNow -lt $deadline)
    if (!$ready) { throw "服务未在 8 分钟内就绪。请查看 $stderr" }
    Write-Host "工作台已就绪  $url/"
    if (!$NoBrowser) {
        try { Start-Process -FilePath "$url/" }
        catch { Write-Host "请在 Edge 或 Chrome 打开 $url/" }
    }
} catch {
    if ($server -and !$ready -and !$server.HasExited) {
        Stop-Process -InputObject $server -ErrorAction SilentlyContinue
    }
    Write-Error -ErrorAction Continue (($_.Exception.Message))
    exit 1
} finally {
    foreach ($name in $restore.Keys) {
        [Environment]::SetEnvironmentVariable($name, $restore[$name], 'Process')
    }
    if ($locked) { $lock.ReleaseMutex() }
    $lock.Dispose()
}
