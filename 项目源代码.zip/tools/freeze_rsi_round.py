"""Freeze the runnable source and audio used by one local RSI round."""

import argparse
import hashlib
import json
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ("verify", "reason", "interrupt", "interrupt_alt", "interrupt_both", "confirm", "wrong")
SOURCE_SUFFIXES = {".py", ".html", ".js", ".css", ".json"}


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def freeze(output, fixture_dir, wrong_audio):
    audio = {name: fixture_dir / f"{name}.wav" for name in FIXTURES}
    audio["wrong"] = wrong_audio
    for path in audio.values():
        if not path.is_file():
            raise FileNotFoundError(path)

    sources = sorted(
        [path for path in (ROOT / "jd_mock").rglob("*")
         if path.is_file() and path.suffix in SOURCE_SUFFIXES]
        + [ROOT / "requirements.txt", ROOT / "start.ps1"]
    )
    output.mkdir(parents=True, exist_ok=False)
    baseline = output / "baseline"
    fixtures = output / "fixtures"
    fixtures.mkdir()

    source_hashes = {}
    for path in sources:
        relative = path.relative_to(ROOT)
        snapshot = baseline / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, snapshot)
        source_hashes[relative.as_posix()] = digest(snapshot)
    shutil.copytree(baseline, output / "candidate")

    fixture_hashes = {}
    for name, path in audio.items():
        snapshot = fixtures / f"{name}.wav"
        shutil.copy2(path, snapshot)
        fixture_hashes[name] = digest(snapshot)

    manifest = {
        "round": output.name.removeprefix("rsi-round-"),
        "baseline_source_sha256": source_hashes,
        "fixture_sha256": fixture_hashes,
    }
    manifest_path = output / "freeze.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    archive = output / "baseline.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as packaged:
        for name in source_hashes:
            packaged.write(baseline / name, name)
        packaged.write(manifest_path, "freeze.json")
        for name in FIXTURES:
            packaged.write(fixtures / f"{name}.wav", f"fixtures/{name}.wav")
    return archive


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path, help="A new directory for this round")
    parser.add_argument("--fixtures", type=Path, default=ROOT / ".runtime" / "voice-fixtures")
    parser.add_argument("--wrong-audio", type=Path, default=ROOT / ".runtime" / "verify" / "wrong.wav")
    options = parser.parse_args()
    archive = freeze(options.output, options.fixtures, options.wrong_audio)
    print(f"{archive}  SHA256 {digest(archive)}")


if __name__ == "__main__":
    main()
