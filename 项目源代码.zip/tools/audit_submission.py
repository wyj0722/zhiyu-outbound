"""Recompute the competition acceptance metrics from the bundled evidence."""

import argparse
import hashlib
import json
import math
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "results" / "webrtc-five-20261124"
FINAL = ROOT / "results" / "webrtc-five-20261124-retest-final"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def check(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stats(values):
    ordered = sorted(values)
    check(ordered, "No measured business turns")

    def percentile(fraction):
        offset = (len(ordered) - 1) * fraction
        lower = math.floor(offset)
        upper = math.ceil(offset)
        value = ordered[lower] + (ordered[upper] - ordered[lower]) * (offset - lower)
        return round(value, 1)

    return {"n": len(ordered), "p50": percentile(.5), "p95": percentile(.95)}


def check_stats(observed, recorded, description):
    check(observed["n"] == recorded["n"], f"Sample count mismatch: {description}")
    for key in ("p50", "p95"):
        check(abs(observed[key] - recorded[key]) <= .100001, f"Percentile mismatch: {description} {key}")


def audit_snapshot(directory, report, *, installed=False):
    freeze = read(directory / "freeze.json")
    content = directory / freeze["archive"]
    check(digest(content.read_bytes()) == freeze["archive_sha256"], f"Archive hash mismatch: {content.name}")
    manifest = freeze["source_sha256"]
    with ZipFile(content) as archive:
        check(sorted(archive.namelist()) == sorted(manifest), f"Archive members changed: {directory.name}")
        for name, expected in manifest.items():
            check(digest(archive.read(name)) == expected, f"Source hash mismatch: {name}")
            if installed:
                check(digest((ROOT / name).read_bytes()) == expected, f"Packaged code differs from run: {name}")
    snapshot = manifest | read(FINAL / "freeze.json")["test_runner_and_wav_sha256"]
    for name, expected in report["source_sha256"].items():
        check(snapshot.get(name) == expected, f"Reported source hash does not match snapshot: {name}")


def collect_turns(report):
    turns = {}
    planned = 0
    for call in report["calls"]:
        planned += sum(phase != "identity" for phase in call["planned_phases"])
        for turn in call["turns"]:
            if turn["phase"] == "identity" or turn["browser_first_audio_ms"] is None:
                continue
            key = (call["case_id"], call["path"], turn["phase"])
            check(key not in turns, f"Duplicate turn: {key}")
            turns[key] = turn
    rates = stats(turn["browser_first_audio_ms"] for turn in turns.values())
    check_stats(rates, report["first_audio_ms"], "all business turns")
    check(planned == report["first_audio_ms"]["planned"], "Planned turn count mismatch")
    check(planned - rates["n"] == report["first_audio_ms"]["missing"], "Missing turn count mismatch")
    return turns


def audit_receipts(report, recorded):
    check(recorded["integrity_check"] == "ok", "Recorded SQLite integrity check failed")
    check(len(report["calls"]) == len(recorded["calls"]) == 10, "Expected ten calls")
    audit_by_id = {row["call_id"]: row for row in recorded["calls"]}
    check(len(audit_by_id) == 10, "Duplicate SQLite call ID")
    refusals, receipts, seen_paths = 0, set(), set()
    for call in report["calls"]:
        audit = audit_by_id[call["call_id"]]
        path = (call["case_id"], call["path"])
        check(path not in seen_paths, f"Duplicate scenario path: {path}")
        seen_paths.add(path)
        check(call["passed"] and audit["passed"] and audit["checks"] == call["checks"], f"Failed call: {path}")
        check(audit["case_id"] == path[0] and audit["path"] == path[1], f"SQLite audit mismatch: {path}")
        check(not audit["pending_writeback"], f"Writeback still pending: {path}")
        if path[1] == "refusal":
            check(call["checks"]["refusal_without_receipt"] and audit["terminal_state"] == "closed", str(path))
            check(audit["receipt_count_in_sqlite"] == 0 and audit["receipt_id"] is None, str(path))
            refusals += 1
        else:
            check(path[1] == "interrupt_and_retry" and audit["terminal_state"] == "complete", str(path))
            for key in ("interruption", "continued_plan", "confirmed_and_pending", "idempotent_retry"):
                check(call["checks"].get(key), f"Missing check {key}: {path}")
            receipt = call["receipt"]["receipt_id"]
            check(audit["receipt_count_in_sqlite"] == 1 and audit["receipt_id"] == receipt, str(path))
            check(call["retry_receipt_ids"] == audit["repeat_retry_receipt_ids"] == [receipt] * 2, str(path))
            receipts.add(receipt)
    check(refusals == len(receipts) == recorded["total_receipts"] == 5, "Unexpected receipt totals")
    return {"passed_calls": len(seen_paths), "refusals_with_zero_receipts": refusals,
            "confirmed_calls_with_single_receipt": len(receipts)}


def audit():
    before, after = (read(folder / "acceptance.json") for folder in (BASELINE, FINAL))
    recorded = read(FINAL / "comparison.json")
    audit_snapshot(BASELINE, before)
    audit_snapshot(FINAL, after, installed=True)
    test_files = read(FINAL / "freeze.json")["test_runner_and_wav_sha256"]
    for name, expected in test_files.items():
        check(digest((ROOT / name).read_bytes()) == expected, f"Playback input hash mismatch: {name}")
    fixture_hashes = {Path(name).stem: value for name, value in test_files.items() if name.endswith(".wav")}
    for report in (before, after):
        check({name: fixture["sha256"] for name, fixture in report["fixtures"].items()} == fixture_hashes,
              "Recorded fixture hashes do not match the WAV files")
        check(report["active_strategy_count"] == 19, "Expected 19 active strategies")
    check(before["browser"] == after["browser"] and before["latency_definition"] == after["latency_definition"],
          "Browser version or measurement definition changed")
    turns_before, turns_after = collect_turns(before), collect_turns(after)
    paired = sorted(turns_before.keys() & turns_after.keys())
    paired_before = stats(turns_before[key]["browser_first_audio_ms"] for key in paired)
    paired_after = stats(turns_after[key]["browser_first_audio_ms"] for key in paired)
    pair_details = recorded["paired_business_phases"]
    check_stats(paired_before, pair_details["before"], "paired baseline")
    check_stats(paired_after, pair_details["after"], "paired final")
    expected_pairs = [
        {"case_id": case_id, "path": path, "phase": phase,
         "before_ms": turns_before[case_id, path, phase]["browser_first_audio_ms"],
         "after_ms": turns_after[case_id, path, phase]["browser_first_audio_ms"]}
        for case_id, path, phase in paired
    ]
    check(expected_pairs == pair_details["turns"], "Paired turn details differ from the recorded comparison")
    chain_key = ("JD-DEMO-003", "interrupt_and_retry", "interruption")
    chain_before, chain_after = turns_before[chain_key], turns_after[chain_key]
    check(recorded["chain_review_after_interrupt"] == {"before": chain_before, "after": chain_after},
          "Chain interruption trace differs from the recorded comparison")
    return {
        "verified_wavs": len(fixture_hashes),
        "baseline_passed_calls": sum(call["passed"] for call in before["calls"]),
        "retest": audit_receipts(after, recorded["sqlite_audit"]),
        "paired_business_before_ms": paired_before,
        "paired_business_after_ms": paired_after,
        "all_final_business_ms": after["first_audio_ms"],
        "chain_interruption": {
            "browser_first_audio_before_ms": chain_before["browser_first_audio_ms"],
            "browser_first_audio_after_ms": chain_after["browser_first_audio_ms"],
            "tts_first_before_ms": chain_before["server_stages"]["tts_first_ms"],
            "tts_first_after_ms": chain_after["server_stages"]["tts_first_ms"],
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write an additional JSON copy to a new file")
    args = parser.parse_args()
    result = json.dumps(audit(), indent=2, ensure_ascii=False) + "\n"
    if args.output:
        with args.output.open("x", encoding="utf-8") as output:
            output.write(result)
    print(result, end="")


if __name__ == "__main__":
    main()
