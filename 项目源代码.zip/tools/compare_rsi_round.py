"""Compare frozen RSI browser evidence and write a GO/NO-GO report."""

import argparse
import hashlib
import json
import math
import tempfile
from pathlib import Path


PHASES = ("verify", "reason", "interrupt", "confirm")
CASE_TERMS = {
    "interrupt": ("鞋类",),
    "interrupt_alt": ("授权类目",),
    "interrupt_both": ("鞋类", "授权类目"),
}
FIXTURES = {*PHASES, *CASE_TERMS, "wrong"}
TARGET_CASE = "interrupt_both"
TARGET_TERM = "鞋类"
CANDIDATE_SOURCE = "jd_mock/speech.py"
MEASUREMENT_FIELDS = ("browser_version", "measurement", "input_rms", "output_rms")
P50_LIMIT_MS = 2000


def sha256(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def source_hashes(directory):
    if not directory.is_dir() or directory.is_symlink():
        raise ValueError(f"{directory.name} must be a source directory")
    hashes = {}
    for path in sorted(directory.rglob("*")):
        relative = path.relative_to(directory)
        if "__pycache__" in relative.parts:
            continue
        if path.is_symlink():
            raise ValueError(f"{directory.name}/{relative.as_posix()} is a symlink")
        if path.is_file():
            hashes[relative.as_posix()] = sha256(path)
    return hashes


def read_object(path, reasons):
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, dict):
            raise ValueError("expected a JSON object")
        return data
    except (OSError, ValueError) as error:
        reasons.append(f"{path.name}: {error}")
        return {}


def measured(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def latency_summary(values, planned):
    values = sorted(values)

    def percentile(fraction):
        if not values:
            return None
        index = (len(values) - 1) * fraction
        lower, upper = math.floor(index), math.ceil(index)
        return values[lower] + (values[upper] - values[lower]) * (index - lower)

    return {"n": len(values), "planned": planned, "p50_ms": percentile(0.5), "p95_ms": percentile(0.95)}


def review_run(label, evidence, frozen_fixtures, reasons):
    if evidence.get("fixture_sha256") != frozen_fixtures:
        reasons.append(f"{label}: fixture hashes do not match the freeze")

    identity = evidence.get("identity")
    identity_passed = (
        isinstance(identity, dict)
        and identity.get("passed") is True
        and identity.get("fixture") == "wrong"
        and isinstance(identity.get("transcript"), str)
        and bool(identity["transcript"].strip())
        and identity.get("verified") is False
        and identity.get("disclosed_case_details") is False
        and type(identity.get("receipt_count")) is int
        and identity["receipt_count"] == 0
        and identity.get("pending_writeback") is False
        and identity.get("final_state") == "closed"
    )
    if not identity_passed:
        reasons.append(f"{label}: wrong-identity call failed or its evidence is incomplete")

    calls = evidence.get("calls")
    if not isinstance(calls, list) or not all(isinstance(call, dict) for call in calls):
        calls = []
    case_order = [call.get("interrupt_fixture") for call in calls]
    if case_order != list(CASE_TERMS):
        reasons.append(f"{label}: expected ordered cases {list(CASE_TERMS)}, got {case_order}")

    durations = []
    cases = {}
    accepted = 0
    for index, (fixture, call) in enumerate(zip(CASE_TERMS, calls), start=1):
        if call.get("interrupt_fixture") != fixture or call.get("index") != index:
            continue
        acceptance = call.get("acceptance")
        if not isinstance(acceptance, dict):
            acceptance = {}
        interrupt_count = acceptance.get("interrupt_count")
        if (
            call.get("passed") is True
            and acceptance.get("turn_count") == 4
            and type(interrupt_count) is int
            and interrupt_count >= 1
            and type(acceptance.get("receipt_count")) is int
            and acceptance["receipt_count"] == 1
        ):
            accepted += 1
        else:
            reasons.append(f"{label}/{fixture}: acceptance failed for four turns, interruption or receipt retry")

        turns = call.get("turns")
        if not isinstance(turns, list) or len(turns) != len(PHASES):
            reasons.append(f"{label}/{fixture}: expected exactly four main turns")
            continue
        phase_times = {}
        transcript = None
        recognized = []
        mute_ms = None
        for phase, turn in zip(PHASES, turns):
            expected_fixture = fixture if phase == "interrupt" else phase
            if not isinstance(turn, dict) or (turn.get("phase"), turn.get("fixture")) != (phase, expected_fixture):
                reasons.append(f"{label}/{fixture}: invalid {phase} turn or fixture")
                continue
            text = turn.get("transcript")
            if not isinstance(text, str) or not text.strip():
                reasons.append(f"{label}/{fixture}: {phase} transcript missing")
                text = ""
            duration = turn.get("browser_render_ms")
            if measured(duration):
                durations.append(duration)
                phase_times[phase] = duration
            else:
                reasons.append(f"{label}/{fixture}: {phase} browser latency missing or invalid")
            if phase == "interrupt":
                transcript = text
                recognized = [term for term in CASE_TERMS[fixture] if term in text]
                if turn.get("expected_terms") != list(CASE_TERMS[fixture]) or turn.get("recognized_terms") != recognized:
                    reasons.append(f"{label}/{fixture}: reported term hits disagree with fixture or transcript")
                mute_ms = turn.get("barge_in_to_mute_ms")
                if not measured(mute_ms):
                    reasons.append(f"{label}/{fixture}: barge-in mute latency missing or invalid")
                    mute_ms = None
        cases[fixture] = {
            "transcript": transcript,
            "recognized_terms": recognized,
            "browser_render_ms": phase_times,
            "barge_in_to_mute_ms": mute_ms,
        }

    case_count = len(CASE_TERMS)
    if (accepted, evidence.get("requested_calls"), evidence.get("passed_calls"), evidence.get("failed_calls")) != (
        case_count, case_count, case_count, 0
    ):
        reasons.append(f"{label}: all {case_count} main calls must pass")
    planned = case_count * len(PHASES)
    if len(durations) != planned:
        reasons.append(f"{label}: measured {len(durations)}/{planned} main turns")
    return {
        "accepted_calls": accepted,
        "planned_calls": case_count,
        "wrong_identity_passed": identity_passed,
        "latency": latency_summary(durations, planned),
        "recognized_terms": sum(len(case["recognized_terms"]) for case in cases.values()),
        "planned_terms": sum(map(len, CASE_TERMS.values())),
        "cases": cases,
    }


def compare_round(directory):
    reasons = []
    freeze = read_object(directory / "freeze.json", reasons)
    frozen_fixtures = freeze.get("fixture_sha256")
    try:
        fixture_hashes = {path.stem: sha256(path) for path in sorted((directory / "fixtures").glob("*.wav"))}
        if set(fixture_hashes) != FIXTURES or frozen_fixtures != fixture_hashes:
            reasons.append("Frozen fixture files must match the seven expected fixture hashes")
    except OSError as error:
        reasons.append(f"Cannot hash frozen fixture files: {error}")

    changes = []
    try:
        baseline_hashes = source_hashes(directory / "baseline")
        candidate_hashes = source_hashes(directory / "candidate")
        if baseline_hashes != freeze.get("baseline_source_sha256"):
            reasons.append("Baseline source tree does not match the freeze")
        changes = sorted(
            path for path in baseline_hashes.keys() | candidate_hashes.keys()
            if baseline_hashes.get(path) != candidate_hashes.get(path)
        )
        if changes != [CANDIDATE_SOURCE] or any(
            CANDIDATE_SOURCE not in hashes for hashes in (baseline_hashes, candidate_hashes)
        ):
            reasons.append(f"Candidate source changes must be exactly [{CANDIDATE_SOURCE}], got {changes}")
    except (OSError, ValueError) as error:
        reasons.append(f"Cannot verify source hashes: {error}")

    baseline_data = read_object(directory / "baseline-results.json", reasons)
    candidate_data = read_object(directory / "candidate-results.json", reasons)
    settings = {field: baseline_data.get(field) for field in MEASUREMENT_FIELDS}
    for field, baseline_value in settings.items():
        if field in ("browser_version", "measurement"):
            valid = isinstance(baseline_value, str) and bool(baseline_value.strip())
        else:
            valid = measured(baseline_value) and 0 < baseline_value <= 1
        if not valid or baseline_value != candidate_data.get(field):
            reasons.append(f"Browser measurement setting {field} is missing, invalid or differs")

    baseline = review_run("baseline", baseline_data, frozen_fixtures, reasons)
    candidate = review_run("candidate", candidate_data, frozen_fixtures, reasons)
    for fixture in CASE_TERMS:
        before = baseline["cases"].get(fixture, {}).get("recognized_terms", [])
        after = candidate["cases"].get(fixture, {}).get("recognized_terms", [])
        lost_terms = [term for term in before if term not in after]
        if lost_terms:
            reasons.append(f"{fixture}: candidate lost baseline terms {lost_terms}")
    before_target = baseline["cases"].get(TARGET_CASE, {})
    after_target = candidate["cases"].get(TARGET_CASE, {})
    if TARGET_TERM in before_target.get("recognized_terms", []) or TARGET_TERM not in after_target.get("recognized_terms", []):
        reasons.append(f"{TARGET_CASE}: {TARGET_TERM} must be absent in baseline and present in candidate")

    candidate_p50 = candidate["latency"]["p50_ms"]
    if candidate_p50 is None or candidate_p50 > P50_LIMIT_MS:
        reasons.append(f"Candidate browser P50 must be at most {P50_LIMIT_MS} ms")
    return {
        "decision": "NO-GO" if reasons else "GO",
        "reasons": reasons,
        "source_changes": changes,
        "measurement_settings": settings,
        "candidate_p50_limit_ms": P50_LIMIT_MS,
        "baseline": baseline,
        "candidate": candidate,
        "target": {"case": TARGET_CASE, "term": TARGET_TERM, "baseline": before_target, "candidate": after_target},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("round_directory", type=Path)
    directory = parser.parse_args().round_directory
    if not directory.is_dir():
        parser.error(f"Round directory does not exist: {directory}")

    report = compare_round(directory)
    output = directory / "comparison.json"
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", dir=directory, prefix=".comparison-", delete=False
        ) as file:
            temporary = Path(file.name)
            json.dump(report, file, ensure_ascii=False, indent=2, allow_nan=False)
            file.write("\n")
        temporary.replace(output)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    print(f"{report['decision']} ({output.name})")
    return int(report["decision"] != "GO")


if __name__ == "__main__":
    raise SystemExit(main())
