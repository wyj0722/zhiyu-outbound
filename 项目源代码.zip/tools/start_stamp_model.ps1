param(
    [switch]$Setup,
    [ValidateRange(1, 65535)][int]$Port = 8781,
    [ValidateSet('qwen2.5-1.5b', 'qwen3-4b')][string]$Variant = 'qwen2.5-1.5b'
)

# Official llama.cpp Windows CPU release and Qwen GGUF. The inference service
# listens only on loopback. Setup downloads software and weights, never orders.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$modelDir = Join-Path $projectRoot '.runtime/stamp-llm'
if ($Variant -eq 'qwen3-4b') {
    if (!$PSBoundParameters.ContainsKey('Port')) { $Port = 8782 }
    $modelFile = 'Qwen3-4B-Q4_K_M.gguf'
    $modelAlias = 'stamp-qwen3-4b'
    $modelRepo = 'Qwen/Qwen3-4B-GGUF'
    $modelScopeRev = '8cca206c792af04f8d452368bd30b43ec18007f1'
    $huggingFaceRev = 'bc640142c66e1fdd12af0bd68f40445458f3869b'
    $modelHash = '7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5'
    $extraArgs = @('--reasoning', 'off')
} else {
    $modelFile = 'qwen2.5-1.5b-instruct-q4_k_m.gguf'
    $modelAlias = 'stamp-qwen'
    $modelRepo = 'Qwen/Qwen2.5-1.5B-Instruct-GGUF'
    $modelScopeRev = 'e8b19c78f775ccbcf6df15ceace6bb5276f09765'
    $huggingFaceRev = '91cad51170dc346986eccefdc2dd33a9da36ead9'
    $modelHash = '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e'
    $extraArgs = @()
}
$build = 'b12608'
$archiveName = "llama-$build-bin-win-cpu-x64.zip"
$archive = Join-Path $modelDir $archiveName
$engineDir = Join-Path $modelDir "llama-$build"
$engine = Join-Path $engineDir 'llama-server.exe'
$weights = Join-Path $modelDir $modelFile

function Get-VerifiedFile([string]$File, [string]$Digest, [string[]]$Urls) {
    if (Test-Path -LiteralPath $File) {
        if ((Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash -eq $Digest) { return }
        throw "Checksum mismatch in $File. Move the damaged file before retrying setup."
    }
    $partial = "$File.download"
    foreach ($url in $Urls) {
        & curl.exe --fail --silent --show-error --location --retry 2 --connect-timeout 20 --speed-time 60 --speed-limit 4096 --continue-at - --output $partial $url
        if ($LASTEXITCODE -eq 0) {
            if ((Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ne $Digest) {
                throw "Checksum mismatch in $partial. Move the damaged download before retrying setup."
            }
            Move-Item -LiteralPath $partial -Destination $File
            return
        }
    }
    throw "Download failed. Run setup again to resume $partial."
}

if ($Setup) {
    $null = New-Item -ItemType Directory -Force -Path $modelDir
    Get-VerifiedFile -File $archive -Digest '7f83ea573f23eb3233ccea0ef4dbcb6eb84aec4b558034e39f08270989f4c3c6' -Urls @(
        "https://github.com/ggml-org/llama.cpp/releases/download/$build/$archiveName"
    )
    if (!(Test-Path -LiteralPath $engine)) {
        Expand-Archive -LiteralPath $archive -DestinationPath $engineDir -Force
    }
    Get-VerifiedFile -File $weights -Digest $modelHash -Urls @(
        "https://modelscope.cn/models/$modelRepo/resolve/$modelScopeRev/$modelFile",
        "https://huggingface.co/$modelRepo/resolve/$huggingFaceRev/$modelFile"
    )
}

if (!(Test-Path -LiteralPath $engine) -or !(Test-Path -LiteralPath $weights)) {
    throw "Run tools\start_stamp_model.ps1 -Variant $Variant -Setup first."
}

$probe = New-Object Net.WebClient
$probe.Proxy = $null
try {
    $models = $null
    try { $models = $probe.DownloadString("http://127.0.0.1:$Port/v1/models") | ConvertFrom-Json }
    catch [Net.WebException] { }
    if ($models -and $modelAlias -in @($models.data.id)) {
        Write-Host "$modelAlias is already available at http://127.0.0.1:$Port/v1"
        return
    }
    if ($models) { throw "Another model is already listening on port $Port." }
} finally { $probe.Dispose() }

Push-Location -LiteralPath $modelDir
try {
    & $engine -m $modelFile --alias $modelAlias --host 127.0.0.1 --port $Port -c 4096 -np 1 -t 6 -tb 8 --cache-ram 128 --no-webui @extraArgs
    if ($LASTEXITCODE -ne 0) { throw "llama-server exited with code $LASTEXITCODE." }
} finally { Pop-Location }
