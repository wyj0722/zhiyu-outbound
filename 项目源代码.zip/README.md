# 智语外呼 · 五张模拟资审工单

京东 POP 资质审核的本机 Mock。选一张工单后，在浏览器用耳麦扮演商家。浏览器通过 WebRTC 与 Python 服务通话，语音识别与合成均在本机运行。每通电话在发起时绑定工单号，业务状态和回执保存在 SQLite。五张样单都属于模拟商家「小贝塔」，工单和公司名称均为演示数据。

## 启动

Windows 64 位使用 Edge 或 Chrome。启动脚本会优先使用本机的 Codex Python 3.12，也可以用 -Python 指定自己的 64 位 Python 3.12。

在当前目录打开 PowerShell。语音依赖和模型已就绪时运行下面的命令。

    powershell -ExecutionPolicy Bypass -File .\start.ps1

首次在新机器配置时需要联网下载 Python 依赖和约 190 MB 的模型压缩包。

    powershell -ExecutionPolicy Bypass -File .\start.ps1 -Setup

服务显示就绪后，打开 [http://127.0.0.1:8765](http://127.0.0.1:8765)，允许浏览器使用麦克风，建议戴耳麦。服务绑定在本机。端口占用时可在启动命令后加 -Port 8766，同时修改浏览器端口。结束服务按 Ctrl+C。

### 工单的大模型模式

在项目根目录用两个 PowerShell 终端启动。第一个运行本机推理服务，首次加 `-Setup` 会下载并校验 llama.cpp 和约 1.12 GB 的模型权重，以后可离线运行。

    powershell -ExecutionPolicy Bypass -File .\tools\start_stamp_model.ps1 -Setup

第二个终端启动网页。新机器首次加 `-Setup`，会一并下载公章工单使用的 SenseVoice 和本地 Silero 人声检测模型。默认 `-DialogueMode model` 对五张工单启用大模型。设置 `DEEPSEEK_API_KEY` 后，启动脚本默认选 DeepSeek。使用本机 Qwen 时指定 `-LlmProvider local`。用 `-DialogueMode stamp` 可以复现只有公章单走模型的配置，用 `-DialogueMode rules` 可以运行规则基线。

    powershell -ExecutionPolicy Bypass -File .\start.ps1 -LlmProvider deepseek -DialogueMode model -Port 8779 -Database .runtime/stamp-ab/headset.sqlite3

打开 [工作台](http://127.0.0.1:8779)，选择一张模拟工单。通过身份核验后，DeepSeek 或本机 Qwen2.5-1.5B-Instruct Q4_K_M 结合商家转写、工单事实、主表和 QA，选择业务动作。类目单会区分只经营授权范围和补充授权后保留其他类目，链路单会结合当前授权两方判断追问、纠正或上传，公章单会区分经手人和章面主体。工单事实决定坐席话术，后端核实商家同意后写入幂等回执。每通电话的模型动作、实际采用动作、耗时和业务依据可在工单的 SQLite 决策记录复核。

「授权书内容不完整」的模型模式可用 `JD_STAMP_ASR=sensevoice` 明确指定识别器。默认 `auto` 会优先加载已安装的 SenseVoice。启动后通过 `/api/health` 的 `stamp_asr` 与 `stamp_warmup` 检查实际使用的识别器与模型。权重来源为 [SenseVoiceSmall](https://huggingface.co/FunAudioLLM/SenseVoiceSmall)，本机使用 [sherpa-onnx 发布的量化模型](https://github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models)。

`-LlmProvider local` 使用本机回环地址。默认模型端口为 8781，可用 `JD_STAMP_LLM_URL`、`JD_STAMP_LLM_MODEL` 和 `JD_STAMP_LLM_TIMEOUT` 配置本机兼容服务。冻结实验使用支持约束解码的 llama.cpp b12608 和 Q4_K_M 权重，下载版本及 SHA-256 见启动脚本。权重来自 [Qwen 官方模型库](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF)，推理软件来自 [llama.cpp 官方发行版](https://github.com/ggml-org/llama.cpp/releases/tag/b12608)。

### 五种工单的策略库

顶部「策略库」可按五种工单筛选，查看策略版本、适用条件和处理动作。策略库使用与工作台相同的 SQLite 文件。

在 DeepSeek 全工单模式下，完成身份核验后，客服会按工单场景和本轮问题检索策略。试问「具体缺哪一段授权」，再问「把这个证明补齐了，就一定能过审吗」，通话里会依次标出缺件和复审策略。办理确认仍以已播出的方案和商家的明确同意为依据。

首次配置时使用 `start.ps1 -Setup -DialogueMode model -LlmProvider deepseek`，启动脚本会准备本地中文向量模型。

### 抗噪和语音端点

语音服务优先使用本机 Silero 区分人声和环境声。检测前衰减低频底噪，识别仍接收原始语段和约 0.29 秒起音缓存。坐席保留当前播报，等本机转写出现有效内容再停播。提前同意仍按原开口时刻判断。可以在 `/api/health` 查看实际的 `vad_backend`。设置 `JD_VAD_MODE=silero` 可明确要求加载模型，设置 `JD_VAD_MODE=energy` 可用原音量门限跑对照。模型由安装脚本从 sherpa-onnx 官方发行资源下载并校验 SHA-256。 [Silero 模型来源](https://github.com/snakers4/silero-vad) · [sherpa-onnx 安装来源](https://github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models)

### 按工单定制语音词表

编辑 [默认领域词表](jd_mock/asr_vocabulary.json) 并重启服务，也可以复制一份，用 `-AsrVocabulary .\my-vocabulary.json` 指定。在直接启动 Python 服务时使用 `--asr-vocabulary` 或环境变量 `JD_ASR_VOCAB_FILE`。词表版本为 `1`，条目放入 `rules`。每条填写工单号 `case_id`、标准写法 `term`、实际听错的写法 `aliases`，并至少加一个语境条件。例子如下。

```json
{
  "case_id": "JD-DEMO-002",
  "term": "公章",
  "aliases": ["公张"],
  "before": ["盖", "盖了", "补盖"],
  "requires": ["授权书"]
}
```

`before` 和 `after` 分别检查紧挨别名的左侧和右侧，任一候选匹配即可。`requires` 中的词需全部在同一标点分句里。选填的 `left_pattern` 和 `right_pattern` 用于已有的正则语境。默认涵盖类目、公章和链路三张单。仅核验身份后，Zipformer2 CTC 和 SenseVoice 的最终转写才按当前工单修正。浏览器显示修正后的文本，命中时数据通道和大模型决策记录也保留 `raw_text`。身份核验、同意回写和停播判断使用原始识别结果。这个版本在识别结束后应用词表。 [sherpa-onnx 热词支持说明](https://k2-fsa.github.io/sherpa/onnx/hotwords/index.html)

打开 `/api/health` 查看 `asr_vocabulary` 的文件名、规则数和 SHA-256。配置错误会在启动时指出位置。需要空词表做回放时可传入 `{"version":1,"rules":[]}`。

可选的 `focus` 数组把规则限制在指定的对话环节。链路单的名称纠错保留原话中的先后顺序和授权关系。

离线对照用同一份转写分别运行冻结的旧规则和当前词表。已有录音路径、文件摘要和逐词结果保存在 [离线回放报告](results/asr-vocabulary/offline-01.json)。按下文配置好 Python 环境后，在项目根目录可用 `python -m tests.replay_asr_vocabulary --output .runtime/asr-vocabulary/recheck.json` 复跑。

### 切换 DeepSeek 及同批语音对照

启用 DeepSeek 时，配置 DeepSeek 官方 API Key。启动脚本可从当前进程或 Windows 用户环境变量读取配置。默认使用 `deepseek-flash`，可以用 `JD_DEEPSEEK_MODEL` 指定其他支持同一接口的官方模型。项目使用 JSON 输出并由后端校验选项。语音识别、停播、合成和工单回写均在本机，云端接收用于选动作的模拟工单事实和文本转写。API Key 只用于后端请求。 [DeepSeek 官方文档](https://api-docs.deepseek.com/zh-cn/guides/json_mode/)

```powershell
$env:DEEPSEEK_API_KEY = [System.Net.NetworkCredential]::new('', (Read-Host 'DeepSeek API Key' -AsSecureString)).Password
powershell -ExecutionPolicy Bypass -File .\start.ps1 -LlmProvider deepseek -Port 8812 -Database .runtime/model-ab-deepseek.sqlite3
```

用另一个终端启动本地对照。本地端由 `tools/start_stamp_model.ps1` 提供推理。两端用各自的空测试库，并保持识别和合成模型配置一致。

```powershell
powershell -ExecutionPolicy Bypass -File .\start.ps1 -LlmProvider local -Port 8811 -Database .runtime/model-ab-local.sqlite3
```

在另一终端用同一份录音分别回放。若 Node 已能直接加载 Playwright，可省去 `JD_PLAYWRIGHT_PATH`。

```powershell
$env:JD_PLAYWRIGHT_PATH = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'
$env:JD_WORKBENCH_ALL_MODEL = '1'
$env:JD_WORKBENCH_EXPECT_PROVIDER = 'local'
node tests/verify_workbench.cjs http://127.0.0.1:8811 results/model-ab/local.json
$env:JD_WORKBENCH_EXPECT_PROVIDER = 'deepseek'
node tests/verify_workbench.cjs http://127.0.0.1:8812 results/model-ab/deepseek.json
node tests/compare_model_replays.cjs results/model-ab/local.json results/model-ab/deepseek.json results/model-ab/comparison.json
```

报告保存实际转写、模型选择、浏览器首响、插话停播和回执。对照器按工单和固定录音对齐，单列识别差异，对模型不可用或样本缺失的轮次标明覆盖情况。DeepSeek 模型请求默认超时 6 秒，可用 `JD_DEEPSEEK_TIMEOUT` 单独配置。

要在独立网页地址试用 Qwen3-4B，可先在另一个终端运行 `powershell -ExecutionPolicy Bypass -File .\tools\start_stamp_model.ps1 -Variant qwen3-4b`。首次安装这款权重时加 `-Setup`。在启动试用网页的终端执行：

    $env:JD_STAMP_LLM_URL = 'http://127.0.0.1:8782/v1'
    $env:JD_STAMP_LLM_MODEL = 'stamp-qwen3-4b'
    $env:JD_STAMP_LLM_TIMEOUT = '12'
    powershell -ExecutionPolicy Bypass -File .\start.ps1 -DialogueMode model -Port 8784 -Database .runtime/qwen3-trial.sqlite3

第一轮对规则版与初版模型做了 8 通、18 个业务轮的配对语音盲测。初版模型的首响 P50 为 1.442 秒，9 轮明示章面主体均未正确提取，2 次明确办理同意均漏写。这批录音现用于回归。第一轮结果与回放材料见 [对比结果](results/stamp-ab/comparison.json) 和 [复核包](results/stamp-ab/replay.zip)。

公章工作台在 v2.1 的基础上补充了方案复述、明确上传承诺和材料更换后的章面核对。历史 v2.1 在 9 通公开回归中有 6/10 个明确章面主体判对。4 个明确同意轮实际写了 2 张，其中 1 张满足“上轮先给对方案、当轮同意并写回”。独立的另 4 通中，首轮方案 4/4 正确，两次应写的回执均漏写。相关指标来自当时的冻结代码。[v2.1 实测与复核](results/stamp-round2/v2.1/README.md)

当时的 v2.2 在同组 21 轮的动作正确数从 14 降至 12，实际正向回执从 2/4 降至 1/4。其独立交互用例通过 3/4。[确认逻辑试验](results/stamp-round2/v2.2/README.md)

### RSI 自动回放与提示词改进

先启动本机推理服务，再从项目根目录运行。每轮使用新的输出目录。

    python tools/run_dialogue_rsi.py --output results/rsi-dialogue/round-002
    python tools/run_dialogue_rsi.py --verify results/rsi-dialogue/round-002

脚本按随机种子从业务场景生成两组措辞并封存，先回放开发组，按失败类型组合有针对性的提示词，再用同一组留出用例比较初始版本和候选版本。三个工单都经过真实本机模型和独立 SQLite。指标包括正确业务动作、符合预期的回执、未核验披露和误写回等。通过率改善且原有通过用例没有退步时，脚本才推荐候选。要加载经复核的推荐配置，可以用 `-CasePolicy <结果目录>/recommendation.json` 启动模型模式。首次运行的留出组从 7/14 提高到 8/14，但一条审核咨询发生回归，脚本选择保留原配置。[首轮 RSI 结果](results/rsi-dialogue/round-001/comparison.json)

当前代码另用新种子从同一自建语料库抽样，留出集从 10/14 提高到 11/14，仍因一条审核咨询退步而保留原配置。网页主流程三单均经过真实模型、插话和幂等回写，20 轮可听首响的 P50 为 1.525 秒，P95 为 2.859 秒。类目单一条补充语音探针误识了“鞋类和服装都想保留”，同上下文的标准文字可进入补授权分支。[当前 RSI 结果](results/rsi-dialogue/final/comparison.json) · [语音验收](results/workbench-three-model/browser-acceptance-v2.json) · [语音与文本对照](results/workbench-three-model/category-asr-diagnostic.json)

RSI 首轮使用合成文本。网页语音、VAD 打断和首响另用 WebRTC 回放验收。模型及开源实现可逐项核对，sherpa-onnx 代码采用 Apache-2.0，llama.cpp 采用 MIT，当前 Qwen GGUF 采用 Apache-2.0。SenseVoice 源码与预训练权重采用各自的许可；发行预训练权重时查阅对应模型卡。[sherpa-onnx](https://github.com/k2-fsa/sherpa-onnx) · [llama.cpp](https://github.com/ggml-org/llama.cpp) · [Qwen 权重](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF) · [SenseVoice 权重说明](https://github.com/QwenAudio/SenseVoice#license)

## 手动验收

在顶部点选一张工单卡片，戴上耳麦，点击「发起通话」。客服自报身份后会问「请问您是否是商家小贝塔？」。答「是的，我是本人」。接下来可以直接说自己卡在哪里，也可以插话。客服开始播报办理方案后，你可以在播报途中说「好的」或「就这么办」。客服会停止播报方案、写入回执，播完结束语自动挂断。回执可在右侧查看。

通话记录上方的「已提交材料」随工单切换。客服请商家查看授权书时，样张会自动展开。问到授权双方、授权范围或公章时，对应字段会高亮。也可点击「查看样张」手动打开，样张下方显示审核发现。

想试拨错电话的情况，可以单独开一通，说「不是，您打错了」。客服应结束通话，通话记录里不会出现驳回原因，本单的历史回执数也不会增加。

| 模拟工单 | 商家可以这样说 | 留意客服怎么接 |
| --- | --- | --- |
| JD-DEMO-001 · 品牌类目不符 | 核验后选「只卖鞋类」或「我还想卖服装」，听到具体步骤后说「行，就这么办」。 | 客服直接说明申请类目和现有授权范围，按选择给出一份方案。保留服装时，无授权先补、有授权直接上传。明确同意后只写一条回执。 |
| JD-DEMO-002 · 授权书内容不完整 | 核验后听客服说明缺什么章，听到办理步骤后说「行，就这么办」。 | 客服直接说明样张盖的是小贝塔的章，并说明如何找青禾品牌公司补盖和重新提交。明确同意后只写一条回执。 |
| JD-DEMO-003 · 授权链路不完整 | 核验身份后，听客服一次讲清现有材料、缺少的证明和上传步骤。开始说办理步骤后，可以直接说「行，就这么办」。 | 客服会高亮已提交材料的双方，说明要补云杉品牌公司授权给星桥商贸公司的证明，并征求一次确认。确认后只生成一条本单回执。 |

用类目单试通话记忆时，先说「我还想卖服装」，再说「我已经拿到授权书了」。插问「补完就一定能通过审核吗？」，回执数应为零。接着问「那接下来怎么办？」。客服应记得授权书已拿到，继续讲上传和重新提交，然后征求确认。确认后检查工单号和步骤。每张单的历史回执按工单号查看，同一通电话的重复确认、超时重试均只对应一条回执。通话中的材料状态和暂存方案按通话记录，新拨一通会重新核对。

以下是用第一张单单独验证插话和重试的操作。先勾选「模拟首次回写超时」再发起通话。

| 操作 | 页面和坐席的预期表现 |
| --- | --- |
| 等待开场，先问「请问有什么事？」 | 坐席再次询问是否是商家小贝塔，暂不说出该单驳回原因。 |
| 说「是的，我是本人」 | 核验通过。坐席读出申请的是服装、现有授权只覆盖鞋类，只问想保留哪些类目。 |
| 说「只卖鞋类」 | 坐席一次说明从哪里选鞋类、怎么去掉服装并重新提交。 |
| 坐席开始说具体步骤后插话「行，就这么办」 | 播报停下，页面打断次数增加。页面提示回执超时，点击「重试回写」后看到一条本单回执。 |
| 核对回执并挂断 | 回写数量为 1，收到的是本次确认的原回执。挂断后麦克风停止，页面可查看本次转写与回执。 |

成功路径本身包含四轮语音交互。也可以取消勾选超时选项再打一次，验证收到回执后立即显示完成。

业务依据来自《资审关单场景话术 V1.0》的「场景汇总」。原三张样单来自第 29、79、52 行，同类规则见第 60、17、50、22 行。回执记录商家确认的下一步，后续材料提交与复审由业务方办理。

| 新增电话场景 | 工单事实与处理步骤 | 主表依据 |
| --- | --- | --- |
| 授权时间到期 | 模拟样张会显示授权方和日期。联系海棠品牌公司重开有效授权书，传回品牌申请单，再重新提交。 | 第 21 行，同类流程见第 51 行 |
| 法人证件类型 | 本单应上传身份证，误传了护照。在公司资质申请单的法人证件一栏换传身份证，再重新提交。 | 第 76 行，第 49 行为入驻环节的同类检查 |

这两张单核验身份后会直接解释原因并给出处理方案。可以问「材料要传到哪里」或「改完就能过审吗」。听到完整方案或具体整改步骤已经开始播报后，直接说「我同意按步骤修改后重新提交」。系统会结束通话并记录这张工单的确认回执。

## 回归检查

使用启动脚本采用的 Python 运行单测。

    $env:PYTHONPATH = Join-Path (Get-Location) '.runtime/packages'
    python -m unittest discover -s tests -p "test_*.py" -v

如系统没有 python 命令，可将其换成启动脚本采用的 Python 路径。测试覆盖身份校验、流程状态、语音端点检测和重试、并发与重启后的幂等性。服务运行数据在 .runtime/calls.sqlite3，依赖和模型在 .runtime/。

## 浏览器自动验收

新版用同一浏览器在空的测试库中顺序切换三张单，每张单回放 6 轮含核验的通话，验证插话、暂缓、正确方案和单条回执，并检查超时后的重复查询。另有一通未通过身份核验的电话。15 个业务轮的可听首响 P50 为 1008.7 毫秒，P95 为 1634.5 毫秒。使用的是本机合成商家录音。[三单验收结果](results/workbench-polish/final-acceptance.json)

服务运行时，可以用 Playwright 和已安装的 Edge 回放合成语音。项目本身启动只需要 Python。自动验收另外使用 Node.js 和 Playwright。Playwright 安装在其他位置时，用 JD_PLAYWRIGHT_PATH 指向其模块目录。

要验收授权到期和法人证件两张单，先沿用上面的 Python 环境生成录音，再以 DeepSeek 模式启动一个使用全新 SQLite 文件的隔离服务。

    python -m tests.make_additional_work_order_fixtures
    python -m tests.make_voice_fixtures --case-matrix --only matrix_confirm_retry --output .runtime/identity-v2-replay-fixtures
    python -m jd_mock.server --port 8826 --db .runtime/additional-work-orders/replay.sqlite3 --dialogue-mode model --llm-provider deepseek

在另一个终端运行新增场景的 WebRTC 验收。重新回放时使用新的 SQLite 文件和报告路径。

    node tests/verify_additional_work_orders.cjs http://127.0.0.1:8826 results/workbench-second-batch/replay.json

    $env:PYTHONPATH = (Get-Location).Path + ';' + (Join-Path (Get-Location) '.runtime/packages')
    python tests\make_voice_fixtures.py
    node tests\verify_browser.cjs http://127.0.0.1:8765 .runtime/verify/acceptance.png

自动验收把合成语音送入浏览器 WebRTC 麦克风音轨，经过实际的本地识别和合成，核对核验、对话轮数、停播、超时、重试回执和挂断。实际麦克风效果和正式首字时延以比赛设备和赛方口径测量。

要复核三张单，在一个单独的测试服务上回放以下录音，避免给手动演示工单增加测试回执。在项目根目录沿用上面的 Python 环境，启动 `python -m jd_mock.server --port 8771 --db .runtime/case-matrix-test.sqlite3`。在另一终端使用相同环境运行：

    python tests\make_voice_fixtures.py --case-matrix
    $env:JD_CASE_MATRIX = '1'
    $env:JD_VERIFY_RESULTS = '.runtime/case-matrix-results.json'
    node tests\verify_browser.cjs http://127.0.0.1:8771

回放先用一通电话依次播放旧数字、含糊回答和明确否认，检查前两轮继续询问商家身份，最后一轮结束通话且回执数为零。接着在同一页面换三张工单，逐通确认身份，核对各单答复、工单编号和回执，并检查重复回写只生成一条记录。若还要跑下面的单场景基准，请使用新终端，以免沿用三单回放的环境变量。

要额外验收公章追问，在上述三单回放命令前设置 `$env:JD_CASE_DIALOGUE = '1'`。浏览器会在第二张单连续播放商家说已盖章、说明盖的是自家章、询问是否一定通过的录音。报告保留每一轮实际转写和坐席回答，检查这几轮均未产生回执。

这次修改身份确认时，复测沿用了先前三单测试的业务录音，只换了身份回答。要重放同一批输入，可在运行三单回放前将 `JD_VERIFY_FIXTURES` 设为 `.runtime/identity-v2-replay-fixtures` 的绝对路径。另做新一轮时，可在生成录音的命令后加 `--reuse-business 旧录音目录`，复用其中的话术录音。

## 语音基准回放

启用基准模式会顺序运行六通电话，轮换三段插话录音。每通记录核验、需求、打断后追问和确认四轮，继续检查停播和幂等回写。模型就绪后才发起通话。固定首句和位置追问的话术在服务启动时预合成，首次启动需等预合成结束。

    $env:JD_BENCHMARK = '1'
    $env:JD_VERIFY_RUNS = '6'
    New-Item -ItemType Directory -Force .runtime\voice-benchmark | Out-Null
    $env:JD_VERIFY_RESULTS = '.runtime/voice-benchmark/current.json'
    node tests\verify_browser.cjs http://127.0.0.1:8765

用同一份 WAV 比较两个版本，生成一次录音后保留原文件。可用 JD_VERIFY_FIXTURES 指向固定的录音目录。逐轮结果保留录音 SHA-256、转写、关键词命中、浏览器渲染首音、服务端首帧和打断到静音耗时。首音以浏览器音频时钟测量，从注入录音最后一个有声窗结束到 WebRTC 下行解码后的第一个有声窗。P50/P95 对实测值线性插值，报告同时列出通话失败数。

## 复现历史实验：第一轮 RSI

第一轮实验冻结于商家名称确认上线前。代码、录音和哈希存于 .runtime/rsi-round-01。baseline.zip 可独立归档，运行所需的 Python 依赖和语音模型按上面的安装步骤准备。

冻结版本使用数字核验。同一批历史录音包含一通错误核验码通话和三通带插话的正常通话。错误码必须停留在核验阶段，零业务披露和回执。三通正常通话轮换追问录音，其中一段同时包含「鞋类」和「授权类目」，并逐通检查模拟回执超时、重试和挂断。

复现时，从本轮的 baseline 或 candidate 目录启动服务。将 PYTHONPATH 设为项目根目录下 .runtime/packages 的绝对路径，并用启动脚本采用的 Python 运行下面的命令。baseline 用 8767，candidate 用 8768，分别使用独立数据库。

    python -B -m jd_mock.server --port 8767 --models ..\..\models --db ..\baseline-replay.sqlite3
    python -B -m jd_mock.server --port 8768 --models ..\..\models --db ..\candidate-replay.sqlite3

回到项目根目录，在第二个终端顺序回放两个版本。沿用前面的 Playwright 配置。

    $jdRound = Join-Path (Get-Location) '.runtime/rsi-round-01'
    $env:JD_RSI = '1'
    $env:JD_VERIFY_FIXTURES = Join-Path $jdRound 'fixtures'
    $env:JD_VERIFY_RESULTS = Join-Path $jdRound 'baseline-results.json'
    node tests\verify_browser.cjs http://127.0.0.1:8767
    $env:JD_VERIFY_RESULTS = Join-Path $jdRound 'candidate-results.json'
    node tests\verify_browser.cjs http://127.0.0.1:8768

比较程序读取两份报告，并检查哈希、关键业务断言、术语改善和候选首响 P50。结论保存在本轮目录的 comparison.json。

    python tools\compare_rsi_round.py .runtime\rsi-round-01

可从 .runtime/rsi-round-01/baseline/jd_mock/speech.py 取回冻结的语音模块以回滚本轮改动。运行中的服务需要重启才能加载替换后的模块。
