"""Shared voice-call workflow and receipts for the selected mock audit order."""

import json
import re
import sqlite3
import unicodedata
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from uuid import uuid4

from .cases import CHAIN, DEFAULT_CASE_ID, DEMO_MERCHANT_NAME, INCOMPLETE, ORDERS, get_order
from .chain_strategy_agent import chain_facts, strategy_choice_context
from .dialogue import (
    COMMITMENT_QUESTION, accepts_offered_plan, acknowledges_plan, asks_for_commitment,
    chain_submitted_material, contradicts_plan,
    heard_commitment_plan, introduce, receipt_steps, respond, resubmission_plan, stamp_submitted_material,
)
from .stamp_evidence import is_future_upload_pledge

IDENTITY_QUESTION = f"请问您是否是商家{DEMO_MERCHANT_NAME}？"
OPENING = "您好，我是京东商家资质审核演示 AI 助手。" + IDENTITY_QUESTION
IDENTITY_END = "明白，打扰您了。本次通话到此结束，再见。"
COMPLETED = "好，我把您刚确认的处理办法记在这张工单上了。谢谢您接听，再见。"
TIMEOUT = "暂未收到回写响应，请重试查询本次回执。"
CLOSED = "好的，先不打扰您了。再见。"
END_REQUESTS = frozenset((
    "不用了", "不需要了", "我现在没空", "暂时不方便", "先到这里", "就到这里", "请挂断", "挂断",
    "挂了", "没有别的问题了", "没有其他问题了", "没有别的事了",
))
STAMP_CLARIFICATION = "盖章这一步我想再确认一下。"
STAMP_HOLD = "我先不登记。您还有哪一步想核实？"
FIRST_REPLY_TEMPLATES = (
    OPENING, IDENTITY_QUESTION, IDENTITY_END, COMPLETED, TIMEOUT, "刚才没听清，请再说一遍。", STAMP_CLARIFICATION, STAMP_HOLD,
    *(introduce(order)[0] for order in ORDERS.values()),
    *(order.reason for order in ORDERS.values()),
)
IDENTITY_FOLLOWUP = re.compile(r"我想(?:了解|知道|问)|请问|为什么|为啥|我已经|我找不到|我没找到|请说|请讲")
MERCHANT = rf"(?:商家)?{re.escape(DEMO_MERCHANT_NAME)}"
IDENTITY_YES = re.compile(
    rf"(?:嗯|喂|您好|你好)*(?:(?:(?:是的?|对的?|没错)(?:我(?:就)?是)?|我(?:就)?是|是我)"
    rf"(?:{MERCHANT}(?:本人)?|我?本人)?|我叫{MERCHANT})(?:啊|呀)?"
)
# Keep homophones and dropped syllables confined to denials naming the merchant role.
DENIAL_NAMES_WITH_ROLE = "|".join(re.escape(name).replace("贝", "[贝倍辈背]") for name in (
    DEMO_MERCHANT_NAME,
    *(DEMO_MERCHANT_NAME[:i] + DEMO_MERCHANT_NAME[i + 1:] for i in range(1, len(DEMO_MERCHANT_NAME))),
))
IDENTITY_NO = re.compile(
    rf"(?:嗯|不是的?|是的)?(?:我(?:真|确实)?)?不是"
    rf"(?:的|本人|我|[您你]找的人|(?:(?:商家|上家)(?:{DENIAL_NAMES_WITH_ROLE})|{re.escape(DEMO_MERCHANT_NAME)})(?:本人)?)?[啊呀]?"
)
WRONG_RECIPIENT = re.compile(
    rf"(?:打错|找错)(?:了|人|电话|号码)"
    rf"|(?:我|这边)(?:替|帮|代)(?:他|她|别人|朋友|同事|老板).{{0,4}}接|代接"
    rf"|(?<!不)是(?:他|她|{MERCHANT})(?:的)?(?:同事|朋友|家人|助理)(?:接|代接|$)"
)
UNCERTAIN_IDENTITY = ("?", "吗", "吧", "是否", "是不是", "不确定", "不清楚", "不知道", "不一定",
                      "没听清", "可能", "好像", "如果", "假如", "假设", "应该")
SKIPS_REMEDIATION = re.compile(
    r"(?:不(?:想|愿意|愿|打算|用|必|需要|准备)?|无需|没必要|没(?:有)?|尚未)(?:先|再)?"
    r"(?:按|照|修改|调整|勾选|选择|改|选|补|盖|找|联系|上传|提供|处理)"
    r"|(?:按|照|保持|维持)原样|原样(?:重新提交|重提)|跳过(?:整改|盖章|补)"
)
SPOKEN_PLAN_ASSENT = re.compile(
    r"(?:好[的啊]?|行|可以|没问题)?(?:那)?(?:我|我们)?(?:同意|确认|决定|会)?(?:就)?"
    r"(?:按|按照|照)(?:(?:[您你](?:刚才)?说的|刚才说的|这个|这套)(?:办法|方法|方案|步骤)?|步骤)"
    r"(?:来)?(?:处理|办|做|整改|修改)(?:(?:好|完)?(?:后|再)(?:重新提交|提交|重提))?(?:吧|了)?"
)

# A merchant may state the entire remedy even if the previous question was
# about ownership. Match the whole statement: a quoted plan or a qualification
# at the end cannot silently authorize a receipt.
STAMP_PLEDGE = (
    r"(?:嗯|好的?|行|可以|没问题)?(?:那)?(?:我(?:们)?(?:这边)?(?:确认|同意|愿意|决定|会|将|就)"
    r"|(?:确认|同意|愿意)|我(?:们)?(?:这就|马上|现在|回去就))"
    r"(?:按(?:照)?(?:您|你)?(?:刚才?|刚刚)?说的(?:办法|方案|步骤))?(?:先)?"
)
STAMP_DOCUMENT = r"(?:这份|那份|一份)?(?:完整的?|盖好章的?)?(?:销售)?(?:授权书|材料|文件|申请单|申请)"
STAMP_SUBMIT = (
    r"(?:以后|之后|然后|后|好)?(?:我(?:们)?)?(?:再)?"
    rf"(?:把{STAMP_DOCUMENT})?(?:(?:传回|上传)(?:到)?(?:商品申请单|申请单|后台)?(?:后|并|再)?)?"
    rf"(?:重新提交|重提|再次提交|再提交|提交)(?:{STAMP_DOCUMENT})?(?:了)?"
)
STAMP_EXPLICIT_YES = {"同意办理", "我同意办理", "同意按这个办法办理", "我愿意按这个方案办理", "我接受这个方案"}
STAMP_VOICE_CONFLICT = re.compile(r"(?:不该|不盖|不补)(?:[这那枚个颗的授权方品牌公司公印重]{0,6})(?:章|印)")
STAMP_NONCOMMIT = re.compile(r"[?？“”「」]|(?:不|没|别|未|假如|如果|除非|万一|要是|再说|考虑|也许|可能|或许|好像|似乎|"
                             r"好险|差点|差一点|本来|原本|原先|对方说|别人说|"
                             r"商量|问问|问一|打听|咨询|了解|看看|看一|核实|确定一下|确认一下|"
                             r"听说|据说|他说|她说|你说我|您说我|你是说|您是说|能否|能不能|是否|要不要|吗|么|呢|谁|怎么|等一下|稍等|旧照|旧件|原样|"
                             r"举例|上次|上个月|以前|之前|曾经|早就|(?:提交|上传|传回|重交)过|(?:已经|早已).{0,3}(?:提交|上传))")
STAMP_PERSONAL = re.compile(r"^(?:嗯|好(?:的)?|行|那|可以|对|没问题|明白了?|知道了|收到)*(?:我(?:们)?(?:这边)?(?:答应|确认|同意|决定|会|愿意|按|照|就|去|打算|准备|马上|这就|接受)|同意|愿意|答应|就按|就照)")
STAMP_DELIVERY = re.compile(r"上传|提交|重交|重传|重提|传回|交回|传上去|传上来|交上去")
STAMP_AFFIRMATIVE_ONSET = re.compile(
    r"^(?:[对好行嗯呃哦]|可以)[\u4e00-\u9fff]?(?=我(?:们)?(?:这边)?(?:就|会|愿意))"
)


def _stamp_receipt_basis(text, order, current, previous, choice):
    if choice.source != "model" or not current["verified"] or current["state"] not in {"need", "explain"}:
        return "", ""
    grantor = rf"(?:授权方|品牌方|{re.escape(order.facts['grantor'])})"
    stamp = r"(?:公章|印章|章)"
    get_stamp = (
        rf"(?:(?:去)?(?:请|找|让|联系){grantor}(?:在(?:这份)?授权书上)?(?:重新)?(?:补盖|盖好|盖上|加盖|盖){stamp}"
        rf"|(?:补盖|盖好|补好|补齐|加盖){grantor}的?{stamp})"
    )
    if re.fullmatch(STAMP_PLEDGE + get_stamp + STAMP_SUBMIT, text):
        return "explicit_remedy", "request_stamp"
    # The model handles wording variation. A self-contained pledge still needs
    # an unqualified speaker commitment, the named grantor and both actions.
    words = text.removeprefix("没问题")
    unqualified = (not STAMP_NONCOMMIT.search(words) and not order.contradicts_action(text)
                   and not _contains(text, ("经销商", "代理商", "供货商", "自己盖", "同事盖", "先问", "再问")))
    model_pledge = choice.action == "record" and choice.consent and unqualified and STAMP_PERSONAL.match(text)
    if model_pledge and STAMP_DELIVERY.search(text) and re.search(
        rf"{grantor}.{{0,8}}(?:盖|用印).{{0,3}}(?:章|印)|(?:补盖|加盖|盖好|补齐){grantor}的?{stamp}", text
    ):
        return "explicit_remedy", "request_stamp"
    plan = previous.get("plan")
    if not previous.get("plan_offered") or plan not in {"request_stamp", "upload"} or not asks_for_commitment(current["reply"]):
        return "", ""
    if accepts_offered_plan(text) or text in STAMP_EXPLICIT_YES or SPOKEN_PLAN_ASSENT.fullmatch(text):
        return "accepted_spoken_plan", plan
    # A noisy syllable after an affirmative lead cannot invalidate an intact
    # first-person commitment tied to the offer. Check the entire statement
    # for qualifications, then check the whole commitment clause.
    onset = STAMP_AFFIRMATIVE_ONSET.match(text)
    if unqualified and onset and accepts_offered_plan(text[onset.end():]):
        return "accepted_spoken_plan", plan
    if model_pledge and re.search(r"(?:按|照)(?:照)?(?:您说的|你说的|您刚说的|你刚说的|刚才的|刚才说的|这个|这套)(?:办法|方案|步骤)?(?:来|去)?(?:做|办|改|处理|操作|落实)", text):
        return "accepted_spoken_plan", plan
    if (plan == "request_stamp" and model_pledge and STAMP_DELIVERY.search(text)
            and re.search(r"(?:补好|补齐|补盖|盖好|补上)(?:该有的|公|印)?章", text)
            and not re.search(r"请|让|找|联系|公司|单位|代理|经销|店|别家|别的|代盖", text)):
        return "accepted_spoken_plan", plan
    if plan == "upload" and previous.get("owner") == "grantor":
        if choice.action == "record" and choice.consent and is_future_upload_pledge(text):
            return "accepted_upload", plan
        if model_pledge and STAMP_DELIVERY.search(text) and ("授权书" in text or "盖好" in text):
            return "accepted_upload", plan
        if re.fullmatch(STAMP_PLEDGE + rf"(?:把{STAMP_DOCUMENT})?(?:重新上传|上传|传回)(?:后|并|再)?" + STAMP_SUBMIT, text):
            return "accepted_upload", plan
    return "", ""


def _submitted_stamp_trace(order, text, reply):
    context = {
        "owner": "merchant", "handler": "unknown", "action": "request_stamp",
        "plan": "request_stamp", "plan_offered": True,
        "owner_evidence": order.submitted_authorization["seal"], "owner_source": "submitted_material",
    }
    return {
        "text": text, "reply": reply, "owner": "merchant", "handler": "unknown",
        "action": "request_stamp", "applied_action": "request_stamp", "source": "policy",
        "latency_ms": 0, "error": None, "context": context, "evidence_refs": list(order.evidence),
    }


def _contains(text, phrases):
    return any(phrase in text for phrase in phrases)


def _normalize(text):
    return unicodedata.normalize("NFKC", text).strip()


def _verify_identity(text):
    clauses = re.split(r"[,。.!;；、]+", re.sub(r"\s+", "", text))
    for clause in clauses:
        if _contains(clause, UNCERTAIN_IDENTITY):
            continue
        if _contains(clause, ("不方便", "拒绝核验", "不想确认身份", "不愿确认身份", "不想验证")):
            return "closed", ""
        if WRONG_RECIPIENT.search(clause) or IDENTITY_NO.fullmatch(clause):
            return "closed", ""
        other = re.fullmatch(r"(?:我叫|我是商家|我的名字是)([\u4e00-\u9fff]{2,8})", clause)
        if other and other[1] not in (DEMO_MERCHANT_NAME, DEMO_MERCHANT_NAME + "本人"):
            return "closed", ""

    joined = "".join(clauses)
    boundary = IDENTITY_FOLLOWUP.search(joined)
    end = boundary.start() if boundary else len(joined)
    if IDENTITY_YES.fullmatch(joined[:end]):
        request = joined[end:]
        if re.search(r"(?:是不是|是否是|不是)(?:商家|本人|小贝塔)", request):
            return "verify", ""
        return "need", request
    return "verify", ""


def _confirms_action(text, order, last_reply):
    has_offer = asks_for_commitment(last_reply)
    if accepts_offered_plan(text):
        return has_offer
    questions_or_conditions = (
        "?", "吗", "呢", "么", "哪", "谁", "如何", "是否", "能否",
        "能不能", "如果", "万一", "只要", "前提", "但是", "不过",
        "考虑", "再决定", "要不要", "再说", "之前", "怎么", "等等", "等一下",
        "先问", "问问", "先核实", "先商量", "商量过", "已提交", "已经重新提交", "提交过",
    )
    refusals = (
        "不确认", "不接受", "不同意", "不改", "不会", "不想", "不打算", "不愿",
        "没法", "不方便", "不能", "不准备", "拒绝", "不提交", "未确认", "取消", "算了", "不是确认",
        "先别", "别记", "暂不", "别登记", "不用登记",
    )
    if _contains(text, questions_or_conditions) or _contains(text, refusals):
        return False
    for other in ORDERS.values():
        if other.procedure is not order.procedure and _contains(text, (other.render(term) for term in other.procedure.action_terms)):
            return False
    agreement = re.match(r"^(?:好的?|行|我?明白了|我?知道了)?(?:那)?(?:我)?(?:确认|同意|会|按|就按|将|愿意|要按)", text)
    concrete_action = re.search(r"改|勾选|调整|选择|删|去掉|保留|授权|上传|盖|补", text)
    return bool(agreement) and (has_offer or bool(concrete_action)) and _contains(text, ("重新提交", "重提", "再提交"))


class Store:
    """Persist call state and its single writeback receipt in SQLite."""

    def __init__(self, db_path, stamp_agent=None, case_agent=None, *, chain_agent=None, strategy_library=None):
        self._db_path = db_path
        self.stamp_agent = stamp_agent
        self.case_agent = case_agent
        self.chain_agent = chain_agent
        self.strategy_library = strategy_library
        with self._connection() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS calls (
                    call_id TEXT PRIMARY KEY,
                    state TEXT NOT NULL,
                    reply TEXT NOT NULL,
                    verified INTEGER NOT NULL DEFAULT 0,
                    turn_count INTEGER NOT NULL DEFAULT 0,
                    dialogue_focus TEXT NOT NULL DEFAULT '',
                    pending_writeback INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS turns (
                    call_id TEXT NOT NULL REFERENCES calls(call_id),
                    turn_id TEXT NOT NULL,
                    PRIMARY KEY (call_id, turn_id)
                );
                CREATE TABLE IF NOT EXISTS receipts (
                    call_id TEXT PRIMARY KEY REFERENCES calls(call_id),
                    payload TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS stamp_decisions (
                    call_id TEXT NOT NULL,
                    turn_id TEXT NOT NULL,
                    trace TEXT NOT NULL,
                    PRIMARY KEY (call_id, turn_id),
                    FOREIGN KEY (call_id, turn_id) REFERENCES turns(call_id, turn_id)
                );
                CREATE TABLE IF NOT EXISTS dialogue_decisions (
                    call_id TEXT NOT NULL,
                    turn_id TEXT NOT NULL,
                    trace TEXT NOT NULL,
                    PRIMARY KEY (call_id, turn_id),
                    FOREIGN KEY (call_id, turn_id) REFERENCES turns(call_id, turn_id)
                );
                CREATE TABLE IF NOT EXISTS strategy_qa (
                    call_id TEXT NOT NULL,
                    turn_id TEXT NOT NULL,
                    question TEXT NOT NULL,
                    expected_reply TEXT NOT NULL,
                    spoken_reply TEXT NOT NULL DEFAULT '',
                    evidence TEXT NOT NULL,
                    PRIMARY KEY (call_id, turn_id),
                    FOREIGN KEY (call_id, turn_id) REFERENCES turns(call_id, turn_id)
                );
                """
            )
        # Calls created by the single-case version all belong to the category order.
        # Serialize the schema check and ALTER if two services open an old file at once.
        with self._connection(write=True) as connection:
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(calls)")}
            if "case_id" not in columns:
                connection.execute("ALTER TABLE calls ADD COLUMN case_id TEXT NOT NULL DEFAULT 'JD-DEMO-001'")
            if "dialogue_focus" not in columns:
                connection.execute("ALTER TABLE calls ADD COLUMN dialogue_focus TEXT NOT NULL DEFAULT ''")

    @contextmanager
    def _connection(self, *, write=False):
        with closing(sqlite3.connect(self._db_path, timeout=10)) as connection, connection:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            if write:
                connection.execute("BEGIN IMMEDIATE")
            yield connection

    def _snapshot(self, connection, call_id):
        row = connection.execute(
            """
            SELECT calls.*, receipts.payload
            FROM calls LEFT JOIN receipts USING (call_id)
            WHERE call_id = ?
            """,
            (call_id,),
        ).fetchone()
        if row is None:
            raise KeyError(call_id)

        snapshot = dict(row)
        payload = snapshot.pop("payload")
        if snapshot["state"] == "verify":
            # An old, still-open call may contain a saved prompt from the previous identity flow.
            snapshot["reply"] = OPENING if snapshot["turn_count"] == 0 else IDENTITY_QUESTION
        snapshot["verified"] = bool(snapshot["verified"])
        snapshot["pending_writeback"] = bool(snapshot["pending_writeback"])
        snapshot["receipt_count"] = int(payload is not None)
        procedure = get_order(snapshot["case_id"]).procedure
        snapshot["scenario"] = procedure.scenario
        if self.chain_agent and procedure is CHAIN:
            snapshot["completed_qa_count"] = self._qa_count(connection, call_id)
        if self.stamp_agent and procedure is INCOMPLETE:
            last = connection.execute(
                "SELECT trace FROM stamp_decisions WHERE call_id = ? ORDER BY rowid DESC LIMIT 1", (call_id,)
            ).fetchone()
            snapshot["stamp_decision"] = json.loads(last["trace"]) if last else None
        elif self.case_agent and procedure is not INCOMPLETE:
            last = connection.execute(
                "SELECT trace FROM dialogue_decisions WHERE call_id = ? ORDER BY rowid DESC LIMIT 1", (call_id,)
            ).fetchone()
            snapshot["dialogue_decision"] = json.loads(last["trace"]) if last else None
        snapshot["receipt"] = (
            self._decode_receipt(payload, snapshot["case_id"])
            if payload and not snapshot["pending_writeback"] else None
        )
        return snapshot

    @staticmethod
    def _qa_count(connection, call_id):
        return connection.execute(
            "SELECT COUNT(*) FROM strategy_qa WHERE call_id=? AND spoken_reply<>''", (call_id,),
        ).fetchone()[0]

    def record_spoken_reply(self, call_id, turn_id, reply):
        """Publish the fully delivered sentences for an audio turn."""
        with self._connection(write=True) as connection:
            row = connection.execute(
                "SELECT expected_reply, spoken_reply FROM strategy_qa WHERE call_id=? AND turn_id=?",
                (call_id, turn_id),
            ).fetchone()
            if row and reply:
                compact = re.sub(r"\s+", "", reply)
                expected = re.sub(r"\s+", "", row["expected_reply"])
                if expected.startswith(compact) and len(reply) > len(row["spoken_reply"]):
                    connection.execute(
                        "UPDATE strategy_qa SET spoken_reply=? WHERE call_id=? AND turn_id=?",
                        (reply, call_id, turn_id),
                    )
            return self._qa_count(connection, call_id)

    @staticmethod
    def _spoken_qa(connection, call_id, *, limit=None):
        rows = connection.execute(
            """SELECT question, spoken_reply, evidence FROM strategy_qa
               WHERE call_id=? AND spoken_reply<>'' ORDER BY rowid DESC LIMIT ?""",
            (call_id, limit if limit is not None else -1),
        ).fetchall()
        return [
            dict(turn_id=f"QA_{index}", question=row["question"], answer=row["spoken_reply"],
                 **json.loads(row["evidence"]))
            for index, row in enumerate(reversed(rows), 1)
        ]

    def evolution_snapshot(self, call_id):
        with self._connection() as connection:
            call = self._snapshot(connection, call_id)
            order = get_order(call["case_id"])
            if not self.chain_agent or order.procedure is not CHAIN:
                raise ValueError("当前仅授权链路不完整工单支持自主进化。")
            qa = self._spoken_qa(connection, call_id)
            if not qa:
                raise ValueError("需等待至少一轮问答播报后再开始自主进化。")
            return {"call_id": call_id, "scene": CHAIN.scenario, "opening": OPENING,
                    "facts": chain_facts(order, verified=call["verified"]), "qa": qa}

    @staticmethod
    def _decode_receipt(payload, case_id):
        receipt = json.loads(payload)
        receipt.setdefault("case_id", case_id)
        return receipt

    def start_call(self, case_id=DEFAULT_CASE_ID):
        get_order(case_id)
        call_id = uuid4().hex
        with self._connection(write=True) as connection:
            connection.execute(
                "INSERT INTO calls (call_id, case_id, state, reply) VALUES (?, ?, 'verify', ?)",
                (call_id, case_id, OPENING),
            )
            return self._snapshot(connection, call_id)

    def case_receipts(self, case_id):
        get_order(case_id)
        with self._connection() as connection:
            row = connection.execute(
                """
                SELECT receipts.payload, COUNT(*) OVER () AS receipt_count
                FROM receipts JOIN calls USING (call_id)
                WHERE calls.case_id = ? AND calls.pending_writeback = 0
                ORDER BY receipts.rowid DESC LIMIT 1
                """,
                (case_id,),
            ).fetchone()
        return {
            "case_id": case_id,
            "receipt_count": row["receipt_count"] if row else 0,
            "latest_receipt": self._decode_receipt(row["payload"], case_id) if row else None,
        }

    def get_call(self, call_id):
        with self._connection() as connection:
            return self._snapshot(connection, call_id)

    def turn(self, call_id, text, turn_id, *, simulate_timeout=False, cancelled=None,
             delivered_reply=None, started_plan="", raw_text=None):
        if not isinstance(text, str) or not text.strip():
            raise ValueError("请提供本轮通话内容。")
        if not isinstance(turn_id, str) or not turn_id.strip():
            raise ValueError("请提供本轮通话标识。")

        while True:
            with self._connection() as connection:
                current = self._snapshot(connection, call_id)
                seen = connection.execute("SELECT 1 FROM turns WHERE call_id=? AND turn_id=?", (call_id, turn_id)).fetchone()
                order = get_order(current["case_id"])
                record_qa = bool(self.chain_agent and order.procedure is CHAIN)
                history = []
                if record_qa:
                    history.append({"role": "assistant", "content": OPENING})
                    for qa in self._spoken_qa(connection, call_id, limit=4):
                        history.extend(({"role": "user", "content": qa["question"]},
                                        {"role": "assistant", "content": qa["answer"]}))
            if seen or current["state"] in {"complete", "closed"} or (cancelled and cancelled()):
                return current
            (state, reply, verified, focus), trace = self._advance(
                current, text, order, delivered_reply, started_plan, raw_text=raw_text, history=history,
            )
            # Model I/O runs outside the transaction. Re-check the input state
            # before committing, so a hangup or concurrent turn wins cleanly.
            with self._connection(write=True) as connection:
                fresh = self._snapshot(connection, call_id)
                if fresh["state"] in {"complete", "closed"} or (cancelled and cancelled()):
                    return fresh
                if (fresh["turn_count"], fresh["state"]) != (current["turn_count"], current["state"]):
                    continue
                inserted = connection.execute(
                    "INSERT INTO turns (call_id, turn_id) VALUES (?, ?) ON CONFLICT DO NOTHING", (call_id, turn_id)
                )
                if not inserted.rowcount:
                    return fresh
                if trace is not None:
                    trace["turn_id"] = turn_id
                    if raw_text is not None:
                        trace["raw_text"] = raw_text
                    table = "stamp_decisions" if order.procedure is INCOMPLETE else "dialogue_decisions"
                    connection.execute(f"INSERT INTO {table} VALUES(?,?,?)",
                                       (call_id, turn_id, json.dumps(trace, ensure_ascii=False)))
                pending = state == "complete" and bool(simulate_timeout)
                if state == "complete":
                    self._write_receipt(connection, call_id, turn_id, order, focus, trace)
                reply = TIMEOUT if pending else reply
                if record_qa and reply:
                    evidence = {"facts": chain_facts(order, verified=verified),
                                "strategies": ((trace or {}).get("retrieval") or {}).get("strategies", [])}
                    connection.execute(
                        "INSERT INTO strategy_qa VALUES (?, ?, ?, ?, ?, ?)",
                        (call_id, turn_id, raw_text if raw_text is not None else text, reply,
                         reply if delivered_reply is None else "", json.dumps(evidence, ensure_ascii=False)),
                    )
                connection.execute(
                    """UPDATE calls SET state=?, reply=?, verified=?, turn_count=turn_count+1,
                       pending_writeback=?, dialogue_focus=? WHERE call_id=?""",
                    (state, reply, verified, pending, focus, call_id),
                )
                snapshot = self._snapshot(connection, call_id)
                if self.strategy_library or self.chain_agent:
                    snapshot["strategy_retrieval"] = (trace or {}).get("retrieval")
                return snapshot

    def _retrieve_strategy(self, order, text, last_reply):
        if self.strategy_library is None or order.procedure is CHAIN:
            return None
        material = order.submitted_material if order.procedure.material_title else order.submitted_authorization
        facts = {
            **order.facts,
            "identity_verified": True,
            "review_phase": "未重新提交",
            "application": order.render("{application}"),
            "material_context": f"{material['title']}。{order.reason}",
            "submitted_material": material,
        }
        history = [{"role": "assistant", "content": last_reply}] if last_reply else ()
        try:
            return self.strategy_library.retrieve(text, facts=facts, history=history, scene=order.procedure.scenario)
        except sqlite3.Error:
            return {"query": text, "strategies": [], "reason": "strategy_unavailable"}

    def _advance(self, current, text, order, delivered_reply=None, started_plan="", *, raw_text=None, history=()):
        # Identity, ending the call and consent must use the original ASR output.
        normalized = _normalize(raw_text if raw_text is not None else text)
        utterance = re.sub(r"[\s,。.!、]+", "", normalized)
        business_utterance = utterance if raw_text is None else re.sub(r"[\s,。.!、]+", "", _normalize(text))
        state = current["state"]
        verified = current["verified"]
        focus = current["dialogue_focus"]
        plan_started = bool(started_plan and started_plan == current["reply"] and asks_for_commitment(started_plan))
        if utterance in END_REQUESTS or _contains(utterance, (
            "结束通话", "先挂了", "再见", "不方便接电话", "不方便说话", "我在开会", "别再打了",
        )):
            return ("closed", CLOSED, verified, focus), None

        if state == "verify":
            identity, request = _verify_identity(normalized)
            if identity == "closed":
                return ("closed", IDENTITY_END, False, focus), None
            if identity == "verify":
                return ("verify", IDENTITY_QUESTION, False, focus), None
            reply, focus = introduce(order)
            stamp_trace = (_submitted_stamp_trace(order, normalized, reply)
                           if self.stamp_agent and order.procedure is INCOMPLETE else None)
            if not request or request in {"请说", "请讲"}:
                return ("explain" if asks_for_commitment(reply) else "need", reply, True, focus), stamp_trace
            if stamp_trace:
                # The submitted facts are available to answer a question in the
                # identity turn. Its plan has not spoken yet.
                stamp_trace["context"]["plan_offered"] = False
                current = dict(current, stamp_decision=stamp_trace)
            utterance = request
            business_utterance = request

        if self.stamp_agent and order.procedure is INCOMPLETE:
            if (focus == "stamp_hold" and current["reply"].endswith("您还有哪一步想核实？")
                    and (delivered_reply is None or delivered_reply == current["reply"])
                    and utterance in {"没有", "没有了", "没了", "没问题了", "没有其他问题", "没有其他问题了"}):
                return ("closed", CLOSED, verified, focus), None
            return self._stamp_turn(
                current, request if state == "verify" else text, order, delivered_reply, plan_started,
                raw_text=raw_text if state != "verify" else None,
            )
        use_model = bool(self.case_agent and order.procedure is not INCOMPLETE)
        references_offer = accepts_offered_plan(utterance)
        previous = (current.get("dialogue_decision") or {}).get("context", {})
        if use_model:
            # The receipt must describe the plan the merchant accepted. A
            # partial restatement can introduce conditions or another remedy.
            agrees = state == "explain" and (
                (references_offer and asks_for_commitment(current["reply"]))
                or bool(SPOKEN_PLAN_ASSENT.fullmatch(utterance))
            )
        else:
            agrees = state == "explain" and _confirms_action(utterance, order, current["reply"])
        # A model can explain a remedy, but consent must follow a confirmation
        # proposal that binds to the correct call state and the transmitted audio.
        unheard_assent = (agrees and (references_offer or use_model) and delivered_reply is not None
                          and not plan_started and not heard_commitment_plan(current["reply"], delivered_reply))
        if (state == "explain" and asks_for_commitment(current["reply"])
                and (unheard_assent or acknowledges_plan(utterance))):
            reply = current["reply"]
            if order.procedure is CHAIN:
                reply = reply.removeprefix(chain_submitted_material(order))
            return ("explain", reply, True, focus), None
        readings = (utterance,) if raw_text is None else (utterance, business_utterance)
        skipping = any(SKIPS_REMEDIATION.search(reading) and _contains(reading, ("提交", "重提"))
                       for reading in readings)
        if order.procedure.offer and (skipping or any(order.contradicts_action(reading) for reading in readings)):
            reply, focus = resubmission_plan(order)
            return ("explain", reply, True, focus), None
        invalid_remedy = skipping or (agrees and any(contradicts_plan(order, reading, focus) for reading in readings))
        if invalid_remedy:
            business_utterance = "我到底要改什么"
        elif agrees:
            if use_model and not asks_for_commitment(current["reply"]):
                if order.procedure.offer:
                    reply, focus = resubmission_plan(order)
                    return ("explain", reply, True, focus), None
                reply = "".join(receipt_steps(order, focus)) + COMMITMENT_QUESTION
                return ("explain", reply, True, focus), None
            if use_model:
                trace = dict(text=raw_text if raw_text is not None else text,
                             reply=COMPLETED, focus=focus, action="record", applied_action="record",
                             source="policy", latency_ms=0, error=None, evidence_refs=list(order.evidence),
                             context=previous, previous_plan_started=plan_started,
                             previous_plan_sent=heard_commitment_plan(current["reply"], delivered_reply))
                return ("complete", COMPLETED, True, focus), trace
            return ("complete", COMPLETED, True, focus), None
        if use_model:
            case_text = request if state == "verify" else text
            retrieval = None
            if self.chain_agent and order.procedure is CHAIN and not invalid_remedy:
                choice, retrieval = self.chain_agent.decide(
                    order, case_text, focus, current["reply"], context=previous, history=history,
                    raw_question=raw_text if raw_text is not None else text,
                )
            else:
                if not invalid_remedy:
                    last_heard = current["reply"] if delivered_reply is None else delivered_reply
                    retrieval = self._retrieve_strategy(order, case_text, last_heard)
                guidance = strategy_choice_context(retrieval)
                strategy_options = {"strategy_context": guidance} if guidance else {}
                choice = self.case_agent.decide(order, case_text, focus, current["reply"],
                                                context=previous, **strategy_options)
                if retrieval is not None and choice.source != "model":
                    retrieval = dict(retrieval, strategies=[], reason="strategy_answer_unavailable")
            trace = dict(text=case_text, reply=choice.reply, focus=choice.focus, action=choice.action,
                         applied_action=choice.action, model_action=choice.model_action, source=choice.source,
                         latency_ms=choice.latency_ms, error=choice.error, evidence_refs=list(choice.evidence_refs),
                         context=choice.context)
            if retrieval is not None:
                trace["retrieval"] = retrieval
            return ("explain", choice.reply, True, choice.focus), trace
        reply, next_focus = respond(order, business_utterance, focus)
        return ("explain", reply, True, next_focus), None

    def _stamp_turn(self, current, text, order, delivered_reply, plan_started, *, raw_text=None):
        prior_decision = current.get("stamp_decision") or {}
        previous = prior_decision.get("context", {})
        policy_text = raw_text if raw_text is not None else text
        utterance = re.sub(r"[\s,。.!、]+", "", _normalize(policy_text))
        corrected_conflict = raw_text is not None and order.contradicts_action(_normalize(text))
        spoken_in_full = delivered_reply == current["reply"] if delivered_reply is not None else None
        plan_heard = heard_commitment_plan(current["reply"], delivered_reply) if delivered_reply is not None else None
        active_plan = (current["state"] == "explain" and current["verified"] and asks_for_commitment(current["reply"])
                       and previous.get("plan_offered") and previous.get("plan") in {"upload", "request_stamp"})
        simple_assent = not corrected_conflict and (accepts_offered_plan(utterance) or utterance in STAMP_EXPLICIT_YES
                                                    or SPOKEN_PLAN_ASSENT.fullmatch(utterance))
        if active_plan and simple_assent and (plan_started or plan_heard):
            context = dict(previous, action="record", plan_offered=False)
            trace = {
                "text": policy_text, "reply": COMPLETED, "owner": context.get("owner", prior_decision.get("owner")),
                "handler": context.get("handler", prior_decision.get("handler")),
                "action": "record", "applied_action": "record", "source": "policy",
                "receipt_basis": "accepted_spoken_plan", "previous_reply_sent_in_full": spoken_in_full,
                "previous_plan_started": plan_started, "previous_plan_sent": plan_heard,
                "latency_ms": 0, "error": None, "context": context,
                "evidence_refs": prior_decision.get("evidence_refs", list(order.evidence)),
            }
            return ("complete", COMPLETED, True, "stamp_record"), trace
        if (active_plan and previous.get("owner_source") == "submitted_material"
                and (simple_assent or acknowledges_plan(utterance))):
            # Acknowledging the submitted facts is not agreement to a remedy.
            plan = previous["plan"]
            reply = current["reply"].removeprefix(stamp_submitted_material(order))
            trace = dict(prior_decision, text=policy_text, reply=reply, action=plan, applied_action=plan,
                         source="policy", receipt_basis="", previous_reply_sent_in_full=spoken_in_full,
                         previous_plan_started=plan_started, previous_plan_sent=plan_heard,
                         latency_ms=0, error=None)
            trace.pop("retrieval", None)
            return ("explain", reply, True, "stamp_" + plan), trace

        last_heard = current["reply"] if delivered_reply is None else delivered_reply
        retrieval = self._retrieve_strategy(order, text, last_heard)
        guidance = strategy_choice_context(retrieval)
        strategy_options = {"strategy_context": guidance} if guidance else {}
        choice = self.stamp_agent.decide(order, text, previous, current["reply"], **strategy_options)
        applied = choice.action
        reply = choice.reply
        context = dict(choice.context)
        basis, plan = _stamp_receipt_basis(utterance, order, current, previous, choice)
        if corrected_conflict:
            basis, plan = "", ""
        refers_to_plan = basis in {"accepted_spoken_plan", "accepted_upload"}
        needs_confirmation = (
            not basis and previous.get("plan_offered") and previous.get("plan") in {"upload", "request_stamp"}
            and asks_for_commitment(current["reply"])
            and (accepts_offered_plan(utterance) or acknowledges_plan(utterance)
                 or (choice.action == "record" and not STAMP_NONCOMMIT.search(utterance)
                     and not order.contradicts_action(utterance)))
        )
        if refers_to_plan or needs_confirmation:
            for field in ("owner", "handler", "owner_evidence", "handler_evidence"):
                if field in previous:
                    context[field] = previous[field]
        if (refers_to_plan and plan_heard is False and not plan_started) or needs_confirmation:
            # Repeat only when the offer never reached the caller or assent is ambiguous.
            applied = previous["plan"]
            reply, basis = current["reply"].removeprefix(stamp_submitted_material(order)), ""
            context.update(action=applied, plan=applied, plan_offered=True)
        elif basis:
            applied, reply = "record", COMPLETED
            context.update(action=applied, plan=plan, plan_offered=False)
        elif (choice.source == "model" and STAMP_PERSONAL.match(utterance)
              and STAMP_VOICE_CONFLICT.search(utterance) and STAMP_DELIVERY.search(utterance)):
            applied = "clarify_stamp"
            reply = STAMP_CLARIFICATION + order.render("这张单需要找{grantor}盖好公章，再提交完整授权书。") + COMMITMENT_QUESTION
            context.update(action=applied, plan="request_stamp", plan_offered=True)
        elif choice.action == "record":
            applied, reply = "hold", STAMP_HOLD
            context.update(action=applied, plan="", plan_offered=False)
        trace = {
            "text": policy_text if applied == "record" else text,
            "reply": reply, "owner": context.get("owner", choice.owner),
            "handler": context.get("handler", choice.handler),
            "action": choice.action, "applied_action": applied, "source": choice.source,
            "receipt_basis": basis, "previous_reply_sent_in_full": spoken_in_full,
            "previous_plan_started": plan_started, "previous_plan_sent": plan_heard,
            "latency_ms": choice.latency_ms, "error": choice.error, "context": context,
            "evidence_refs": list(choice.evidence_refs),
        }
        if retrieval is not None:
            trace["retrieval"] = retrieval if choice.source == "model" else dict(
                retrieval, strategies=[], reason="strategy_answer_unavailable",
            )
        state = "complete" if applied == "record" else "explain"
        return (state, reply, True, "stamp_" + applied), trace

    @staticmethod
    def _write_receipt(connection, call_id, turn_id, order, focus, trace=None):
        payload = {
            "receipt_id": uuid4().hex,
            "call_id": call_id,
            "case_id": order.case_id,
            "scenario": order.procedure.scenario,
            "subject": order.title,
            "verified": True,
            "reason": order.reason,
            "action_steps": receipt_steps(order, focus),
            "confirmation": "商家确认按步骤修改后重新提交",
            "confirmation_turn_id": turn_id,
            "channel": "电话",
            "evidence_refs": order.evidence,
            "recorded_at": datetime.now(timezone.utc).isoformat(),
        }
        context = trace.get("context", {}) if trace else {}
        if context.get("plan") == "upload":
            payload["action_steps"] = [order.render("核对现有完整授权书上的公章全称为{grantor}。"), *order.steps[1:]]
        if focus.startswith("category_extra_") and context.get("document") == "available":
            payload["action_steps"] = payload["action_steps"][1:]
        if trace:
            payload["evidence_refs"] = trace["evidence_refs"]
            payload["confirmation_text"] = trace["text"]
        connection.execute(
            "INSERT INTO receipts (call_id, payload) VALUES (?, ?)",
            (call_id, json.dumps(payload, ensure_ascii=False)),
        )

    def retry_writeback(self, call_id):
        with self._connection(write=True) as connection:
            connection.execute(
                """
                UPDATE calls
                SET pending_writeback = 0, reply = CASE WHEN state = 'closed' THEN reply ELSE ? END
                WHERE call_id = ? AND pending_writeback = 1
                """,
                (COMPLETED, call_id),
            )
            return self._snapshot(connection, call_id)

    def end_call(self, call_id):
        with self._connection(write=True) as connection:
            connection.execute(
                "UPDATE calls SET state = 'closed', reply = ? WHERE call_id = ? AND state != 'closed'",
                (CLOSED, call_id),
            )
            return self._snapshot(connection, call_id)
