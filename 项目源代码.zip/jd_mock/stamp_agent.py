"""Evidence-grounded inference for an incomplete authorization letter."""

import http.client
import ipaddress
import json
import math
import os
import time
from dataclasses import dataclass
from urllib.parse import urlsplit

from .ark_llm import ArkTransport
from .cases import INCOMPLETE
from .dialogue import STAMP_CHECK_PROMPTS, stamp_confirmation, stamp_submitted_material
from .stamp_evidence import (
    DESCRIPTIONS, HANDLERS, LEGAL_UNIT, ROLES, SURFACE, needs_handler_recheck, needs_owner_recheck, readings,
)


PLANS = ("request_stamp", "upload")
INSTRUCTIONS = "请提取商户原文的确切意思，然后在下面备选答案中选择同义的一项。"
ACTIONS = {"M": "request_stamp", "T": "request_stamp", "N": "request_stamp", "G": "upload",
           "U": "ask_owner", "W": "reason", "R": "review", "A": "upload", "P": "ask_owner",
           "S": "required_stamp_party", "H": "hold", "C": "record"}


@dataclass(frozen=True)
class StampDecision:
    reply: str
    action: str
    owner: str
    handler: str
    consent: bool
    context: dict
    source: str
    error: str | None
    latency_ms: int
    evidence_refs: tuple[str, ...]


def _replies(order):
    get_stamp, _ = stamp_confirmation(order)
    upload, _ = stamp_confirmation(order, already_stamped=True)
    replies = {
        **{code: order.render(prompt) for code, prompt in STAMP_CHECK_PROMPTS.items()},
        "W": stamp_submitted_material(order),
        "M": "您看到的是自己店铺的章。" + get_stamp,
        "T": "您看到的是第三方单位的章。" + get_stamp,
        "N": "您确认手头这份还没有盖章。" + get_stamp,
        "G": order.render("您已核对章面是授权方{grantor}。") + upload,
        "R": "还要等复审。审核人员看过您提交的完整材料后，才能确定结果。",
        "S": order.render("本单需要授权方{grantor}的公章，补盖时请联系该公司。"),
        "H": "好的，先不登记办理结果。您还有哪一步想核实？",
        "C": "好的，已收到您对办理方案的确认。",
    }
    for subject in ("M", "T", "G", "N"):
        replies[subject + "+R"] = replies[subject].split("。", 1)[0] + "。" + replies["R"]
    return replies


def first_replies(order):
    """All grounded first sentences can be synthesized before the call."""
    return (*_replies(order).values(), stamp_confirmation(order)[0],
            stamp_confirmation(order, already_stamped=True)[0])


def _choices(codes):
    return " | ".join(json.dumps(code) for code in codes)


def _wire_codes(options):
    return dict(zip("ABCDEFGHIJKLMNOPQRSTUVWXY", (code for code in options if code != "U"))) | {"Z": "U"}


def _meaning(code):
    return "，并且".join(DESCRIPTIONS[part] for part in code.split("+"))


def _prompt(order, text, previous, options, handlers, recalled_owner):
    captions = dict(DESCRIPTIONS, M="店家自己的单位", T="第三方单位", G=order.facts["grantor"],
                    N="根本没有印章", H="暂不办理", R="担心能否审核通过", C="同意办理")
    wire = _wire_codes(options)
    alternatives = "\n".join(
        f"{letter}. {'，并且'.join(captions[part] for part in code.split('+'))}（原话：{options[code].quote}）"
        for letter, code in wire.items() if code != "U"
    )
    question = "原文：「" + text + "」\n" + alternatives + "\nZ. 只知道跑腿的人或完全不清楚单位"
    if recalled_owner != "unknown" and ("P" in options or "A" in options):
        owner_code = next(code for code, owner in ROLES.items() if owner == recalled_owner)
        question += "\n本通已核对的章面：" + captions[owner_code] + "。"
    if "C" in options:
        plans = {"request_stamp": order.render("请{grantor}补盖公章，再上传完整授权书并重新提交"),
                 "upload": "上传盖有授权方公章的现有完整授权书并重新提交"}
        question += "\n上轮方案：" + plans.get(previous.get("plan"), "无")
    grammar = "root ::= (" + _choices(wire) + ")"
    choices = tuple(wire)
    if len(handlers) > 2:
        actors = "；".join(code + "=" + (item.mention or "不详") for code, item in handlers.items())
        question += "\n独立选经手人：" + actors + "。格式：结论/经手人。"
        grammar += ' "/" (' + _choices(handlers) + ")"
        choices = tuple(f"{letter}/{actor}" for letter in wire for actor in handlers)
    else:
        question += "\n选哪个？"
    messages = [{"role":"system","content":INSTRUCTIONS}, {"role":"user","content":question}]
    return messages, grammar, choices


class StampAgent:
    def __init__(self, url="http://127.0.0.1:8781/v1", model="stamp-qwen", timeout=6.0, *, cloud=None):
        self._cloud = cloud
        if cloud is not None:
            self.model = cloud.model
            self.provider = cloud.provider
            return

        parsed = urlsplit(url)
        host = parsed.hostname or ""
        local_host = host.lower() == "localhost"
        if not local_host:
            try:
                local_host = ipaddress.ip_address(host).is_loopback
            except ValueError:
                pass
        if (parsed.scheme != "http" or not local_host or parsed.username is not None
                or parsed.password is not None or parsed.query or parsed.fragment):
            raise ValueError("仅支持本机回环 HTTP 推理服务。")
        if not model or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("需要本机模型名称和有效的请求时限。")
        self.host = host
        self.port = parsed.port or 80
        path = parsed.path.rstrip("/") or "/v1"
        self.path = path if path.endswith("/chat/completions") else path + "/chat/completions"
        self.model = model
        self.timeout = timeout
        self.provider = "local"

    @classmethod
    def from_env(cls, provider=None):
        provider = provider or os.getenv("JD_LLM_PROVIDER", "local")
        if provider == "doubao":
            return cls(cloud=ArkTransport.from_env())
        if provider == "deepseek":
            from .deepseek_llm import DeepSeekTransport

            return cls(cloud=DeepSeekTransport.from_env())
        if provider != "local":
            raise ValueError("JD_LLM_PROVIDER must be local, deepseek or doubao.")
        return cls(
            os.getenv("JD_STAMP_LLM_URL", "http://127.0.0.1:8781/v1"),
            os.getenv("JD_STAMP_LLM_MODEL", "stamp-qwen"),
            float(os.getenv("JD_STAMP_LLM_TIMEOUT", "6")),
        )

    def _complete(self, messages, grammar, *, choices):
        if self._cloud is not None:
            return self._cloud.complete(messages, choices)

        payload = {
            "model": self.model, "messages": messages, "temperature": 0,
            "max_tokens": 8, "stream": False, "grammar": grammar, "cache_prompt": True,
        }
        connection = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        try:
            connection.request("POST", self.path, json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                               {"Content-Type": "application/json"})
            response = connection.getresponse()
            if response.status != 200:
                raise ConnectionError(f"inference HTTP {response.status}")
            choice = json.loads(response.read(65537))["choices"][0]
            if not isinstance(choice, dict) or choice.get("finish_reason") != "stop":
                raise ValueError("incomplete model output")
            return choice["message"]["content"]
        finally:
            connection.close()

    def decide(self, order, text, context=None, last_reply="", *, strategy_context=""):
        if order.procedure.scenario != INCOMPLETE.scenario:
            raise ValueError("本决策器仅服务授权书内容不完整工单。")
        previous = context or {}
        started = time.perf_counter()
        options, handlers = readings(order, text, previous, last_reply)
        recalled_owner = previous.get("owner", "unknown")
        observed_roles = (ROLES.get(option.partition("+")[0], "unknown") for option in options)
        observed_owners = set(observed_roles) - {"unknown"}
        if recalled_owner not in ROLES.values() or needs_owner_recheck(text) or observed_owners - {recalled_owner}:
            recalled_owner = "unknown"
        raw, error = "", None
        try:
            messages, grammar, choices = _prompt(order, text, previous, options, handlers, recalled_owner)
            messages[0]["content"] += strategy_context
            raw = self._complete(messages, grammar, choices=choices)
            if not isinstance(raw, str):
                raise ValueError("missing model output")
            letter, sep, actor = raw.partition("/")
            if bool(sep) != (len(handlers) > 2):
                raise ValueError("invalid number of fields")
            if not sep:
                # Single explicit actor/handling relation was independently
                # grounded in a source clause. It never establishes the owner.
                actor = next(iter(handlers))
            code = _wire_codes(options)[letter]
            if actor not in handlers:
                raise ValueError("unsupported evidence")
        except TimeoutError:
            error = "timeout"
        except (OSError, http.client.HTTPException):
            error = "unavailable"
        except (ValueError, TypeError, KeyError, IndexError):
            error = "invalid_decision"
        if error:
            code, actor = "U", "-"

        evidence = options[code]
        subject, _, inquiry = code.partition("+")
        owner = ROLES.get(subject, recalled_owner) if subject != "U" else recalled_owner
        owner_quote = ""
        owner_source = ""
        if owner != "unknown":
            if subject in ROLES and subject != "U":
                owner_quote, owner_source = evidence.quote, "merchant_report"
            else:
                owner_quote = previous.get("owner_evidence", "")
                owner_source = previous.get("owner_source", "")
        owner_code = next(key for key, value in ROLES.items() if value == owner)
        action, reply_code = ACTIONS[subject], subject
        if inquiry == "R":
            action, reply_code = "review", code
        elif inquiry == "S":
            action, reply_code = "required_stamp_party", "S"
        if code in {"A", "P"}:
            reply_code = owner_code
            action = ACTIONS[reply_code]
        # Keep the grounded remedy across follow-up questions or a pause. A
        # remembered remedy only becomes actionable when it is offered again.
        plan = ACTIONS[owner_code] if owner != "unknown" else ""
        if code == "C":
            accepted_plan = previous.get("plan") if previous.get("plan_offered") else "request_stamp"
            if accepted_plan in PLANS:
                plan = accepted_plan
            else:
                action, reply_code = "hold", "H"
        pending = ""
        if not error and code == "U" and owner == "unknown" and LEGAL_UNIT.search(text) and SURFACE.search(text):
            reply_code = "X"
            pending = order.facts["grantor"]
        reply = _replies(order)[reply_code]
        if code in {"A", "P"} and owner != "unknown":
            reply, _ = stamp_confirmation(order, already_stamped=owner == "grantor")
        elif code == "W" and owner_source == "submitted_material":
            reply, _ = stamp_confirmation(order, include_submitted=True)
            action = "request_stamp"
        elif reply_code == "U" and owner != "unknown":
            reply = "您想核对哪一步？"
            if not error:
                action = "clarify"
        handler = HANDLERS[actor]
        actor_quote = handlers[actor].quote
        handler_source = ("model_choice" if len(handlers) > 2 else "explicit_mention") if actor_quote else ""
        if actor == "-" and len(handlers) == 1 and not needs_handler_recheck(text):
            handler = previous.get("handler", "unknown")
            actor_quote = previous.get("handler_evidence", "")
            handler_source = previous.get("handler_source", "")
        memory = {"owner": owner, "handler": handler, "action": action, "meaning": _meaning(code),
                  "plan": plan, "plan_offered": action in PLANS, "model_output": raw[:96] if isinstance(raw, str) else "",
                  "model_options": _wire_codes(options), "matched_mention": evidence.mention,
                  "model_name": self.model, "evidence_text": "" if error else evidence.quote,
                  "owner_evidence": owner_quote, "owner_source": owner_source, "handler_evidence": actor_quote,
                  "handler_source": handler_source,
                  "pending_grantor_confirmation": pending}
        refs = (f"工单 {order.case_id} · {order.title}", order.evidence[0])
        if action == "review":
            refs += (order.evidence[1],)
        return StampDecision(reply, action, owner, handler, action == "record",
                             memory, "fallback" if error else "model", error,
                             round(1000 * (time.perf_counter() - started)), refs)
