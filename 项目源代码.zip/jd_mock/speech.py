"""Local Mandarin speech recognition and synthesis using sherpa-onnx."""

import argparse
import os
from pathlib import Path
from threading import Lock
from time import perf_counter

import numpy as np
import sherpa_onnx

from .asr_vocabulary import default_vocabulary
from .cases import DEFAULT_CASE_ID
from .speech_assets import ASR, DEFAULT_ASSET_DIR, SILERO_VAD_FILENAME, STAMP_ASR, TTS, silero_vad_installed
from .vad import SileroVoiceActivity, VoiceActivity


ASR_SAMPLE_RATE = 16_000
# Zipformer needs right context for its final chunk, even after input_finished.
ASR_TRAILING_SILENCE = np.zeros(int(0.66 * ASR_SAMPLE_RATE), dtype=np.float32)

def _sherpa_path(path: Path) -> str:
    # Native Windows readers for text assets can require ASCII file paths.
    if os.name == "nt" and not str(path).isascii():
        try:
            relative = os.path.relpath(path)
        except ValueError:  # Assets and cwd are on different Windows drives.
            pass
        else:
            if relative.isascii():
                return relative
    return str(path)


class SpeechStream:
    """A single utterance's streaming recognition state."""

    def __init__(self, recognizer: sherpa_onnx.OnlineRecognizer, lock: Lock, *, business_terms: bool = False):
        self._recognizer = recognizer
        self._lock = lock
        self._business_terms = business_terms
        self._result: str | None = None
        with lock:
            self._stream = recognizer.create_stream()

    def _decode_ready(self) -> None:
        while self._recognizer.is_ready(self._stream):
            self._recognizer.decode_stream(self._stream)

    def feed(self, samples: np.ndarray) -> None:
        samples = np.asarray(samples, dtype=np.float32)
        if samples.ndim != 1:
            raise ValueError("Expected mono 16 kHz PCM samples in a one-dimensional array.")
        with self._lock:
            if self._result is not None:
                raise RuntimeError("This utterance has already finished.")
            if samples.size:
                self._stream.accept_waveform(ASR_SAMPLE_RATE, samples)
                self._decode_ready()

    def partial_text(self) -> str:
        with self._lock:
            return self._recognizer.get_result(self._stream).strip()

    def finish(self) -> str:
        with self._lock:
            if self._result is None:
                self._stream.accept_waveform(ASR_SAMPLE_RATE, ASR_TRAILING_SILENCE)
                self._stream.input_finished()
                self._decode_ready()
                result = self._recognizer.get_result(self._stream).strip()
                if self._business_terms:
                    result = default_vocabulary().correct(DEFAULT_CASE_ID, result)
                self._result = result
            return self._result


class StampSpeechStream:
    """Accumulate one VAD-bounded utterance and decode it locally at endpoint."""

    def __init__(self, recognizer, lock: Lock):
        self._recognizer = recognizer
        self._lock = lock
        self._chunks = []
        self._result = None

    def feed(self, samples: np.ndarray) -> None:
        if self._result is not None:
            raise RuntimeError("This utterance has already finished.")
        samples = np.asarray(samples, dtype=np.float32)
        if samples.ndim != 1:
            raise ValueError("Expected mono 16 kHz PCM samples in a one-dimensional array.")
        if samples.size:
            self._chunks.append(samples)

    def finish(self) -> str:
        if self._result is None and not self._chunks:
            self._result = ""
        if self._result is None:
            with self._lock:
                stream = self._recognizer.create_stream()
                stream.accept_waveform(ASR_SAMPLE_RATE, np.concatenate(self._chunks))
                self._recognizer.decode_stream(stream)
            self._result = stream.result.text.strip()
            self._chunks.clear()
        return self._result


class SpeechEngine:
    """Share the model sessions while keeping each utterance's state separate."""

    def __init__(self, asset_dir: Path, *, stamp_asr: bool = False, vad_mode: str = "auto"):
        asset_dir = asset_dir.resolve()
        if vad_mode not in {"auto", "energy", "silero"}:
            raise ValueError("JD_VAD_MODE must be auto, energy or silero.")
        self._vad_config = None
        if vad_mode != "energy" and silero_vad_installed(asset_dir):
            config = sherpa_onnx.VadModelConfig()
            config.silero_vad.model = _sherpa_path(asset_dir / SILERO_VAD_FILENAME)
            config.silero_vad.window_size = SileroVoiceActivity.frame_size
            config.silero_vad.threshold = 0.70
            config.silero_vad.min_speech_duration = 0.064
            config.silero_vad.min_silence_duration = 0.4
            config.silero_vad.max_speech_duration = 15.0
            self._vad_config = config
        elif vad_mode == "silero":
            raise FileNotFoundError("Missing or invalid Silero VAD weights. Run start.ps1 -Setup.")

        for model in (ASR, TTS):
            if not model.is_installed(asset_dir):
                raise FileNotFoundError(
                    f"Missing or incomplete speech model {asset_dir / model.name}. "
                    f'Run python -m jd_mock.speech_assets --asset-dir "{asset_dir}".'
                )

        asr_dir = asset_dir / ASR.name
        self._recognizer = sherpa_onnx.OnlineRecognizer.from_zipformer2_ctc(
            tokens=_sherpa_path(asr_dir / "tokens.txt"),
            model=_sherpa_path(asr_dir / "model.int8.onnx"),
            num_threads=1,
            sample_rate=ASR_SAMPLE_RATE,
            provider="cpu",
        )

        tts_dir = asset_dir / TTS.name
        config = sherpa_onnx.OfflineTtsConfig(
            model=sherpa_onnx.OfflineTtsModelConfig(
                vits=sherpa_onnx.OfflineTtsVitsModelConfig(
                    model=_sherpa_path(tts_dir / "model.onnx"),
                    lexicon=_sherpa_path(tts_dir / "lexicon.txt"),
                    tokens=_sherpa_path(tts_dir / "tokens.txt"),
                ),
                provider="cpu",
                num_threads=min(4, os.cpu_count() or 1),
            ),
            rule_fsts=",".join(
                _sherpa_path(tts_dir / filename) for filename in ("date.fst", "phone.fst", "number.fst")
            ),
        )
        if not config.validate():
            raise ValueError(f"Invalid local synthesis model configuration at {tts_dir}.")

        self._tts = sherpa_onnx.OfflineTts(config)
        self._asr_lock = Lock()
        self._tts_lock = Lock()
        self._stamp_lock = Lock()
        self._stamp_recognizer = None
        if stamp_asr:
            stamp_dir = asset_dir / STAMP_ASR.name
            if not STAMP_ASR.is_installed(asset_dir):
                raise FileNotFoundError(f"Missing {stamp_dir}. Run python -m jd_mock.speech_assets --stamp-asr.")
            self._stamp_recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
                model=_sherpa_path(stamp_dir / "model.int8.onnx"),
                tokens=_sherpa_path(stamp_dir / "tokens.txt"),
                num_threads=2, provider="cpu", language="zh", use_itn=True,
            )

    @property
    def stamp_asr_ready(self) -> bool:
        return self._stamp_recognizer is not None

    @property
    def vad_backend(self) -> str:
        return "silero" if self._vad_config is not None else "energy"

    def new_vad(self):
        if self._vad_config is None:
            return VoiceActivity()
        detector = sherpa_onnx.VoiceActivityDetector(self._vad_config, buffer_size_in_seconds=20)
        return SileroVoiceActivity(detector)

    def new_stamp_stream(self) -> StampSpeechStream:
        if self._stamp_recognizer is None:
            raise RuntimeError("SenseVoiceSmall is not enabled for this workbench.")
        return StampSpeechStream(self._stamp_recognizer, self._stamp_lock)

    def new_stream(self, *, business_terms: bool = False) -> SpeechStream:
        return SpeechStream(self._recognizer, self._asr_lock, business_terms=business_terms)

    def synthesize(self, text: str) -> tuple[np.ndarray, int]:
        text = text.strip()
        if not text:
            return np.empty(0, dtype=np.float32), self._tts.sample_rate
        with self._tts_lock:
            audio = self._tts.generate(text)
        samples = np.asarray(audio.samples, dtype=np.float32)
        if not samples.size:
            raise RuntimeError("The local speech synthesizer returned no audio.")
        return np.clip(samples, -1.0, 1.0), audio.sample_rate


def main() -> None:
    parser = argparse.ArgumentParser(description="Run an offline Mandarin speech smoke test.")
    parser.add_argument("--asset-dir", type=Path, default=DEFAULT_ASSET_DIR)
    args = parser.parse_args()
    engine = SpeechEngine(args.asset_dir)
    start = perf_counter()
    samples, rate = engine.synthesize("你好，今天天气很好。")
    synthesis_seconds = perf_counter() - start
    if not np.isfinite(samples).all() or np.max(np.abs(samples)) < 0.05:
        raise RuntimeError("The synthesized audio is silent or invalid.")

    target = np.arange(round(len(samples) * ASR_SAMPLE_RATE / rate)) * rate / ASR_SAMPLE_RATE
    resampled = np.interp(target, np.arange(len(samples)), samples).astype(np.float32)
    stream = engine.new_stream()
    start = perf_counter()
    for offset in range(0, len(resampled), 320):
        stream.feed(resampled[offset : offset + 320])
    result = stream.finish()
    recognition_seconds = perf_counter() - start
    if "今天天气很好" not in result:
        raise RuntimeError(f"Unexpected Mandarin recognition result: {result!r}")
    print(f"{rate} Hz, {len(samples) / rate:.2f} s of audio, TTS {synthesis_seconds:.2f} s")
    print(f"ASR {recognition_seconds:.2f} s: {result}")


if __name__ == "__main__":
    main()
