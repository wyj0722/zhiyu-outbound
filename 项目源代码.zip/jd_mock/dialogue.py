"""Spoken guidance for verified merchants. The focus records the last question or step."""

import re

from .cases import CATEGORY, CHAIN, INCOMPLETE, authorization_party_pattern


COMMITMENT_QUESTION = "您打算按这个办法处理吗？"
CATEGORY_CHOICE = "您想只卖{authorized}，还是也保留{requested}？"
CHAIN_ROLE_FOCI = frozenset(("chain_parties", "chain_grantor", "chain_grantee"))
SPEECH_FILLERS = r"[嗯呃哦啊唔]*+"
AFFIRMATION = r"(?:好(?:的)?|行(?:的)?|可以(?:的)?|成|没(?:有)?问题|没意见|对(?:的)?|是(?:的)?|(?:我(?:们)?)?(?:确认|同意))(?:啊|呀)?+"
UNDERSTOOD = r"(?:我(?:们)?)?(?:收到(?:了)?|(?:知道|了解|听(?:清楚|清|懂|明白)|明白)(?:您|你)?(?:的意思)?了)"
PLAN_NOUN = r"(?:办法|方法|方案|步骤|流程|思路|说法)"
PLAN_REFERENCE = (
    r"(?:(?:刚才|刚刚|前面)(?:说的|提的)?)?(?:这|那)(?:个|套)"
    r"|(?:您|你)(?:刚才|刚刚|刚)?(?:说|讲|提|建议)(?:过)?的"
    r"|(?:刚才|刚刚|前面)(?:说|讲|提)的"
)
PLAN_EXECUTION = r"(?:来(?:做|办|处理)?|办理|办|做|弄|处理|改|整改|操作|执行|落实|走)"
PLAN_ACCEPTANCE = re.compile(
    rf"{SPEECH_FILLERS}(?:{AFFIRMATION}{SPEECH_FILLERS})+"
    # Some decoders recognize the connector before a decision as 又. Only
    # consider it with a clear affirmative lead and a complete decision.
    rf"|{SPEECH_FILLERS}(?:{AFFIRMATION}{SPEECH_FILLERS})+(?:那)?又这(?:么|样)定(?:了)?"
    rf"|{SPEECH_FILLERS}(?:(?:{AFFIRMATION}|{UNDERSTOOD}){SPEECH_FILLERS})*"
    rf"(?:那)?(?:我(?:们)?(?:这边)?)?(?:就|会|愿意|打算|现在|这就)?"
    rf"(?:照办|听(?:您|你)的|这(?:么|样)(?:{PLAN_EXECUTION}|定(?:了)?)"
    rf"|(?:按(?:照|着)?|照(?:着)?|依(?:照)?)(?:{PLAN_REFERENCE})(?:{PLAN_NOUN})?(?:{PLAN_EXECUTION})?"
    rf"|(?:同意|接受|认可)(?:按(?:照)?|照(?:着)?)?(?:{PLAN_REFERENCE})?(?:{PLAN_NOUN}|办理|办))"
    rf"(?:了|啊|呀|吧)?"
)
PLAN_ACKNOWLEDGMENT = re.compile(
    rf"{SPEECH_FILLERS}(?:(?:{AFFIRMATION}{SPEECH_FILLERS})*{UNDERSTOOD}{SPEECH_FILLERS})*"
)


def asks_for_commitment(reply):
    return reply.endswith(COMMITMENT_QUESTION)


def commitment_plan_text(reply):
    return reply.removesuffix(COMMITMENT_QUESTION) if asks_for_commitment(reply) else ""


def accepts_offered_plan(text):
    # Match the whole utterance so an initial yes cannot swallow a trailing
    # condition, a question, or a refusal.
    return bool(PLAN_ACCEPTANCE.fullmatch(re.sub(r"[\s,，、。.!！]+", "", text)))


def acknowledges_plan(text):
    compact = re.sub(r"[\s,，、。.!！]+", "", text)
    return bool(compact and PLAN_ACKNOWLEDGMENT.fullmatch(compact))


def heard_commitment_plan(reply, delivered_reply):
    plan = commitment_plan_text(reply)
    return bool(plan and delivered_reply in (reply, plan))


# A focus identifies the step the merchant most recently heard. A request to
# repeat stays on this step; a short answer is interpreted in its context.
PROMPTS = {
    "category_reason": "您在{application}里申请了{requested}，已提交的销售授权书只覆盖{authorized}。" + CATEGORY_CHOICE,
    "category_open": "请打开被驳回的{application}，找到销售授权书这一栏。",
    "category_field": "入口在销售授权书下方。打开“有经营范围限制”，再点“选择授权类目”。",
    "category_select": "点“有经营范围限制”，再点“选择授权类目”。这份授权可以勾选{authorized}，把{requested}去掉就行。",
    "category_extra_document": "保留{requested}需要一份覆盖{requested}的销售授权书。",
    "category_extra_request": "如果暂时拿不到，请联系品牌授权方补一份写明{requested}的销售授权书。拿到后再补到这张{application}里。",
    "category_extra_upload": "拿到覆盖{requested}的授权后，把销售授权书传到{application}，按新范围勾选类目，再重新提交。" + COMMITMENT_QUESTION,
    "stamp_reason": "这份销售授权书缺少{grantor}的公章。您手里的授权书上已经盖章了吗？",
    "stamp_owner": "您看一下章上的公司全称，盖的是哪家公司的章？",
    "stamp_request": "请找{grantor}，让他们在这份销售授权书上盖公章。您现在能联系上授权方吗？",
    "stamp_upload": "如果章上写的是{grantor}，请把盖好公章的完整授权书上传到{application}，再重新提交。",
    "stamp_contact": "这份授权还需要{grantor}的公章。您手里有他们盖好章的另一份完整授权书吗？",
    "chain_reason": "这张单还要补{upstream}授权给{downstream}的证明。",
    "chain_request": "要补的是{upstream}授权给{downstream}的证明。请先找{upstream}要这份材料。",
    "chain_upload": "把这段证明和已有的授权材料一起上传到{application}，核对公司名称后重新提交。",
    "chain_contact": "缺的这段得由{upstream}授权给{downstream}。您手里还有写了这两家公司名称的授权文件吗？",
}
SHORT = {
    "category_reason": CATEGORY_CHOICE,
    "category_open": "请先打开那张被驳回的{application}。",
    "category_field": "在销售授权书下方点“有经营范围限制”。",
    "category_select": "点“选择授权类目”，留{authorized}，去掉{requested}。",
    "category_extra_document": "保留{requested}需要补对应的销售授权。",
    "category_extra_request": "请授权方补一份写明{requested}的销售授权书。",
    "category_extra_upload": "把覆盖{requested}的新授权上传，再重新提交。",
    "stamp_reason": "授权书缺{grantor}的公章。",
    "stamp_owner": "章上写的是哪家公司？",
    "stamp_request": "找{grantor}在这份授权书上盖公章。",
    "stamp_upload": "把盖好授权方公章的完整授权书上传到{application}。",
    "stamp_contact": "手头还有盖了{grantor}公章的授权书吗？",
    "chain_reason": "缺{upstream}授权给{downstream}这一段。",
    "chain_request": "找{upstream}，补他们授权给{downstream}的证明。",
    "chain_upload": "把补好的证明和已有材料一起上传。",
    "chain_contact": "您还有{upstream}授权给{downstream}的文件吗？",
}

REASON = {CATEGORY.scenario: "category_reason", INCOMPLETE.scenario: "stamp_reason", CHAIN.scenario: "chain_reason"}
REVIEW = {
    CATEGORY.scenario: "还得等复审。审核时会核对您选的类目和销售授权书上的范围。",
    INCOMPLETE.scenario: "结果还得等复审。眼下先核对销售授权书上的公章和授权方名称。",
    CHAIN.scenario: "结果还得等复审。审核时会核对这几份授权能不能从品牌方一直接到您这边。",
}
STAMP_CHECK_PROMPTS = {
    "U": "您看一下手里的原件，公章上刻的是哪家公司的全称？",
    "X": "我想核对一下这个公司名。请您对照章面，上面写的是{grantor}这几个字吗？",
    "W": "原申请中的授权书缺少{grantor}的公章。您看下手头原件，章面全称是什么？",
}

MATERIAL_QUESTIONS = {
    CATEGORY.scenario: (
        (PROMPTS["category_reason"], ("scope",)),
        (SHORT["category_reason"], ("scope",)),
        (PROMPTS["category_extra_document"], ("scope",)),
        (SHORT["category_extra_document"], ("scope",)),
    ),
    INCOMPLETE.scenario: (
        (PROMPTS["stamp_reason"], ("seal",)),
        (PROMPTS["stamp_owner"], ("seal",)),
        (SHORT["stamp_owner"], ("seal",)),
        (PROMPTS["stamp_request"], ("grantor",)),
        (STAMP_CHECK_PROMPTS["U"], ("seal",)),
        (STAMP_CHECK_PROMPTS["W"], ("seal",)),
        (STAMP_CHECK_PROMPTS["X"], ("grantor", "seal")),
    ),
}


def material_question_fields(order, reply):
    """Return fields referenced in the spoken reply. An empty tuple opens the file."""
    scenario = order.procedure.scenario
    if order.procedure is CHAIN:
        return ("grantor", "grantee") if chain_submitted_material(order) in reply else None
    if order.procedure is INCOMPLETE and stamp_submitted_material(order) in reply:
        return ("grantor", "seal")
    if order.procedure.material_fields and order.reason in reply:
        return tuple(key for key, _ in order.procedure.material_fields)
    return next(
        (fields for prompt, fields in MATERIAL_QUESTIONS.get(scenario, ()) if reply.endswith(order.render(prompt))),
        None,
    )


def introduce(order):
    if order.procedure is CHAIN:
        return chain_confirmation(order, include_submitted=True)
    if order.procedure is INCOMPLETE:
        return stamp_confirmation(order, include_submitted=True)
    if order.procedure.offer:
        return resubmission_plan(order, include_reason=True)
    return _say(order, "category_reason")


def resubmission_plan(order, *, include_reason=False):
    reason = order.reason if include_reason else ""
    return reason + order.render(order.procedure.offer) + COMMITMENT_QUESTION, "resubmission"


def resubmission_reply(order, action, last_reply=""):
    if action == "next" or action == "repeat" and not last_reply:
        return resubmission_plan(order)
    answer = {
        "reason": order.reason,
        "upload": order.guidance,
        "review": "重新提交后还要复审，审核人员会核对您更新后的材料。",
        "hold": "好，我先不登记。有什么需要核对的，可以现在问我。",
        "repeat": last_reply,
        "clarify": "您是想核对驳回原因，还是想了解怎么换传材料？",
    }
    return answer[action], "resubmission"


def _resubmission_action(text):
    if _has(text, "先不", "没决定", "不确定", "考虑", "不同意", "暂不", "先等等"):
        return "hold"
    if _has(text, "过审", "能过", "保证", "包过", "通过吗", "会不会通过"):
        return "review"
    if _has(text, "原因", "为什么", "为啥", "怎么回事"):
        return "reason"
    if _has(text, "哪里", "哪儿", "从哪", "怎么传", "怎么上传", "入口", "往哪"):
        return "upload"
    if _has(text, "没听清", "再说", "重复", "接下来", "下一步", "怎么改", "怎么办", "怎么做", "改什么", "重提"):
        return "next"
    return "clarify"


def _say(order, focus, lead=""):
    return order.render(lead + PROMPTS[focus]), focus


def category_choice(order):
    return order.render(CATEGORY_CHOICE), "category_reason"


def category_confirmation(order, *, retain_requested=False, document_available=False):
    if retain_requested:
        remedy = ""
        if not document_available:
            remedy = "还没拿到覆盖{requested}的销售授权书的话，先请品牌授权方补一份。"
        remedy += "把覆盖{requested}的授权书上传到{application}，按新范围勾选类目，再重新提交。"
        return order.render(remedy) + COMMITMENT_QUESTION, "category_extra_confirm"
    remedy = order.render(
        "请在{application}的销售授权书下方打开“有经营范围限制”，"
        "在“选择授权类目”勾选{authorized}、去掉{requested}，再重新提交。"
    )
    return remedy + COMMITMENT_QUESTION, "category_select"


def stamp_submitted_material(order):
    material = order.submitted_authorization
    return order.render(
        f"您在{{application}}提交的授权书上盖的是{material['seal']}的章，缺少{{grantor}}的公章。"
    )


def stamp_confirmation(order, *, include_submitted=False, already_stamped=False):
    material = stamp_submitted_material(order) if include_submitted else ""
    if already_stamped:
        remedy = "请把加盖{grantor}公章的完整授权书上传到{application}，再重新提交。"
        focus = "stamp_upload"
    else:
        remedy = "请联系{grantor}补盖公章，把完整授权书上传到{application}，再重新提交。"
        focus = "stamp_request_stamp"
    return material + order.render(remedy) + COMMITMENT_QUESTION, focus


def chain_submitted_material(order):
    material = order.submitted_authorization
    application = order.render("{application}")
    return f"您在{application}里已提交的授权材料上，授权方是{material['grantor']}，被授权方是{material['grantee']}。"


def chain_submitted_reply(order):
    return _say(order, "chain_request", chain_submitted_material(order))


def chain_confirmation(order, *, include_submitted=False):
    material = chain_submitted_material(order) if include_submitted else ""
    remedy = order.render(
        "请补齐{upstream}授权给{downstream}的证明，"
        "和已有材料一起上传到{application}，再重新提交。"
    )
    return material + remedy + COMMITMENT_QUESTION, "confirm"


def commitment_preface(order, reply):
    if order.procedure is CHAIN:
        preface = chain_submitted_material(order)
    elif order.procedure is INCOMPLETE:
        preface = stamp_submitted_material(order)
    elif order.procedure.offer:
        preface = order.reason
    else:
        return ""
    return preface if reply.startswith(preface) else ""


def _has(text, *terms):
    return any(term in text for term in terms)


def _ack(text):
    return bool(re.fullmatch(
        r"(?:嗯|好|是|对)?(?:嗯|好[的啊]?|是的?|对的?|行|明白了|知道了|可以|方便|有(?:的)?|"
        r"(?:我)?(?:已经)?(?:打开|看到|看见|找到|选好|盖好|备好|准备好|拿到)(?:了)?(?:了)?)", text
    ))


def _next(order, focus):
    if order.procedure is CATEGORY and focus in {"", "intro", "category_reason"}:
        return category_choice(order)
    if order.procedure is CHAIN and focus in {"chain_request", "chain_upload", "confirm"}:
        return chain_confirmation(order)
    if focus in ("category_select", "stamp_upload", "confirm"):
        action = {
            CATEGORY.scenario: "把类目按授权范围改好后，核对一遍，再重新提交。",
            INCOMPLETE.scenario: "把授权方盖好公章的完整授权书传回申请单，再重新提交。",
        }[order.procedure.scenario]
        return action + COMMITMENT_QUESTION, "confirm"
    if focus == "category_extra_upload" or focus == "category_extra_confirm":
        return category_confirmation(order, retain_requested=True)
    if order.procedure is CHAIN and (focus in CHAIN_ROLE_FOCI or focus in {"", "intro", "chain_reason"}):
        return chain_submitted_reply(order)
    if focus == "chain_contact":
        return _say(order, "chain_upload", "拿到缺的那一段之后，")
    next_step = {
        "category_open": "category_field",
        "category_extra_document": "category_extra_upload", "category_extra_request": "category_extra_upload",
        "stamp_reason": "stamp_owner", "stamp_owner": "stamp_owner", "stamp_request": "stamp_upload",
        "stamp_contact": "stamp_owner",
    }
    return _say(order, next_step.get(focus, REASON[order.procedure.scenario]))


def category_preference(order, text, focus):
    compact = re.sub(r"[\s，,。.!！？?、]+", "", text)
    if _has(compact, "如果", "假如", "要是", "万一", "是否", "是不是", "不确定", "再考虑", "再想想", "我没说"):
        return None
    authorized = order.facts["authorized"]
    requested = order.facts["requested"]
    target = re.escape(requested)
    covered = re.escape(authorized)
    covered_names = {authorized}
    if authorized == "鞋类":
        covered_names.update(("鞋", "鞋子"))
        covered = r"(?:鞋类|鞋子?(?=$|了$|吧$|怎么|怎么办))"
    if (re.search(r"(?:可以吗|行吗|对吗|能吗|好不好)$", compact)
            or re.search(r"[？?]", text) and compact in covered_names | {requested}):
        return None
    drops_requested = bool(re.search(rf"(?:不想|不要|不打算|不再)(?:继续|再)?(?:卖|做|经营|保留|申请){target}", compact))
    if (focus == "category_reason" and compact in {requested, requested + "吧", "选" + requested}
            or re.search(rf"(?:两(?:种|样|个类目)|两个)都(?:想|要)?(?:卖|经营|做|申请|保留|选|留|要)?$", compact)
            or authorized in compact and requested in compact and re.search(r"都(?:想|要|卖|留|保留|经营)|一起(?:卖|做)", compact)
            or not drops_requested and re.search(
                rf"(?:还想|也想|还要|也要|想继续|继续|我想|我要|希望)(?:卖|做|选|保留|经营|申请){target}"
                rf"|{target}(?:我|我们)?(?:还想|还要|也想|也要|想继续)(?:卖|做|留|经营|保留)", compact,
            )):
        return "expanded_authorization"
    if not _has(compact, "不想只", "不只", "不止", "不能只", "不要只", "不打算只", "不是只", "并非只",
                "不能去掉", "不想去掉", "不去掉", "不要去掉", "不想删", "不删掉"):
        if (drops_requested or focus == "category_reason" and compact in covered_names | {authorized + "吧", "选" + authorized}
                or re.search(rf"(?:只|先|就)(?:卖|做|选|留|保留|经营){covered}|(?:去掉|不卖|不申请){target}|{target}不卖了", compact)):
            return "authorized_only"
    return None


def _category(order, text, focus, how):
    extra = focus.startswith("category_extra_")
    preference = category_preference(order, text, focus)
    if preference == "authorized_only":
        return category_confirmation(order)
    if preference == "expanded_authorization":
        return category_confirmation(order, retain_requested=True)
    if extra:
        if _has(text, "没有", "还没", "没给我", "拿不到", "联系不上"):
            return category_confirmation(order, retain_requested=True)
        if focus == "category_extra_document" and text in {"有", "有的"}:
            return category_confirmation(order, retain_requested=True, document_available=True)
        if _has(text, "已经有", "手里有", "我有", "已经拿到", "拿到了", "怎么传", "在哪传", "上传", "入口", "在哪里"):
            return category_confirmation(
                order, retain_requested=True,
                document_available=_has(text, "已经有", "手里有", "我有", "已经拿到", "拿到了"),
            )
        if how:
            return category_confirmation(order, retain_requested=True)
        return None   # Other questions cannot silently change the agreed category plan.
    if focus == "category_reason" and (_ack(text) or accepts_offered_plan(text)
                                       or _has(text, "如果", "假如", "要是", "是不是", "是否")):
        return category_choice(order)
    if _has(text, "没打开", "还没开", "找不到入口", "页面在哪", "哪个页面", "没找到入口"):
        return _say(order, "category_open")
    if focus == "category_select" and _has(text, "哪儿重新提交", "哪里重新提交", "怎么重新提交",
                                           "勾好了", "已经勾好") and not _has(
            text, "没勾好", "不确定", "是不是", "不打算", "先不提交", "暂不提交"):
        return _next(order, focus)
    if focus == "category_field" and not _has(text, "没看到", "没看见", "看不见", "没找到"):
        if _has(text, "怎么勾", "勾哪个", "勾哪项", "该选哪"):
            facts = order.render("按已有授权可勾选{authorized}。")
            choice, next_focus = category_choice(order)
            return facts + choice, next_focus
        if _has(text, "看到选项", "看到那个选项", "看到了", "我找到了"):
            return category_choice(order)
    if _has(text, "已经打开", "我打开了", "在页面", "在申请单") or (
        focus == "category_field" and _has(text, "没看到", "没看见", "看不见", "没找到", "找不到", "没有", "看不到")
    ):
        return _say(order, "category_field")
    if _has(text, "哪里选", "哪儿选", "在哪选", "在哪里", "在哪儿", "哪里改", "哪里点", "入口", "选择授权类目"):
        return _say(order, "category_field")
    if how:
        return _say(order, "category_reason")
    return None


def _stamp(order, text, focus, how):
    if focus in ("stamp_contact", "stamp_request") and _has(text, "拿到以后", "拿到之后", "要是拿到", "拿到了呢"):
        return _say(order, "stamp_upload")
    if focus == "stamp_request" and text in {"能", "可以联系", "联系得上", "能联系上", "联系上了", "能找到"}:
        return _say(order, "stamp_upload", "那先请对方在原来的授权书上盖章。")
    if focus == "stamp_request" and text in {"不行", "不能", "没法", "暂时不能", "没有"}:
        return _say(order, "stamp_contact")
    if _has(text, "联系不上", "联系不到", "找不到品牌", "不回我", "没法联系"):
        return _say(order, "stamp_contact")
    if focus == "stamp_contact" and _has(text, "没有", "没了", "手里没", "找不到"):
        return order.render("那先把这份授权书留好。等联系上{grantor}，拿到盖好公章的完整文件后再传。"), "stamp_request"
    if _has(text, "自己的", "我们的", "我方的", "本店的", "我们盖", "我们公司", "店里的"):
        return _say(order, "stamp_request", "本单要核对的是授权方的章。")
    grantor = order.facts["grantor"]
    if (_has(text, grantor, grantor.removesuffix("品牌公司"), "授权方的", "品牌方的") and
            (focus == "stamp_owner" or _has(text, "盖的", "盖好了", "盖过", "授权方的", "品牌方的")) and
            not _has(text, "没", "不是", "没有", "吗", "是不是", "?", "？")):
        return _say(order, "stamp_upload")
    if _has(text, "没盖", "没有盖", "没章", "没有章", "还没盖", "谁盖", "谁的章", "找谁", "怎么盖", "哪家盖", "谁来盖"):
        return _say(order, "stamp_request")
    if _has(text, "盖过", "盖了", "盖好", "有章", "盖着", "上面有", "已经盖"):
        return _say(order, "stamp_owner")
    if _has(text, "上传", "哪里传", "在哪传", "传哪里"):
        return _say(order, "stamp_upload")
    if how:
        return _say(order, "stamp_request")
    return None


def chain_collection_paused(text):
    return _has(text, "先别", "先不", "暂不", "不打算", "先等一下", "先看看", "再商量")


def _chain(order, text, focus, how):
    source = authorization_party_pattern(order.facts["upstream"])
    target = authorization_party_pattern(order.facts["downstream"])
    if focus in ("chain_contact", "chain_request") and _has(text, "拿到以后", "拿到之后", "要是拿到", "拿到了呢"):
        return _say(order, "chain_upload")
    if _has(text, "联系不上", "联系不到", "找不到品牌", "不回我", "没法联系"):
        return _say(order, "chain_contact")
    if focus == "chain_contact" and _has(text, "没有", "没了", "手里没", "找不到"):
        return order.render("已有的授权书先留好。请联系{upstream}，拿到他们授权给{downstream}的证明后再一起上传。"), "chain_request"
    if _has(text, "同一家", "是一家", "同一个老板", "关联公司", "同集团"):
        return order.render("如果是关联公司，请准备两家公司的关系证明，交给审核人员核实。您现在有这份证明吗？"), "chain_contact"
    if order.contradicts_action(text):
        return _say(order, "chain_request", "这个方向反了。")
    if re.search(rf"{source}(?:授权给|出给|开给|给|到){target}", text) and not _has(
            text, "缺", "没有", "还没", "不是", "如果", "假如", "是不是", "想问", "应该", "需要", "吗", "？", "?"):
        lead = "拿到缺的那一段之后，"
        if _has(text, "拿到", "收到", "找到了", "已经有"):
            lead = "您说的正是本单要补的那一段。"
        return _say(order, "chain_upload", lead)
    if (re.search(r"(?:从|往|在)?哪(?:里|儿)?.{0,2}(?:上传|传上去|传)|(?:上传|传到)(?:到)?哪", text)
            or _has(text, "传在哪里", "怎么上传")):
        return _say(order, "chain_upload", "拿到缺的那一段之后，")
    if _has(text, "没交", "没有交", "没传", "没有传", "没提交", "没有提交"):
        return _say(order, "chain_request")
    if _has(text, "交过", "交了一份", "已经交", "提交了", "提交过", "传过", "上传了", "传上去了", "手里有", "我有一份", "有授权"):
        if focus not in {"chain_upload", "confirm"}:
            return chain_submitted_reply(order)
    if re.search(rf"{target}(?:授权给|出给|开给|给)(?:我|咱|{re.escape(order.submitted_authorization['grantee'])})", text):
        if focus not in {"chain_upload", "confirm"}:
            return chain_submitted_reply(order)
    if how or _has(text, "哪两家", "哪一段", "哪段", "找谁", "谁给谁", "什么关系", "缺什么", "谁授权"):
        return chain_submitted_reply(order)
    if focus in CHAIN_ROLE_FOCI:
        return chain_submitted_reply(order)
    return None


def respond(order, text, focus=""):
    text = re.sub(r"[\s,，。！!、]+", "", text)
    if order.procedure.offer:
        return resubmission_reply(order, _resubmission_action(text))
    reason = REASON[order.procedure.scenario]
    extra = focus.startswith("category_extra_")
    if _has(text, "没听清", "说慢", "慢点", "简单点", "再说一遍", "重复一遍", "听不懂", "讲简单"):
        if focus == "confirm":
            return _next(order, focus)
        if order.procedure is CHAIN and (focus in CHAIN_ROLE_FOCI or focus in {"intro", "chain_reason", "chain_request"}):
            return chain_submitted_reply(order)
        short = SHORT.get(focus, SHORT["category_extra_upload"] if extra else SHORT[reason])
        return order.render(short), focus or reason
    if _has(text, "为什么没过", "为什么没通过", "为啥没过", "为什么被驳", "原因", "为啥驳回", "怎么回事"):
        if order.procedure is CHAIN:
            return chain_submitted_reply(order)
        if extra:
            return order.reason + order.render("您可以补上覆盖{requested}的授权，再保留这个类目。"), focus
        return _say(order, reason)
    if _has(text, "能过", "通过", "过审", "保证", "包过", "一定过"):
        return REVIEW[order.procedure.scenario], focus or reason
    if order.procedure is CHAIN and chain_collection_paused(text):
        return "那我先不记录。您还有哪一步想问清楚？", focus
    how = _has(text, "改什么", "怎么改", "怎么做", "怎么办", "怎么处理", "要补什么", "做什么", "怎么操作")
    handler = {CATEGORY.scenario: _category, INCOMPLETE.scenario: _stamp, CHAIN.scenario: _chain}[order.procedure.scenario]
    answer = handler(order, text, focus, how)
    if answer:
        return answer
    if _has(text, "下一步", "接下来", "然后呢", "之后呢", "再怎么", "再然后") or _ack(text):
        return _next(order, focus)
    if _has(text, "没决定", "不确定", "考虑", "不确认", "不同意", "不打算", "先不提交", "暂不提交"):
        return "那我先不记录。您还有哪一步想问清楚？", focus
    return "您刚才指的是哪一步？可以说说您手上有什么，或者卡在哪里。", focus


def receipt_steps(order, focus):
    if focus.startswith("category_extra_"):
        return tuple(order.render(text) for text in (
            "尚未取得相关授权时，联系授权方补一份覆盖{requested}类目的销售授权书。",
            "把新授权书上传到{application}，按新范围勾选{requested}。",
            "核对授权范围后重新提交申请。",
        ))
    return order.steps


def contradicts_plan(order, text, focus):
    if focus.startswith("category_extra_"):
        return _has(text, "不补", "不用补", "无需补", "不需要补", "按原样", "不换授权", "不用新授权",
                    order.render("只保留{authorized}"), order.render("去掉{requested}"), order.render("取消{requested}"),
                    order.render("只卖{authorized}"), order.render("只选{authorized}"))
    return order.contradicts_action(text)
