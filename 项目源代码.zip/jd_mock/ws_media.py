"""WebSocket carrier for the existing audio and dialogue processing pipeline."""

import asyncio
import json
import logging
import time
from fractions import Fraction
from uuid import uuid4

import numpy as np
from aiortc import MediaStreamError
from av import AudioFrame
from fastapi import WebSocketDisconnect

from .media import AUDIO_FRAMES_PER_SECOND, CallMedia


log = logging.getLogger(__name__)
PCM_RATE = 16_000
PCM_FRAME = PCM_RATE // AUDIO_FRAMES_PER_SECOND
PCM_BYTES = PCM_FRAME * 2
PCM_BURST_FRAMES = 128
PCM_FRAMES_PER_SECOND = 65
MAX_WRITE_QUEUE = 64
WRITE_HIGH_WATER = MAX_WRITE_QUEUE // 2
WRITE_LOW_WATER = MAX_WRITE_QUEUE // 4
SEND_TIMEOUT = 8.0
PCM_TIME_BASE = Fraction(1, PCM_RATE)


class _WriteDrainTimeout(TimeoutError):
    """The outgoing queue could not drain within a bounded pause."""


class _SocketInput:
    """Read ordered controls and fixed-size 20 ms PCM from one accepted socket."""

    readyState = "open"

    def __init__(self, socket, acknowledge):
        self.socket = socket
        self.acknowledge = acknowledge
        self.close_code = 1000
        self.peer_close_code = None
        self._pts = 0
        self._credit = float(PCM_BURST_FRAMES)
        self._control_credit = 16.0
        self._last_frame = self._last_control = time.monotonic()

    def _invalid(self, code):
        self.close_code = code
        raise MediaStreamError

    def _control(self, raw):
        now = time.monotonic()
        self._control_credit = min(16, self._control_credit + (now - self._last_control) * 10)
        self._last_control = now
        if self._control_credit < 1:
            self._invalid(1008)
        self._control_credit -= 1
        if not isinstance(raw, str) or len(raw) > 256:
            self._invalid(1003)
        try:
            data = json.loads(raw)
        except (ValueError, RecursionError):
            self._invalid(1003)
        if not isinstance(data, dict) or data.get("type") != "plan-started" or not isinstance(data.get("token"), str):
            self._invalid(1003)
        self.acknowledge(data["token"])

    async def recv(self):
        while True:
            message = await self.socket.receive()
            if message["type"] == "websocket.disconnect":
                self.peer_close_code = message.get("code", 1000)
                raise MediaStreamError
            data = message.get("bytes")
            if data is None:
                self._control(message.get("text"))
                continue
            if len(data) != PCM_BYTES:
                self._invalid(1003)
            now = time.monotonic()
            # A public TCP relay can deliver several seconds of evenly
            # captured blocks in a burst after a brief pause on the network.
            self._credit = min(PCM_BURST_FRAMES, self._credit + (now - self._last_frame) * PCM_FRAMES_PER_SECOND)
            self._last_frame = now
            if self._credit < 1:
                self._invalid(1008)
            self._credit -= 1
            pcm = np.frombuffer(data, dtype="<i2").astype(np.int16, copy=False)
            frame = AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
            frame.sample_rate = PCM_RATE
            frame.time_base = PCM_TIME_BASE
            frame.pts = self._pts
            self._pts += PCM_FRAME
            return frame


class SocketCallMedia(CallMedia):
    """Run one full-duplex PCM call on a WebSocket that the route has accepted."""

    def __init__(self, store, engine, call_id, simulate_timeout, on_close, prepared_audio, *, vocabulary=None):
        super().__init__(store, engine, call_id, simulate_timeout, on_close, prepared_audio,
                         vocabulary=vocabulary, _webrtc=False, _output_rate=PCM_RATE)
        self._write_queue = asyncio.Queue(maxsize=MAX_WRITE_QUEUE)
        self._write_queue_drained = asyncio.Event()
        self._queue_overloaded = asyncio.Event()
        self._reply_epoch = 0
        self._plan_token = None
        self._plan_ack_at = None
        self._has_audio = False

    def _enqueue(self, payload, epoch=None):
        if self.closed or self._queue_overloaded.is_set():
            return
        try:
            self._write_queue.put_nowait((epoch, payload))
        except asyncio.QueueFull:
            self._queue_overloaded.set()

    def send(self, kind, **data):
        self._enqueue(json.dumps({"type": kind, **data}, ensure_ascii=False))

    def _cancel_reply(self):
        super()._cancel_reply()
        self._reply_epoch += 1
        self._plan_token = None
        self._plan_ack_at = None

    def _on_output_frame(self, has_audio):
        self._has_audio = has_audio
        started_at = self.plan_started_at
        super()._on_output_frame(has_audio)
        if has_audio and started_at is None and self.plan_started_at is not None:
            self._plan_token = uuid4().hex
            marker = json.dumps({"type": "plan-start", "token": self._plan_token})
            self._enqueue(marker, self._reply_epoch)

    def _acknowledge(self, token):
        if self._plan_token is not None and token == self._plan_token and self._plan_ack_at is None:
            self._plan_ack_at = time.monotonic()

    def _playback_at_onset(self, onset):
        if self._plan_token is None or self._plan_ack_at is None or onset <= self._plan_ack_at:
            return "", ""
        # The browser acknowledges rendering the first remedy block. Server
        # timing can still describe the full send, but cannot establish onset.
        delivered, _ = super()._playback_at_onset(onset)
        return delivered, self.reply_text

    async def _write(self, socket):
        while not self.closed:
            epoch, payload = await self._write_queue.get()
            if self._write_queue.qsize() <= WRITE_LOW_WATER:
                self._write_queue_drained.set()
            if epoch is not None and epoch != self._reply_epoch:
                continue
            async with asyncio.timeout(SEND_TIMEOUT):
                if isinstance(payload, bytes):
                    await socket.send_bytes(payload)
                else:
                    await socket.send_text(payload)

    async def _pump_audio(self):
        while not self.closed:
            if self._write_queue.qsize() >= WRITE_HIGH_WATER:
                try:
                    async with asyncio.timeout(SEND_TIMEOUT):
                        while self._write_queue.qsize() > WRITE_LOW_WATER:
                            self._write_queue_drained.clear()
                            await self._write_queue_drained.wait()
                except TimeoutError:
                    raise _WriteDrainTimeout from None
                # A pause for the relay must not make the media clock send
                # the backlog in a burst when the socket becomes writable.
                self.output.resync_clock()
            frame = await self.output.recv()
            if self._has_audio:
                self._enqueue(frame.to_ndarray().astype("<i2", copy=False).tobytes(), self._reply_epoch)

    async def run(self, socket):
        source = _SocketInput(socket, self._acknowledge)
        self.channel = source
        tasks = set()
        close_code = 1000
        try:
            call = await asyncio.to_thread(self.store.get_call, self.call_id)
            if self.closed:
                return
            self._begin_call(call)
            self.reader = asyncio.create_task(self._read_audio(source))
            tasks = {
                self.reader,
                asyncio.create_task(self._write(socket)),
                asyncio.create_task(self._pump_audio()),
                asyncio.create_task(self._queue_overloaded.wait()),
            }
            finished, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in finished:
                if not task.cancelled():
                    task.result()
            close_code = source.close_code
            if self._queue_overloaded.is_set():
                close_code = 1013
                log.warning("%s WebSocket outbound queue overflow", self.call_id)
        except _WriteDrainTimeout:
            close_code = 1013
            log.warning("%s WebSocket outbound queue did not drain in time", self.call_id)
        except TimeoutError:
            close_code = 1013
            log.warning("%s WebSocket outbound send timed out", self.call_id)
        except (WebSocketDisconnect, OSError):
            pass
        except Exception:
            close_code = 1011
            log.exception("WebSocket audio transport failed for %s", self.call_id)
        finally:
            if source.peer_close_code is not None:
                log.info("%s WebSocket inbound disconnected (code %d)", self.call_id, source.peer_close_code)
            await self.close()
            self.output.stop()
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            try:
                await socket.close(code=close_code)
            except (RuntimeError, WebSocketDisconnect, OSError):
                pass
