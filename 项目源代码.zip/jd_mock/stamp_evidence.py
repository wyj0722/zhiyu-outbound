"""Retrieve possible interpretations from this turn for a local model to rank.

Company names come from the selected order. A mention offers an option to the
model, not a finding of ownership. Each option retains the original clause.
"""

import re
from dataclasses import dataclass

from .cases import DEMO_MERCHANT_NAME
from .dialogue import accepts_offered_plan, asks_for_commitment


@dataclass(frozen=True)
class Evidence:
    quote: str
    mention: str = ""


DESCRIPTIONS = {
    "M": "现有店铺自己的章", "G": "现有授权方的章", "T": "现有其他单位的章",
    "N": "原件完全没盖章", "U": "信息不足或只知道经手人",
    "R": "问能否通过审核", "W": "问为什么退回或缺什么", "A": "问上传办法", "P": "问接下来怎么处理或重述方案",
    "S": "问本单需要哪家公司的公章或联系谁补盖",
    "C": "本人明确接受办理方案", "H": "未同意、暂缓办理",
}
HANDLERS = {"m": "merchant", "g": "grantor", "t": "third_party", "-": "unknown"}
ROLES = {"M": "merchant", "G": "grantor", "T": "third_party", "N": "none", "U": "unknown"}

MERCHANT = re.compile(
    rf"{re.escape(DEMO_MERCHANT_NAME)}|我(?:们)?(?:这家|自家|自己|这边的?|家|的)?(?:店面?|门店|单位|公司|商号|企业|商家|商户|卖家)"
    r"|我们(?:自己|的(?:公?章|印|名))|咱(?:们)?(?:家|们|自己|店|门店|公司)"
    r"|本(?:店|公司|企业|商户)|(?:(?<!\w)|(?<=是))自(?:家|己)(?:的)?(?:店|名|公?章|公司)|我(?:司|方)|店(?:铺|里)|卖场自己"
)
THIRD = re.compile(r"(?:代理|经销|供货|批发|供销|供应|分销|渠道|物流|租赁|代运营)(?:单位|企业|公司|商|方)?"
                   r"|(?:中间|代办)(?:单位|企业|公司|商|方)"
                   r"|别(?:人|家|的公司)|其他(?:单位|公司)|外(?:面|部|包)(?:的)?(?:单位|公司)|第三方")
LEGAL_UNIT = re.compile(r"(?:公司|集团|工作室|经营部|合作社|事务所|商行|商贸|实业|工厂|有限公司)")
HANDLING = re.compile(r"跑(?:腿|的|去|这|过|手续)|经手|经办|承办|交接|办理(?:人|的)|去办|帮.{0,7}(?:办|拿|盖|取|递|送|带)|"
                      r"(?:送|递|交|取)件|(?:拿|递)(?:过来|过|来|去|回)|"
                      r"送(?:去|来|过)|带(?:回|去|来)|代(?:盖|办|送)|亲自|盖章的(?:人|手)|(?:出面|负责)(?:办理|跑)")
STAFF = re.compile(r"(?:我们?|咱们?|店里|本店|店铺).{0,5}(?:亲自|自己|伙计|员工|会计|出纳|同事|业务员)|我(?:亲自|去|跑)|店里")
PERSON_ROLE = re.compile(r"会计(?!师事务所)|出纳|财务(?:人员)?|代理员|员工|业务员|伙计|同事|经办人|送件人|联系人")
FACE_STATEMENT = re.compile(r"(?:章[面上里]|印文|印章|公章|红章)(?:上|里|中间)?(?:面|的字)?(?:写|刻|是|属于|显示|印着|标)|刻着|印着|印的是|盖的是")
SURFACE = re.compile(r"章(?:面|上|里|印|属)|印(?:文|着|的|面|迹|记|上|的字|章)|公章|红章|盖的|刻|落款|抬头|上面|全(?:名|称)|名(?:字|称)|执照")
UNKNOWN = re.compile(r"看不清|没(?:有)?(?:看|辨认|看清|留意|注意|问|瞧)|不(?:清楚|知道|确定|认识|敢说|好说)|"
                     r"(?:说|认)不(?:清|准)|不记得|似乎|也许|可能|好像|据说|听说|得.{0,5}(?:看看|核实|查)|看错|说错|记错|认错")
NEW_DOCUMENT = re.compile(r"换(?:了|成)(?:另(?:外)?|新)?(?:一|[这那两])?[份张套]|"
                          r"(?:拿到|找到|收到)(?:了)?(?:另(?:外)?|新)(?:一|[这那])?[份张套]")
RETRACTED_READING = re.compile(r"(?:我(?:们)?)?(?:(?:刚才|前面|之前|刚刚)(?:我(?:们)?)?)?"
                               r"(?:看|认|核对)错了?")
HYPOTHETICAL = re.compile(r"如果|假如|假设|要是")
QUESTION = re.compile(r"[?？]|吗|能否|可否|是否|是不是|会不会|要不要|怎样|如何|哪里|哪儿|怎么|什么要求|"
                      r"为啥|为什么|想问|问一下|如果|假如|假设")
REVIEW = re.compile(r"(?:复审|过审|审核|审批|通过|能过|稳过|包过|就过|能批|驳回)")
DETAIL = re.compile(r"原因|哪里.{0,2}缺|缺(?:啥|什么|哪)|要求|为(?:啥|什么)|退回|不完整")
NEXT_STEP = re.compile(
    r"(?:下一步|接下来|然后).{0,8}(?:怎么|怎样|如何|做什么|改什么|该做啥)"
    r"|(?:再|重)(?:说|讲|复述).{0,4}(?:一遍|一下|一次)"
    r"|(?:那|上一|刚才的)(?:一)?(?:步|个步骤|个方案).{0,8}(?:再讲讲|再说说|怎么做)"
    r"|(?:怎么|怎样|如何)(?:补救|整改|处理|修改)"
)
UPLOAD = re.compile(r"传|重交|重提|提交|交到|交给")
FUTURE_UPLOAD_PLEDGE = re.compile(
    r"(?:好的?|行|可以|嗯|没问题|明白了)?(?:那)?(?:就这[么样]定了?)?"
    r"我(?:们)?(?:(?:今天|明天|一会儿?|待会儿?|稍后|晚点|今晚|明早|现在|回去|下午)(?:就|会)?|会|就|这就|马上)"
    r"把(?:这份|这张|这个|那份)?(?:(?:已经)?(?:完整|盖好章?|带公章)的?)?"
    r"(?:销售)?(?:授权书|文件|材料|附件)"
    r"(?:重新)?(?:上传|重传|传回|传上去)(?:到(?:商品|品牌|入驻)?申请单)?"
    r"(?:然后|之后|后|并|再)?(?:重新提交|重交|重提|提交)(?:申请(?:单)?)?"
)
HOLD = re.compile(r"暂缓|暂时|再(?:定|说(?!一下|一遍|一次|一回|说)|商量|决定|考虑)|别.{0,5}(?:记|办)|不(?:想|要|同意|接受|愿意|确定|能确认)|"
                  r"(?:没|尚未|未).{0,3}(?:同意|答应|决定)|先.{0,8}(?:商量|考虑|问问|核实|查查|确认一下)|"
                  r"等.{0,12}(?:再|回来)|不能.{0,4}(?:保证|答应)|(?:转.{0,2}人工|找人工)")
DEFERRED_CHOICE = re.compile(r"(?:再|才|随后)(?:决定|考虑|看看|确认)(?:要不要|是否|能不能|是不是)")
ASSENT = re.compile(r"同意|答应|确认|决定|愿意|我(?:们)?(?:会|就|这就|来|马上)|(?:按|照).{0,18}(?:做|办|处理|来|改|重交)|就这(?:么|样)办")
STAMP = re.compile(r"(?:补|加|重新|去)?盖.{0,4}(?:章|印)|补.{0,3}[章印]")
REQUIRED_SEAL_PARTY = re.compile(
    r"(?:需要|应(?:该)?|该|要).{0,18}(?:谁|哪家(?:公司)?|哪个(?:公司|单位)?).{0,8}(?:章|印)|"
    r"(?:找|请|联系|让).{0,4}(?:谁|哪家(?:公司)?|哪个(?:公司|单位)?).{0,6}(?:盖|补).{0,3}(?:章|印)|"
    r"(?:盖|用|补盖)(?:谁|哪家(?:公司)?|哪个(?:公司|单位)?)(?:的)?(?:公章|印章|章|印)"
)
ABSENT = re.compile(r"(?:没(?:有)?|未(?:曾)?|忘(?:记|了)?|漏)(?:给.{1,4})?(?:加|签)?盖(?:过|上|任何|一枚|一个|一颗|红色的)?(?:公章|印章|章|印)"
                    r"|(?:没有|没|无|找不到|看不到)(?:任何|一[个枚颗处]?)?(?:公章|印章|红章|印迹|印章痕迹)|"
                    r"(?:章|印)(?:都|也|还)?(?:没有|没盖)|(?:空白|空着).{0,4}(?:章|印)|(?:用印处|盖章处).{0,3}(?:空白|空着)")


def is_future_upload_pledge(text):
    return bool(FUTURE_UPLOAD_PLEDGE.fullmatch(re.sub(r"[\s,，。.!！、]+", "", text)))


def asks_required_seal_party(text):
    if not REQUIRED_SEAL_PARTY.search(text):
        return False
    past = re.search(r"原来|之前|以前|当时|当初|上次|已经|曾经|刚才|刚刚|找过|联系过", text)
    required_now = re.search(r"需要|应(?:该)?|该|现在|这次|本单|接下来|还要|要找|要联系", text)
    return not past or bool(required_now)


def needs_owner_recheck(text):
    return any(
        not HYPOTHETICAL.search(clause) and (
            NEW_DOCUMENT.search(clause) or RETRACTED_READING.fullmatch(clause)
            or SURFACE.search(clause) and not asks_required_seal_party(clause)
            and (UNKNOWN.search(clause) or re.search(r"不是|并非|不属于", clause))
            or FACE_STATEMENT.search(clause) and LEGAL_UNIT.search(clause)
        )
        for clause in _clauses(text)
    )


def needs_handler_recheck(text):
    return any(
        not HYPOTHETICAL.search(clause) and (
            NEW_DOCUMENT.search(clause) or HANDLING.search(clause) and UNKNOWN.search(clause)
        )
        for clause in _clauses(text)
    )


def _grantor_words(order):
    name = order.facts["grantor"]
    short = re.sub(r"(?:品牌(?:有限责任|有限)?公司|有限责任公司|有限公司|集团公司)$", "", name)
    aliases = [re.escape(name), r"授权(?:单位|公司|人|方|一方)", r"(?:品牌|商标)(?:权人|持有方|持有人|所有人|那边|方)",
               r"(?:给我们?|给本店|给店铺)(?:出具)?授权的(?:公司|单位)?"]
    if len(short) >= 2 and short != name:
        # A short trading name alone is useful only if the speaker explicitly
        # associates it with the seal. It must not prefix a different legal name.
        aliases.append(re.escape(short) + r"(?=的?(?:公?章|印)|[，。！？,!?\s]|$)")
    return re.compile("|".join(aliases))


def _negated(clause, match):
    before, after = clause[:match.start()], clause[match.end():]
    return bool(re.search(r"(?:不是|并非|不属于|不叫|没盖|没有盖)(?:用|盖|咱|我们)?(?:的)?$", before)
                or re.match(r".{0,4}(?:不同|不一样|不一致|不相符|没关系|不是一家)", after))


def _clauses(text):
    return [piece.strip() for piece in re.split(
        r"[，,。.!！;；、\n]+|(?<=[?？])|(?=不过|但是|其实|而是|实际上|章(?:上|面)(?:写|刻|是)|印文(?:显示|是)"
        r"|还需不需要|还需要|还要不要|该怎么|那我想问)", text
    ) if piece.strip()]


def readings(order, text, previous, last_reply):
    grantor = _grantor_words(order)
    hypotheses, handlers = {}, {}
    pieces = _clauses(text)
    question = bool(QUESTION.search(text) or asks_required_seal_party(text))
    owner_changed = needs_owner_recheck(text)
    prior_plan = previous.get("plan_offered") and asks_for_commitment(last_reply) and not owner_changed
    offered_upload = prior_plan and previous.get("plan") == "upload" and previous.get("owner") == "grantor"
    skips_remedy = re.search(r"(?:不|没(?:有)?|无需|不用)(?:再|去)?(?:盖|补|找|改|重交|提交)|按?原样", text)
    consent = not (question or HOLD.search(text) or skips_remedy) and (
        prior_plan and (ASSENT.search(text) or accepts_offered_plan(text) or STAMP.search(text) and UPLOAD.search(text))
        or offered_upload and is_future_upload_pledge(text)
        or ASSENT.search(text) and grantor.search(text) and STAMP.search(text) and UPLOAD.search(text)
    )
    for clause in pieces:
        hand = HANDLING.search(clause)
        people = {"m": STAFF.search(clause) or MERCHANT.search(clause),
                  "g": grantor.search(clause), "t": THIRD.search(clause)}
        if hand and not UNKNOWN.search(clause) and not asks_required_seal_party(clause):
            for role, mention in people.items():
                if mention and not _negated(clause, mention):
                    handlers[role] = Evidence(clause, mention[0])

        if (QUESTION.search(clause) or asks_required_seal_party(clause) or HYPOTHETICAL.search(text)
                or consent or UNKNOWN.search(clause) or HOLD.search(clause)):
            continue
        if ABSENT.search(clause):
            hypotheses["N"] = Evidence(clause, ABSENT.search(clause)[0])
            continue
        # An organization mentioned only in a delivery/handling clause, or
        # in a future instruction, supplies no evidence about today's seal.
        if (hand or PERSON_ROLE.search(clause)) and not FACE_STATEMENT.search(clause):
            continue
        if re.search(r"(?:应该|打算|得先|准备|需要|要去|要求|想找|要找|要请|我会|请问|还得|要让)", clause):
            continue
        merchant, authorized, other = MERCHANT.search(clause), grantor.search(clause), THIRD.search(clause)
        for code, mention in (("M", merchant), ("G", authorized), ("T", other)):
            if not mention or _negated(clause, mention):
                continue
            # A short answer must actually name the owner. Its length cannot
            # distinguish "我们店的" from a statement about the shop's clerk.
            prefix, suffix = clause[:mention.start()], clause[mention.end():]
            direct = (re.fullmatch(r"(?:是|就是|用了|用的|盖的)?(?:那个|这家|一家)?", prefix)
                      and re.fullmatch(r"(?:铺|里)?(?:自己|自家)?(?:的)?(?:公章|印章|章|印)?", suffix))
            if SURFACE.search(clause) or direct:
                hypotheses[code] = Evidence(clause, mention[0])

    inquiry = ""
    inquiry_text = "。".join(clause for clause in pieces if not DEFERRED_CHOICE.search(clause))
    if QUESTION.search(inquiry_text) and REVIEW.search(inquiry_text):
        inquiry = "R"
    elif asks_required_seal_party(inquiry_text):
        inquiry = "S"
    elif QUESTION.search(inquiry_text):
        if UPLOAD.search(inquiry_text):
            inquiry = "A"
        elif DETAIL.search(inquiry_text):
            inquiry = "W"
    known_owner = not owner_changed and previous.get("owner") in {"merchant", "grantor", "third_party", "none"}
    if not inquiry and not HOLD.search(text) and NEXT_STEP.search(text) and (hypotheses or known_owner):
        inquiry = "P"
    if inquiry:
        # One response can both acknowledge a reported seal and answer a
        # question. The model may also select a question without that fact.
        hypotheses = {code + "+" + inquiry: evidence for code, evidence in hypotheses.items()}
        hypotheses[inquiry] = Evidence(text)
    if HOLD.search(text) and inquiry != "R":
        hypotheses["H"] = Evidence(text)
    if consent:
        hypotheses["C"] = Evidence(text)
    grantor_name = order.facts["grantor"]
    if (previous.get("pending_grantor_confirmation") == grantor_name
            and last_reply.endswith(f"上面写的是{grantor_name}这几个字吗？")):
        if re.fullmatch(r"(?:是(?:的|这家|这几个字)?|对(?:的|就是这家|得上)?|没错|字都对|一字不差|完全一致)[。!！\s]*", text.strip()):
            hypotheses["G"] = Evidence(text)
    hypotheses["U"] = Evidence(text)
    handlers["-"] = Evidence("")
    return hypotheses, handlers
