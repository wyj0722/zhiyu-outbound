from collections import deque
from dataclasses import dataclass
from math import tau

import numpy as np


SAMPLE_RATE = 16_000


@dataclass(frozen=True)
class Detection:
    audio: np.ndarray | None = None
    started: bool = False
    ended: bool = False
    voiced: bool = False
    onset_lookback: float = 0.0
    trailing_silence: float | None = None


class VoiceActivity:
    """Endpoint 20 ms frames at 16 kHz, keeping the onset for the recognizer."""

    frame_size = 320

    def __init__(self):
        self._lead = deque(maxlen=14)
        self._loud = 0
        self._quiet = 0
        self._active = 0

    def push(self, frame: np.ndarray) -> Detection:
        level = float(np.sqrt(np.mean(frame * frame)))
        if not self._active:
            self._lead.append(frame)
            self._loud = self._loud + 1 if level >= 0.014 else 0
            if self._loud < 3:
                return Detection()
            audio = np.concatenate(self._lead)
            self._lead.clear()
            self._active = self._loud
            return Detection(audio=audio, started=True, voiced=True, onset_lookback=0.04)

        self._active += 1
        voiced = level >= 0.009
        self._quiet = 0 if voiced else self._quiet + 1
        ended = self._quiet >= 20 or self._active >= 750
        if ended:
            self._active = self._loud = self._quiet = 0
        return Detection(audio=frame, ended=ended, voiced=voiced)


class SileroVoiceActivity:
    """Adapt 32 ms sherpa-onnx detection to the live recognizer's frame API."""

    frame_size = 512
    _highpass_decay = 1 / (1 + tau * 160 / SAMPLE_RATE)

    def __init__(self, detector):
        self._detector = detector
        self._lead = deque(maxlen=9)
        self._samples_seen = 0
        self._speech_start = None
        self._previous_input = 0.0
        self._previous_output = 0.0

    def _for_detection(self, frame: np.ndarray) -> np.ndarray:
        # Keep the filter continuous across frames. The recognizer receives
        # the original samples, including quiet consonants before onset.
        filtered = np.empty_like(frame)
        previous_input = self._previous_input
        previous_output = self._previous_output
        for index, sample in enumerate(frame):
            value = float(sample)
            previous_output = self._highpass_decay * (previous_output + value - previous_input)
            filtered[index] = previous_output
            previous_input = value
        self._previous_input = previous_input
        self._previous_output = previous_output
        return filtered

    def push(self, frame: np.ndarray) -> Detection:
        if frame.shape != (self.frame_size,):
            raise ValueError("Silero expects 512 mono samples at 16 kHz.")
        self._detector.accept_waveform(self._for_detection(frame))
        self._samples_seen += self.frame_size
        active = self._detector.is_speech_detected()
        if self._speech_start is None:
            self._lead.append(frame)
            if not active:
                return Detection()
            self._speech_start = self._detector.current_segment.start
            # The native start includes context before speech. Using it as
            # the earliest possible onset avoids crediting audio played later.
            lookback = max(0, self._samples_seen - self._speech_start) / SAMPLE_RATE
            audio = np.concatenate(self._lead)
            self._lead.clear()
            return Detection(audio=audio, started=True, voiced=True, onset_lookback=lookback)

        if not self._detector.empty():
            segment = self._detector.front
            silence = max(0, self._samples_seen - segment.start - len(segment.samples)) / SAMPLE_RATE
            self._detector.pop()
            self._speech_start = None
            return Detection(audio=frame, ended=True, trailing_silence=silence)

        if self._samples_seen - self._speech_start >= 15 * SAMPLE_RATE:
            self._detector.reset()
            self._samples_seen = 0
            self._speech_start = None
            return Detection(audio=frame, ended=True, voiced=active)
        return Detection(audio=frame, voiced=active)
