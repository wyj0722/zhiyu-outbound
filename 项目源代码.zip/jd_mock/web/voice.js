function gatherIce(peer) {
  if (peer.iceGatheringState === "complete") return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      peer.removeEventListener("icegatheringstatechange", check);
      reject(new Error("WebRTC 未能获取本机连接地址。"));
    }, 5000);
    function check() {
      if (peer.iceGatheringState !== "complete") return;
      clearTimeout(timer);
      peer.removeEventListener("icegatheringstatechange", check);
      resolve();
    }
    peer.addEventListener("icegatheringstatechange", check);
    check();
  });
}

export class VoiceCall {
  constructor(callbacks) {
    this.callbacks = callbacks;
    this.closed = false;
  }

  async connect(callId, _openingReply, { simulateTimeout = false } = {}) {
    if (!navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection) {
      throw new Error("请通过本机地址在 Edge 或 Chrome 打开，并允许使用麦克风。");
    }
    this.callbacks.onState?.("connecting");
    this.audio = new Audio();
    this.audio.autoplay = true;
    try {
      const mic = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 },
      });
      if (this.closed) {
        mic.getTracks().forEach((track) => track.stop());
        return;
      }
      this.mic = mic;
      const peer = new RTCPeerConnection({ iceServers: [] });
      this.peer = peer;
      for (const track of mic.getAudioTracks()) peer.addTrack(track, mic);
      const channel = peer.createDataChannel("call-events");
      this.channel = channel;
      peer.addEventListener("track", ({ track, streams }) => {
        if (track.kind !== "audio" || this.closed) return;
        this.audio.srcObject = streams[0] || new MediaStream([track]);
        this.audio.play().catch(() => this.callbacks.onError?.("浏览器阻止了声音播放，请在页面上重新发起通话。"));
      });
      channel.addEventListener("message", (event) => this.receive(JSON.parse(event.data)));
      peer.addEventListener("connectionstatechange", () => {
        if (peer.connectionState === "failed" && !this.closed) {
          this.callbacks.onError?.("本机 WebRTC 连接失败，请结束通话后重试。");
        }
      });
      await peer.setLocalDescription(await peer.createOffer());
      await gatherIce(peer);
      const response = await fetch("/api/calls/" + encodeURIComponent(callId) + "/offer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: peer.localDescription.type,
          sdp: peer.localDescription.sdp,
          simulate_timeout: simulateTimeout,
        }),
      });
      const answer = await response.json();
      if (!response.ok) throw new Error(answer.detail || "无法发起 WebRTC 通话。");
      if (!this.closed) await peer.setRemoteDescription(answer);
    } catch (error) {
      this.close();
      throw error;
    }
  }

  receive(message) {
    if (this.closed) return;
    const cb = this.callbacks;
    switch (message.type) {
      case "interrupt":
        this.audio.muted = true;
        cb.onInterrupt?.(message);
        break;
      case "state":
        if (message.state === "speaking") this.audio.muted = false;
        cb.onState?.(message.state, message);
        break;
      case "transcript":
        cb.onTranscript?.(message);
        break;
      case "update":
        cb.onUpdate?.(message.data);
        break;
      case "timing":
        cb.onTiming?.(message);
        break;
      case "error":
        cb.onError?.(message.message);
        break;
      case "ended":
        this.close();
        break;
    }
  }

  setMuted(muted) {
    for (const track of this.mic?.getAudioTracks() || []) track.enabled = !muted;
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    this.channel?.close();
    this.peer?.close();
    this.mic?.getTracks().forEach((track) => track.stop());
    if (this.audio) {
      this.audio.pause();
      this.audio.srcObject = null;
    }
    this.callbacks.onState?.("closed");
  }
}
