import { VoiceCall } from "./voice.js?v=strategy-library";
import { VoiceSocketCall } from "./voice-socket.js?v=strategy-library";
import { connectStrategyLibrary, strategyMatch } from "./strategies.js?v=all-scenes-2";

const $ = (id) => document.getElementById(id);
const startButton = $("start-call");
const muteButton = $("mute-call");
const endButton = $("end-call");
const retryButton = $("retry-writeback");
const timeoutControl = $("simulate-timeout");
const caseSelect = $("case-select");
const caseOptions = $("case-options");
const materialFields = $("material-fields");
const authorizationRows = Array.from(materialFields.children);
const transcriptBody = $("transcript-body");
const progressSteps = Array.from($("progress").children);
const cases = new Map();
const pendingCalls = new Map();
const modelLabels = { local: "本机大模型", deepseek: "DeepSeek API", doubao: "豆包 API" };

const phases = {
  idle: ["待拨号", "麦克风待启用", "发起通话后，允许浏览器使用麦克风。"],
  connecting: ["正在接通", "正在连接麦克风", "请在浏览器提示时允许使用麦克风。"],
  listening: ["正在聆听", "麦克风已启用", "请用麦克风说话。"],
  speaking: ["坐席播报中", "麦克风已启用", "你可以直接说话打断坐席。"],
  processing: ["正在处理", "麦克风已启用", "坐席正在处理刚才的回复。"],
  muted: ["已静音", "麦克风已静音", "点击取消静音，继续与坐席对话。"],
  closed: ["已挂断", "麦克风已关闭", "通话已结束，仍可查看通话记录和回写结果。"],
  error: ["连接中断", "麦克风已关闭", "可以重新发起通话。"],
};

let voice;
let callId;
let selectedCaseId;
let historyRequest = 0;
let displayedReceiptId;
let displayedDecisionTurnId;
let phase = "idle";
let action;
let muted = false;
let connected = false;
let pendingWriteback = false;
let resolvingPending = false;
let ready = null;
let VoiceTransport = VoiceCall;
let startedAt = 0;
let elapsedTimer;
let interruptCount = 0;
let receiptCount = 0;
let session = 0;
connectStrategyLibrary(request);

function showNotice(message = "") {
  const notice = $("notice");
  notice.textContent = message;
  notice.hidden = !message;
}

async function request(path, body) {
  const options = body === undefined ? { cache: "no-store" } : {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
  const response = await fetch(path, options);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = payload.detail || payload.error || payload.message;
    const error = new Error(typeof message === "string" ? message : `请求失败（${response.status}）`);
    error.status = response.status;
    throw error;
  }
  return payload;
}

function callPath(endpoint) {
  return `/api/calls/${encodeURIComponent(callId)}/${endpoint}`;
}

function rememberPending(caseId, id) {
  const key = `jd-mock.pending.${caseId}`;
  if (id) pendingCalls.set(caseId, id);
  else pendingCalls.delete(caseId);
  try {
    if (id) window.sessionStorage.setItem(key, id);
    else window.sessionStorage.removeItem(key);
  } catch {
    // The in-memory map still supports switching orders when tab storage is disabled.
  }
}

async function restorePending(caseId, version) {
  let id = pendingCalls.get(caseId);
  if (!id) {
    try { id = window.sessionStorage.getItem(`jd-mock.pending.${caseId}`); }
    catch { return; }
  }
  if (!id) return;
  resolvingPending = true;
  renderControls();
  try {
    const payload = await request(`/api/calls/${encodeURIComponent(id)}`);
    if (version !== session) return;
    resolvingPending = false;
    if (payload.case_id === caseId && payload.call_id === id && payload.pending_writeback === true) {
      callId = id;
      setPhase("closed");
      applyUpdate(payload, { showReply: false });
    } else {
      rememberPending(caseId);
    }
  } catch (error) {
    if (version !== session) return;
    if (error.status === 404) {
      resolvingPending = false;
      rememberPending(caseId);
    } else {
      showNotice("暂时无法核对这张工单的待查询回执。请刷新页面，或切换工单后再试。");
    }
  }
  renderControls();
}

async function refreshHistory() {
  const caseId = selectedCaseId;
  const version = ++historyRequest;
  try {
    const history = await request(`/api/cases/${encodeURIComponent(caseId)}/receipts`);
    if (version !== historyRequest || selectedCaseId !== caseId) return;
    if (history.case_id !== caseId) throw new Error("工单编号不一致。");
    $("case-history-count").textContent = history.receipt_count;
    const latest = history.latest_receipt;
    $("last-receipt-id").textContent = latest?.receipt_id || "";
    $("last-receipt-reason").textContent = latest?.reason || "";
    $("last-receipt-confirmation").textContent = latest?.confirmation_text || latest?.confirmation || "";
    $("last-receipt-row").hidden = !latest;
  } catch {
    if (version !== historyRequest || selectedCaseId !== caseId) return;
    $("case-history-count").textContent = "暂时无法读取";
    $("last-receipt-id").textContent = "";
    $("last-receipt-row").hidden = true;
  }
}

function selectCase(caseId) {
  const workOrder = cases.get(caseId);
  if (!workOrder || caseId === selectedCaseId) return;
  ++session;
  selectedCaseId = caseId;
  caseSelect.value = caseId;
  resolvingPending = false;
  resetCall();
  showNotice();
  setPhase("idle");
  $("case-id").textContent = caseId;
  $("case-title").textContent = workOrder.scenario;
  $("case-merchant").textContent = workOrder.merchant_name || "—";
  renderMaterial(workOrder.submitted_material ?? workOrder.submitted_authorization);
  $("case-area-row").hidden = !workOrder.area;
  $("case-area").textContent = workOrder.area || "";
  $("case-history-count").textContent = "…";
  $("last-receipt-id").textContent = "";
  $("last-receipt-row").hidden = true;
  $("last-receipt-row").open = false;
  void refreshHistory();
  void restorePending(caseId, session);
}

function renderMaterial(material) {
  const details = $("submitted-materials");
  details.open = false;
  details.hidden = !material?.title;
  if (details.hidden) return;

  const { title, grantor, grantee, scope, seal, review_note, fields } = material;
  let keyFact = "";
  if (Array.isArray(fields)) {
    const rows = fields.filter((field) => typeof field?.key === "string" && field.key
      && typeof field.label === "string" && field.label).map(({ key, label, value }) => {
      const row = document.createElement("div");
      const term = document.createElement("dt");
      const description = document.createElement("dd");
      row.dataset.materialField = key;
      term.textContent = label;
      description.textContent = value || "未记录";
      row.append(term, description);
      return row;
    });
    materialFields.replaceChildren(...rows);
  } else {
    materialFields.replaceChildren(...authorizationRows);
    keyFact = grantor && grantee ? `${grantor} → ${grantee}` : scope && `覆盖${scope}`;
    $("material-grantor").textContent = grantor || "未记录";
    $("material-grantee").textContent = grantee || "未记录";
    $("material-scope").textContent = scope || "未记录";
    $("material-seal").textContent = seal || "未记录";
  }
  $("material-glance").textContent = [title, keyFact].filter(Boolean).join(" · ");
  $("material-title").textContent = title;
  $("material-review-note").textContent = review_note || "";
  $("material-review").hidden = !review_note;
}

function highlightMaterial(fields) {
  const details = $("submitted-materials");
  if (details.hidden) return;
  const promptFields = Array.isArray(fields) ? fields : [];
  const labels = [];
  for (const item of details.querySelectorAll("[data-material-field]")) {
    if (promptFields.includes(item.dataset.materialField)) {
      item.dataset.highlighted = "true";
      labels.push(item.querySelector("dt").textContent);
    } else {
      delete item.dataset.highlighted;
    }
  }
  if (Array.isArray(fields)) details.open = true;
  $("material-focus").textContent = labels.length ? `正在核对${labels.join("、")}` : "";
}

async function loadCases() {
  try {
    const catalog = await request("/api/cases");
    if (!catalog.cases?.length) throw new Error("当前没有可拨打的模拟工单。");
    for (const item of catalog.cases) cases.set(item.case_id, item);
    caseSelect.replaceChildren(...catalog.cases.map((item) =>
      new Option(`${item.scenario} · ${item.case_id}`, item.case_id)
    ));
    caseOptions.replaceChildren(...catalog.cases.map((item) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "case-option";
      button.dataset.caseId = item.case_id;
      const title = document.createElement("strong");
      title.textContent = item.scenario;
      const area = document.createElement("span");
      area.textContent = item.title?.split(" · ", 1)[0] || item.area || item.case_id;
      const marker = document.createElement("span");
      marker.className = "selection-marker";
      marker.setAttribute("aria-hidden", "true");
      button.append(marker, title, area);
      button.addEventListener("click", () => selectCase(item.case_id));
      return button;
    }));
    selectCase(catalog.cases[0].case_id);
  } catch (error) {
    caseSelect.replaceChildren(new Option("工单读取失败", ""));
    caseOptions.textContent = "工单读取失败";
    showNotice(`无法加载工单，请刷新页面重试。${error.message}`);
  }
  renderControls();
}

function setElapsed() {
  const seconds = startedAt ? Math.floor((Date.now() - startedAt) / 1000) : 0;
  $("elapsed").textContent = [Math.floor(seconds / 60), seconds % 60]
    .map((value) => String(value).padStart(2, "0")).join(":");
}

function setPhase(next) {
  if (!Object.hasOwn(phases, next)) return;
  phase = next;
  if (["listening", "speaking", "processing"].includes(phase)) {
    connected = true;
    if (!startedAt) {
      startedAt = Date.now();
      elapsedTimer = window.setInterval(setElapsed, 1000);
    }
  }
  if (["closed", "error"].includes(phase)) {
    connected = false;
    muted = false;
    window.clearInterval(elapsedTimer);
    setElapsed();
    clearInterim();
    highlightMaterial();
  }
  renderControls();
}

function renderControls() {
  const visiblePhase = connected && muted ? "muted" : phase;
  const [status, micStatus, hint] = phases[visiblePhase];
  $("rail-indicator").dataset.state = visiblePhase;
  $("rail-status").textContent = status;
  $("mic-status").textContent = micStatus;
  const answeringIdentity = visiblePhase === "listening"
    && document.querySelector("#progress [data-step='verify'][aria-current='step']");
  $("call-hint").textContent = answeringIdentity
    ? "请回答「是的，我是本人」或「不是，您打错了」。"
    : hint;
  $("call-wave").dataset.active = String(visiblePhase === "speaking" || visiblePhase === "listening");
  $("call-wave").dataset.state = visiblePhase;
  $("connection-label").hidden = !connected;
  const hasCall = phase === "connecting" || connected;
  caseSelect.disabled = hasCall || Boolean(action) || !selectedCaseId;
  for (const button of caseOptions.querySelectorAll("button")) {
    button.disabled = caseSelect.disabled;
    button.setAttribute("aria-pressed", String(button.dataset.caseId === selectedCaseId));
  }
  startButton.disabled = hasCall || Boolean(action) || ready !== true || !selectedCaseId || pendingWriteback || resolvingPending;
  startButton.textContent = hasCall ? "通话中" : (callId ? "重新发起通话" : "发起通话");
  endButton.disabled = !callId || !hasCall || action === "end" || action === "retry";
  muteButton.disabled = !connected || typeof voice?.setMuted !== "function";
  muteButton.textContent = muted ? "取消静音" : "静音";
  muteButton.setAttribute("aria-pressed", String(muted));
  timeoutControl.disabled = hasCall || Boolean(action);
  retryButton.hidden = !pendingWriteback;
  retryButton.disabled = Boolean(action);
  retryButton.textContent = action === "retry" ? "正在重试…" : "重试回写";
}

function transcriptTimestamp() {
  return new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(new Date());
}

function addMessage(role, value, retrieval) {
  const text = typeof value === "string" ? value.trim() : "";
  if (!text) return;
  const message = document.createElement("li");
  message.className = "message";
  message.dataset.role = role;
  const label = document.createElement("span");
  label.className = "message-label";
  label.textContent = `${role === "agent" ? "外呼坐席" : "商家"}　${transcriptTimestamp()}`;
  const content = document.createElement("p");
  content.textContent = text;
  message.append(label, content);
  const match = strategyMatch(retrieval);
  if (match) message.append(match);
  $("empty-transcript").hidden = true;
  $("messages").append(message);
  transcriptBody.scrollTop = transcriptBody.scrollHeight;
}

function clearInterim() {
  $("interim").hidden = true;
  $("interim-text").textContent = "";
}

function updateTranscript(event) {
  const { text, final, role } = typeof event === "string" ? { text: event } : (event || {});
  if (final) {
    clearInterim();
    if (role !== "agent" && role !== "assistant") addMessage("merchant", text);
    return;
  }
  if (role === "agent" || role === "assistant") return;
  $("interim").hidden = !text;
  $("interim-text").textContent = text || "";
  transcriptBody.scrollTop = transcriptBody.scrollHeight;
}

function renderProgress(state, finished) {
  const current = progressSteps.findIndex((step) => step.dataset.step === state);
  for (const [index, step] of progressSteps.entries()) {
    step.removeAttribute("aria-current");
    step.dataset.status = "waiting";
    if (finished || index < current) step.dataset.status = "done";
    if (!finished && index === current) {
      step.dataset.status = "current";
      step.setAttribute("aria-current", "step");
    }
  }
}

function displayValue(value) {
  if (Array.isArray(value)) return value.map(displayValue).filter(Boolean).join("\n");
  if (value && typeof value === "object") {
    return value.label || value.title || value.id || value.reference || JSON.stringify(value);
  }
  return typeof value === "boolean" ? (value ? "是" : "否") : String(value ?? "");
}

function renderReceipt(receipt) {
  const badge = $("receipt-badge");
  const fields = $("receipt-fields");
  const status = $("receipt-status");
  badge.hidden = !(receipt || pendingWriteback);
  fields.hidden = !receipt;
  if (!receipt) {
    badge.dataset.status = "pending";
    badge.textContent = "待重试";
    status.textContent = pendingWriteback ? "本次回写超时，点击「重试回写」取回原凭证。" : "确认处理方案后生成回写凭证。";
    fields.replaceChildren();
    return;
  }

  badge.dataset.status = "saved";
  badge.textContent = "已回写";
  status.textContent = `本次通话已生成 ${receiptCount || 1} 条凭证。`;
  fields.replaceChildren();
  const entries = [
    ["对应工单", receipt.case_id],
    ["业务场景", receipt.scenario],
    ["凭证编号", receipt.receipt_id],
    ["通话编号", receipt.call_id],
    ["身份核验", receipt.verified],
    ["原因说明", receipt.reason],
    ["处理步骤", receipt.action_steps],
    ["商家确认", receipt.confirmation],
    ["确认时的转写", receipt.confirmation_text],
    ["办理渠道", receipt.channel],
    ["证据引用", receipt.evidence_refs],
    ["记录时间", receipt.recorded_at],
  ];
  for (const [label, value] of entries) {
    const formatted = displayValue(value);
    if (!formatted) continue;
    const entry = document.createElement("div");
    const term = document.createElement("dt");
    const description = document.createElement("dd");
    term.textContent = label;
    description.textContent = formatted;
    entry.append(term, description);
    fields.append(entry);
  }
}

function applyUpdate(payload, { showReply = true } = {}) {
  if (!payload || payload.call_id !== callId || payload.case_id !== selectedCaseId) return;
  const decision = payload.stamp_decision || payload.dialogue_decision;
  const modelLabel = modelLabels[cases.get(selectedCaseId)?.dialogue_provider] || modelLabels.local;
  if (decision?.source === "policy") {
    $("case-engine").textContent = decision.action === "record"
      ? "商家已确认当前办理方案" : "已根据工单材料给出办理方案";
  } else if (decision?.source === "model") {
    $("case-engine").textContent = `本轮由${modelLabel}判断`;
  } else if (decision?.source === "fallback") {
    $("case-engine").textContent = payload.stamp_decision
      ? "本轮模型未给出有效判断，已转为追问" : "本轮模型不可用，已用业务规则继续";
  }
  if (payload.stamp_decision) {
    const parties = { merchant: "商家方", grantor: "授权方", third_party: "第三方" };
    $("stamp-owner-row").hidden = false;
    $("stamp-owner").textContent = decision.owner === "none" ? "尚未盖章" : (parties[decision.owner] || "待核实");
    $("stamp-handler-row").hidden = !parties[decision.handler];
    $("stamp-handler").textContent = parties[decision.handler] || "";
  }
  if (Number.isInteger(payload.turn_count)) $("turn-count").textContent = payload.turn_count;
  if (typeof payload.pending_writeback === "boolean") pendingWriteback = payload.pending_writeback;
  rememberPending(payload.case_id, pendingWriteback ? payload.call_id : undefined);
  if (Number.isInteger(payload.receipt_count)) receiptCount = payload.receipt_count;
  if (payload.state && payload.state !== "closed") renderProgress(payload.state, Boolean(payload.receipt));
  if (payload.receipt) {
    renderProgress("complete", true);
    if (payload.receipt.receipt_id !== displayedReceiptId) {
      displayedReceiptId = payload.receipt.receipt_id;
      void refreshHistory();
    }
  }
  if (Object.hasOwn(payload, "receipt") || Object.hasOwn(payload, "pending_writeback")) renderReceipt(payload.receipt);
  if (showReply) {
    const fresh = !decision?.turn_id || decision.turn_id !== displayedDecisionTurnId;
    const retrieval = Object.hasOwn(payload, "strategy_retrieval")
      ? payload.strategy_retrieval : fresh ? decision?.retrieval : undefined;
    addMessage("agent", payload.reply, retrieval);
    if (decision?.turn_id) displayedDecisionTurnId = decision.turn_id;
  }
  renderControls();
}

function resetCall() {
  const order = cases.get(selectedCaseId);
  const modelLabel = modelLabels[order?.dialogue_provider] || modelLabels.local;
  $("case-engine").textContent = order?.dialogue_model ? modelLabel : "业务规则";
  $("stamp-owner-row").hidden = true;
  $("stamp-handler-row").hidden = true;
  callId = undefined;
  displayedReceiptId = undefined;
  displayedDecisionTurnId = undefined;
  startedAt = 0;
  setElapsed();
  interruptCount = 0;
  receiptCount = 0;
  pendingWriteback = false;
  $("turn-count").textContent = "0";
  $("interrupt-count").textContent = "0";
  $("messages").replaceChildren();
  $("empty-transcript").hidden = false;
  clearInterim();
  highlightMaterial();
  renderProgress();
  renderReceipt();
}

async function disconnectFailedCall(error) {
  const failedVoice = voice;
  voice = undefined;
  failedVoice?.close();
  setPhase("error");
  const message = error?.name === "NotAllowedError"
    ? "浏览器未授权使用麦克风。请在地址栏设置中允许麦克风，然后重新发起通话。"
    : (error?.message || String(error) || "语音连接中断，请重试。");
  showNotice(message);
  if (!callId) return;

  const failedSession = session;
  try {
    const payload = await request(callPath("end"), {});
    if (failedSession === session) applyUpdate(payload, { showReply: false });
  } catch {
    // Preserve the original connection error in the workspace.
  }
}

async function startCall() {
  if (startButton.disabled) return;
  const currentSession = ++session;
  const caseId = selectedCaseId;
  const simulateTimeout = timeoutControl.checked;
  resetCall();
  action = "start";
  showNotice();
  setPhase("connecting");
  try {
    const payload = await request("/api/calls", { case_id: caseId, simulate_timeout: simulateTimeout });
    if (currentSession !== session) return;
    callId = payload.call_id;
    if (!callId || payload.case_id !== caseId) throw new Error("服务返回的通话与所选工单不一致，请重新拨号。");
    applyUpdate(payload);

    const call = new VoiceTransport({
      onState: (state, message) => {
        if (voice !== call || currentSession !== session) return;
        setPhase(state);
        if (state === "speaking") highlightMaterial(message?.material_fields);
      },
      onTranscript: (transcript) => {
        if (voice === call && currentSession === session) updateTranscript(transcript);
      },
      onInterrupt: () => {
        if (voice === call && currentSession === session) $("interrupt-count").textContent = ++interruptCount;
      },
      onUpdate: (update) => {
        if (voice === call && currentSession === session) applyUpdate(update);
      },
      onError: (error) => {
        if (voice === call && currentSession === session) void disconnectFailedCall(error);
      },
    });
    voice = call;
    await call.connect(callId, payload.reply, { simulateTimeout });
    if (currentSession !== session || voice !== call) call.close();
    else if (phase === "connecting") setPhase("listening");
  } catch (error) {
    if (currentSession === session && phase !== "error") await disconnectFailedCall(error);
  } finally {
    if (currentSession === session) {
      action = undefined;
      renderControls();
    }
  }
}

async function endCall() {
  session += 1;
  action = "end";
  showNotice();
  const endingVoice = voice;
  voice = undefined;
  endingVoice?.close();
  setPhase("closed");
  try {
    const payload = await request(callPath("end"), {});
    applyUpdate(payload, { showReply: false });
  } catch (error) {
    showNotice(`通话已挂断，结束状态保存失败。${error.message}`);
  } finally {
    action = undefined;
    renderControls();
  }
}

async function retryWriteback() {
  action = "retry";
  showNotice();
  renderControls();
  try {
    const payload = await request(callPath("retry"), {});
    applyUpdate(payload, { showReply: false });
  } catch (error) {
    showNotice(`回写重试失败。${error.message}`);
  } finally {
    action = undefined;
    renderControls();
  }
}

async function checkHealth() {
  const health = $("health");
  try {
    const status = await request("/api/health");
    VoiceTransport = status.voice_transport === "websocket" ? VoiceSocketCall : VoiceCall;
    ready = status.speech_ready !== false;
    health.dataset.health = ready ? "ready" : "unavailable";
    $("health-text").textContent = ready ? "语音服务就绪" : "语音服务未就绪";
    if (!ready && phase === "idle") showNotice(status.detail || "请配置语音服务并重新启动本地应用。");
  } catch {
    ready = false;
    health.dataset.health = "unavailable";
    $("health-text").textContent = "语音服务状态未知";
  }
  renderControls();
}

caseSelect.addEventListener("change", () => {
  if (caseSelect.disabled) caseSelect.value = selectedCaseId;
  else selectCase(caseSelect.value);
});
startButton.addEventListener("click", startCall);
endButton.addEventListener("click", endCall);
retryButton.addEventListener("click", retryWriteback);
muteButton.addEventListener("click", () => {
  if (!voice || !connected) return;
  voice.setMuted(!muted);
  muted = !muted;
  if (muted) clearInterim();
  renderControls();
});
window.addEventListener("pagehide", () => voice?.close());
void checkHealth();
void loadCases();
