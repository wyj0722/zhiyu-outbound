const SAMPLE_RATE = 16000;
const FRAME_BYTES = (SAMPLE_RATE / 50) * 2;
const MAX_MIC_BACKLOG = FRAME_BYTES * 12;
const CONNECT_TIMEOUT_MS = 10000;

async function withTimeout(operation, milliseconds, message) {
  let timer;
  try {
    return await Promise.race([
      operation,
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), milliseconds); }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

export class VoiceSocketCall {
  constructor(callbacks) {
    this.callbacks = callbacks;
    this.closed = false;
    this.muted = false;
    this.outputPaused = true;
    this.generation = 0;
    this.outputTimers = new Set();
    this.silence = new ArrayBuffer(FRAME_BYTES);
  }

  async connect(callId, _openingReply, { simulateTimeout = false } = {}) {
    if (!navigator.mediaDevices?.getUserMedia || !window.AudioContext || !window.AudioWorkletNode) {
      throw new Error("请在 Edge 或 Chrome 通过 HTTPS 或本机地址打开，并允许使用麦克风。");
    }
    this.callbacks.onState?.("connecting");
    try {
      const context = new AudioContext({ sampleRate: SAMPLE_RATE });
      this.context = context;
      if (context.sampleRate !== SAMPLE_RATE || !context.audioWorklet) {
        throw new Error("浏览器无法启用 16 kHz 语音，请换用 Edge 或 Chrome。");
      }
      await withTimeout(context.resume(), CONNECT_TIMEOUT_MS, "浏览器未能启动声音播放，请重新拨号。");
      if (this.closed) return;
      const mic = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 },
      });
      if (this.closed) {
        mic.getTracks().forEach((track) => track.stop());
        return;
      }
      this.mic = mic;
      await context.audioWorklet.addModule(new URL("./voice-socket-worklet.js?v=3", import.meta.url));
      if (this.closed) return;
      const worklet = new AudioWorkletNode(context, "jd-voice-socket", {
        channelCount: 1,
        channelCountMode: "explicit",
        outputChannelCount: [1],
      });
      this.worklet = worklet;
      const rendering = new Promise((resolve, reject) => {
        worklet.port.onmessage = ({ data }) => {
          if (data.type === "ready") {
            resolve();
            return;
          }
          this.handleWorklet(data);
        };
        worklet.onprocessorerror = () => reject(new Error("浏览器语音处理已中断，请重新拨号。"));
      });
      this.source = context.createMediaStreamSource(mic);
      this.source.connect(worklet).connect(context.destination);
      await withTimeout(rendering, 6000, "浏览器音频设备未能开始采播。请检查麦克风和声音输出后重新拨号。");
      if (this.closed) return;
      worklet.onprocessorerror = () => this.fail("浏览器语音处理已中断，请重新拨号。");

      const url = new URL(`/api/calls/${encodeURIComponent(callId)}/voice`, window.location.href);
      url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
      url.searchParams.set("simulate_timeout", String(simulateTimeout));
      const socket = new WebSocket(url);
      this.socket = socket;
      socket.binaryType = "arraybuffer";
      socket.onmessage = ({ data }) => this.handleSocket(data);
      await withTimeout(new Promise((resolve, reject) => {
        socket.onopen = () => {
          socket.onclose = () => {
            if (!this.ending) this.fail("网页语音连接已断开，请重新拨号。");
          };
          resolve();
        };
        socket.onclose = () => reject(new Error("无法连接网页语音服务，请重新拨号。"));
      }), CONNECT_TIMEOUT_MS, "网页语音连接超时，请重新拨号。");
    } catch (error) {
      this.close();
      throw error;
    }
  }

  handleSocket(data) {
    if (this.closed || this.ending) return;
    if (typeof data === "string") {
      let event;
      try {
        event = JSON.parse(data);
      } catch {
        this.fail("网页语音收到无法处理的消息，请重新拨号。");
        return;
      }
      if (event && typeof event === "object") this.receive(event);
      return;
    }
    if (this.outputPaused) return;
    if (!(data instanceof ArrayBuffer) || data.byteLength !== FRAME_BYTES) {
      this.fail("网页语音收到异常音频，请重新拨号。");
      return;
    }
    this.worklet.port.postMessage({ type: "audio", pcm: data, token: this.nextToken, generation: this.generation }, [data]);
    this.nextToken = undefined;
  }

  receive(message) {
    const cb = this.callbacks;
    switch (message.type) {
      case "plan-start":
        if (typeof message.token === "string" && message.token) this.nextToken = message.token;
        break;
      case "interrupt":
        this.clearPlayback();
        cb.onInterrupt?.(message);
        break;
      case "state":
        if (message.state === "speaking") this.outputPaused = false;
        cb.onState?.(message.state, message);
        break;
      case "transcript":
        cb.onTranscript?.(message);
        break;
      case "update":
        cb.onUpdate?.(message.data);
        break;
      case "timing":
        cb.onTiming?.(message);
        break;
      case "error":
        this.fail(message.message);
        break;
      case "ended":
        this.ending = true;
        this.setMuted(true);
        this.worklet.port.postMessage({ type: "drain" });
        this.drainTimer = setTimeout(() => this.close(), 2000);
        break;
    }
  }

  handleWorklet(message) {
    if (this.closed) return;
    const socket = this.socket;
    if (message.type === "capture") {
      if (!this.ending && socket?.readyState === 1 && socket.bufferedAmount <= MAX_MIC_BACKLOG) {
        socket.send(this.muted ? this.silence : message.pcm);
      }
    } else if (message.type === "drained") {
      this.afterPlayout(message.contextTime, () => this.close());
    } else if (message.generation === this.generation) {
      if (message.type === "started") {
        this.afterPlayout(message.contextTime, () => {
          if (!this.ending && socket?.readyState === 1) socket.send(JSON.stringify({ type: "plan-started", token: message.token }));
        });
      } else if (message.type === "overflow") {
        this.fail("网页语音播放积压，请检查网络后重新拨号。");
      }
    }
  }

  afterPlayout(target, done) {
    const context = this.context;
    const deadline = performance.now() + 1800;
    const check = () => {
      if (this.closed) return;
      if (context.state === "running") {
        const timestamp = context.getOutputTimestamp?.();
        // currentTime is a render clock. Without an output clock, allow for
        // the browser's output buffering before treating the sample as audible.
        const reached = timestamp?.performanceTime > 0
          ? timestamp.contextTime >= target
          : context.currentTime >= target + (context.baseLatency || 0) + (context.outputLatency || 0.06);
        if (reached) {
          done();
          return;
        }
      }
      if (performance.now() >= deadline) return;
      const timer = setTimeout(() => {
        this.outputTimers.delete(timer);
        check();
      }, 12);
      this.outputTimers.add(timer);
    };
    check();
  }

  clearPlayback() {
    this.generation += 1;
    this.outputPaused = true;
    this.nextToken = undefined;
    for (const timer of this.outputTimers) clearTimeout(timer);
    this.outputTimers.clear();
    this.worklet?.port.postMessage({ type: "clear" });
  }

  setMuted(muted) {
    this.muted = muted;
    for (const track of this.mic?.getAudioTracks() || []) track.enabled = !muted;
  }

  fail(message) {
    if (!this.closed) this.callbacks.onError?.(message);
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.drainTimer);
    this.clearPlayback();
    this.socket?.close();
    this.mic?.getTracks().forEach((track) => track.stop());
    this.source?.disconnect();
    this.worklet?.disconnect();
    this.worklet?.port.close();
    if (this.context && this.context.state !== "closed") void this.context.close().catch(() => {});
    this.callbacks.onState?.("closed");
  }
}
