const FIELD_LABELS = {
  conditions: "适用条件", actions: "处理动作", reply_requirements: "回复要求", query_examples: "示例问法",
  evidence_refs: "业务依据",
  review_phase: "审核阶段", relation_check: "关系核验", missing_link: "缺失授权关系",
  intent_key: "检索意图", identity_verified: "身份核验状态",
};
const RULE_FIELDS = ["conditions", "actions", "reply_requirements", "query_examples", "evidence_refs"];

function node(tag, content, className) {
  const element = document.createElement(tag);
  if (content) element.textContent = content;
  if (className) element.className = className;
  return element;
}

function display(value) {
  if (Array.isArray(value)) return value.map(display).filter(Boolean).join("\n");
  if (value && typeof value === "object") {
    return Object.entries(value).map(([key, item]) => `${FIELD_LABELS[key] || key} ${display(item)}`).join("\n");
  }
  if (typeof value === "boolean") return value ? "是" : "否";
  return String(value ?? "");
}

function ruleFields(rule) {
  const details = node("dl", "", "strategy-fields");
  for (const key of RULE_FIELDS) {
    const value = display(rule[key]);
    if (!value) continue;
    const row = node("div");
    row.append(node("dt", FIELD_LABELS[key]), node("dd", value));
    details.append(row);
  }
  return details;
}

function versionLabel(strategy) {
  return [strategy.strategy_id, Number.isInteger(strategy.version) && `v${strategy.version}`].filter(Boolean).join(" / ");
}

export function strategyMatch(retrieval) {
  if (!retrieval || !Array.isArray(retrieval.strategies)) return null;
  const matches = retrieval.strategies.map(versionLabel).filter(Boolean);
  const badge = node("span", matches.length ? `命中策略 ${matches.join("、")}` : "本轮无适用策略", "message-strategy");
  badge.dataset.match = matches.length ? "matched" : "none";
  if (retrieval.query) badge.title = `检索问法 ${retrieval.query}`;
  return badge;
}

function strategyCard(strategy, expanded) {
  const entry = node("details");
  const heading = node("summary");
  heading.append(node("strong", strategy.title || strategy.intent || strategy.strategy_id),
    node("span", versionLabel(strategy), "strategy-version"));
  entry.dataset.strategyId = strategy.strategy_id;
  entry.open = expanded.has(strategy.strategy_id);
  entry.addEventListener("toggle", () => {
    if (entry.open) expanded.add(strategy.strategy_id);
    else expanded.delete(strategy.strategy_id);
  });
  entry.append(heading, ruleFields(strategy));
  return entry;
}

export function connectStrategyLibrary(request) {
  const $ = (id) => document.getElementById(id);
  const library = $("strategy-library");
  const filter = $("strategy-scene-filter");
  const status = $("strategy-library-status");
  const list = $("strategy-library-list");
  const expanded = new Set();
  let groups = new Map();
  let revision = 0;

  function render() {
    const selected = filter.value;
    const visible = [...groups].filter(([scene]) => !selected || selected === scene);
    const count = visible.reduce((total, [, rules]) => total + rules.length, 0);
    status.textContent = !count ? "当前没有生效策略。" : selected
      ? `本场景 ${count} 条生效策略` : `共 ${count} 条生效策略，覆盖 ${visible.length} 个场景`;
    list.replaceChildren(...visible.map(([scene, rules]) => {
      const group = node("section", "", "strategy-group");
      group.dataset.scene = scene;
      group.append(node("h3", scene), ...rules.map((rule) => strategyCard(rule, expanded)));
      return group;
    }));
  }

  async function refresh() {
    const requestNumber = ++revision;
    const selected = filter.value;
    status.textContent = "正在读取生效策略…";
    filter.disabled = true;
    list.replaceChildren();
    try {
      const payload = await request("/api/strategies");
      if (requestNumber !== revision) return;
      if (!Array.isArray(payload.strategies)) throw new Error("策略列表格式错误");
      groups = new Map();
      for (const rule of payload.strategies) {
        if (rule.status && rule.status !== "active") continue;
        const scene = rule.scene || "未标注场景";
        if (!groups.has(scene)) groups.set(scene, []);
        groups.get(scene).push(rule);
      }
      filter.replaceChildren(new Option("全部场景", ""), ...[...groups.keys()].map((scene) => new Option(scene, scene)));
      filter.value = groups.has(selected) ? selected : "";
      filter.disabled = groups.size === 0;
      render();
    } catch (error) {
      if (requestNumber !== revision) return;
      status.textContent = `无法读取策略库。${error.message}`;
    }
  }

  filter.addEventListener("change", render);
  $("strategy-library-open").addEventListener("click", () => {
    library.showModal();
    void refresh();
  });
}
