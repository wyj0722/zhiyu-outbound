const FRAME_SAMPLES = sampleRate / 50;
const MAX_PLAYBACK_FRAMES = 64;

class VoiceSocketProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.capture = new DataView(new ArrayBuffer(FRAME_SAMPLES * 2));
    this.captureOffset = 0;
    this.port.onmessage = ({ data }) => {
      switch (data.type) {
        case "audio":
          if (this.queue.length >= MAX_PLAYBACK_FRAMES) {
            this.port.postMessage({ type: "overflow", generation: data.generation });
            return;
          }
          this.queue.push({ samples: new DataView(data.pcm), token: data.token, generation: data.generation });
          break;
        case "clear":
          this.clear();
          break;
        case "drain":
          this.draining = true;
          break;
      }
    };
    this.clear();
  }

  clear() {
    this.queue = [];
    this.frame = null;
    this.playbackOffset = 0;
    this.playing = false;
    this.draining = false;
    this.primedAt = null;
  }

  process(inputs, outputs) {
    const output = outputs[0]?.[0];
    if (!output) return true;
    if (!this.rendered) {
      this.rendered = true;
      this.port.postMessage({ type: "ready" });
    }
    const input = inputs[0]?.[0];
    for (let index = 0; index < output.length; index++) {
      const sample = input?.[index] ?? 0;
      const bounded = Math.max(-1, Math.min(1, sample));
      this.capture.setInt16(this.captureOffset * 2, bounded * (bounded < 0 ? 32768 : 32767), true);
      if (++this.captureOffset < FRAME_SAMPLES) continue;
      const pcm = this.capture.buffer;
      this.port.postMessage({ type: "capture", pcm }, [pcm]);
      this.capture = new DataView(new ArrayBuffer(FRAME_SAMPLES * 2));
      this.captureOffset = 0;
    }

    if (!this.playing && this.queue.length) this.primedAt ??= currentFrame;
    const waitingForFrame = this.primedAt !== null && currentFrame - this.primedAt >= FRAME_SAMPLES;
    if (this.queue.length >= 2 || waitingForFrame || this.draining) {
      this.primedAt = null;
      this.playing = true;
    }
    for (let index = 0; this.playing && index < output.length; index++) {
      if (!this.frame) {
        this.frame = this.queue.shift();
        if (!this.frame) {
          this.playing = false;
          if (this.draining) {
            this.draining = false;
            this.port.postMessage({ type: "drained", contextTime: (currentFrame + index) / sampleRate });
          }
          break;
        }
        const { token, generation } = this.frame;
        if (token !== undefined) {
          this.port.postMessage({ type: "started", token, generation, contextTime: (currentFrame + index) / sampleRate });
        }
      }
      output[index] = this.frame.samples.getInt16(this.playbackOffset * 2, true) / 32768;
      if (++this.playbackOffset === FRAME_SAMPLES) {
        this.frame = null;
        this.playbackOffset = 0;
      }
    }
    return true;
  }
}

registerProcessor("jd-voice-socket", VoiceSocketProcessor);
