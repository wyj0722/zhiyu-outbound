"""Versioned strategy library and local semantic retrieval for the work orders."""

import hashlib
import json
import math
import re
import sqlite3
from collections import OrderedDict
from contextlib import closing, contextmanager
from copy import deepcopy
from pathlib import Path
from threading import Lock

from .dialogue import accepts_offered_plan, acknowledges_plan
from .strategy_catalog import EXTRA_SEEDS, EXTRA_SEED_INTENTS, intent_keys_for_scene


SCENE = "授权链路不完整"
MODEL = "BAAI/bge-small-zh-v1.5"
MODEL_CACHE = Path(__file__).resolve().parents[1] / ".runtime" / "models" / "strategy-fastembed"
_HANDOFF_SCENE = "品牌授权链路不完整外呼"
_CHAIN_ID = "POP-AUTH-CHAIN-01"
_REVIEW_ID = "POP-REVIEW-001"
_MATERIAL_ID = "POP-AUTH-CHAIN-MATERIAL-01"
_FIELDS = {"intent", "conditions", "query_examples", "actions", "reply_requirements"}
_SEEDS = (
    {
        "strategy_id": _CHAIN_ID, "version": 1, "status": "active", "scene": SCENE,
        "intent": "询问授权链路缺失的授权关系和如何补件",
        "conditions": {},
        "query_examples": ["缺哪一段授权？", "需要谁给谁开授权证明？",
                           "我们两家公司是一家，怎么还要补授权书？"],
        "actions": [
            "查阅本单审核记录，确认缺失授权关系的授权方和被授权方。",
            "告诉商家还缺谁授权给谁的证明，补齐后重新提交。",
        ],
        "reply_requirements": ["依据本单已核实事实，保持缺失授权的方向准确。",
                               "不把商家的关联主张当成已核实事实，不保证审核通过。"],
    },
    {
        "strategy_id": _REVIEW_ID, "version": 1, "status": "active", "scene": SCENE,
        "intent": "询问补齐材料后能否通过审核",
        "conditions": {"review_phase": ["未重新提交", "已重新提交待审"]},
        "query_examples": ["授权书补齐了就能过审吗？", "我把这个补上，这单就没问题了吗？",
                           "现在是等待审核，还是已经通过了？"],
        "actions": ["说明暂时无法确定能否通过审核。",
                    "尚未重新提交时提醒补齐材料后重新提交，已提交待审时说明需等待审核结果。"],
        "reply_requirements": ["说明能否通过以完整材料的审核结果为准。"],
    },
    {
        "strategy_id": _MATERIAL_ID, "version": 1, "status": "active", "scene": SCENE,
        "intent": "核对已提交的材料上谁授权给谁",
        "conditions": {},
        "query_examples": ["原来交上去的证明是谁授权给谁？", "已经提交的是哪一段材料？"],
        "actions": ["根据本单已提交材料读出授权方和被授权方。",
                    "如有必要区分已提交材料和还需补交的证明。"],
        "reply_requirements": ["只使用工单能核实的材料内容，不把缺失的一段说成已提交。"],
    },
)
_SEEDS += EXTRA_SEEDS
_SUPPORTED_SCENES = frozenset(row["scene"] for row in _SEEDS)
_SEED_INTENTS = {
    _CHAIN_ID: {"segment", "relationship"}, _REVIEW_ID: {"review"}, _MATERIAL_ID: {"submitted_material"},
    **EXTRA_SEED_INTENTS,
}
_DURATION = re.compile(r"多久|多长时间|几[天周个月]|几个(?:工作日|小时)|多少(?:天|个工作日|小时)|何时|什么时候|用时|时长")
_REVIEW = re.compile(r"过审|通过|能过|会过|包过|保过|稳过|复审|审核结果|待审|没问题了吗|就没事了")
_RELATED = re.compile(r"关联|同(?:一家|一家公司|一个老板|集团|法人|法定代表人)|是一家|一家人|一家的|一家啊|关系密切|持股|母公司|分公司")
_MATERIAL = re.compile(
    r"(?:已(?:经)?|原来|之前|刚才)(?:[^。？！？]{0,9})(?:提交|上传|交上去|交过|传过|那份材料)"
    r"|已交|提交过|上传过|(?:材料|授权书|证明)上(?:是谁|哪家|写了什么)"
)
_SEGMENT = re.compile(
    r"缺(?:少|哪|谁|什么)|谁(?:授权|给谁|开给)|哪一?段|哪个环节|授权链(?:路)?|"
    r"(?:要|需|还|怎么|如何|为啥|为什么).{0,8}(?:补|授权|重新提交)|"
    r"找谁|往哪|(?:上传|提交|传)到哪|哪里(?:上传|提交)|申请.{0,6}(?:问题|驳回)"
    r"|(?:原因|为什么|为啥).{0,8}(?:没过|驳回|拒绝|退回)"
)
_EXPLICIT_SEGMENT = re.compile(r"缺(?:哪|谁|什么)|谁给谁|谁授权给谁|哪一?段|哪个环节|找谁补")
_REFERENCE = re.compile(r"这个|那个|这(?:一?份|一?段)|那(?:一?份|一?段)|上(?:一)?份|刚才说的")
_REFERENCE_QUESTION = re.compile(r"吗|么|呢|[?？]|能否|哪|怎么|如何|什么|可不可以|是不是")
_TOPIC = re.compile(r"资质|授权|申请|补件|材料|证明|驳回|审核|复核|复审|提交|整改")
_MATERIAL_SUBJECTS = {
    "品牌类目不符": re.compile(r"销售授权书|授权范围|类目|经营范围"),
    "授权书内容不完整": re.compile(r"授权书|章面|公章|盖章"),
    "授权时间到期": re.compile(r"授权书|有效期|到期|过期|截止日期"),
    "法人证件类型": re.compile(r"证件|身份证|护照"),
}


def _scene(scene):
    return SCENE if scene == _HANDOFF_SCENE else scene


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _digest(value):
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _text(value, field, *, limit=400):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"策略的 {field} 需为非空文本且不超过 {limit} 字。")
    return value.strip()


def _texts(value, field):
    if not isinstance(value, list) or not 1 <= len(value) <= 24:
        raise ValueError(f"策略的 {field} 需要包含 1 到 24 条文本。")
    return [_text(item, field) for item in value]


def _condition_choices(field, value):
    if field != "identity_verified":
        return _texts(value, f"conditions.{field}")
    if type(value) is bool:
        return [value]
    if isinstance(value, list) and 1 <= len(value) <= 24 and all(type(item) is bool for item in value):
        return list(value)
    raise ValueError("策略的 conditions.identity_verified 需为布尔值或含 1 到 24 项布尔值的数组。")


def _fields(values, *, partial=False):
    if not isinstance(values, dict) or not values or not values.keys() <= _FIELDS:
        raise ValueError("策略更新字段无效。")
    if not partial and values.keys() != _FIELDS:
        raise ValueError("新增策略缺少必填字段。")
    sanitized = {}
    for name, value in values.items():
        if name == "intent":
            sanitized[name] = _text(value, name)
        elif name == "conditions":
            if not isinstance(value, dict) or len(value) > 12:
                raise ValueError("策略的 conditions 需为工单字段到可接受值的对象。")
            conditions = {}
            for key, option in value.items():
                field = _text(key, "conditions 的字段", limit=80)
                conditions[field] = _condition_choices(field, option)
            sanitized[name] = conditions
        else:
            sanitized[name] = _texts(value, name)
    return sanitized


def _candidate(active, update, scene):
    scene = _scene(scene)
    if not isinstance(scene, str) or scene not in _SUPPORTED_SCENES or not isinstance(update, dict):
        raise ValueError("策略更新需要受支持的工单场景和更新对象。")
    op = update.get("operation")
    strategy_id = update.get("strategy_id")
    old_version = update.get("expected_version")
    new_version = update.get("new_version")
    if type(new_version) is not int:
        raise ValueError("策略的新版本号需为整数。")
    if op == "add_strategy":
        if strategy_id is not None or old_version is not None or new_version != 1:
            raise ValueError("新增策略由程序分配编号，版本须从 1 开始。")
        data = update.get("strategy")
        if not isinstance(data, dict) or _scene(data.get("scene")) != scene:
            raise ValueError("新增策略的场景与工单不符。")
        values = _fields({key: value for key, value in data.items() if key != "scene"})
        if scene == SCENE:
            strategy_id = "POP-AUTH-CHAIN-" + _digest(values)[:16].upper()
        else:
            strategy_id = "POP-STRATEGY-" + _digest({"scene": scene, **values})[:16].upper()
        if any(row["scene"] == scene and row["strategy_id"] == strategy_id for row in active):
            raise ValueError("相同策略已存在。")
        return {"strategy_id": strategy_id, "version": 1, "status": "active", "scene": scene, **values}
    if op == "modify_strategy":
        if not isinstance(strategy_id, str) or type(old_version) is not int or new_version != old_version + 1:
            raise ValueError("修正策略需要编号和连续的新旧版本。")
        row = next((item for item in active if item["scene"] == scene and item["strategy_id"] == strategy_id), None)
        if row is None or row["version"] != old_version:
            raise ValueError("当前策略版本已变化，请在新版本上重新回放。")
        values = _fields(update.get("changes"), partial=True)
        if all(row[key] == value for key, value in values.items()):
            raise ValueError("策略正文没有变化。")
        return {**row, **values, "version": new_version}
    raise ValueError("不支持此策略更新操作。")


def project(strategies, update, *, scene=SCENE):
    """Create a candidate active library without writing a version or update record."""
    active = deepcopy(list(strategies))
    candidate = _candidate(active, update, scene)
    if update["operation"] == "add_strategy":
        return active + [candidate]
    return [candidate if (row["scene"], row["strategy_id"]) == (candidate["scene"], candidate["strategy_id"])
            else row for row in active]


def _intent_keys(text, scene=SCENE):
    if scene != SCENE:
        return intent_keys_for_scene(scene, text)
    if _DURATION.search(text):
        return ("duration",)
    keys = []
    if _REVIEW.search(text):
        keys.append("review")
    if _MATERIAL.search(text) and (not keys or _EXPLICIT_SEGMENT.search(text)):
        keys.append("submitted_material")
    if _RELATED.search(text) and not _EXPLICIT_SEGMENT.search(text):
        keys.append("relationship")
    if (not keys and _SEGMENT.search(text)) or (
        keys and _EXPLICIT_SEGMENT.search(text) and "submitted_material" not in keys
    ):
        keys.append("segment")
    return tuple(keys)


def _row_intents(row):
    specified = row["conditions"].get("intent_key")
    if specified is not None:
        return set(specified)
    if row["strategy_id"] in _SEED_INTENTS:
        return _SEED_INTENTS[row["strategy_id"]]
    scene = row["scene"]
    known = set(_intent_keys(row["intent"], scene))
    if not known:
        known = {key for sample in row["query_examples"] for key in _intent_keys(sample, scene)}
    return known


def _condition_matches(field, value, allowed):
    if field == "identity_verified":
        return type(value) is bool and any(value is expected for expected in allowed)
    return value in allowed


def _prior_replies(history):
    for entry in list(history)[-4:]:
        if isinstance(entry, str):
            yield entry
        elif isinstance(entry, dict):
            if entry.get("role") == "assistant":
                yield str(entry.get("content", ""))
            elif entry.get("role") is None:
                yield str(entry.get("reply") or entry.get("answer") or entry.get("a") or "")


def _query(text, facts, history, keys, scene):
    if not _REFERENCE.search(text):
        return text, keys, False
    previous = tuple(item for item in _prior_replies(history) if item)
    if scene != SCENE:
        material = facts.get("material_context")
        subject = _MATERIAL_SUBJECTS[scene]
        if (isinstance(material, str) and material.strip() and previous
                and subject.search(previous[-1]) and _REFERENCE_QUESTION.search(text)):
            rewritten = f"{text}（指本单材料：{material.strip()[:500]}）"
            return rewritten, keys or ("submitted_material",), False
        return text, keys, not keys

    missing = facts.get("missing_segment")
    latest = next((item for item in reversed(previous) if _TOPIC.search(item)), "")
    if isinstance(missing, str) and missing and re.search(r"补|缺", latest):
        rewritten = f"{text}（指本单缺少的材料：{missing}）"
        return rewritten, keys or _intent_keys(rewritten), False
    if not keys and not _TOPIC.search(text):
        return text, keys, True
    return text, keys, False


class _FastEmbed:
    name = MODEL

    def __init__(self, *, download=False):
        self.model = None
        self.download = download

    def __call__(self, texts):
        if self.model is None:
            from fastembed import TextEmbedding

            self.model = TextEmbedding(model_name=MODEL, cache_dir=str(MODEL_CACHE), threads=1,
                                       local_files_only=not self.download)
        return self.model.embed(texts)


def warm_embedding_model():
    """Install public model assets into the configured cache and verify one local vector."""
    return len(next(iter(_FastEmbed(download=True)(["请补齐授权证明。"]))))


def _unit(vector):
    values = tuple(float(value) for value in vector)
    norm = math.sqrt(sum(value * value for value in values))
    if not values or not norm or not math.isfinite(norm):
        raise ValueError("策略向量为空或无效。")
    return tuple(value / norm for value in values)


class StrategyLibrary:
    def __init__(self, db_path, *, embed=None):
        self.db_path = db_path
        self.embed = embed if embed is not None else _FastEmbed()
        self._index = OrderedDict()
        self._encoder_lock = Lock()
        with self._connection() as connection:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS strategy_versions (
                    scene TEXT NOT NULL, strategy_id TEXT NOT NULL, version INTEGER NOT NULL,
                    status TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY (scene, strategy_id, version)
                );
                CREATE UNIQUE INDEX IF NOT EXISTS strategy_one_active ON strategy_versions(scene, strategy_id)
                    WHERE status = 'active';
                CREATE TABLE IF NOT EXISTS strategy_updates (
                    update_id TEXT PRIMARY KEY, request_hash TEXT NOT NULL, result TEXT NOT NULL
                );
            """)
            connection.execute("BEGIN IMMEDIATE")
            for row in _SEEDS:
                connection.execute(
                    "INSERT OR IGNORE INTO strategy_versions VALUES (?, ?, ?, ?, ?)",
                    (row["scene"], row["strategy_id"], row["version"], row["status"], _json(row)),
                )

    @contextmanager
    def _connection(self):
        with closing(sqlite3.connect(self.db_path, timeout=10)) as connection, connection:
            connection.row_factory = sqlite3.Row
            yield connection

    @staticmethod
    def _active(connection, scene):
        rows = connection.execute(
            "SELECT payload FROM strategy_versions WHERE scene = ? AND status = 'active' ORDER BY strategy_id",
            (_scene(scene),),
        )
        return [json.loads(row["payload"]) for row in rows]

    def list_active(self, scene=SCENE):
        with self._connection() as connection:
            return self._active(connection, scene)

    def list_all_active(self):
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT payload FROM strategy_versions WHERE status = 'active' ORDER BY scene, strategy_id",
            )
            return [json.loads(row["payload"]) for row in rows]

    def list_versions(self, strategy_id, *, scene=SCENE):
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT status, payload FROM strategy_versions WHERE scene = ? AND strategy_id = ? ORDER BY version",
                (_scene(scene), strategy_id),
            )
            return [dict(json.loads(row["payload"]), status=row["status"]) for row in rows]

    def apply(self, update, *, scene=SCENE):
        return self.apply_batch([update], scene=scene)[0]

    def apply_batch(self, updates, *, scene=SCENE):
        scene = _scene(scene)
        if not isinstance(scene, str) or scene not in _SUPPORTED_SCENES:
            raise ValueError("策略更新的工单场景不受支持。")
        results = []
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            for update in updates:
                key = _text(update.get("update_id") if isinstance(update, dict) else None, "update_id", limit=160)
                fingerprint = _digest(update)
                applied = connection.execute(
                    "SELECT request_hash, result FROM strategy_updates WHERE update_id = ?", (key,),
                ).fetchone()
                if applied:
                    prior = json.loads(applied["result"])
                    if applied["request_hash"] != fingerprint or prior["scene"] != scene:
                        raise ValueError("更新编号已被用于不同的策略变更。")
                    results.append({"update_id": key, "strategy": prior, "applied": False})
                    continue
                row = _candidate(self._active(connection, scene), update, scene)
                if update["operation"] == "modify_strategy":
                    connection.execute(
                        "UPDATE strategy_versions SET status = 'superseded' WHERE scene = ? AND strategy_id = ? AND version = ?",
                        (scene, row["strategy_id"], update["expected_version"]),
                    )
                encoded = _json(row)
                connection.execute("INSERT INTO strategy_versions VALUES (?, ?, ?, 'active', ?)",
                                   (scene, row["strategy_id"], row["version"], encoded))
                connection.execute("INSERT INTO strategy_updates VALUES (?, ?, ?)", (key, fingerprint, encoded))
                results.append({"update_id": key, "strategy": row, "applied": True})
        return results

    def _semantic_scores(self, query, rows):
        with self._encoder_lock:
            query_vector = _unit(next(iter(self.embed([query]))))
            scored = []
            for row in rows:
                texts = tuple([row["intent"], *row["query_examples"]])
                index_key = row["scene"], row["strategy_id"], texts
                vectors = self._index.get(index_key)
                if vectors is None:
                    vectors = tuple(_unit(vector) for vector in self.embed(texts))
                    if len(vectors) != len(texts):
                        raise ValueError("策略向量数量与索引条目不一致。")
                    self._index[index_key] = vectors
                    if len(self._index) > 128:
                        self._index.popitem(last=False)
                self._index.move_to_end(index_key)
                score = max(sum(x * y for x, y in zip(query_vector, vector, strict=True)) for vector in vectors)
                scored.append((score, row))
        return sorted(scored, key=lambda item: (-item[0], item[1]["strategy_id"]))

    def retrieve(self, text, *, facts, history=(), scene=SCENE, strategies=None):
        scene = _scene(scene)
        should_search = (isinstance(scene, str) and scene in _SUPPORTED_SCENES
                         and not (accepts_offered_plan(text) or acknowledges_plan(text)))
        if should_search:
            query, keys, ambiguous = _query(text, facts, history, _intent_keys(text, scene), scene)
        else:
            query, keys, ambiguous = text, (), False
        base = {"query": query, "strategies": [], "encoder": getattr(self.embed, "name", "custom"),
                "intent_key": "ambiguous" if ambiguous else keys[0] if keys else "unknown",
                "intent_keys": list(keys), "reason": "no_applicable_strategy"}
        if not should_search or ambiguous or "duration" in keys:
            return base
        if not keys and (scene != SCENE or not _TOPIC.search(query)):
            return base
        library = self.list_active(scene) if strategies is None else strategies
        rows = [row for row in library if row["status"] == "active" and _scene(row["scene"]) == scene]
        if not rows:
            return base
        try:
            ranked = self._semantic_scores(query, rows)
        except (ImportError, OSError, RuntimeError, StopIteration, TypeError, ValueError):
            return dict(base, reason="embedding_unavailable")
        candidates = ranked if keys else ranked[:3]
        selected = []
        for key in (keys or ("unknown",)):
            for score, row in candidates:
                intents = _row_intents(row)
                if not intents or (key not in intents if key != "unknown" else score < 0.66):
                    continue
                if not all(_condition_matches(field, key if field == "intent_key" else facts.get(field), allowed)
                           for field, allowed in row["conditions"].items()):
                    continue
                if not any(existing["strategy_id"] == row["strategy_id"] for existing in selected):
                    selected.append(dict(row, score=round(score, 5)))
                if key == "unknown" and len(intents) == 1:
                    base.update(intent_key=next(iter(intents)), intent_keys=sorted(intents))
                break
        return dict(base, strategies=selected, reason="matched" if selected else base["reason"])
