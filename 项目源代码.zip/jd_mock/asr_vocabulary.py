"""Versioned, work-order-scoped corrections for final ASR transcripts."""

from dataclasses import dataclass
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re

from .cases import ORDERS


_RULE_KEYS = {"case_id", "term", "aliases", "before", "after", "requires", "left_pattern", "right_pattern", "focus"}
_CLAUSE_BREAK = re.compile(r"[,，。.!！?？;；\r\n]")


def _strings(row, field, context):
    values = row.get(field, [])
    if (not isinstance(values, list) or (field == "aliases" and not values)
            or any(not isinstance(value, str) or not value.strip() for value in values)):
        raise ValueError(f"{context}.{field}: expected an array of nonempty strings")
    return tuple(values)


def _context_pattern(row, field, context):
    if field not in row:
        return None
    pattern = row[field]
    if not isinstance(pattern, str) or not pattern.strip():
        raise ValueError(f"{context}.{field}: expected a nonempty regular expression")
    try:
        return re.compile(rf"(?:{pattern})\Z" if field == "left_pattern" else pattern)
    except re.error as error:
        raise ValueError(f"{context}.{field}: {error}") from None


@dataclass(frozen=True)
class _Rule:
    term: str
    aliases: re.Pattern[str]
    focus: tuple[str, ...]
    before: tuple[str, ...]
    after: tuple[str, ...]
    requires: tuple[str, ...]
    left_pattern: re.Pattern[str] | None
    right_pattern: re.Pattern[str] | None

    def replace(self, match):
        raw = match.group()
        left, right = match.string[:match.start()], match.string[match.end():]
        if self.before and not left.endswith(self.before):
            return raw
        if self.after and not right.startswith(self.after):
            return raw
        if self.left_pattern is not None and not self.left_pattern.search(left):
            return raw
        if self.right_pattern is not None and not self.right_pattern.match(right):
            return raw
        if self.requires:
            clause = _CLAUSE_BREAK.split(left)[-1] + raw + _CLAUSE_BREAK.split(right, maxsplit=1)[0]
            if _CLAUSE_BREAK.search(raw) or any(word not in clause for word in self.requires):
                return raw
        return self.term


class Vocabulary:
    """Load literal aliases with context guards and apply them to one work order."""

    def __init__(self, rules, metadata):
        self._rules = rules
        self._metadata = metadata

    @classmethod
    def from_file(cls, path: str | Path) -> "Vocabulary":
        path = Path(path)
        try:
            raw = path.read_bytes()
            config = json.loads(raw.decode("utf-8-sig"))
        except OSError as error:
            raise ValueError(f"{path}: cannot read vocabulary ({error.strerror})") from None
        except UnicodeDecodeError:
            raise ValueError(f"{path}: vocabulary must be UTF-8") from None
        except json.JSONDecodeError as error:
            raise ValueError(f"{path}: invalid JSON at line {error.lineno}, column {error.colno}: {error.msg}") from None
        if not isinstance(config, dict) or type(config.get("version")) is not int or config["version"] != 1:
            raise ValueError(f"{path}: version must be 1")
        unknown_fields = config.keys() - {"version", "rules"}
        if unknown_fields:
            raise ValueError(f"{path}: unexpected top-level fields: {', '.join(sorted(unknown_fields))}")
        if not isinstance(config.get("rules"), list):
            raise ValueError(f"{path}: rules must be an array")

        rules = {}
        for index, row in enumerate(config["rules"]):
            context = f"{path}: rules[{index}]"
            if not isinstance(row, dict):
                raise ValueError(f"{context}: expected a rule object")
            unknown_fields = row.keys() - _RULE_KEYS
            if unknown_fields:
                raise ValueError(f"{context}.{min(unknown_fields)}: unrecognized field")
            case_id = row.get("case_id")
            if not isinstance(case_id, str) or case_id not in ORDERS:
                raise ValueError(f"{context}.case_id: expected a known work order ID")
            term = row.get("term")
            if not isinstance(term, str) or not term.strip():
                raise ValueError(f"{context}.term: expected a nonempty string")
            aliases = _strings(row, "aliases", context)
            before, after, requires = (_strings(row, field, context) for field in ("before", "after", "requires"))
            focus = _strings(row, "focus", context)
            left = _context_pattern(row, "left_pattern", context)
            right = _context_pattern(row, "right_pattern", context)
            bounded_pattern = any(pattern is not None and pattern.match("") is None for pattern in (left, right))
            if not (focus or before or after or requires or bounded_pattern):
                raise ValueError(f"{context}: at least one scoped context guard is required")
            # Run rules in file order. For aliases at the same offset in a
            # rule, try the longest literal before shorter alternatives.
            match_alias = re.compile("|".join(re.escape(value) for value in sorted(aliases, key=len, reverse=True)))
            rules.setdefault(case_id, []).append(_Rule(term, match_alias, focus, before, after, requires, left, right))
        return cls(rules, {"source": path.name, "rules": len(config["rules"]), "sha256": hashlib.sha256(raw).hexdigest()})

    @property
    def metadata(self) -> dict[str, str | int]:
        return self._metadata.copy()

    def correct(self, case_id: str, text: str, *, focus: str = "") -> str:
        for rule in self._rules.get(case_id, ()):
            if not rule.focus or focus in rule.focus:
                text = rule.aliases.sub(rule.replace, text)
        return text


@lru_cache(maxsize=1)
def default_vocabulary() -> Vocabulary:
    return Vocabulary.from_file(Path(__file__).with_suffix(".json"))
