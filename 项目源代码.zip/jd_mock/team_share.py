"""Invite-link access for the separate team demo instance."""

import re
from secrets import compare_digest

from starlette.requests import HTTPConnection
from starlette.responses import PlainTextResponse, RedirectResponse


class TeamShareAccess:
    cookie_name = "jd_team_access"

    def __init__(self, app, *, token):
        if not re.fullmatch(r"[A-Za-z0-9_-]{32,128}", token):
            raise ValueError("Team share requires a URL-safe token of at least 32 characters.")
        self.app = app
        self.token = token.encode("ascii")
        self.invite = b"/join/" + self.token

    async def __call__(self, scope, receive, send):
        if scope["type"] not in {"http", "websocket"}:
            await self.app(scope, receive, send)
            return

        connection = HTTPConnection(scope)
        path = scope["path"].encode("utf-8")
        if scope["type"] == "http" and scope["method"] == "GET" and compare_digest(path, self.invite):
            response = RedirectResponse("/", status_code=303, headers={
                "Cache-Control": "no-store", "Referrer-Policy": "no-referrer",
            })
            response.set_cookie(self.cookie_name, self.token.decode("ascii"), secure=True,
                                httponly=True, samesite="lax")
            await response(scope, receive, send)
            return

        credential = connection.cookies.get(self.cookie_name, "").encode("utf-8")
        origin = connection.headers.get("origin")
        host = connection.headers.get("host")
        same_origin = origin is None or origin in {f"https://{host}", f"http://{host}"}
        if compare_digest(credential, self.token) and same_origin:
            await self.app(scope, receive, send)
        elif scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
        else:
            response = PlainTextResponse("请使用组内邀请链接打开工作台。", status_code=403,
                                         headers={"Cache-Control": "no-store"})
            await response(scope, receive, send)
