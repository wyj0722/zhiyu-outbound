"""Constrained intent choices and dialogue through the official DeepSeek Chat API."""

from http.client import HTTPSConnection
import json

from ._choice_llm import CloudChoiceTransport, _unique_object


class DeepSeekTransport(CloudChoiceTransport):
    provider = "deepseek"
    _service = "DeepSeek"
    _key_variable = "DEEPSEEK_API_KEY"
    _model_variable = "JD_DEEPSEEK_MODEL"
    _timeout_variable = "JD_DEEPSEEK_TIMEOUT"
    _default_model = "deepseek-flash"
    _path = "/chat/completions"

    def _connect(self):
        return HTTPSConnection("api.deepseek.com", timeout=self.timeout)

    def _format_instruction(self, choices):
        example = json.dumps({"choice": choices[0]}, ensure_ascii=False, separators=(",", ":"))
        allowed = json.dumps(choices, ensure_ascii=False, separators=(",", ":"))
        return f"以 JSON 对象输出，把选项编码原样写到唯一的 choice 字段里。格式示例：{example}。可选编码：{allowed}。"

    def _request_options(self, _choices):
        return {"thinking": {"type": "disabled"}, "response_format": {"type": "json_object"}}

    def with_timeout(self, timeout):
        return type(self)(self._api_key, self.model, timeout)

    def _chat(self, messages, *, max_tokens, json_mode=False):
        payload = {
            "model": self.model, "messages": messages, "max_tokens": max_tokens,
            "thinking": {"type": "disabled"}, "temperature": 0,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        return self._request_content(payload, max_chars=15_000 if json_mode else 1_500,
                                     response_kind="JSON" if json_mode else "chat").strip()

    def chat_text(self, messages, *, max_tokens=192):
        text = self._chat(messages, max_tokens=max_tokens)
        if not text:
            raise ValueError("DeepSeek returned an empty answer.")
        return text

    def chat_json(self, messages):
        try:
            result = json.loads(self._chat(messages, max_tokens=3584, json_mode=True),
                                object_pairs_hook=_unique_object)
            if not isinstance(result, dict):
                raise ValueError
            return result
        except (TypeError, ValueError, RecursionError):
            raise ValueError("DeepSeek returned an invalid JSON response.") from None
