"""Constrained intent choices through the Volcengine Ark Chat API."""

from http.client import HTTPSConnection

from ._choice_llm import CloudChoiceTransport


class ArkTransport(CloudChoiceTransport):
    provider = "doubao"
    _service = "Ark"
    _key_variable = "ARK_API_KEY"
    _model_variable = "JD_ARK_MODEL"
    _timeout_variable = "JD_ARK_TIMEOUT"
    _path = "/api/v3/chat/completions"

    def _connect(self):
        return HTTPSConnection("ark.cn-beijing.volces.com", timeout=self.timeout)

    def _format_instruction(self, _choices):
        return "以 JSON 对象输出所选选项编码，原样写在唯一的 choice 字段里。"

    def _request_options(self, choices):
        options = {
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "intent_choice",
                    "strict": True,
                    "schema": {
                        "type": "object",
                        "properties": {"choice": {"type": "string", "enum": list(choices)}},
                        "required": ["choice"],
                        "additionalProperties": False,
                    },
                },
            },
        }
        # Ark only accepts a thinking override for supported models. Endpoint
        # IDs do not reveal the model behind them.
        if self.model.startswith(("doubao-seed-1-6-", "doubao-seed-2-0-", "doubao-seed-2-1-")):
            options["thinking"] = {"type": "disabled"}
        return options
