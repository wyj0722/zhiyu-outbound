import argparse
import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

import uvicorn
from aiortc import RTCSessionDescription
from fastapi import FastAPI, HTTPException, WebSocket
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .asr_vocabulary import Vocabulary, default_vocabulary
from .business import FIRST_REPLY_TEMPLATES, Store
from .case_agent import CaseAgent, first_replies as first_case_replies
from .chain_strategy_agent import CHAIN_REVIEW_PREFACE, ChainStrategyAgent, chain_facts
from .cases import CHAIN, DEFAULT_CASE_ID, INCOMPLETE, ORDERS, list_cases
from .dialogue import respond
from .media import CallMedia, reply_sentences
from .stamp_agent import StampAgent, first_replies
from .team_share import TeamShareAccess

ROOT = Path(__file__).resolve().parent.parent
log = logging.getLogger(__name__)


class Offer(BaseModel):
    type: Literal["offer"]
    sdp: str = Field(min_length=1, max_length=65_536)
    simulate_timeout: bool = False


class StartCall(BaseModel):
    case_id: str = Field(default=DEFAULT_CASE_ID, min_length=1, max_length=80)


def create_app(db_path: Path, asset_dir: Path, stamp_agent=None, case_agent=None,
               *, vocabulary=None, share_token=None, strategy_library=None, strategy_transport=None):
    calls = {}
    engine = None
    prepared_audio = {}
    stamp_warmup = None
    strategy_encoder = None
    llm_provider = stamp_agent.provider if stamp_agent else "rules"
    dialogue_models = {
        order.case_id: agent.model for order in ORDERS.values()
        if (agent := stamp_agent if order.procedure is INCOMPLETE else case_agent) is not None
    }
    speech_detail = "正在加载离线语音模型。"
    chain_agent = evolution = None
    if strategy_library is not None and strategy_transport is not None and case_agent is not None:
        from .evolution import EvolutionService

        chain_agent = ChainStrategyAgent(strategy_library, strategy_transport, case_agent)
        offline_transport = strategy_transport.with_timeout(max(30, strategy_transport.timeout))
        replay_agent = ChainStrategyAgent(strategy_library, offline_transport, case_agent)
        evolution = EvolutionService(strategy_library, offline_transport.chat_json, replay_agent.answer)
    store = Store(
        db_path, stamp_agent=stamp_agent, case_agent=case_agent, chain_agent=chain_agent,
        strategy_library=strategy_library if chain_agent is not None else None,
    )
    if vocabulary is None:
        vocabulary = default_vocabulary()

    @asynccontextmanager
    async def lifespan(_app):
        nonlocal engine, speech_detail, stamp_warmup, strategy_encoder
        if chain_agent is not None:
            try:
                sample = next(order for order in ORDERS.values() if order.procedure is CHAIN)
                retrieval = await asyncio.to_thread(strategy_library.retrieve, "缺哪一段授权？",
                                                    facts=chain_facts(sample))
                strategy_encoder = retrieval.get("encoder") if retrieval["strategies"] else None
            except Exception:
                log.exception("Unable to warm strategy retrieval")
        try:
            from .speech import SpeechEngine
            from .speech_assets import STAMP_ASR

            stamp_asr = os.getenv("JD_STAMP_ASR", "auto").lower()
            if stamp_asr not in {"auto", "sensevoice", "zipformer"}:
                raise ValueError("JD_STAMP_ASR must be auto, sensevoice or zipformer.")
            load_stamp_asr = bool(stamp_agent) and (
                stamp_asr == "sensevoice" or (stamp_asr == "auto" and STAMP_ASR.is_installed(asset_dir))
            )
            speech_engine = await asyncio.to_thread(
                SpeechEngine, asset_dir, stamp_asr=load_stamp_asr, vad_mode=os.getenv("JD_VAD_MODE", "auto").lower(),
            )
            first_sentences = [reply_sentences(template)[0] for template in FIRST_REPLY_TEMPLATES]
            if chain_agent is not None:
                first_sentences.append(CHAIN_REVIEW_PREFACE)
            for order in ORDERS.values():
                answer, _ = respond(order, "我到底要改什么", "intro")
                first_sentences.append(reply_sentences(answer)[0])
                if stamp_agent and order.procedure is INCOMPLETE:
                    first_sentences.extend(reply_sentences(item)[0] for item in first_replies(order))
                    probe = await asyncio.to_thread(stamp_agent.decide, order, "请问来电的原因是什么？")
                    stamp_warmup = {"source": probe.source, "error": probe.error, "latency_ms": probe.latency_ms}
                elif case_agent:
                    first_sentences.extend(reply_sentences(item)[0] for item in first_case_replies(order))
            location, _ = respond(ORDERS[DEFAULT_CASE_ID], "鞋类在哪里选", "intro")
            for sentence in dict.fromkeys(first_sentences + reply_sentences(location)):
                prepared_audio[sentence] = await asyncio.to_thread(speech_engine.synthesize, sentence)
            engine = speech_engine
            speech_detail = "本机中文识别与合成已就绪。"
        except Exception:
            log.exception("Unable to load local speech assets")
            speech_detail = "离线语音模型不可用。运行 start.ps1 -Setup，并查看服务终端。"
        yield
        await asyncio.gather(*(media.close() for media in list(calls.values())))

    app = FastAPI(title="智语外呼 Mock", lifespan=lifespan)
    if share_token is not None:
        app.add_middleware(TeamShareAccess, token=share_token)

    def run_store(method, *args):
        try:
            return method(*args)
        except LookupError as error:
            raise HTTPException(status_code=404, detail="未找到这通电话。") from error
        except ValueError as error:
            raise HTTPException(status_code=409, detail=str(error)) from error

    @app.get("/api/health")
    def health():
        return {
            "speech_ready": engine is not None,
            "voice_backend": "本地中文语音 · sherpa-onnx",
            "voice_transport": "websocket" if share_token is not None else "webrtc",
            "vad_backend": engine.vad_backend if engine else None,
            "asr_vocabulary": vocabulary.metadata,
            "detail": speech_detail,
            "llm_provider": llm_provider,
            "stamp_backend": "model" if stamp_agent else "rules",
            "stamp_model": stamp_agent.model if stamp_agent else None,
            "stamp_asr": "sensevoice" if engine and engine.stamp_asr_ready else "zipformer",
            "stamp_warmup": stamp_warmup,
            "dialogue_models": dialogue_models,
            "strategy_pilot": evolution is not None,
            "strategy_encoder": strategy_encoder,
        }

    @app.get("/api/cases")
    def cases():
        catalog = list_cases()
        for item in catalog:
            item["dialogue_model"] = dialogue_models.get(item["case_id"])
            item["dialogue_provider"] = llm_provider if item["dialogue_model"] else "rules"
        return {"cases": catalog}

    @app.get("/api/cases/{case_id}/receipts")
    def case_receipts(case_id: str):
        try:
            return store.case_receipts(case_id)
        except ValueError as error:
            raise HTTPException(status_code=404, detail=str(error)) from error

    @app.post("/api/calls")
    def start_call(data: StartCall | None = None):
        try:
            return store.start_call(data.case_id if data is not None else DEFAULT_CASE_ID)
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from error

    @app.get("/api/calls/{call_id}")
    def get_call(call_id: str):
        return run_store(store.get_call, call_id)

    @app.get("/api/strategies")
    def strategies():
        return {"enabled": strategy_library is not None,
                "strategies": strategy_library.list_all_active() if strategy_library is not None else []}

    @app.post("/api/calls/{call_id}/evolution", status_code=202)
    def start_evolution(call_id: str):
        if evolution is None:
            raise HTTPException(status_code=503, detail="请用 DeepSeek 全工单模式启动自主进化试点。")
        snapshot = run_store(store.evolution_snapshot, call_id)
        try:
            return evolution.start(snapshot)
        except ValueError as error:
            raise HTTPException(status_code=409, detail=str(error)) from error

    @app.get("/api/calls/{call_id}/evolution/{job_id}")
    def evolution_status(call_id: str, job_id: str):
        if evolution is None:
            raise HTTPException(status_code=503, detail="自主进化服务未启用。")
        try:
            return evolution.get(job_id, call_id=call_id)
        except KeyError as error:
            raise HTTPException(status_code=404, detail="未找到这通电话的进化任务。") from error

    @app.post("/api/calls/{call_id}/retry")
    def retry_writeback(call_id: str):
        return run_store(store.retry_writeback, call_id)

    @app.post("/api/calls/{call_id}/end")
    async def end_call(call_id: str):
        result = run_store(store.end_call, call_id)
        media = calls.get(call_id)
        if media:
            await media.close()
            if "completed_qa_count" in result:
                result = run_store(store.get_call, call_id)
        return result

    def forget(media):
        if calls.get(media.call_id) is media:
            calls.pop(media.call_id)

    @app.post("/api/calls/{call_id}/offer")
    async def offer(call_id: str, data: Offer):
        if share_token is not None:
            raise HTTPException(status_code=404)
        call = run_store(store.get_call, call_id)
        if call["state"] == "closed":
            raise HTTPException(status_code=409, detail="这通电话已结束。")
        if engine is None:
            raise HTTPException(status_code=503, detail=speech_detail)
        if call_id in calls:
            raise HTTPException(status_code=409, detail="这通电话已连接。")
        media = CallMedia(store, engine, call_id, data.simulate_timeout, forget, prepared_audio,
                          vocabulary=vocabulary)
        calls[call_id] = media
        try:
            await media.pc.setRemoteDescription(RTCSessionDescription(sdp=data.sdp, type=data.type))
            media.pc.addTrack(media.output)
            await media.pc.setLocalDescription(await media.pc.createAnswer())
            answer = media.pc.localDescription
            return {"type": answer.type, "sdp": answer.sdp}
        except Exception as error:
            log.exception("Unable to negotiate WebRTC")
            await media.close()
            raise HTTPException(status_code=400, detail="WebRTC 协商失败。") from error

    if share_token is not None:
        from .ws_media import SocketCallMedia

        @app.websocket("/api/calls/{call_id}/voice")
        async def voice_socket(websocket: WebSocket, call_id: str, simulate_timeout: bool = False):
            if engine is None or len(calls) >= 3:
                await websocket.close(code=1013)
                return
            try:
                call = store.get_call(call_id)
            except LookupError:
                await websocket.close(code=1008)
                return
            if call_id in calls or call["state"] in {"complete", "closed"}:
                await websocket.close(code=1008)
                return
            media = SocketCallMedia(store, engine, call_id, simulate_timeout, forget, prepared_audio,
                                    vocabulary=vocabulary)
            calls[call_id] = media
            try:
                await websocket.accept()
                await asyncio.wait_for(media.run(websocket), timeout=720)
            except TimeoutError:
                log.info("Team demo call reached its time limit")
            finally:
                await media.close()

    app.mount("/", StaticFiles(directory=ROOT / "jd_mock" / "web", html=True), name="web")
    return app


def main():
    parser = argparse.ArgumentParser(description="Run the local JD mock voice call.")
    parser.add_argument("--host", default="127.0.0.1", help="HTTP server bind address")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--db", type=Path, help="SQLite call database")
    parser.add_argument("--models", type=Path, default=ROOT / ".runtime" / "models")
    parser.add_argument("--stamp-mode", choices=("rules", "model"), default=os.getenv("JD_STAMP_MODE", "rules"))
    parser.add_argument("--dialogue-mode", choices=("rules", "stamp", "model"), default=os.getenv("JD_DIALOGUE_MODE"))
    parser.add_argument("--llm-provider", choices=("local", "deepseek", "doubao"),
                        help="Model provider for the dialogue agents")
    parser.add_argument("--case-policy", type=Path, help="RSI candidate or selected profile for the category and chain model")
    parser.add_argument("--asr-vocabulary", type=Path, default=os.getenv("JD_ASR_VOCAB_FILE") or None,
                        help="Override the default JSON domain vocabulary (JD_ASR_VOCAB_FILE)")
    parser.add_argument("--team-share", action="store_true", help="Enable invite links and WebSocket voice")
    options = parser.parse_args()
    share_token = None
    if options.team_share:
        share_token = os.getenv("JD_TEAM_SHARE_TOKEN", "")
        try:
            TeamShareAccess(None, token=share_token)
        except ValueError as error:
            parser.error(str(error))
    db_path = options.db or ROOT / ".runtime" / ("team-share/calls.sqlite3" if options.team_share else "calls.sqlite3")
    try:
        vocabulary = Vocabulary.from_file(options.asr_vocabulary) if options.asr_vocabulary else default_vocabulary()
    except ValueError as error:
        parser.error(f"Cannot load ASR vocabulary: {error}")
    db_path.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    mode = options.dialogue_mode or ("stamp" if options.stamp_mode == "model" else "rules")
    instruction = ""
    if options.case_policy:
        if mode != "model":
            parser.error("--case-policy requires --dialogue-mode model")
        try:
            profile = json.loads(options.case_policy.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            parser.error(f"Cannot load RSI case policy: {error}")
        if (not isinstance(profile, dict) or profile.get("schema_version") != 1
                or not isinstance(profile.get("instruction"), str) or len(profile["instruction"]) > 4000):
            parser.error("--case-policy expects a version-1 RSI profile")
        instruction = profile["instruction"]
    try:
        stamp_agent = StampAgent.from_env(options.llm_provider) if mode != "rules" else None
    except ValueError as error:
        parser.error(str(error))
    case_agent = CaseAgent(stamp_agent, instruction=instruction) if mode == "model" else None
    from .strategy import StrategyLibrary

    strategy_library = StrategyLibrary(db_path)
    strategy_transport = None
    if case_agent and stamp_agent.provider == "deepseek" and not options.case_policy:
        from .deepseek_llm import DeepSeekTransport
        strategy_transport = DeepSeekTransport.from_env()
    app = create_app(db_path, options.models, stamp_agent, case_agent, vocabulary=vocabulary,
                     share_token=share_token, strategy_library=strategy_library, strategy_transport=strategy_transport)
    socket_options = {"ws": "websockets", "ws_max_size": 4096, "ws_max_queue": 16,
                      "access_log": False} if options.team_share else {}
    uvicorn.run(app, host=options.host, port=options.port, **socket_options)


if __name__ == "__main__":
    main()
