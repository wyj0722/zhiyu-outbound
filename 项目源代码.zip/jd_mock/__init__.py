"""Local mock of the JD merchant qualification outbound call."""
