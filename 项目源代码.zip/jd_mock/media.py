import asyncio
import json
import logging
import re
import time
from collections import deque
from fractions import Fraction
from uuid import uuid4

import numpy as np
from aiortc import AudioStreamTrack, MediaStreamError, RTCConfiguration, RTCPeerConnection
from av import AudioFrame, AudioResampler

from .cases import INCOMPLETE, get_order
from .dialogue import asks_for_commitment, commitment_plan_text, commitment_preface, material_question_fields

log = logging.getLogger(__name__)
OUTPUT_RATE = 48_000
AUDIO_FRAMES_PER_SECOND = 50
OUTPUT_FRAME = OUTPUT_RATE // AUDIO_FRAMES_PER_SECOND
PLAYOUT_MARGIN = 0.16
TERMINAL_CALL_STATES = {"closed", "complete"}


def reply_sentences(text):
    return re.findall(r"[^。！？；]+[。！？；]*", text)


def has_speech_text(text):
    return any(char.isalnum() for char in text)


def use_stamp_asr(call):
    return call["verified"] and call["scenario"] == INCOMPLETE.scenario and call["state"] in {"need", "explain"}


class ReplyTrack(AudioStreamTrack):
    def __init__(self, on_frame, *, sample_rate=OUTPUT_RATE):
        super().__init__()
        self.sample_rate = sample_rate
        self.frame_size = sample_rate // AUDIO_FRAMES_PER_SECOND
        self._time_base = Fraction(1, sample_rate)
        self.frames = deque()
        self._on_frame = on_frame
        self._pts = 0
        self._clock = None

    def append(self, samples, rate):
        samples = np.asarray(samples, dtype=np.float32).reshape(-1)
        if not samples.size:
            return
        if rate != self.sample_rate:
            length = max(1, round(len(samples) * self.sample_rate / rate))
            points = np.arange(length) * rate / self.sample_rate
            samples = np.interp(points, np.arange(len(samples)), samples)
        pcm = (samples.clip(-1, 1) * 32767).astype(np.int16)
        padded = np.pad(pcm, (0, (-len(pcm)) % self.frame_size))
        self.frames.extend(padded.reshape(-1, self.frame_size))

    def resync_clock(self):
        self._clock = time.monotonic() - self._pts / self.sample_rate

    async def recv(self):
        if self.readyState != "live":
            raise MediaStreamError
        if self._clock is None:
            self._clock = time.monotonic()
        else:
            due = self._clock + self._pts / self.sample_rate
            await asyncio.sleep(max(0, due - time.monotonic()))
        has_audio = bool(self.frames)
        pcm = self.frames.popleft() if has_audio else np.zeros(self.frame_size, dtype=np.int16)
        frame = AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
        frame.pts = self._pts
        frame.time_base = self._time_base
        frame.sample_rate = self.sample_rate
        self._pts += self.frame_size
        self._on_frame(has_audio)
        return frame


class CallMedia:
    def __init__(self, store, engine, call_id, simulate_timeout, on_close, prepared_audio, *,
                 vocabulary=None, _webrtc=True, _output_rate=OUTPUT_RATE):
        self.store = store
        self.engine = engine
        self.prepared_audio = prepared_audio
        self.vocabulary = vocabulary
        self.call_id = call_id
        self.simulate_timeout = simulate_timeout
        self.pc = RTCPeerConnection(RTCConfiguration(iceServers=[])) if _webrtc else None
        self.output = ReplyTrack(self._on_output_frame, sample_rate=_output_rate)
        self.channel = None
        self.reader = None
        self.turn_tasks = set()
        self.turn_lock = asyncio.Lock()
        self.input_generation = 0
        self.reply_task = None
        self.speaking = False
        self.synth_done = False
        self.first_audio_at = None
        self.reply_text = ""
        self.delivered_reply = ""
        self.plan_text = ""
        self.plan_start_frames_left = 0
        self.plan_started_at = None
        self.plan_frames_left = 0
        self.plan_ready_at = None
        self.user_ended_at = None
        self.response_timing = None
        self.stamp_asr = False
        self.order = None
        self.verified = False
        self.dialogue_focus = ""
        self.closed = False
        self.ending = False
        self._qa_turn_id = None
        self._qa_sentences = deque()
        self._qa_spoken = []
        self._qa_frames = 0
        self._qa_write = None
        self._on_close = on_close
        if self.pc is None:
            return

        @self.pc.on("track")
        def on_track(track):
            if track.kind == "audio" and self.reader is None:
                self.reader = asyncio.create_task(self._read_audio(track))

        @self.pc.on("datachannel")
        def on_channel(channel):
            if channel.label == "call-events" and self.channel is None:
                self.channel = channel
                self._begin_call(self.store.get_call(self.call_id))

        @self.pc.on("connectionstatechange")
        async def on_connection():
            if self.pc.connectionState in ("failed", "closed"):
                await self.close()

    def _begin_call(self, call):
        self.order = get_order(call["case_id"])
        self.verified = call["verified"]
        self.dialogue_focus = call["dialogue_focus"]
        self.ending = call["state"] in TERMINAL_CALL_STATES
        self.stamp_asr = self.engine.stamp_asr_ready and use_stamp_asr(call)
        if not self.ending:
            self.send("state", state="listening")
        self._reply(call["reply"])

    def send(self, kind, **data):
        if self.channel and self.channel.readyState == "open":
            self.channel.send(json.dumps({"type": kind, **data}, ensure_ascii=False))

    async def close(self):
        if self.closed:
            return
        self.closed = True
        self._cancel_reply()
        if self.reader:
            self.reader.cancel()
        for task in list(self.turn_tasks):
            task.cancel()
        if self._qa_write:
            await self._qa_write
        if self.pc is not None:
            await self.pc.close()
        self._on_close(self)

    def _cancel_reply(self):
        self._save_spoken_qa()
        if self.reply_task and not self.reply_task.done():
            self.reply_task.cancel()
        self.output.frames.clear()
        self.speaking = False
        self.synth_done = False
        self.first_audio_at = None
        self.delivered_reply = ""
        self.plan_text = ""
        self.plan_start_frames_left = 0
        self.plan_started_at = None
        self.plan_frames_left = 0
        self.plan_ready_at = None
        self.user_ended_at = None
        self.response_timing = None
        self._qa_sentences.clear()
        self._qa_spoken.clear()
        self._qa_frames = 0

    def _reply(self, text, user_ended_at=None, timing=None, *, qa_turn_id=None):
        self._cancel_reply()
        self._qa_turn_id = qa_turn_id
        self.reply_text = text
        self.plan_text = commitment_plan_text(text)
        self.user_ended_at = user_ended_at
        self.response_timing = timing
        self.send("state", state="processing")
        self.reply_task = asyncio.create_task(self._synthesize(text))

    async def _synthesize(self, text):
        try:
            plan_sentences = reply_sentences(self.plan_text)
            sentences = plan_sentences + reply_sentences(text[len(self.plan_text):])
            body_index = 0
            if self.plan_text and self.order:
                body_index = len(reply_sentences(commitment_preface(self.order, self.plan_text)))
            plan_audio_valid = True
            for index, sentence in enumerate(sentences):
                sentence = sentence.strip()
                started = time.monotonic()
                cached = self.prepared_audio.get(sentence)
                if cached is None:
                    audio, rate = await asyncio.to_thread(self.engine.synthesize, sentence)
                else:
                    audio, rate = cached
                if index == 0 and self.response_timing is not None:
                    self.response_timing["tts_first_ms"] = round((time.monotonic() - started) * 1000)
                    self.response_timing["cached_first_sentence"] = cached is not None
                queued_before = len(self.output.frames)
                self.output.append(audio, rate)
                if self._qa_turn_id and len(self.output.frames) > queued_before:
                    self._qa_sentences.append((self._qa_frames + len(self.output.frames), sentence))
                if index < len(plan_sentences):
                    queued = len(self.output.frames) > queued_before
                    if (queued and index >= body_index and not self.plan_start_frames_left
                            and self.plan_started_at is None):
                        # Start assent eligibility at the first audible frame of
                        # the remedy, after any informational preface in queue.
                        self.plan_start_frames_left = queued_before + 1
                    plan_audio_valid &= queued
                    if plan_audio_valid and index + 1 == len(plan_sentences):
                        # Everything queued at this boundary belongs to the
                        # plan. Later changes in queue depth may also include
                        # the question and cannot identify this boundary.
                        self.plan_frames_left = len(self.output.frames)
            self.synth_done = True
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Speech synthesis failed for %s", self.call_id)
            self._cancel_reply()
            if self.ending:
                asyncio.create_task(self._close_after_farewell())
            else:
                self.send("error", message="语音合成失败，请结束本次通话后重试。")

    def _on_output_frame(self, has_audio):
        if has_audio and self._qa_turn_id:
            self._qa_frames += 1
            if self._qa_sentences and self._qa_sentences[0][0] <= self._qa_frames:
                self._qa_spoken.append(self._qa_sentences.popleft()[1])
        if has_audio and self.first_audio_at is None:
            self.speaking = True
            self.first_audio_at = time.monotonic()
            fields = material_question_fields(self.order, self.reply_text) if self.verified and self.order else None
            self.send("state", state="speaking", material_fields=fields)
            if self.user_ended_at is not None:
                milliseconds = round((self.first_audio_at - self.user_ended_at) * 1000)
                stages = self.response_timing or {}
                self.send("timing", server_first_audio_ms=milliseconds, **stages)
                log.info("%s server first audio %d ms %s", self.call_id, milliseconds, stages)
        if has_audio and self.plan_start_frames_left:
            self.plan_start_frames_left -= 1
            if not self.plan_start_frames_left:
                self.plan_started_at = time.monotonic() + PLAYOUT_MARGIN
        if has_audio and self.plan_frames_left:
            self.plan_frames_left -= 1
            if not self.plan_frames_left:
                self.plan_ready_at = time.monotonic() + PLAYOUT_MARGIN
        if (self.plan_ready_at is not None and not self.delivered_reply
                and time.monotonic() >= self.plan_ready_at):
            self.delivered_reply = self.plan_text
            self.send("plan-ready")
        if not has_audio and self.synth_done:
            self._save_spoken_qa()
            self.delivered_reply = self.reply_text
            self.synth_done = False
            self.speaking = False
            if self.ending:
                asyncio.create_task(self._close_after_farewell())
            else:
                self.send("state", state="listening")

    def _save_spoken_qa(self):
        turn_id, self._qa_turn_id = self._qa_turn_id, None
        if not turn_id or not self._qa_spoken:
            return
        spoken = "".join(self._qa_spoken)
        previous = self._qa_write

        async def save():
            if previous:
                await previous
            try:
                count = await asyncio.to_thread(self.store.record_spoken_reply, self.call_id, turn_id, spoken)
                if not self.closed:
                    self.send("qa", completed_qa_count=count)
            except Exception:
                log.exception("Could not record played QA for %s", self.call_id)

        self._qa_write = asyncio.create_task(save())

    def _playback_at_onset(self, onset):
        delivered = self.delivered_reply
        if delivered == self.plan_text and self.plan_ready_at is not None and onset < self.plan_ready_at:
            delivered = ""
        started_plan = ""
        if self.plan_started_at is not None and onset >= self.plan_started_at:
            started_plan = self.reply_text
        return delivered, started_plan

    async def _close_after_farewell(self):
        await asyncio.sleep(0.25)
        if self.closed:
            return
        self.send("ended")
        await asyncio.sleep(0.1)
        await self.close()

    def _confirm_user_speech(self):
        self.input_generation += 1
        interrupted = self.speaking
        self._cancel_reply()
        if interrupted:
            self.send("interrupt")
            log.info("%s merchant interrupted playback", self.call_id)
        self.send("state", state="listening")

    async def _read_audio(self, track):
        resampler = AudioResampler(format="s16", layout="mono", rate=16_000)
        pending = np.empty(0, dtype=np.float32)
        stream = None
        speech_probe = None
        offline = False
        heard_before_turn = ""
        started_plan = ""
        last_voice = None
        try:
            vad = self.engine.new_vad()
            confirm_speech = self.engine.vad_backend == "silero"
            while not self.closed:
                frame = await track.recv()
                if self.ending or not self.channel or self.channel.readyState != "open":
                    continue
                for block in resampler.resample(frame):
                    audio = block.to_ndarray().reshape(-1).astype(np.float32) / 32768.0
                    pending = np.concatenate((pending, audio))
                    while len(pending) >= vad.frame_size:
                        detected = vad.push(pending[:vad.frame_size])
                        pending = pending[vad.frame_size:]
                        if detected.started:
                            # Bind consent to playback at the original onset,
                            # even if the speech is confirmed a little later.
                            onset = time.monotonic() - detected.onset_lookback
                            heard_before_turn, started_plan = self._playback_at_onset(onset)
                            offline = self.stamp_asr
                            stream = self.engine.new_stamp_stream() if offline else self.engine.new_stream()
                            if confirm_speech:
                                # SenseVoice decodes at the endpoint. A short
                                # local Zipformer probe can confirm speech earlier.
                                speech_probe = self.engine.new_stream() if offline else stream
                            else:
                                self._confirm_user_speech()
                        if detected.voiced:
                            last_voice = time.monotonic()
                        if stream is not None and detected.audio is not None:
                            stream.feed(detected.audio)
                            if speech_probe is not None:
                                if speech_probe is not stream:
                                    speech_probe.feed(detected.audio)
                                if has_speech_text(speech_probe.partial_text()):
                                    self._confirm_user_speech()
                                    speech_probe = None
                        if stream is not None and detected.ended:
                            endpoint_at = time.monotonic()
                            if detected.trailing_silence is not None:
                                last_voice = endpoint_at - detected.trailing_silence
                            timing = {
                                "endpoint_ms": round((endpoint_at - last_voice) * 1000),
                                "asr_backend": "sensevoice" if offline else "zipformer",
                            }
                            if offline:
                                task = asyncio.create_task(self._decode_stamp(
                                    stream, last_voice, endpoint_at, timing, self.input_generation,
                                    heard_before_turn, started_plan, confirmation_pending=speech_probe is not None))
                                self.turn_tasks.add(task)
                                task.add_done_callback(self.turn_tasks.discard)
                            else:
                                text = stream.finish().strip()
                                timing["asr_finalize_ms"] = round((time.monotonic() - endpoint_at) * 1000)
                                self._finish_recognition(
                                    text, last_voice, timing, heard_before_turn, started_plan,
                                    confirmation_pending=speech_probe is not None,
                                )
                            stream = None
                            speech_probe = None
        except (MediaStreamError, asyncio.CancelledError):
            return
        except Exception:
            log.exception("Incoming audio failed for %s", self.call_id)
            self.send("error", message="语音识别或通话处理失败，请重新发起通话。")

    async def _decode_stamp(self, stream, last_voice, endpoint_at, timing, generation,
                            heard_before_turn="", started_plan="", *, confirmation_pending=False):
        try:
            text = await asyncio.to_thread(stream.finish)
        except Exception:
            log.exception("Stamp recognition failed for %s", self.call_id)
            text = ""
        if self.closed or self.ending or generation != self.input_generation:
            return
        timing["asr_finalize_ms"] = round((time.monotonic() - endpoint_at) * 1000)
        self._finish_recognition(
            text, last_voice, timing, heard_before_turn, started_plan, confirmation_pending=confirmation_pending,
        )

    def _finish_recognition(self, text, last_voice, timing, heard_before_turn, started_plan, *, confirmation_pending):
        if confirmation_pending:
            if not has_speech_text(text):
                return
            self._confirm_user_speech()
        if self.verified and self.order and self.vocabulary and has_speech_text(text):
            corrected = self.vocabulary.correct(self.order.case_id, text, focus=self.dialogue_focus)
            if corrected != text:
                self._finish_turn(corrected, last_voice, timing, heard_before_turn, started_plan, raw_text=text)
                return
        self._finish_turn(text, last_voice, timing, heard_before_turn, started_plan)

    def _finish_turn(self, text, last_voice, timing, heard_before_turn, started_plan="", *, raw_text=None):
        if has_speech_text(text):
            trace = {"raw_text": raw_text} if raw_text is not None else {}
            self.send("transcript", text=text, final=True, role="user", **trace)
        else:
            text = ""
        self.send("state", state="processing")
        task = asyncio.create_task(self._process_turn(
            text, last_voice, timing, self.input_generation, heard_before_turn, started_plan, raw_text=raw_text,
        ))
        self.turn_tasks.add(task)
        task.add_done_callback(self.turn_tasks.discard)

    async def _process_turn(self, text, last_voice, timing, generation, delivered_reply, started_plan="", *, raw_text=None):
        def superseded():
            return self.closed or self.ending or generation != self.input_generation

        started = time.monotonic()
        try:
            async with self.turn_lock:
                if self._qa_write:
                    await asyncio.shield(self._qa_write)
                if superseded():
                    return
                if not text:
                    call = await asyncio.to_thread(self.store.get_call, self.call_id)
                    if superseded() or call["state"] in TERMINAL_CALL_STATES:
                        return
                    context = (call.get("stamp_decision") or {}).get("context", {})
                    if (use_stamp_asr(call) and context.get("plan_offered")
                            and asks_for_commitment(call["reply"])):
                        if delivered_reply == call["reply"]:
                            # The VAD reset this marker at onset. Noise alone
                            # does not undo a proposal that finished playing.
                            self.delivered_reply = delivered_reply
                            self.send("state", state="listening")
                        else:
                            self._reply(call["reply"], last_voice, timing)
                    else:
                        self._reply("刚才没听清，请再说一遍。", last_voice, timing)
                    return
                turn_id = uuid4().hex
                result = await asyncio.to_thread(
                    self.store.turn, self.call_id, text, turn_id,
                    simulate_timeout=self.simulate_timeout, cancelled=superseded, delivered_reply=delivered_reply,
                    started_plan=started_plan, raw_text=raw_text,
                )
        except Exception:
            log.exception("Business turn failed for %s", self.call_id)
            if not superseded():
                self.send("error", message="这一轮未能处理，请再说一遍。")
            return
        if self.closed or self.ending:
            return
        # Later microphone activity may supersede an ordinary reply, but it
        # cannot undo a terminal state already committed by the Store.
        ending = result["state"] in TERMINAL_CALL_STATES
        if not ending and superseded():
            return
        self.ending = ending
        timing["business_ms"] = round((time.monotonic() - started) * 1000)
        decision = result.get("stamp_decision") or result.get("dialogue_decision")
        if decision and decision.get("source") in {"model", "fallback"}:
            timing["model_ms"] = decision["latency_ms"]
        self.stamp_asr = self.engine.stamp_asr_ready and use_stamp_asr(result)
        self.verified = result["verified"]
        self.dialogue_focus = result.get("dialogue_focus", "")
        self.send("update", data=result)
        if result["reply"]:
            qa_turn_id = turn_id if "completed_qa_count" in result else None
            self._reply(result["reply"], last_voice, timing, qa_turn_id=qa_turn_id)
