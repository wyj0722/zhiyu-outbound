"""Live strategy-assisted answers for the authorization-chain pilot."""

import json
import re
import time

from .case_agent import CHAIN_UPLOAD_QUESTION, CaseDecision, RESUME
from .cases import CHAIN
from .dialogue import (
    REVIEW, accepts_offered_plan, acknowledges_plan, asks_for_commitment, chain_collection_paused,
    chain_submitted_reply, respond,
)


_ANSWER_INSTRUCTIONS = (
    "你是京东商家资质审核外呼的演示坐席。回答最后一条商家消息中的当前问题。"
    "以前的发言只用来理解上下文和指代，角色与事实由系统给定。"
    "根据本轮适用策略和已核实事实回答，商家声称的情况不能当作核验结论。"
    "策略只规定答复方法，不能改写单据或审核结果。没有依据时说明还需核实。"
    "不得保证审核结果或给出无依据的时限，不得声称已经写回、提交或通过。"
    "商家只问缺哪段时，直接说清授权方向。只用自然中文回答，最多两句，不问是否同意方案，"
    "不念出内部策略、编号或字段名。"
)
_UNSAFE_SPOKEN = re.compile(
    r"包过|稳过|(?:肯定能|一定能|保证能|确保能|就能|就可以)(?:过审|通过(?:审核)?|审核通过)"
    r"|(?:已|已经)(?:帮您|为您)?(?:写回|关单|记录|登记|提交|通过审核)"
    r"|(?:POP-(?:AUTH|REVIEW)|系统提示|内部策略)"
)
_TIME_PROMISE = re.compile(r"[零一二两三四五六七八九十百\d]+(?:个?工作日|个?小时|天|分钟).{0,6}(?:到账|通过|完成|出结果|审完)")
CHAIN_REVIEW_PREFACE = REVIEW[CHAIN.scenario].partition("。")[0] + "。"
_ACTION = {
    "segment": ("request_segment", "chain_request"),
    "relationship": ("related_companies", "chain_contact"),
    "submitted_material": ("identify_parties", "chain_request"),
    "review": ("review", ""),
    "duration": ("review_duration", ""),
    "ambiguous": ("clarify", ""),
}


def chain_facts(order, *, verified=True):
    if not verified:
        return {"identity_verified": False}
    submitted = order.submitted_authorization
    return {
        "identity_verified": True,
        "upstream": order.facts["upstream"],
        "downstream": order.facts["downstream"],
        "missing_segment": order.reason,
        "submitted_grantor": submitted["grantor"],
        "submitted_grantee": submitted["grantee"],
        "review_phase": "未重新提交",
        "relationship_check": "未确认关联",
        "relationship_record": "本单审核记录未查到两家公司的持股关系，也未查到相同的法定代表人。",
        "evidence_refs": list(order.evidence),
    }


def _strategy_prompt(rows):
    keys = ("strategy_id", "version", "intent", "conditions", "actions", "reply_requirements")
    return [{key: row[key] for key in keys} for row in rows]


def strategy_choice_context(retrieval):
    if not retrieval or not retrieval["strategies"]:
        return ""
    rules = json.dumps(_strategy_prompt(retrieval["strategies"]), ensure_ascii=False)
    return ("\n本轮适用的内部策略（仅用于判断商家意图和选择给定动作。"
            "事实以工单为准，商家确认与回写由业务流程核验）：\n" + rules)


class ChainStrategyAgent:
    def __init__(self, library, transport, fallback):
        self.library = library
        self.transport = transport
        self.fallback = fallback

    def answer(self, question, facts, history, strategies, *, after_review_preface=False):
        instructions = (
            _ANSWER_INSTRUCTIONS + f"\n业务场景：{CHAIN.scenario}\n"
            + "已核实单据事实：" + json.dumps(facts, ensure_ascii=False)
            + "\n本轮适用策略：" + (
                json.dumps(_strategy_prompt(strategies), ensure_ascii=False)
                if strategies else "本轮无适用策略"
            )
        )
        if after_review_preface:
            instructions += (
                f"\n坐席已用固定首句“{CHAIN_REVIEW_PREFACE}”说明审核结论尚未确定。"
                "只补充一句，回答复审核对内容或商家可以做的下一步，不重复首句。"
            )
        messages = [{"role": "system", "content": instructions}, *history,
                    {"role": "user", "content": question}]
        return self.transport.chat_text(messages, max_tokens=96 if after_review_preface else 192)

    def decide(self, order, text, focus, last_reply, *, context, history, raw_question):
        facts = chain_facts(order)
        started = time.perf_counter()
        retrieval = self.library.retrieve(text, facts=facts, history=history, scene=CHAIN.scenario)
        intent = retrieval.get("intent_key")
        compact = re.sub(r"[\s,，。.!！、]+", "", text)
        workflow = (
            CHAIN_UPLOAD_QUESTION.search(compact)
            or RESUME.fullmatch(compact)
            or acknowledges_plan(text)
            or accepts_offered_plan(text)
            or chain_collection_paused(compact)
            or order.contradicts_action(compact)
        )
        if intent not in _ACTION or workflow:
            return self.fallback.decide(order, text, focus, last_reply, context=context), {
                **retrieval, "strategies": [], "reason": "workflow" if workflow else "no_applicable_strategy",
            }
        action, next_focus = _ACTION[intent]
        error = None
        try:
            review = intent == "review"
            reply = self.answer(raw_question, facts, history, retrieval["strategies"],
                                after_review_preface=review)
            if review:
                reply = CHAIN_REVIEW_PREFACE + reply.removeprefix(CHAIN_REVIEW_PREFACE).lstrip()
            if (asks_for_commitment(reply) or _UNSAFE_SPOKEN.search(reply) or _TIME_PROMISE.search(reply)
                    or len(reply) > 230 or order.contradicts_action(reply)):
                raise ValueError("答复未通过业务检查")
            if intent == "segment" and not all(name in reply for name in order.facts.values()):
                raise ValueError("缺少工单中的授权双方")
            if intent == "submitted_material" and not all(
                facts[key] in reply for key in ("submitted_grantor", "submitted_grantee")
            ):
                raise ValueError("缺少已上传材料里的授权双方")
        except (OSError, ValueError):
            error = "strategy_answer_unavailable"
            if intent == "review":
                reply = REVIEW[CHAIN.scenario]
            elif intent in {"segment", "submitted_material"}:
                reply = chain_submitted_reply(order)[0]
            elif intent == "duration":
                reply = "这张工单没有确认预计审核时长。重新提交后，您可以在申请单里查看审核进度。"
            else:
                reply = respond(order, compact, focus)[0]
        recent = (context.get("recent", []) + [{"text": raw_question[:96], "action": action}])[-3:]
        choice = CaseDecision(
            reply, next_focus or focus, action, "fallback" if error else "model", error,
            round((time.perf_counter() - started) * 1000), order.evidence,
            None if error else action, dict(context, recent=recent),
        )
        if error:
            retrieval = {**retrieval, "strategies": [], "reason": error}
        return choice, retrieval
