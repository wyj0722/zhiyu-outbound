"""Official-row-backed strategy seeds for the four additional audit scenes."""

import re

from .cases import (
    AUTHORIZATION_EXPIRED, CATEGORY, INCOMPLETE, LEGAL_REPRESENTATIVE_DOCUMENT_TYPE,
)
from .dialogue import accepts_offered_plan, acknowledges_plan


_MAIN = "[POP资审]资审关单场景话术V1.0.xlsx · 场景汇总!"
_QA = "驳回外呼QA.xlsx · "


def _sources(procedure):
    refs = [_MAIN + f"A{row}:E{row}" for row in procedure.source_areas]
    if procedure.qa_row is not None:
        refs.append(_QA + f"特殊场景!B{procedure.qa_row}:D{procedure.qa_row}")
    return refs


def _seed(identifier, procedure, title, intent, examples, actions, requirements, *, review=False):
    sources = _sources(procedure)
    if review:
        sources.extend((_QA + "高频QA!B12:C12", _QA + "特殊场景!B27:D27"))
    return {
        "strategy_id": identifier, "version": 1, "status": "active", "scene": procedure.scenario,
        "title": title, "intent": intent, "conditions": {}, "query_examples": examples,
        "actions": actions, "reply_requirements": requirements, "evidence_refs": sources,
    }


EXTRA_SEEDS = (
    _seed(
        "POP-CATEGORY-REASON-01", CATEGORY, "核对申请类目与授权范围", "询问品牌类目不符的驳回原因及已提交授权范围",
        ["这张申请为什么被驳回？", "已提交的授权书上写了哪些类目？", "申请的类目和授权范围哪里不一样？"],
        ["读取本单 requested 和 authorized，分别说清申请的类目与现有销售授权覆盖的类目。",
         "依据本单审核发现解释不符之处，区分销售授权范围与商标注册范围。"],
        ["类目名称取自本单事实，不能把已授权与未授权的类目说反。",
         "商家说已经有其他授权时，先核对新材料覆盖范围，不把口头陈述当作审核结论。"],
    ),
    _seed(
        "POP-CATEGORY-SCOPE-01", CATEGORY, "按经营诉求补齐对应授权", "询问保留哪些经营类目及如何补充所需销售授权",
        ["只经营已有授权的类目要怎么改？", "我还想保留申请的其他类目怎么办？", "覆盖新类目的授权书已经拿到了。"],
        ["只经营现有授权范围时，指导保留 authorized 对应类目，去掉本单超出授权的 requested 类目后重新提交。",
         "还要经营 requested 时，说明需有覆盖该类目的销售授权；尚未取得时联系授权方补充，已取得时核对覆盖范围后上传。",
         "按实际有效授权范围选择类目，再重新提交申请。"],
        ["先按商家本轮明确诉求给出对应路径，不替商家决定删掉仍想经营的类目。",
         "不把拿到授权书说成已通过审核，不要求已确认拿到材料的商家重复索取。"],
    ),
    _seed(
        "POP-CATEGORY-LOCATION-01", CATEGORY, "找到授权类目的修改入口", "询问经营范围限制和授权类目的修改位置及提交步骤",
        ["在哪里修改授权类目？", "有经营范围限制怎么选？", "销售授权书下面的选择授权类目在哪里？"],
        ["指导打开已驳回的申请单，在销售授权书下方选择有经营范围限制。",
         "点击选择授权类目，按授权书勾选对应产品类目，核对后重新提交。",
         "涉及删除或保留类目时，以本单事实和商家已经确认的经营选择为准。"],
        ["保留官方 QA 的入口名称和先后步骤。", "不把本次仍要补授权的类目直接作为现有可选授权范围。"],
    ),
    _seed(
        "POP-CATEGORY-REVIEW-01", CATEGORY, "说明类目整改后的复审边界", "询问修改类目或补齐销售授权后能否通过审核",
        ["把类目改完就一定能过审吗？", "我把这个补上，这单就没问题了吗？", "现在是等待审核还是已经通过？"],
        ["先说明是否通过要以完整材料的审核结果为准。",
         "尚未重新提交时，按已选择的整改路径核对类目与授权范围后提交；已提交待审时说明等待审核结果。"],
        ["正面回答能否通过的疑问，不用重复索取授权代替回答。", "不保证通过，不编造审核时限。"], review=True,
    ),
    _seed(
        "POP-AUTH-STAMP-REASON-01", INCOMPLETE, "说明本单授权书缺少的公章", "询问授权书不完整的具体缺项和补件原因",
        ["这份授权书到底缺什么？", "为什么说授权书内容不完整？", "是不是还少一个章？"],
        ["按本单 grantor 和审核发现说明缺少授权方公章。",
         "当前样单属于公章缺项，只解释本单缺项；其他授权书是否需要个人身份证或独占性文字，须另有该单依据。"],
        ["缺章主体必须与本单授权方一致。", "不把别的授权书子场景要求添加到本单。"],
    ),
    _seed(
        "POP-AUTH-STAMP-OWNER-01", INCOMPLETE, "核对章面主体与授权方", "询问盖谁的公章或已盖章材料为什么仍需补章",
        ["盖我们公司的章可以吗？", "我已经盖章了，怎么还说缺章？", "原来上传的那份盖的是谁的章？"],
        ["先区分授权方 grantor 与本单已上传材料显示的章面主体，依可核实记录回答。",
         "商家只说已盖章时，核对章上的公司全称；不能仅凭已盖章就认定满足要求。",
         "本单仍缺授权方公章时，说明联系该授权方补盖。"],
        ["不能用商家自己的章替代本单要求的授权方公章。",
         "不凭谁经手盖章推断章面主体；事实不足时只询问需要核实的主体。"],
    ),
    _seed(
        "POP-AUTH-STAMP-UPLOAD-01", INCOMPLETE, "补盖后上传完整授权书", "询问补盖授权方公章后的材料上传与重新提交步骤",
        ["盖好后在哪里上传？", "授权方盖好的完整授权书拿到了，下一步呢？", "补章以后怎么重新提交？"],
        ["未补齐本单要求公章时，先联系 grantor 补盖。",
         "确认材料符合本单章面主体要求后，将盖好章的完整授权书上传到该申请单，核对清晰完整后重新提交。"],
        ["商家说手上有材料时应结合已确认状态答复，章面未知则先核对。",
         "只说明后续办理动作，不声称系统已经提交或审核完成。"],
    ),
    _seed(
        "POP-AUTH-STAMP-REVIEW-01", INCOMPLETE, "说明补章后的复审边界", "询问授权书补盖公章以后能否通过审核",
        ["这个章补上就一定能通过吗？", "盖好以后是不是就没问题了？", "材料交完会直接通过审核吗？"],
        ["先说明材料上传后仍需审核完整材料，才能确定是否通过。",
         "未提交时提醒按本单缺项补齐并重新提交；已提交待审时说明留意审核结果。"],
        ["不把公章补齐等同于整单通过。", "通用复审口径不增加本单未要求的材料或时限。"], review=True,
    ),
    _seed(
        "POP-AUTH-EXPIRED-REASON-01", AUTHORIZATION_EXPIRED, "核对本单授权截止日期", "询问授权书到期的驳回原因及原材料有效期",
        ["这份授权是哪一天到期的？", "为什么说授权已经失效？", "原来上传的授权截止日期是多少？"],
        ["从本单 expires_on 读取授权截止日期，说明该份授权已到期。",
         "区分销售授权有效期与商标注册期限，不用其他材料仍有效来代替本单授权期限。"],
        ["日期和授权方名称只取自当前单据。", "不自行计算或宣布未提供依据的新有效期。"],
    ),
    _seed(
        "POP-AUTH-EXPIRED-REISSUE-01", AUTHORIZATION_EXPIRED, "联系授权方重新开具授权书", "询问过期授权如何续办以及能否继续使用或自行改日期",
        ["授权过期后找谁重开？", "能自己把日期改一下吗？", "这份旧授权还能继续用吗？"],
        ["指导联系本单授权方 grantor，重新开具一份有效的销售授权书。",
         "旧授权已失效时，不能通过商家自行修改日期或继续上传过期件解决。",
         "已取得新的有效授权时，转为核对新授权并换传，不重复要求重开。"],
        ["官方要求是重新开具授权书，不建议自行改动原件日期。", "不承诺重开授权后即可通过复审。"],
    ),
    _seed(
        "POP-AUTH-EXPIRED-UPLOAD-01", AUTHORIZATION_EXPIRED, "换传新的有效授权书", "询问新授权书已取得后的上传位置和重新提交步骤",
        ["我已拿到新授权书，传到哪里？", "新的有效授权已经开好，接下来怎么办？", "怎么替换原来过期的授权书？"],
        ["按本单已确认材料状态答复，新授权尚未取得时先联系授权方重新开具。",
         "取得新授权后，在已驳回申请单的销售授权书一栏换传新文件，核对授权有效期后重新提交。"],
        ["区分新授权与原过期授权，不能指导重新提交旧件。", "上传位置沿用本单申请单，不引入其他未经确认的表单或入口。"],
    ),
    _seed(
        "POP-AUTH-EXPIRED-REVIEW-01", AUTHORIZATION_EXPIRED, "说明换新授权后的复审边界", "询问授权书重新开具并换传后是否能通过审核",
        ["换成新授权后就能过审吗？", "重新开好授权书是不是就没问题了？", "上传新的以后一定会通过吗？"],
        ["说明重新开具和换传是当前整改要求，能否通过仍需审核完整材料。",
         "尚未重新提交时提醒核对新授权有效期后提交；已提交待审时说明以审核结果为准。"],
        ["不以新授权已开具推断审核通过。", "不编造新的授权期限或审核时限。"], review=True,
    ),
    _seed(
        "POP-LEGAL-DOC-REASON-01", LEGAL_REPRESENTATIVE_DOCUMENT_TYPE, "核对要求证件与已传附件", "询问法人证件类型错误的具体原因及应提交什么证件",
        ["这单应该传什么证件？", "我原来上传的是什么证件？", "为什么法人证件类型不符合？"],
        ["从本单 expected_type 和 submitted_type 分别读取要求的证件和实际上传的证件。",
         "说明本单具体不一致之处；区分已选类型与附件不一致，以及本单已明确要求某类证件的情况。"],
        ["本单要求何种证件以单据为准，不把当前样单要求扩展到所有法人。",
         "个人商标持有人的身份证签字捺印要求不适用于本单法人证件类型核对。"],
    ),
    _seed(
        "POP-LEGAL-DOC-REPLACE-01", LEGAL_REPRESENTATIVE_DOCUMENT_TYPE, "按本单要求更换法人证件", "询问能否只改类型选项或沿用不符的证件附件",
        ["不换附件，只把类型改成护照可以吗？", "这单能继续使用原来的护照吗？", "只有护照，要怎么改这张申请？"],
        ["本单已明确 expected_type 时，指导准备该法人的对应证件，并更换不符的附件。",
         "核对所填证件类型与附件一致；不能仅把选项改为 submitted_type 来绕过本单明确要求。",
         "商家无法提供要求材料时说明当前要求并交由业务核实，不自行批准替代证件。"],
        ["保持本单 expected_type 与 submitted_type 的角色清楚。",
         "不添加官方依据未给出的正反面规格、签字捺印或地区证件政策。"],
    ),
    _seed(
        "POP-LEGAL-DOC-UPLOAD-01", LEGAL_REPRESENTATIVE_DOCUMENT_TYPE, "换传法人证件后重新提交", "询问法人证件的换传位置及重新提交步骤",
        ["在哪个栏目换传法人证件？", "准备好要求的证件以后怎么上传？", "换好附件后怎么重新提交？"],
        ["指导在本单申请单的法人证件一栏换传 expected_type 对应附件。",
         "核对所填证件类型与附件一致，检查材料后重新提交申请。"],
        ["位置与步骤限于当前申请单。", "不要求商家通过电话报出完整证件号码或敏感身份信息。"],
    ),
    _seed(
        "POP-LEGAL-DOC-REVIEW-01", LEGAL_REPRESENTATIVE_DOCUMENT_TYPE, "说明证件整改后的复审边界", "询问更换法人证件后能否通过审核",
        ["按要求上传身份证后能保证通过吗？", "把证件换好这单就没问题了吗？", "重新提交以后是不是直接审核通过？"],
        ["使用资质补交通用复审口径，说明是否通过需以完整材料审核结果为准。",
         "本单证件要求仍取自单据，未提交时按要求更换后重提，已提交待审时说明等待审核结果。"],
        ["通用 QA 只支持复审边界，不充当法人证件类型的专门政策。", "不保证通过，不捏造审核时限。"], review=True,
    ),
)

EXTRA_SEED_INTENTS = {
    "POP-CATEGORY-REASON-01": {"category_reason", "submitted_material"},
    "POP-CATEGORY-SCOPE-01": {"category_scope"},
    "POP-CATEGORY-LOCATION-01": {"category_location"},
    "POP-CATEGORY-REVIEW-01": {"review"},
    "POP-AUTH-STAMP-REASON-01": {"stamp_reason"},
    "POP-AUTH-STAMP-OWNER-01": {"stamp_owner", "submitted_material"},
    "POP-AUTH-STAMP-UPLOAD-01": {"stamp_upload"},
    "POP-AUTH-STAMP-REVIEW-01": {"review"},
    "POP-AUTH-EXPIRED-REASON-01": {"expiry_reason", "submitted_material"},
    "POP-AUTH-EXPIRED-REISSUE-01": {"expiry_reissue"},
    "POP-AUTH-EXPIRED-UPLOAD-01": {"expiry_upload"},
    "POP-AUTH-EXPIRED-REVIEW-01": {"review"},
    "POP-LEGAL-DOC-REASON-01": {"document_reason", "submitted_material"},
    "POP-LEGAL-DOC-REPLACE-01": {"document_replace"},
    "POP-LEGAL-DOC-UPLOAD-01": {"document_upload"},
    "POP-LEGAL-DOC-REVIEW-01": {"review"},
}

_QUESTION = re.compile(r"[?？]|吗|呢|么|怎么|哪里|哪儿|什么|为何|为什么|能不能|会不会|是否|多久|能否|有没有|要不要|是不是|行不行")
_COMMITMENT = re.compile(r"^(?:好的?|行|那|明白了?|没问题)*(?:我|我们)(?:确认|同意|会|这就|马上|回去就|愿意|决定|就).*(?:补|联系|盖|重开|换|上传|提交|勾选|办理|处理)")
_REVIEW = re.compile(
    r"过审|审核结果|审核通过|通过审核|待审|复审|(?:能|会|可以|能否|保证|确保|一定).{0,5}通过|"
    r"(?:能|会|包|保|稳)过(?:吗|么|吧|了|$)|"
    r"(?:补|换|盖|重新提交|重提).{0,18}就.{0,6}(?:没问题|没事|行了|可以了).{0,3}(?:吗|么|[?？])"
)
_DURATION = re.compile(r"多久|多长时间|几天|几个工作日|多少天|审核时长")
_LOCATION = re.compile(
    r"(?:哪儿|哪里|在哪|哪个栏目|哪一栏|哪个位置|入口).{0,12}(?:上传|提交|换传|勾选|选择|改|授权|类目|证件|附件|材料)|"
    r"(?:上传|提交|换传|传到|传|勾选|选择|修改).{0,12}(?:哪儿|哪里|在哪|哪个栏目|哪一栏|哪个位置|入口)|"
    r"销售授权书下方|有经营范围限制|选择授权类目|(?:怎么|如何)(?:上传|换传|勾选|选择|修改)|"
    r"(?:入口|上传位置).{0,4}(?:在哪|哪里|哪儿)|后台.{0,6}(?:怎么|如何)"
)
_WHY = re.compile(r"原因|为什么|为啥|怎么回事|被驳回|不符|哪里有问题|缺什么|哪.{0,5}不对|哪里错|怎么没过")
_NEXT = re.compile(r"下一步|接下来|怎么办|怎么做|怎么整改|怎么处理|怎么重新提交|如何重新提交")
_SUBMITTED = re.compile(r"(?:原来|之前|已(?:经)?)(?:.{0,6})(?:上传|提交|交的)|(?:授权书|材料|附件|证件)上.{0,8}(?:写|盖|什么|哪家|谁|日期|有效期|范围)")
_STAMP_OWNER = re.compile(r"(?:盖|用).{0,8}(?:谁|哪家|我方|自己|我们).{0,8}(?:章|公章)|章上.{0,10}(?:谁|哪家|全称)|公章.{0,8}(?:谁|哪家)|(?:已经|已|早就).{0,5}盖.{0,3}章|(?:谁|哪家(?:公司)?).{0,6}盖(?:公)?章")
_CATEGORY_SCOPE = re.compile(r"授权范围|经营范围|保留|只(?:想|做|经营|卖)|还想.{0,4}(?:经营|卖)|经营其他|都想|去掉.{0,6}类目|补.{0,6}授权|(?:拿到|已有|取得).{0,8}授权书|类目.{0,5}(?:超|限制)")
_EXPIRY_REISSUE = re.compile(r"重开|重新开具|重新开|续授权|续期|找谁|联系谁|(?:自己|自行|直接).{0,5}(?:改|修改|延长).{0,5}(?:日期|有效期)|(?:自己|自行|直接).{0,5}(?:日期|有效期).{0,5}(?:改|修改|延长)|(?:旧|过期|原来).{0,6}授权.{0,8}(?:用|传|交)|授权.{0,5}(?:还能|继续|直接).{0,3}用")
_DOCUMENT_REPLACE = re.compile(r"(?:只|直接|仅|不换附件).{0,8}(?:改|换|类型)|(?:证件)?类型.{0,5}(?:改成|改为|选择|换成)|(?:继续|仍|还|只).{0,6}(?:护照|原证件|原附件)|(?:只有|没有).{0,5}(?:护照|身份证)|不用.{0,4}身份证|(?:法人证件|附件).{0,4}(?:该换|换成|换什么)")


def intent_keys_for_scene(scene, text):
    """Recognize the current request while leaving consent to the call workflow."""
    if scene not in {row["scene"] for row in EXTRA_SEEDS} or not isinstance(text, str):
        return ()
    compact = re.sub(r"[\s,，。.!！、]+", "", text)
    if accepts_offered_plan(text) or acknowledges_plan(text):
        return ()
    if not _QUESTION.search(text) and _COMMITMENT.search(compact):
        return ()
    if _DURATION.search(compact) and (re.search(r"审核|复审|申请|提交|结果|材料|证件|授权|补|换|盖|待审", compact)
                                           or re.fullmatch(r"(?:那)?(?:一般)?(?:还要|要|得)?等?多久[?？吗呢]*", compact)):
        return ("duration",)
    if _REVIEW.search(compact):
        return ("review",)
    if scene == CATEGORY.scenario:
        if _LOCATION.search(compact):
            return ("category_location",)
        if _SUBMITTED.search(compact):
            return ("submitted_material",)
        if _CATEGORY_SCOPE.search(compact):
            return ("category_scope",)
        if _WHY.search(compact) or re.search(r"申请.{0,5}类目|授权书.{0,6}范围", compact):
            return ("category_reason",)
        return ("category_location",) if _NEXT.search(compact) else ()
    if scene == INCOMPLETE.scenario:
        if _STAMP_OWNER.search(compact):
            return ("stamp_owner",)
        if _LOCATION.search(compact) or re.search(r"(?:盖好|补章|完整授权书).{0,12}(?:传|提交)|(?:授权方|品牌方).{0,12}盖好", compact):
            return ("stamp_upload",)
        if _SUBMITTED.search(compact):
            return ("submitted_material",)
        if _WHY.search(compact):
            return ("stamp_reason",)
        return ("stamp_upload",) if _NEXT.search(compact) else ()
    if scene == AUTHORIZATION_EXPIRED.scenario:
        if _LOCATION.search(compact) or re.search(r"(?:拿到|已有|取得|有|开好).{0,8}(?:新|有效|重开).{0,5}授权书|(?:新|有效|重开).{0,5}授权.{0,8}(?:开好|拿到|上传|换传)", compact):
            return ("expiry_upload",)
        if _EXPIRY_REISSUE.search(compact):
            return ("expiry_reissue",)
        if _SUBMITTED.search(compact):
            return ("submitted_material",)
        if _WHY.search(compact) or re.search(r"哪.{0,5}到期|到期.{0,4}日|有效期|截止日期", compact):
            return ("expiry_reason",)
        return ("expiry_reissue",) if _NEXT.search(compact) else ()
    if _LOCATION.search(compact):
        return ("document_upload",)
    if _DOCUMENT_REPLACE.search(compact):
        return ("document_replace",)
    if _SUBMITTED.search(compact):
        return ("submitted_material",)
    if _WHY.search(compact) or re.search(r"(?:该|应|要).{0,5}(?:传|提供|上传).{0,5}(?:什么|哪种|哪个).{0,3}证件|(?:什么|哪种)证件", compact):
        return ("document_reason",)
    return ("document_upload",) if _NEXT.search(compact) else ()
