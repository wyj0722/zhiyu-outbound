"""Shared HTTPS request and validation for cloud intent providers."""

from http.client import HTTPException
import json
import math
import os


_RESPONSE_LIMIT = 65_536
_CHOICE_LIMIT = 1_024


def _unique_object(pairs):
    fields = dict(pairs)
    if len(fields) != len(pairs):
        raise ValueError("Duplicate JSON field")
    return fields


class CloudChoiceTransport:
    _default_model = ""

    def __init__(self, api_key, model, timeout=6.0):
        api_key = api_key.strip()
        model = model.strip()
        if not api_key or any(not 33 <= ord(character) <= 126 for character in api_key):
            raise ValueError(f"Set {self._key_variable} to a valid {self._service} API key.")
        if not model:
            raise ValueError(f"Set {self._model_variable} to a {self._service} model ID.")
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError(f"{self._timeout_variable} must be a positive number of seconds.")
        self._api_key = api_key
        self.model = model
        self.timeout = timeout

    @classmethod
    def from_env(cls):
        try:
            timeout = float(os.environ.get(cls._timeout_variable, "6"))
        except ValueError:
            raise ValueError(f"{cls._timeout_variable} must be a positive number of seconds.") from None
        return cls(os.environ.get(cls._key_variable, ""), os.environ.get(cls._model_variable, cls._default_model), timeout)

    def complete(self, messages, choices):
        choices = tuple(choices)
        if not choices or any(not isinstance(code, str) or not code for code in choices):
            raise ValueError(f"{self._service} requires nonempty choice codes.")
        wire_messages = [{"role": item["role"], "content": item["content"]} for item in messages]
        instruction = self._format_instruction(choices)
        if wire_messages and wire_messages[0]["role"] == "system":
            wire_messages[0]["content"] += "\n" + instruction
        else:
            wire_messages.insert(0, {"role": "system", "content": instruction})
        payload = {
            "model": self.model,
            "messages": wire_messages,
            "max_tokens": 32,
            **self._request_options(choices),
        }
        content = self._request_content(payload, max_chars=_CHOICE_LIMIT, response_kind="choice")
        try:
            wrapped = json.loads(content, object_pairs_hook=_unique_object)
            if not isinstance(wrapped, dict) or wrapped.keys() != {"choice"} or wrapped["choice"] not in choices:
                raise ValueError
            return wrapped["choice"]
        except (TypeError, ValueError, RecursionError):
            raise ValueError(f"{self._service} returned an invalid choice response.") from None

    def _request_content(self, payload, *, max_chars, response_kind):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"}
        try:
            connection = self._connect()
            try:
                connection.request("POST", self._path, body, headers)
                response = connection.getresponse()
                status = response.status
                raw = response.read(_RESPONSE_LIMIT + 1) if status == 200 else b""
            finally:
                connection.close()
        except TimeoutError:
            raise TimeoutError(f"{self._service} request timed out.") from None
        except (OSError, HTTPException):
            raise OSError(f"{self._service} connection failed.") from None
        if status != 200:
            raise OSError(f"{self._service} returned HTTP {status}.")

        try:
            if len(raw) > _RESPONSE_LIMIT:
                raise ValueError
            [choice] = json.loads(raw)["choices"]
            content = choice["message"]["content"]
            if choice.get("finish_reason") != "stop" or not isinstance(content, str) or len(content) > max_chars:
                raise ValueError
            return content
        except (AttributeError, KeyError, TypeError, ValueError, RecursionError):
            raise ValueError(f"{self._service} returned an invalid {response_kind} response.") from None
