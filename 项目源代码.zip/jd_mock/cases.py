"""Synthetic audit orders and their rejection procedures."""

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class Procedure:
    scenario: str
    source_areas: dict[int, str]
    qa_row: int | None
    reason: str
    steps: tuple[str, ...]
    guidance: str
    action_terms: tuple[str, ...]
    followups: tuple[tuple[tuple[str, ...], str], ...] = ()
    conflicting_actions: tuple[str, ...] = ()
    offer: str = ""
    material_title: str = ""
    material_fields: tuple[tuple[str, str], ...] = ()


CATEGORY = Procedure(
    scenario="品牌类目不符",
    source_areas={29: "品牌", 60: "入驻"},
    qa_row=31,
    reason="本次申请选择了{requested}类目，当前销售授权书仅覆盖{authorized}。",
    steps=(
        "打开已驳回的{application}，在销售授权书下方选择“有经营范围限制”。",
        "点击“选择授权类目”，按授权书勾选{authorized}，并去掉不在授权范围内的{requested}类目。",
        "核对所选类目后，重新提交申请。",
    ),
    guidance="入口在销售授权书下方。打开已驳回的申请单，选择“有经营范围限制”。"
             "再点“选择授权类目”，勾选授权书覆盖的{authorized}后重新提交。",
    action_terms=("类目", "勾选", "{requested}", "{authorized}"),
    followups=(
        (("申请{requested}", "卖{requested}", "经营其他类目", "保留{requested}", "经营{requested}"),
         "如需继续申请{requested}类目，请先补充覆盖该类目的销售授权书。"
         "按本单现有授权整改，请保留{authorized}并去掉{requested}。"),
    ),
    conflicting_actions=(
        r"(?:删(?:除|掉)?|去掉|取消|移除|不选)(?:了)?{authorized}",
        r"{authorized}(?:类目)?(?:删(?:除|掉)?|去掉|取消|移除)",
        r"(?:保留|继续勾选|继续选择){requested}",
        r"{requested}(?:类目)?(?:继续)?保留",
        r"(?:补(?:上|齐|好|充)?|新增|换)(?:覆盖)?{requested}(?:类目|销售)?(?:的)?授权",
    ),
)

INCOMPLETE = Procedure(
    scenario="授权书内容不完整",
    source_areas={17: "品牌", 50: "入驻", 79: "商品资质"},
    qa_row=20,
    reason="这份销售授权书缺少授权方{grantor}的公章。",
    steps=(
        "请联系授权方{grantor}，在这份销售授权书上加盖该公司的公章。",
        "把盖好章的完整授权书上传到{application}。",
        "核对文件清晰完整后，重新提交申请。",
    ),
    guidance="请找{grantor}盖公章。将盖章后的完整销售授权书传回{application}，再重新提交。",
    action_terms=("盖章", "公章", "盖好", "盖上", "盖印", "{grantor}"),
    conflicting_actions=(
        r"(?:我方|我们|本店|我店|商家)(?:自己)?(?:公司|店铺)?的?(?:公章|章|印章)",
        r"(?:我方|我们自己|本店|商家自己)(?:公司)?(?:来|自行|直接)?盖",
    ),
)

CHAIN = Procedure(
    scenario="授权链路不完整",
    source_areas={22: "品牌", 52: "入驻"},
    qa_row=26,
    reason="本单缺少{upstream}到{downstream}的授权关系证明。",
    steps=(
        "请联系上游的{upstream}，补充该公司授权给{downstream}的证明。",
        "将这一段证明连同已有授权材料上传到{application}。",
        "核对授权链路连续完整后，重新提交申请。",
    ),
    guidance="请找{upstream}补授权证明。缺的是{upstream}授权给{downstream}这一段，补齐后随已有授权材料一并重新提交。",
    action_terms=("链路", "授权链", "授权关系", "授权证明", "{upstream}", "{downstream}"),
    followups=(
        (("同一家", "是一家", "同一个老板", "关联公司", "同集团"),
         "这张工单记录的是{upstream}与{downstream}之间缺少关系证明。"
         "如果两家公司有关联，请准备相应的关系证明供审核人员核实。"),
    ),
    conflicting_actions=(
        r"{downstream}(?:把授权给|授权给|授权|出给|开给|给|到|向){upstream}",
        r"{upstream}(?:获得|取得|接受){downstream}的?授权",
    ),
)

AUTHORIZATION_EXPIRED = Procedure(
    scenario="授权时间到期",
    source_areas={21: "品牌", 51: "入驻"},
    qa_row=25,
    reason="这张工单里的销售授权书已于{expires_on}到期。",
    steps=(
        "请联系授权方{grantor}重新开具一份有效的销售授权书。",
        "把新授权书上传到{application}的销售授权书一栏。",
        "核对授权有效期后，重新提交申请。",
    ),
    guidance="拿到新授权书后，在已驳回的{application}里找到销售授权书一栏，换传新的，再重新提交。",
    action_terms=("授权到期", "旧授权书", "过期授权书", "{grantor}"),
    conflicting_actions=(
        r"(?:继续|直接|仍然|还|就)(?:用|上传|提交)(?:这份|原来那份|原来的)?(?:原|旧|过期(?:的)?)授权书",
        r"(?:旧|过期(?:的)?)授权书.{{0,5}}(?:上传|提交|重提)",
        r"(?:自行|自己|直接)(?:改|修改|延长).{{0,5}}(?:日期|有效期|截止时间)",
        r"(?:不用|无需|不打算|不想|不)(?:重新开具|重开|换新授权书)",
    ),
    offer="请联系{grantor}重开一份有效的销售授权书，换传到{application}，再重新提交。",
    material_title="销售授权书",
    material_fields=(("grantor", "授权方"), ("expires_on", "授权截止日期")),
)

LEGAL_REPRESENTATIVE_DOCUMENT_TYPE = Procedure(
    scenario="法人证件类型",
    source_areas={49: "入驻", 76: "公司资质"},
    qa_row=None,
    reason="这张工单要求上传法人的{expected_type}，目前传上来的是{submitted_type}。",
    steps=(
        "请准备该法人的{expected_type}。",
        "在{application}的法人证件一栏换传{expected_type}，核对所填证件类型与附件一致。",
        "核对材料后，重新提交申请。",
    ),
    guidance="打开已驳回的{application}，在法人证件一栏换传{expected_type}，核对类型后再重新提交。",
    action_terms=("法人证件", "法人身份证", "{submitted_type}"),
    conflicting_actions=(
        r"(?:继续|直接|仍然|还|就)(?:用|上传|提交)(?:这份|原来那份|原来的)?{submitted_type}",
        r"(?:改|修改|选|选择)(?:证件类型)?(?:成|为){submitted_type}",
        r"(?<!换)(?:不换|不用|无需|不上传)(?:法人的?)?{expected_type}",
    ),
    offer="请在{application}的法人证件一栏换传{expected_type}，核对类型和附件一致后重新提交。",
    material_title="法人证件",
    material_fields=(("expected_type", "本单要求的证件"), ("submitted_type", "已提交的证件")),
)


def authorization_party_pattern(name):
    # Merchants often omit company type when naming the parties from the order.
    match = re.fullmatch(r"(.+?)((?:品牌|商贸)公司)", name)
    if not match:
        return re.escape(name)
    short, suffix = map(re.escape, match.groups())
    return rf"(?:{short}{suffix}|{short}(?!品牌|商贸|公司|有限|集团|实业|科技|物流|工作室))"


def _reversed_chain_roles(text, upstream, downstream):
    receiver = rf"(?:{upstream}(?:是|作为)被授权(?:方|单位|人)|被授权(?:方|单位|人)(?:为|是|[:：]){upstream})"
    grantor = (
        rf"(?:{downstream}(?:是|作为)授权(?:方|单位|人)|授权(?:方|单位|人)(?:为|是|[:：]){downstream}"
        rf"|(?:开出|签发|出具)(?:这份|这张)?(?:授权书|文件)(?:的)?(?:为|是){downstream})"
    )
    join = r"[\s,，、。；;]*(?:而|而且|同时|并且)?"
    return bool(re.search(rf"{receiver}{join}{grantor}|{grantor}{join}{receiver}", text))


@dataclass(frozen=True)
class WorkOrder:
    case_id: str
    title: str
    procedure: Procedure
    source_row: int
    facts: dict[str, str]

    def __post_init__(self):
        if self.source_row not in self.procedure.source_areas:
            raise ValueError("工单来源行与业务场景不匹配。")

    @property
    def area(self):
        return self.procedure.source_areas[self.source_row]

    def render(self, text):
        application = {
            "品牌": "品牌申请单", "入驻": "入驻申请单", "商品资质": "商品申请单", "公司资质": "公司资质申请单",
        }[self.area]
        return text.format(application=application, **self.facts)

    def contradicts_action(self, text):
        pattern = authorization_party_pattern if self.procedure is CHAIN else re.escape
        escaped = {name: pattern(value) for name, value in self.facts.items()}
        return any(re.search(pattern.format_map(escaped), text) for pattern in self.procedure.conflicting_actions) or (
            self.procedure is CHAIN and _reversed_chain_roles(text, escaped["upstream"], escaped["downstream"])
        )

    @property
    def reason(self):
        return self.render(self.procedure.reason)

    @property
    def steps(self):
        return tuple(self.render(step) for step in self.procedure.steps)

    @property
    def guidance(self):
        return self.render(self.procedure.guidance)

    @property
    def evidence(self):
        main = f"[POP资审]资审关单场景话术V1.0.xlsx · 场景汇总!A{self.source_row}:E{self.source_row}"
        qa = self.procedure.qa_row
        return (main, f"驳回外呼QA.xlsx · 特殊场景!B{qa}:D{qa}") if qa is not None else (main,)

    @property
    def submitted_material(self):
        return {
            "title": self.procedure.material_title,
            "review_note": self.reason,
            "fields": [
                {"key": key, "label": label, "value": self.facts[key]}
                for key, label in self.procedure.material_fields
            ],
        }

    @property
    def submitted_authorization(self):
        material = {
            "title": "销售授权书",
            "grantor": "",
            "grantee": DEMO_MERCHANT_NAME,
            "scope": "",
            "seal": "",
            "review_note": self.reason,
        }
        if self.procedure is CATEGORY:
            material["scope"] = self.facts["authorized"]
        elif self.procedure is INCOMPLETE:
            material.update(grantor=self.facts["grantor"], seal=DEMO_MERCHANT_NAME)
        elif self.procedure is CHAIN:
            material.update(title="销售授权证明", grantor=self.facts["downstream"])
        return material


DEMO_MERCHANT_NAME = "小贝塔"
DEFAULT_CASE_ID = "JD-DEMO-001"
ORDERS = {
    order.case_id: order for order in (
        WorkOrder(DEFAULT_CASE_ID, "品牌新增申请", CATEGORY, 29, {"requested": "服装", "authorized": "鞋类"}),
        WorkOrder("JD-DEMO-002", "单品申请 · SKU-MOCK-002", INCOMPLETE, 79, {"grantor": "青禾品牌公司"}),
        WorkOrder("JD-DEMO-003", "商家入驻申请", CHAIN, 52, {"upstream": "云杉品牌公司", "downstream": "星桥商贸公司"}),
        WorkOrder("JD-DEMO-004", "品牌授权审核", AUTHORIZATION_EXPIRED, 21,
                  {"grantor": "海棠品牌公司", "expires_on": "2026年6月30日"}),
        WorkOrder("JD-DEMO-005", "公司资质审核", LEGAL_REPRESENTATIVE_DOCUMENT_TYPE, 76,
                  {"expected_type": "身份证", "submitted_type": "护照"}),
    )
}


def get_order(case_id):
    if not isinstance(case_id, str) or case_id not in ORDERS:
        raise ValueError("未找到所选模拟工单。")
    return ORDERS[case_id]


def list_cases():
    return [
        {
            "case_id": order.case_id, "scenario": order.procedure.scenario, "title": order.title,
            "area": order.area, "merchant_name": DEMO_MERCHANT_NAME,
            **({"submitted_material": order.submitted_material} if order.procedure.material_title
               else {"submitted_authorization": order.submitted_authorization}),
        }
        for order in ORDERS.values()
    ]
