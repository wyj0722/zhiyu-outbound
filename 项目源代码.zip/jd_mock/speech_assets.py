"""Install the pinned public models used by the local speech backend."""

import argparse
import hashlib
import shutil
import tarfile
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.request import Request, urlopen


DEFAULT_ASSET_DIR = Path(__file__).resolve().parent.parent / ".runtime" / "models"
RELEASE_ROOT = "https://github.com/k2-fsa/sherpa-onnx/releases/download"
SILERO_VAD_FILENAME = "silero_vad.onnx"
SILERO_VAD_SHA256 = "9e2449e1087496d8d4caba907f23e0bd3f78d91fa552479bb9c23ac09cbb1fd6"


@dataclass(frozen=True)
class ModelAsset:
    release: str
    name: str
    sha256: str
    required_files: tuple[tuple[str, int], ...]

    def is_installed(self, root: Path) -> bool:
        return all(
            (path := root / self.name / filename).is_file() and path.stat().st_size == size
            for filename, size in self.required_files
        )


ASR = ModelAsset(
    "asr-models",
    "sherpa-onnx-streaming-zipformer-small-ctc-zh-int8-2025-04-01",
    "b3b309f7ce4a737195fcc6963ea19b0653a7d3401580af5ae0d3e284cbb71f0b",
    (("model.int8.onnx", 26_342_340), ("tokens.txt", 13_366)),
)

# SenseVoiceSmall by FunAudioLLM, converted to ONNX by sherpa-onnx.
# Original weights: https://huggingface.co/FunAudioLLM/SenseVoiceSmall
# Weight license: https://github.com/modelscope/FunASR/blob/main/MODEL_LICENSE
STAMP_ASR = ModelAsset(
    "asr-models",
    "sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17",
    "7d1efa2138a65b0b488df37f8b89e3d91a60676e416f515b952358d83dfd347e",
    (("model.int8.onnx", 239_233_841), ("tokens.txt", 315_894)),
)

TTS = ModelAsset(
    "tts-models",
    "vits-melo-tts-zh_en",
    "e58351ed7149f290a54534538badd4077cdbe6fddc964b24d0bee870415d1514",
    (
        ("model.onnx", 170_429_550),
        ("tokens.txt", 655),
        ("lexicon.txt", 6_837_671),
        ("date.fst", 59_154),
        ("phone.fst", 88_630),
        ("number.fst", 64_482),
    ),
)


def install_model(root: Path, model: ModelAsset) -> None:
    if model.is_installed(root):
        print(f"Ready: {model.name}", flush=True)
        return

    root.mkdir(parents=True, exist_ok=True)
    destination = root / model.name
    archive_name = f"{model.name}.tar.bz2"
    cached_archive = root / archive_name
    with TemporaryDirectory(prefix="model-install-", dir=root) as temporary:
        staging = Path(temporary)
        archive = cached_archive
        if not archive.is_file():
            archive = staging / archive_name
            url = f"{RELEASE_ROOT}/{model.release}/{archive_name}"
            print(f"Downloading {model.name} ...", flush=True)
            request = Request(url, headers={"User-Agent": "jd-mock-model-bootstrap/1.0"})
            with urlopen(request, timeout=90) as response, archive.open("wb") as output:
                shutil.copyfileobj(response, output, length=1024 * 1024)

        with archive.open("rb") as source:
            digest = hashlib.file_digest(source, "sha256").hexdigest()
        if digest != model.sha256:
            raise ValueError(f"SHA-256 mismatch for {archive}. Expected {model.sha256}, got {digest}.")

        print(f"Extracting {model.name} ...", flush=True)
        with tarfile.open(archive, "r:bz2") as source:
            source.extractall(staging, filter="data")
        if not model.is_installed(staging):
            raise ValueError(f"The archive did not contain the expected files for {model.name}.")

        if model.is_installed(root):
            return
        if destination.exists():
            raise FileExistsError(f"Move the incomplete model directory {destination} and rerun setup.")
        (staging / model.name).rename(destination)
    print(f"Ready: {model.name}", flush=True)


def silero_vad_installed(root: Path) -> bool:
    path = root / SILERO_VAD_FILENAME
    if not path.is_file():
        return False
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest() == SILERO_VAD_SHA256


def install_silero_vad(root: Path) -> None:
    if not silero_vad_installed(root):
        root.mkdir(parents=True, exist_ok=True)
        with TemporaryDirectory(prefix="vad-install-", dir=root) as temporary:
            staged = Path(temporary) / SILERO_VAD_FILENAME
            url = f"{RELEASE_ROOT}/asr-models/{SILERO_VAD_FILENAME}"
            request = Request(url, headers={"User-Agent": "jd-mock-model-bootstrap/1.0"})
            with urlopen(request, timeout=90) as response, staged.open("wb") as output:
                shutil.copyfileobj(response, output, length=1024 * 1024)
            if not silero_vad_installed(staged.parent):
                raise ValueError("SHA-256 mismatch for Silero VAD.")
            staged.replace(root / SILERO_VAD_FILENAME)
    print(f"Ready: {SILERO_VAD_FILENAME}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--asset-dir", type=Path, default=DEFAULT_ASSET_DIR)
    parser.add_argument("--stamp-asr", action="store_true", help="Also install the SenseVoiceSmall stamp recognizer.")
    args = parser.parse_args()
    for model in (ASR, TTS):
        install_model(args.asset_dir, model)
    install_silero_vad(args.asset_dir)
    if args.stamp_asr:
        install_model(args.asset_dir, STAMP_ASR)


if __name__ == "__main__":
    main()
