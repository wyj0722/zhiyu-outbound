// Isolated browser acceptance for authorization expiry and legal ID type.
const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, readCall, waitForAutoClose } = require("./verify_browser.cjs");
const { start, play, json, hashSources } = require("./verify_workbench.cjs");

const root = path.resolve(__dirname, "..");
const timeout = 35_000;
const commitment = "您打算按这个办法处理吗？";
const newRecordings = ".runtime/additional-work-orders/fixtures";
const fixtures = {
  identity: ["tests/fixtures/merchant_identity/identity_yes.wav", "是的，我是商家小贝塔。"],
  consent: [".runtime/identity-v2-replay-fixtures/matrix_confirm_retry.wav", "我同意按步骤修改后重新提交。"],
  expiry_reason: [`${newRecordings}/expiry_reason.wav`, "这份授权书为什么被驳回？"],
  expiry_upload: [`${newRecordings}/expiry_upload.wav`, "新的销售授权书要上传到哪里？"],
  legal_reason: [`${newRecordings}/legal_reason.wav`, "为什么我上传的法人证件没有通过？"],
  legal_upload: [`${newRecordings}/legal_upload.wav`, "请问法人的身份证应该在哪里上传？"],
  reoffer: [`${newRecordings}/reoffer.wav`, "接下来我具体要怎么改？"],
};

const checks = {
  "JD-DEMO-004": {
    name: "授权时间到期", topic: "expiry", earlyConsent: true,
    reason: /2026年6月30日.*到期/,
    plan: /海棠品牌公司.*重开.*销售授权书.*重新提交/,
    upload: /品牌申请单.*销售授权书.*重新提交/,
    steps: /海棠品牌公司.*销售授权书.*重新提交/,
  },
  "JD-DEMO-005": {
    name: "法人证件类型", topic: "legal", simulateTimeout: true,
    reason: /法人.*身份证.*护照/,
    plan: /法人证件.*换传身份证.*重新提交/,
    upload: /法人证件.*换传身份证.*核对.*重新提交/,
    steps: /法人.*身份证.*重新提交/,
  },
};

function checkNoReceipt(snapshot) {
  assert.equal(snapshot.receipt_count, 0);
  assert.equal(snapshot.pending_writeback, false);
}

async function verify(page, call, settings) {
  const historyPath = `/api/cases/${call.case_id}/receipts`;
  assert.equal((await json(page, historyPath)).receipt_count, 0, "Use a fresh isolated acceptance database");
  await start(page, call, Boolean(settings.simulateTimeout));
  const identity = await play(page, call, "identity", "identity");
  assert.equal(identity.verified, true);
  assert.match(identity.reply, settings.reason);
  assert.match(identity.reply, settings.plan);
  assert.ok(identity.reply.endsWith(commitment));
  checkNoReceipt(identity);

  const reason = await play(page, call, `${settings.topic}_reason`, "asks_reason");
  assert.match(reason.reply, settings.reason);
  assert.equal(reason.dialogue_decision?.source, "model");
  assert.equal(reason.dialogue_decision?.applied_action, "reason");
  checkNoReceipt(reason);

  const upload = await play(page, call, `${settings.topic}_upload`, "asks_where_to_upload");
  assert.match(upload.reply, settings.upload);
  assert.equal(upload.dialogue_decision?.source, "model");
  assert.equal(upload.dialogue_decision?.applied_action, "upload");
  checkNoReceipt(upload);

  const offerMarker = await page.evaluate(() => window.jdAcceptance.trace.length);
  const offer = await play(page, call, "reoffer", "actionable_plan", { consumeReply: !settings.earlyConsent });
  assert.match(offer.reply, settings.plan);
  assert.ok(offer.reply.endsWith(commitment));
  checkNoReceipt(offer);

  if (settings.earlyConsent) await page.waitForTimeout(400);
  const confirmation = await play(page, call, "consent", "confirmed", {
    consumeReply: false,
    barge: Boolean(settings.earlyConsent),
  });
  assert.equal(confirmation.state, "complete");
  assert.equal(confirmation.receipt_count, 1);
  assert.equal(confirmation.pending_writeback, Boolean(settings.simulateTimeout));
  call.automatically_ended = await waitForAutoClose(page, timeout).then(() => true);

  if (settings.earlyConsent) {
    call.interruption = await page.evaluate((marker) => {
      const events = window.jdAcceptance.trace.slice(marker);
      const interruption = events.findIndex((event) => event.type === "interrupt");
      const offer = window.jdAcceptance.turns.find((turn) => turn.phase === "actionable_plan");
      const accepted = window.jdAcceptance.turns.find((turn) => turn.phase === "confirmed");
      return {
        before_plan_end: interruption >= 0 && !events.slice(0, interruption).some((event) => event.type === "plan-ready"),
        onset_after_first_audio_ms: Math.round((accepted.voiceStart - offer.firstAudioAt) * 1000),
      };
    }, offerMarker);
    assert.equal(call.interruption.before_plan_end, true);
    assert.ok(call.interruption.onset_after_first_audio_ms > 0);
    assert.equal(confirmation.dialogue_decision?.previous_plan_started, true);
    assert.equal(confirmation.dialogue_decision?.previous_plan_sent, false);
  }

  if (settings.simulateTimeout) {
    assert.equal((await json(page, historyPath)).receipt_count, 0, "Pending receipts stay hidden from order history");
    await page.locator("#retry-writeback").click({ timeout });
    await page.locator('#receipt-badge[data-status="saved"]').waitFor({ timeout });
  }
  const state = await readCall(page, call.call_id);
  assert.equal(state.receipt_count, 1);
  assert.equal(state.pending_writeback, false);
  const receipt = state.receipt;
  assert.equal(receipt.call_id, call.call_id);
  assert.equal(receipt.case_id, call.case_id);
  assert.equal(receipt.scenario, settings.name);
  assert.match(receipt.reason, settings.reason);
  assert.match(receipt.action_steps.join(" "), settings.steps);
  assert.equal(receipt.confirmation_text, call.turns.at(-1).transcript);
  const retryPath = `/api/calls/${call.call_id}/retry`;
  for (let attempt = 0; attempt < 2; attempt++) {
    const repeated = await json(page, retryPath, true);
    assert.equal(repeated.receipt_count, 1);
    assert.deepEqual(repeated.receipt, receipt);
  }
  const history = await json(page, historyPath);
  assert.equal(history.receipt_count, 1);
  assert.equal(history.latest_receipt.receipt_id, receipt.receipt_id);
  call.receipt = receipt;
  call.idempotent = true;
  call.passed = true;
}

async function main() {
  const [baseURL, output, caseId] = process.argv.slice(2);
  if (!baseURL || !output || fs.existsSync(output) || (caseId && !Object.hasOwn(checks, caseId))) {
    throw new Error("Usage: node tests/verify_additional_work_orders.cjs http://127.0.0.1:TEST_PORT NEW_RESULT.json [CASE_ID]");
  }
  const url = new URL(baseURL);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || Number(url.port) < 8800) {
    throw new Error("Use an isolated loopback WebRTC instance on port 8800 or higher.");
  }
  const recordings = Object.fromEntries(Object.entries(fixtures).map(([name, [file, phrase]]) => {
    const wav = fs.readFileSync(path.join(root, file));
    return [name, { file, phrase, sha256: createHash("sha256").update(wav).digest("hex"), encoded: wav.toString("base64") }];
  }));
  const report = {
    replay_suite: "additional-work-orders-v1", base_url: baseURL, started_at: new Date().toISOString(),
    fixtures: Object.fromEntries(Object.entries(recordings).map(([key, { encoded, ...evidence }]) => [key, evidence])),
    source_sha256: hashSources("tests/verify_additional_work_orders.cjs", "tests/make_additional_work_order_fixtures.py"),
    calls: [], passed: false,
  };
  const browser = await chromium.launch({ executablePath: browserPath, headless: true,
    args: ["--autoplay-policy=no-user-gesture-required"] });
  report.browser = browser.version();
  try {
    const page = await browser.newPage({ baseURL });
    await installFixtureMicrophone(page, recordings, { meterEnabled: true, measureReprompts: true });
    await page.goto("/");
    await page.locator('#health[data-health="ready"]').waitFor({ timeout });
    report.health = await json(page, "/api/health");
    assert.equal(report.health.llm_provider, "deepseek");
    assert.equal(report.health.voice_transport, "webrtc");
    assert.equal(report.health.stamp_warmup?.source, "model");
    for (const id of caseId ? [caseId] : Object.keys(checks)) {
      const call = { case_id: id, turns: [], passed: false };
      report.calls.push(call);
      try {
        assert.ok(report.health.dialogue_models?.[id]);
        await verify(page, call, checks[id]);
        console.log(id, "PASS", JSON.stringify(call.interruption || { idempotent: call.idempotent }));
      } catch (error) {
        call.error = error.message;
        if (call.call_id) {
          call.last_state = await readCall(page, call.call_id).catch(() => null);
          await json(page, `/api/calls/${call.call_id}/end`, true).catch(() => {});
        }
        console.error(id, error.message);
        await page.reload();
      }
    }
    report.passed = report.calls.every((call) => call.passed);
  } finally {
    report.ended_at = new Date().toISOString();
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
    await browser.close();
  }
  if (!report.passed) process.exitCode = 1;
}

main().catch((error) => { console.error(error.message); process.exitCode = 1; });
