// One fixed, repeatable browser WebRTC suite for all five model-enabled work orders.
const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, readCall, stats, waitForAutoClose } = require("./verify_browser.cjs");
const { start, play, json, hashSources, endViaButton } = require("./verify_workbench.cjs");

const root = path.resolve(__dirname, "..");
const timeout = Number(process.env.JD_WORKBENCH_TIMEOUT || 65_000);
const question = "您打算按这个办法处理吗？";
const matrix = ".runtime/identity-v2-replay-fixtures";
const additional = ".runtime/additional-work-orders/fixtures";
const fixtures = {
  identity: ["tests/fixtures/merchant_identity/identity_yes.wav", "是的，我是商家小贝塔。"],
  decline: [`${matrix}/matrix_negative.wav`, "我不确认，也不打算重新提交。"],
  submit: [`${matrix}/matrix_confirm_retry.wav`, "我同意按步骤修改后重新提交。"],
  category_interrupt: [".runtime/voice-fixtures/interrupt.wav", "等一下，鞋类在哪里选？"],
  category_offer: [".runtime/all-model-fixtures/keep_available.wav", "那我就只卖鞋类。"],
  stamp_info: [".runtime/stamp-llm-eval/wav/u02.wav", "刚翻到印文，印的是我们店铺登记的全名。"],
  stamp_interrupt: ["tests/fixtures/merchant_dialogue/review_outcome.wav", "盖好公章就一定能通过审核吗？"],
  stamp_submit: [".runtime/headset-method-replay/method-confirm.wav", "好的，我按这个方法来办。"],
  chain_interrupt: [".runtime/strategy-evolution/fixtures/review_after.wav", "补齐后就一定能过审吗？"],
  chain_offer: [".runtime/all-model-fixtures/next.wav", "接下来呢？"],
  expiry_upload: [`${additional}/expiry_upload.wav`, "新的销售授权书要上传到哪里？"],
  legal_upload: [`${additional}/legal_upload.wav`, "请问法人的身份证应该在哪里上传？"],
  reoffer: [`${additional}/reoffer.wav`, "接下来我具体要怎么改？"],
};

const cases = {
  "JD-DEMO-001": {
    name: "品牌类目不符", offer: "category_offer", beforeBarge: "category_offer",
    issue: /服装.*鞋类|鞋类.*服装/,
    interrupt: "category_interrupt", answer: /销售授权书|经营范围|授权类目/,
    steps: /(?:勾选|保留)鞋类.*(?:去掉|取消).*服装.*重新提交/,
  },
  "JD-DEMO-002": {
    name: "授权书内容不完整", offer: "stamp_info", beforeBarge: "stamp_info", submit: "stamp_submit",
    issue: /小贝塔.*青禾品牌公司.*公章/,
    interrupt: "stamp_interrupt", answer: /复审|审核.*(?:材料|结果)/,
    steps: /青禾品牌公司.*公章.*重新提交/,
  },
  "JD-DEMO-003": {
    name: "授权链路不完整", offer: "chain_offer",
    issue: /云杉品牌公司.*授权给.*星桥商贸公司/,
    interrupt: "chain_interrupt", answer: /复审|审核.*(?:材料|结果|核对)/,
    steps: /云杉品牌公司.*授权给.*星桥商贸公司.*重新提交/,
  },
  "JD-DEMO-004": {
    name: "授权时间到期", offer: "reoffer",
    issue: /2026年6月30日.*到期/,
    interrupt: "expiry_upload", answer: /品牌申请单.*销售授权书.*重新提交/,
    steps: /海棠品牌公司.*销售授权书.*重新提交/,
  },
  "JD-DEMO-005": {
    name: "法人证件类型", offer: "reoffer",
    issue: /法人.*身份证.*护照/,
    interrupt: "legal_upload", answer: /法人证件.*换传身份证.*重新提交/,
    steps: /法人证件.*换传身份证.*重新提交/,
  },
};

function checkNoReceipt(state) {
  assert.equal(state.receipt_count, 0);
  assert.equal(state.pending_writeback, false);
}

function checkPlan(state, settings) {
  assert.match(state.reply, settings.steps);
  assert.ok(state.reply.endsWith(question), "整改方案应以办理确认问题收尾");
  checkNoReceipt(state);
}

function historyPath(call) {
  return `/api/cases/${call.case_id}/receipts`;
}

function newCall(id, scenario, pathName) {
  const accept = pathName === "interrupt_and_retry";
  const plannedPhases = accept
    ? ["identity", ...(scenario.beforeBarge ? ["initial_plan"] : []), "interruption", "continued_plan", "confirmation"]
    : ["identity", ...(id === "JD-DEMO-001" ? ["initial_plan"] : []), "declines_current_plan"];
  return {
    case_id: id, name: scenario.name, path: pathName, planned_phases: plannedPhases,
    turns: [], checks: {}, passed: false,
  };
}

async function verify(page, call, scenario) {
  const accept = call.path === "interrupt_and_retry";
  call.stage = "opening";
  const before = await json(page, historyPath(call));
  await start(page, call, accept);
  call.stage = "identity";
  const interruptIdentity = accept && !scenario.beforeBarge;
  const identity = await play(page, call, "identity", "identity", { consumeReply: !interruptIdentity });
  assert.equal(identity.verified, true);
  assert.match(identity.reply, scenario.issue);
  checkNoReceipt(identity);
  call.checks.identity = true;

  call.stage = "initial_plan";
  if (accept && scenario.beforeBarge) {
    const plan = await play(page, call, scenario.beforeBarge, "initial_plan", { consumeReply: false });
    checkPlan(plan, scenario);
  } else if (!accept && call.case_id === "JD-DEMO-001") {
    const plan = await play(page, call, scenario.offer, "initial_plan");
    checkPlan(plan, scenario);
  } else {
    checkPlan(identity, scenario);
  }

  if (!accept) {
    call.stage = "declines_current_plan";
    const refused = await play(page, call, "decline", "declines_current_plan", { consumeReply: false });
    checkNoReceipt(refused);
    const transcript = call.turns.at(-1).transcript || "";
    assert.match(transcript, /不确认|不打算|不提交|不想|先不|暂不/, "实际转写必须保留拒绝语义");
    assert.equal(await page.locator("#retry-writeback").isVisible(), false);
    if (refused.state === "closed") await waitForAutoClose(page, timeout);
    else await endViaButton(page, call);
    const terminal = await readCall(page, call.call_id);
    call.terminal_state = terminal.state;
    assert.equal(terminal.state, "closed");
    checkNoReceipt(terminal);
    const after = await json(page, historyPath(call));
    assert.equal(after.receipt_count, before.receipt_count);
    call.checks.refusal_without_receipt = true;
    return;
  }

  call.stage = "interruption";
  const answer = await play(page, call, scenario.interrupt, "interruption", { barge: true });
  assert.match(answer.reply, scenario.answer);
  checkNoReceipt(answer);
  call.checks.interruption = true;

  call.stage = "continued_plan";
  const plan = await play(page, call, scenario.offer, "continued_plan");
  checkPlan(plan, scenario);
  call.checks.continued_plan = true;

  call.stage = "confirmation";
  const confirmed = await play(page, call, scenario.submit || "submit", "confirmation", { consumeReply: false });
  assert.equal(confirmed.state, "complete");
  assert.equal(confirmed.pending_writeback, true);
  assert.equal(confirmed.receipt_count, 1);
  assert.equal(confirmed.receipt, null);
  assert.equal((await json(page, historyPath(call))).receipt_count, before.receipt_count);
  await waitForAutoClose(page, timeout);
  call.checks.confirmed_and_pending = true;

  call.stage = "receipt_retry";
  await page.locator("#retry-writeback").click({ timeout });
  await page.locator('#receipt-badge[data-status="saved"]').waitFor({ timeout });
  const saved = await readCall(page, call.call_id);
  const receipt = saved.receipt;
  assert.equal(saved.receipt_count, 1);
  assert.equal(saved.pending_writeback, false);
  assert.equal(receipt.call_id, call.call_id);
  assert.equal(receipt.case_id, call.case_id);
  assert.equal(receipt.scenario, scenario.name);
  assert.equal(receipt.verified, true);
  assert.equal(receipt.confirmation_text, call.turns.at(-1).transcript);
  assert.match(receipt.action_steps.join(" "), scenario.steps);
  const retryIds = [];
  for (let attempt = 0; attempt < 2; attempt++) {
    const repeated = await json(page, `/api/calls/${call.call_id}/retry`, true);
    assert.equal(repeated.receipt_count, 1);
    assert.deepEqual(repeated.receipt, receipt);
    retryIds.push(repeated.receipt.receipt_id);
  }
  const after = await json(page, historyPath(call));
  assert.equal(after.receipt_count, before.receipt_count + 1);
  assert.equal(after.latest_receipt.receipt_id, receipt.receipt_id);
  call.receipt = receipt;
  call.retry_receipt_ids = retryIds;
  call.checks.idempotent_retry = true;
  assert.ok(call.turns.length >= 3, "有效的实时语音来回轮次少于三轮");
}

function summarize(calls) {
  const planned = calls.flatMap((call) => call.planned_phases.filter((phase) => phase !== "identity")).length;
  const business = calls.flatMap((call) => call.turns.filter((turn) => turn.phase !== "identity"));
  return {
    first_audio_ms: stats(business.map((turn) => turn.browser_first_audio_ms), planned),
    identity_first_audio_ms: stats(calls.flatMap((call) => call.turns.filter((turn) => turn.phase === "identity")
      .map((turn) => turn.browser_first_audio_ms)), calls.length),
  };
}

async function main() {
  const [baseURL, output, frozenWavs] = process.argv.slice(2);
  const url = new URL(baseURL || "http://127.0.0.1");
  if (!output || fs.existsSync(output) || url.protocol !== "http:" || url.hostname !== "127.0.0.1"
      || Number(url.port) < 8800 || url.pathname !== "/" || url.username || url.password || url.search || url.hash) {
    throw new Error("Usage: node tests/verify_five_work_orders.cjs http://127.0.0.1:TEST_PORT NEW_RESULT.json [FROZEN_WAVS_DIR] (port >= 8800)");
  }
  const recordings = Object.fromEntries(Object.entries(fixtures).map(([key, [source, phrase]]) => {
    const file = frozenWavs ? path.join(frozenWavs, `${key}.wav`) : source;
    const wav = fs.readFileSync(path.resolve(root, file));
    return [key, { file, phrase, sha256: createHash("sha256").update(wav).digest("hex"), encoded: wav.toString("base64") }];
  }));
  const calls = Object.entries(cases).flatMap(([id, scenario]) =>
    ["refusal", "interrupt_and_retry"].map((name) => newCall(id, scenario, name)));
  const report = {
    replay_suite: "five-work-orders-webrtc-v1", base_url: baseURL, started_at: new Date().toISOString(),
    input: "固定合成普通话 WAV 注入真实浏览器 WebRTC 麦克风音轨。本地语音模型、DeepSeek 和独立 SQLite。",
    latency_definition: "从商家 WAV 最后一个有声窗口结束到浏览器 WebRTC 下行首个可听音频窗口。毫秒，线性分位数，业务轮另列身份轮。",
    fixtures: Object.fromEntries(Object.entries(recordings).map(([key, { encoded, ...evidence }]) => [key, evidence])),
    source_sha256: hashSources("tests/verify_five_work_orders.cjs"),
    calls, passed: false,
  };
  let browser;
  try {
    browser = await chromium.launch({ executablePath: browserPath, headless: true,
      args: ["--autoplay-policy=no-user-gesture-required"] });
    report.browser = browser.version();
    const page = await browser.newPage({ baseURL });
    await installFixtureMicrophone(page, recordings, { meterEnabled: true, measureReprompts: true });
    await page.goto("/");
    await page.locator('#health[data-health="ready"]').waitFor({ timeout });
    report.health = await json(page, "/api/health");
    assert.equal(report.health.llm_provider, "deepseek");
    assert.equal(report.health.voice_transport, "webrtc");
    assert.equal(report.health.speech_ready, true);
    report.active_strategy_count = (await json(page, "/api/strategies")).strategies.length;
    for (const id of Object.keys(cases)) {
      assert.ok(report.health.dialogue_models?.[id], `${id} 未配置对话模型`);
      assert.equal((await json(page, `/api/cases/${id}/receipts`)).receipt_count, 0, "必须使用空回执的隔离库");
    }
    for (const call of calls) {
      try {
        await verify(page, call, cases[call.case_id]);
        call.stage = "complete";
        call.passed = true;
        console.log(call.case_id, call.path, "PASS");
      } catch (error) {
        call.error = error.message;
        if (call.call_id) {
          call.last_state = await readCall(page, call.call_id).catch(() => null);
          await json(page, `/api/calls/${call.call_id}/end`, true).catch(() => {});
        }
        console.error(call.case_id, call.path, call.stage, error.message);
        await page.reload();
      }
    }
    report.passed = calls.every((call) => call.passed);
  } catch (error) {
    report.error = error.message;
    throw error;
  } finally {
    Object.assign(report, summarize(calls));
    report.per_case = Object.fromEntries(Object.keys(cases).map((id) => [id, summarize(calls.filter((call) => call.case_id === id))]));
    report.ended_at = new Date().toISOString();
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
    await browser?.close();
  }
  if (!report.passed) process.exitCode = 1;
}

main().catch((error) => { console.error(error.message); process.exitCode = 1; });
