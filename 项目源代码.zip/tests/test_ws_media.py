import asyncio
import json
import time
import unittest
from unittest.mock import AsyncMock, Mock, call, patch

import numpy as np
from aiortc import MediaStreamError

from jd_mock.cases import get_order
from jd_mock.dialogue import chain_confirmation
from jd_mock.media import OUTPUT_FRAME, OUTPUT_RATE, ReplyTrack, reply_sentences
from jd_mock.vad import Detection
from jd_mock.ws_media import PCM_BURST_FRAMES, PCM_BYTES, PCM_FRAME, PCM_RATE, SocketCallMedia, _SocketInput


class SocketStub:
    def __init__(self):
        self.input = asyncio.Queue()
        self.output = []
        self.close_code = None

    async def receive(self):
        return await self.input.get()

    async def send_bytes(self, data):
        self.output.append(data)

    async def send_text(self, data):
        self.output.append(json.loads(data))

    async def close(self, code=1000):
        self.close_code = code


class SocketCallMediaTests(unittest.IsolatedAsyncioTestCase):
    async def wait_for(self, condition):
        async with asyncio.timeout(2):
            while not condition():
                await asyncio.sleep(0.005)

    def make_media(self, reply, focus="confirm"):
        self.engine = Mock(vad_backend="energy", stamp_asr_ready=False)
        self.vad = self.engine.new_vad.return_value
        self.vad.frame_size = 320
        self.vad.push.return_value = Detection()
        store = Mock()
        store.get_call.return_value = {
            "case_id": "JD-DEMO-003", "scenario": "授权链路不完整", "state": "explain",
            "verified": True, "dialogue_focus": focus, "reply": reply,
        }
        audio = np.full(OUTPUT_FRAME, 0.25, np.float32)
        self.on_close = Mock()
        return SocketCallMedia(store, self.engine, "mock-call", False, self.on_close,
                               {sentence: (audio, OUTPUT_RATE) for sentence in reply_sentences(reply)})

    async def test_action_frame_marker_and_client_ack_guard(self):
        reply, focus = chain_confirmation(get_order("JD-DEMO-003"), include_submitted=True)
        media = self.make_media(reply, focus)
        socket = SocketStub()
        running = asyncio.create_task(media.run(socket))
        try:
            await self.wait_for(lambda: any(isinstance(item, dict) and item.get("type") == "plan-start"
                                            for item in socket.output))
            mark = next(index for index, item in enumerate(socket.output)
                        if isinstance(item, dict) and item.get("type") == "plan-start")
            await self.wait_for(lambda: len(socket.output) > mark + 1)
            token = socket.output[mark]["token"]
            self.assertTrue(any(isinstance(item, bytes) for item in socket.output[:mark]))
            self.assertIsInstance(socket.output[mark + 1], bytes)
            self.assertEqual(len(socket.output[mark + 1]), 640)
            before_ack = time.monotonic()
            self.assertEqual(media._playback_at_onset(before_ack), ("", ""))

            socket.input.put_nowait({"type": "websocket.receive", "text": json.dumps({"type": "plan-started", "token": token})})
            await self.wait_for(lambda: media._playback_at_onset(time.monotonic())[1] == reply)
            self.assertEqual(media._playback_at_onset(before_ack), ("", ""))
            media._cancel_reply()
            socket.input.put_nowait({"type": "websocket.receive", "text": json.dumps({"type": "plan-started", "token": token})})
            await asyncio.sleep(0.05)
            self.assertEqual(media._playback_at_onset(time.monotonic()), ("", ""))

            silence = bytes(PCM_BYTES)
            for _ in range(3):
                socket.input.put_nowait({"type": "websocket.receive", "bytes": silence})
            await self.wait_for(lambda: self.vad.push.called)
            self.assertEqual(self.vad.push.call_args.args[0].shape, (320,))
        finally:
            socket.input.put_nowait({"type": "websocket.disconnect", "code": 1000})
            await asyncio.wait_for(running, 2)
        self.on_close.assert_called_once_with(media)

    async def test_rejects_audio_frames_of_the_wrong_size_and_releases_call(self):
        media = self.make_media("您好。")
        socket = SocketStub()
        socket.input.put_nowait({"type": "websocket.receive", "bytes": b"invalid"})
        await asyncio.wait_for(media.run(socket), 2)
        self.assertEqual(socket.close_code, 1003)
        self.assertFalse(self.vad.push.called)
        self.on_close.assert_called_once_with(media)

    async def test_accepts_batched_audio_but_limits_excessive_input(self):
        socket = SocketStub()
        silence = bytes(PCM_BYTES)
        for _ in range(PCM_BURST_FRAMES + 1):
            socket.input.put_nowait({"type": "websocket.receive", "bytes": silence})
        with patch("jd_mock.ws_media.time.monotonic", return_value=1):
            source = _SocketInput(socket, Mock())
            for _ in range(PCM_BURST_FRAMES):
                frame = await source.recv()
                self.assertEqual((frame.sample_rate, frame.samples), (16_000, 320))
            with self.assertRaises(MediaStreamError):
                await source.recv()
        self.assertEqual(source.close_code, 1008)

    async def test_interrupt_drops_stale_pcm_without_reordering_control(self):
        media = self.make_media("您好。")
        socket = SocketStub()
        stale = bytes(PCM_BYTES)
        next_reply = b"\x01\x00" * PCM_FRAME
        media._enqueue(stale, media._reply_epoch)
        media._cancel_reply()
        media.send("interrupt")
        media._enqueue(next_reply, media._reply_epoch)
        writing = asyncio.create_task(media._write(socket))
        try:
            await self.wait_for(lambda: len(socket.output) >= 2)
            self.assertEqual(socket.output, [{"type": "interrupt"}, next_reply])
        finally:
            writing.cancel()
            await asyncio.gather(writing, return_exceptions=True)

    async def test_local_reply_track_keeps_48khz_20ms_frames(self):
        local = ReplyTrack(Mock())
        local.append(np.full(PCM_FRAME, 0.25, np.float32), PCM_RATE)
        first = await local.recv()
        second = await local.recv()
        self.assertEqual((first.sample_rate, first.samples, second.pts), (48_000, 960, 960))

    async def test_audio_waits_for_the_writer_and_rebases_its_clock(self):
        media = self.make_media("您好。")
        socket = SocketStub()
        media.output = Mock()
        reading = asyncio.Event()

        async def read_frame():
            reading.set()
            await asyncio.Future()

        media.output.recv = AsyncMock(side_effect=read_frame)
        for _ in range(media._write_queue.maxsize // 2):
            media.send("state", state="speaking")
        tasks = [asyncio.create_task(media._pump_audio())]
        try:
            await asyncio.sleep(0)
            self.assertFalse(reading.is_set())
            tasks.append(asyncio.create_task(media._write(socket)))
            await asyncio.wait_for(reading.wait(), 2)
            self.assertEqual(media.output.mock_calls[:2], [call.resync_clock(), call.recv()])
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
