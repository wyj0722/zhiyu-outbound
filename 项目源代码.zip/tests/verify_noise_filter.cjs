// WebRTC noise rejection and barge-in with a measured noisy consent recording.
const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, readCall, waitForAutoClose } = require("./verify_browser.cjs");
const { start, play, readyForNextTurn, json, checkProvider, hashSources } = require("./verify_workbench.cjs");

const root = path.resolve(__dirname, "..");
const fixtureDirectory = path.join(root, ".runtime/noise-verification/fixtures");
const caseId = "JD-DEMO-001";
const receiptPath = `/api/cases/${caseId}/receipts`;
const fixtures = {
  identity: "tests/fixtures/merchant_dialogue/recipient_repeat.wav",
  requested: ".runtime/consent-loop/fixtures/requested.wav",
  obtained: ".runtime/consent-loop/fixtures/obtained.wav",
  fan_keyboard: ".runtime/noise-verification/fixtures/fan_keyboard.wav",
  noisy_yes: ".runtime/noise-verification/fixtures/noisy_yes.wav",
};

async function noiseProbe(page, report, phase, expectedState) {
  const fixture = "fan_keyboard";
  const before = await readCall(page, report.call.call_id);
  const state = await page.locator("#rail-indicator").getAttribute("data-state");
  assert.equal(state, expectedState, `${phase} must start in ${expectedState}`);
  const [traceStart, samplesStart] = await page.evaluate(([name, phase]) => {
    const meter = window.jdAcceptance;
    const start = [meter.trace.length, meter.audioChecks.length];
    meter.play(name, phase);
    return start;
  }, [fixture, phase]);
  await (await page.waitForFunction(({ name, start, lastMs }) => window.jdAcceptance.audioChecks.slice(start)
    .some(sample => sample.fixture === name && sample.elapsed >= lastMs),
  { name: fixture, start: samplesStart, lastMs: report.fixture_manifest.fixtures[fixture].duration_seconds * 1000 },
  { timeout: 12_000 })).dispose();
  const evidence = await page.evaluate(({ traceStart, samplesStart, fixture }) => {
    const events = window.jdAcceptance.trace.slice(traceStart);
    const samples = window.jdAcceptance.audioChecks.slice(samplesStart).filter(item => item.fixture === fixture);
    return { events, samples };
  }, { traceStart, samplesStart, fixture });
  const after = await readCall(page, report.call.call_id);
  const sent = evidence.samples.at(-1).packets - evidence.samples[0].packets;
  const energy = evidence.samples.at(-1).audioEnergy - evidence.samples[0].audioEnergy;
  const unwanted = evidence.events.filter(event => ["interrupt", "transcript", "update", "error"].includes(event.type)
    || (event.type === "playback-mute" && event.muted)
    || (event.type === "state" && (event.state === "processing" ||
      (expectedState === "listening" && event.state === "speaking"))));
  report.noise_probes.push({
    phase, fixture, started_during: state, packets_sent: sent, media_source_energy_delta: energy,
    observed_events: evidence.events.map(event => event.state || event.type), unexpected_events: unwanted,
    turn_count_before: before.turn_count, turn_count_after: after.turn_count,
    receipt_count_before: before.receipt_count, receipt_count_after: after.receipt_count,
  });
  assert.ok(sent > 20 && energy > 0.0001, `${phase}: the non-speech recording must traverse the real audio track`);
  assert.deepEqual(unwanted, [], `${phase}: a non-speech recording must not interrupt, transcribe or update`);
  assert.equal(after.turn_count, before.turn_count, phase);
  assert.equal(after.receipt_count, 0, phase);
}

async function verify(page, report) {
  const call = report.call;
  const expectedHistory = Number(process.env.JD_NOISE_EXPECT_EXISTING_RECEIPTS || 0);
  assert.ok(Number.isSafeInteger(expectedHistory) && expectedHistory >= 0);
  const priorReceipts = (await json(page, receiptPath)).receipt_count;
  assert.equal(priorReceipts, expectedHistory, "Use an isolated acceptance database with the expected history");
  report.prior_case_receipts = priorReceipts;
  await start(page, call, false);
  await noiseProbe(page, report, "noise_while_listening", "listening");
  assert.equal((await play(page, call, "identity", "identity")).verified, true);
  const questionStart = await page.evaluate(() => window.jdAcceptance.trace.length);
  const asked = await play(page, call, "requested", "requests_additional_category", { consumeReply: false });
  assert.match(asked.reply, /覆盖服装.*手头有这份文件吗/);
  // Finish the non-speech exposure on the preceding question, leaving time
  // to deliver the noisy consent while the subsequent plan is still early.
  await noiseProbe(page, report, "noise_while_question_speaks", "speaking");
  await readyForNextTurn(page, questionStart);
  const offerStart = await page.evaluate(() => window.jdAcceptance.trace.length);
  const offer = await play(page, call, "obtained", "offers_upload", { consumeReply: false });
  assert.match(offer.reply, /上传.*重新提交.*您打算按这个办法处理吗？$/);
  assert.equal(offer.receipt_count, 0);
  assert.equal(await page.locator("#rail-indicator").getAttribute("data-state"), "speaking");

  const confirmed = await play(page, call, "noisy_yes", "noisy_voice_interrupts", { consumeReply: false, barge: true });
  const consent = call.turns.at(-1);
  assert.match(consent.transcript, /好/);
  assert.equal(confirmed.state, "complete");
  assert.equal(confirmed.receipt_count, 1);
  assert.equal(confirmed.pending_writeback, false);
  const boundary = await page.evaluate(start => {
    const events = window.jdAcceptance.trace.slice(start);
    const barge = events.findIndex(event => event.type === "interrupt");
    return barge >= 0 && !events.slice(0, barge).some(event => event.type === "plan-ready");
  }, offerStart);
  const noisyFixture = report.fixture_manifest.fixtures.noisy_yes;
  const muteFromFixtureStart = consent.barge_to_mute_ms + noisyFixture.voice_bounds_seconds[0] * 1000;
  const beforeVoice = muteFromFixtureStart < noisyFixture.noise_only_prefix_seconds * 1000;
  const tailMs = noisyFixture.trailing_noise_seconds * 1000;
  report.noisy_consent = { before_plan_boundary: boundary, transcript: consent.transcript,
    barge_to_mute_ms: consent.barge_to_mute_ms, browser_first_audio_ms: consent.browser_first_audio_ms,
    mute_from_fixture_start_ms: Math.round(muteFromFixtureStart * 10) / 10, mute_before_possible_voice: beforeVoice,
    response_started_while_noise_continued: Number.isFinite(consent.browser_first_audio_ms) && consent.browser_first_audio_ms < tailMs };
  await waitForAutoClose(page);
  call.automatically_ended = true;
  const saved = await readCall(page, call.call_id);
  assert.deepEqual((await json(page, `/api/calls/${call.call_id}/retry`, true)).receipt, saved.receipt);
  const history = await json(page, receiptPath);
  assert.equal(history.receipt_count, priorReceipts + 1);
  assert.equal(history.latest_receipt.case_id, caseId);
  assert.equal(history.latest_receipt.call_id, call.call_id);
  call.receipt = history.latest_receipt;
  assert.equal(boundary, true, "The consent must cut in before the actionable plan finishes");
  assert.equal(confirmed.dialogue_decision?.previous_plan_started, true);
  assert.equal(confirmed.dialogue_decision?.previous_plan_sent, false);
  assert.ok(Number.isFinite(noisyFixture.noise_only_prefix_seconds), "Regenerate the noise fixture manifest");
  assert.equal(beforeVoice, false, "Playback must not mute during the noise-only prefix of the consent fixture");
  report.passed = true;
}

async function main() {
  const [baseURL, output] = process.argv.slice(2);
  if (!baseURL || !output || fs.existsSync(output)) {
    throw new Error("Usage: node tests/verify_noise_filter.cjs http://127.0.0.1:TEST_PORT NEW_RESULT.json");
  }
  const url = new URL(baseURL);
  assert.ok(url.protocol === "http:" && url.hostname === "127.0.0.1" && url.port && url.port !== "8779",
    "Use an isolated loopback service with an empty database");
  const fixture_manifest = JSON.parse(fs.readFileSync(path.join(fixtureDirectory, "manifest.json"), "utf8"));
  assert.equal(fixture_manifest.fixtures.fan_keyboard.exceeds_old_gate_for_60ms, true);
  const recordings = Object.fromEntries(Object.entries(fixtures).map(([name, file]) => {
    const wav = fs.readFileSync(path.join(root, file));
    const sha256 = createHash("sha256").update(wav).digest("hex");
    const manifest = fixture_manifest.fixtures[name];
    if (manifest) assert.equal(sha256, manifest.sha256, file + " does not match its manifest");
    return [name, { file, encoded: wav.toString("base64"), sha256, voiceBounds: manifest?.voice_bounds_seconds }];
  }));
  const report = {
    base_url: baseURL, started_at: new Date().toISOString(), fixture_manifest,
    fixtures: Object.fromEntries(Object.entries(recordings).map(([name, { encoded, ...meta }]) => [name, meta])),
    source_sha256: hashSources("tests/verify_noise_filter.cjs", "tests/make_noise_fixtures.py"),
    call: { case_id: caseId, turns: [] }, noise_probes: [], passed: false,
  };
  const browser = await chromium.launch({ executablePath: browserPath, headless: true,
    args: ["--autoplay-policy=no-user-gesture-required"] });
  report.browser = browser.version();
  const page = await browser.newPage({ baseURL });
  try {
    report.health = await json(page, "/api/health");
    checkProvider(report.health);
    assert.equal(report.health.speech_ready, true);
    const expectedVAD = process.env.JD_NOISE_EXPECT_VAD;
    if (expectedVAD) assert.equal(report.health.vad_backend, expectedVAD);
    await installFixtureMicrophone(page, recordings, { meterEnabled: true, measureReprompts: true });
    await page.goto("/");
    await page.locator('#health[data-health="ready"]').waitFor();
    await verify(page, report);
    console.log("noise rejection and noisy consent PASS");
  } catch (error) {
    report.error = error.message;
    if (report.call.call_id) await json(page, `/api/calls/${report.call.call_id}/end`, true).catch(() => {});
    throw error;
  } finally {
    report.ended_at = new Date().toISOString();
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
