"""Paired oracle-transcript diagnostic. The store receives utterances only, never grading labels."""

import argparse
import hashlib
import importlib
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("directory", type=Path)
    parser.add_argument("database", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("--agent-module", help="Module exporting StampAgent.from_env for the candidate")
    args = parser.parse_args()
    if args.database.exists() or args.report.exists():
        raise ValueError("Use new and distinct database and report paths")
    seal = hashlib.sha256((args.directory / "sealed.json").read_bytes()).hexdigest()
    if seal != (args.directory / "seal.sha256").read_text("utf-8").strip():
        raise ValueError("Test manifest differs from its seal")
    manifest = json.loads((args.directory / "sealed.json").read_text("utf-8"))
    sys.path.insert(0, str(args.source.resolve()))
    from jd_mock.business import Store
    opts = {}
    if args.agent_module:
        opts["stamp_agent"] = importlib.import_module(args.agent_module).StampAgent.from_env()
        if opts["stamp_agent"] is None:
            raise ValueError("Candidate model is not configured")
    store = Store(args.database, **opts)
    report = {"mode":"oracle_text", "started_at":now(), "seal_sha256":seal, "episodes":[]}
    for episode in manifest["episodes"]:
        call = store.start_call(manifest["order"])
        call_id = call["call_id"]
        result = {"id":episode["id"], "call_id":call_id, "turns":[]}
        report["episodes"].append(result)
        try:
            identity = store.turn(call_id, "是的，我是本人", uuid.uuid4().hex)
            if not identity["verified"]:
                raise ValueError("Text identity control failed")
            for t in episode["turns"]:
                response = store.turn(call_id, t["say"], uuid.uuid4().hex)
                result["turns"].append({"id":t["id"], "transcript":t["say"], "reply":response["reply"],
                                        "receipt_count":response["receipt_count"], "state":response["state"],
                                        "stamp_decision":response.get("stamp_decision")})
                if response["state"] in {"closed","complete"}:
                    break
        finally:
            result["final_state"] = store.end_call(call_id)
        print(episode["id"], len(result["turns"]), "of", len(episode["turns"]), flush=True)
    report["ended_at"] = now()
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
