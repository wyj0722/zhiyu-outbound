"""Create fixed synthetic audio for the category consent-loop regression."""

import argparse
import wave
from pathlib import Path

import numpy as np

from jd_mock.speech import SpeechEngine
from jd_mock.speech_assets import DEFAULT_ASSET_DIR


PHRASES = {
    "requested": "我还想卖服装。",
    "missing": "目前还没有。",
    "obtained": "我现在已经拿到授权书了。",
    "review": "补完以后，就一定能通过审核吗？",
    "resume": "那接下来怎么办？",
    "yes": "好的。",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(".runtime/consent-loop/fixtures"))
    parser.add_argument("--only", nargs="+", choices=PHRASES)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    engine = SpeechEngine(DEFAULT_ASSET_DIR)
    for key in args.only or PHRASES:
        audio, rate = engine.synthesize(PHRASES[key])
        samples = (np.clip(audio, -1, 1) * 32767).astype("<i2")
        with wave.open(str(args.output / f"{key}.wav"), "wb") as stream:
            stream.setparams((1, 2, rate, 0, "NONE", "not compressed"))
            stream.writeframes(samples.tobytes())


if __name__ == "__main__":
    main()
