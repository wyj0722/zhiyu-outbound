// Additional WebRTC regression on synthetic, previously seen speech.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, waitForReplyToFinish, readCall, selectWorkOrder, milliseconds } = require("./verify_browser.cjs");

async function main() {
  const [url, ownerWav, output] = process.argv.slice(2);
  if (!url || !ownerWav || !output || fs.existsSync(output)) {
    throw new Error("Supply a test-workbench URL, a merchant-owned stamp WAV, and a new result path");
  }
  const fixtures = {
    identity: "tests/fixtures/merchant_dialogue/recipient_repeat.wav",
    owner: ownerWav,
    interrupt: "tests/fixtures/merchant_dialogue/review_outcome.wav",
    ack: "tests/fixtures/merchant_dialogue/stamp_ack.wav",
    confirm: ".runtime/identity-v2-matrix-fixtures/matrix_confirm_retry.wav",
  };
  const bytes = Object.fromEntries(Object.entries(fixtures).map(([name, file]) =>
    [name, { encoded: fs.readFileSync(path.resolve(file)).toString("base64") }]));
  const browser = await chromium.launch({ executablePath: browserPath, headless: true,
    args: ["--autoplay-policy=no-user-gesture-required"] });
  const report = { url, passed: false, turns: [] };
  const page = await browser.newPage({ baseURL: url });
  try {
    await installFixtureMicrophone(page, bytes, { meterEnabled: true, measureReprompts: true });
    await page.goto("/");
    await selectWorkOrder(page, "JD-DEMO-002");
    await page.locator("#simulate-timeout").check();
    const created = page.waitForResponse(r => new URL(r.url()).pathname === "/api/calls" && r.ok());
    await page.locator("#start-call").click();
    report.call_id = (await (await created).json()).call_id;
    await waitForReplyToFinish(page, 0);

    async function say(name, phase = name, listenToEnd = true) {
      const marker = await page.evaluate(() => window.jdAcceptance.trace.length);
      await page.evaluate(([name, phase]) => window.jdAcceptance.play(name, phase), [name, phase]);
      await page.waitForFunction(index => window.jdAcceptance.trace.slice(index).some(e => e.type === "update"),
        marker, { timeout: 45000 });
      const turn = await readCall(page, report.call_id);
      const trace = turn.stamp_decision;
      report.turns.push({ phase, text: trace?.text, reply: turn.reply, state: turn.state,
        owner: trace?.owner, applied_action: trace?.applied_action, receipts: turn.receipt_count });
      if (listenToEnd) await waitForReplyToFinish(page, marker);
      return turn;
    }

    assert.ok((await say("identity")).verified);
    assert.equal((await say("owner", "first_owner", false)).receipt_count, 0);
    await page.waitForFunction(() => window.jdAcceptance.turns.some(t => t.phase === "first_owner" && t.firstAudioAt));
    const interrupted = await say("interrupt");
    assert.equal(interrupted.receipt_count, 0);
    assert.equal(interrupted.stamp_decision.applied_action, "review");
    const timing = await page.evaluate(() => window.jdAcceptance.turns.find(t => t.phase === "interrupt"));
    assert.ok(Number.isFinite(timing.mutedAt) && timing.quietAfterMute, "Interrupted audio must become quiet");
    report.barge_to_mute_ms = milliseconds(timing.voiceStart, timing.mutedAt);
    report.interrupt_count = Number(await page.locator("#interrupt-count").innerText());
    assert.ok(report.interrupt_count >= 1);
    const plan = await say("owner", "restated_owner", false);
    assert.equal(plan.stamp_decision.owner, "merchant");
    assert.equal(await page.locator("#stamp-owner").innerText(), "商家方");
    assert.equal(plan.receipt_count, 0);
    await page.waitForFunction(() => window.jdAcceptance.turns.some(t => t.phase === "restated_owner" && t.firstAudioAt));
    const earlyYes = await say("ack");
    assert.equal(earlyYes.receipt_count, 0);
    assert.equal(earlyYes.stamp_decision.previous_reply_sent_in_full, false);
    assert.equal(earlyYes.stamp_decision.applied_action, "request_stamp");
    assert.equal(earlyYes.reply, plan.reply);
    const pending = await say("confirm", "confirm", false);
    assert.ok(pending.pending_writeback);
    assert.equal(pending.receipt, null);
    await page.locator("#retry-writeback").click();
    await page.locator('#receipt-badge[data-status="saved"]').waitFor();
    const saved = await readCall(page, report.call_id);
    const again = await (await page.request.post("/api/calls/" + report.call_id + "/retry")).json();
    assert.equal(saved.receipt.case_id, "JD-DEMO-002");
    assert.equal(saved.receipt.call_id, report.call_id);
    assert.equal(again.receipt_count, 1);
    assert.deepEqual(again.receipt, saved.receipt);
    assert.ok((await page.locator("#receipt-fields").innerText()).includes(saved.receipt.confirmation_text));
    report.receipt = again.receipt;
    report.receipt_count = again.receipt_count;
    report.passed = true;
  } catch (error) {
    report.error = error.message;
    throw error;
  } finally {
    if (report.call_id) await page.request.post("/api/calls/" + report.call_id + "/end").catch(() => {});
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
