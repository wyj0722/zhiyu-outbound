from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import Mock
import wave

import numpy as np

from jd_mock.vad import SileroVoiceActivity, VoiceActivity


SILERO_MODEL = Path(__file__).resolve().parents[1] / ".runtime" / "models" / "silero_vad.onnx"


class VoiceActivityTest(unittest.TestCase):
    def setUp(self):
        self.vad = VoiceActivity()
        self.quiet = np.zeros(320, dtype=np.float32)
        self.voice = np.full(320, 0.1, dtype=np.float32)

    def test_single_loud_frame_does_not_interrupt(self):
        self.assertIsNone(self.vad.push(self.voice).audio)
        for _ in range(24):
            self.assertFalse(self.vad.push(self.quiet).started)

    def test_preserves_quiet_consonant_before_voice_onset(self):
        consonant = np.full(320, 0.003, dtype=np.float32)
        self.vad.push(consonant)
        for _ in range(8):
            self.vad.push(self.quiet)
        for _ in range(2):
            self.vad.push(self.voice)
        onset = self.vad.push(self.voice)
        np.testing.assert_array_equal(onset.audio[:320], consonant)

    def test_retains_onset_and_ends_after_silence(self):
        for _ in range(4):
            self.vad.push(self.quiet)
        for _ in range(2):
            self.assertFalse(self.vad.push(self.voice).started)
        onset = self.vad.push(self.voice)
        self.assertTrue(onset.started)
        self.assertEqual(onset.onset_lookback, 0.04)
        self.assertEqual(np.count_nonzero(onset.audio), 960)
        for _ in range(19):
            self.assertFalse(self.vad.push(self.quiet).ended)
        self.assertTrue(self.vad.push(self.quiet).ended)
        self.assertIsNone(self.vad.push(self.quiet).audio)

    def test_silero_attenuates_low_frequency_noise_without_modifying_asr_audio(self):
        detector = Mock()
        detector.is_speech_detected.side_effect = [False] * 7 + [True]
        detector.current_segment.start = 0
        vad = SileroVoiceActivity(detector)
        index = np.arange(vad.frame_size * 8)
        signal = (0.06 * np.sin(2 * np.pi * 120 * index / 16000)).astype(np.float32)
        for frame in signal.reshape(-1, vad.frame_size):
            detection = vad.push(frame)
        filtered = detector.accept_waveform.call_args.args[0]
        raw = signal[-vad.frame_size:]
        self.assertLess(np.linalg.norm(filtered), 0.70 * np.linalg.norm(raw))
        np.testing.assert_array_equal(detection.audio, signal)


class SileroEndpointTest(unittest.TestCase):
    def test_continuous_speech_is_split_after_fifteen_seconds(self):
        detector = Mock()
        detector.current_segment = SimpleNamespace(start=0)
        detector.is_speech_detected.return_value = True
        detector.empty.return_value = True
        vad = SileroVoiceActivity(detector)
        frame = np.zeros(vad.frame_size, dtype=np.float32)
        self.assertTrue(vad.push(frame).started)
        frames_before_split = (15 * 16_000 - 1) // vad.frame_size
        for _ in range(1, frames_before_split):
            self.assertFalse(vad.push(frame).ended)
        self.assertTrue(vad.push(frame).ended)
        detector.reset.assert_called_once()


@unittest.skipUnless(SILERO_MODEL.is_file(), "Local Silero model is not installed")
class SileroModelTest(unittest.TestCase):
    def setUp(self):
        try:
            import sherpa_onnx
        except ImportError:
            self.skipTest("The sherpa-onnx runtime is not installed for this Python interpreter")
        config = sherpa_onnx.VadModelConfig()
        config.sample_rate = 16_000
        config.num_threads = 1
        config.silero_vad.model = str(SILERO_MODEL)
        config.silero_vad.threshold = 0.70
        config.silero_vad.min_speech_duration = 0.064
        config.silero_vad.min_silence_duration = 0.4
        config.silero_vad.window_size = 512
        self.vad = SileroVoiceActivity(sherpa_onnx.VoiceActivityDetector(config, buffer_size_in_seconds=20))

    def detections(self, vad, audio):
        return [vad.push(audio[start:start + vad.frame_size])
                for start in range(0, len(audio) - vad.frame_size + 1, vad.frame_size)]

    def test_pure_noises_over_the_rms_gate_do_not_start_a_turn(self):
        length = 512 * 64
        rng = np.random.default_rng(66)
        for name, noise in (
            ("white", rng.normal(0, 0.03, length)),
            ("fan-like low tone", 0.03 * np.sin(2 * np.pi * 120 * np.arange(length) / 16_000)),
        ):
            with self.subTest(noise=name):
                audio = noise.astype(np.float32)
                self.assertTrue(any(result.started for result in self.detections(VoiceActivity(), audio)))
                self.assertFalse(any(result.started for result in self.detections(self.vad, audio)))

    def test_short_affirmative_keeps_onset_and_silence_endpoint(self):
        fixture = Path(__file__).parent / "fixtures" / "merchant_dialogue" / "stamp_ack.wav"
        with wave.open(str(fixture), "rb") as recorded:
            data = np.frombuffer(recorded.readframes(recorded.getnframes()), dtype="<i2")
            samples = data.reshape(-1, recorded.getnchannels()).mean(axis=1) / 32768
            rate = recorded.getframerate()
        sample_times = np.arange(round(len(samples) * 16_000 / rate)) * rate / 16_000
        short_ack = np.interp(sample_times, np.arange(len(samples)), samples).astype(np.float32)
        self.assertLess(len(short_ack), 8_000)
        audio = np.concatenate((np.zeros(5120, dtype=np.float32), short_ack, np.zeros(16_000, dtype=np.float32)))
        results = self.detections(self.vad, audio)
        [onset] = [item for item in results if item.started]
        [endpoint] = [item for item in results if item.ended]
        self.assertGreater(onset.onset_lookback, 0)
        self.assertGreater(len(onset.audio), self.vad.frame_size)
        self.assertAlmostEqual(endpoint.trailing_silence, 0.4, delta=0.032)


if __name__ == "__main__":
    unittest.main()
