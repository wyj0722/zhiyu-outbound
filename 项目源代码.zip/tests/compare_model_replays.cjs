// Offline comparison of two fresh, model-enabled browser WebRTC reports.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const caseIds = ["JD-DEMO-001", "JD-DEMO-002", "JD-DEMO-003"];
const cloudProviders = ["deepseek", "doubao"];
const mainPhases = ["identity", "diagnosis", "interjection", "declines_current_plan", "revisits_plan", "confirmation"];
const probes = {
  "JD-DEMO-001": ["discusses_both_categories", "chooses_current_authorization"],
  "JD-DEMO-002": [],
  "JD-DEMO-003": ["reverses_authorization_direction"],
};
const modelPhases = new Set(["diagnosis", "interjection", "revisits_plan", ...Object.values(probes).flat()]);

function validatePair(local, candidate, suite, cloudProvider) {
  for (const [provider, report] of Object.entries({ local, [cloudProvider]: candidate })) {
    assert.equal(report.replay_suite, suite, `Use a fresh ${suite} report for ${provider}`);
    assert.equal(report.health?.llm_provider, provider, `Expected ${provider} from /api/health.llm_provider`);
    assert.equal(report.health.speech_ready, true, `${provider}: speech backend was not ready`);
    assert.equal(report.health.stamp_warmup?.source, "model", `${provider}: actual model warmup did not succeed`);
    assert.deepEqual(report.calls.map(call => call.case_id).sort(), caseIds, `${provider}: expected all three work orders`);
    assert.ok(caseIds.every(id => report.models?.[id]), `${provider}: expected a model on every order`);
    assert.ok(report.source_sha256?.["jd_mock/server.py"], `${provider}: missing source hashes`);
    assert.ok(Object.keys(report.fixtures).length && Object.values(report.fixtures)
      .every(item => /^[0-9a-f]{64}$/.test(item.sha256)), `${provider}: missing WAV hashes`);
  }
  assert.equal(local.browser, candidate.browser, "Browser versions differ");
  for (const field of ["voice_backend", "stamp_asr"]) {
    assert.equal(local.health[field], candidate.health[field], `Speech setup differs: ${field}`);
  }
  const fixtureHashes = report => Object.fromEntries(Object.entries(report.fixtures).map(([key, item]) => [key, item.sha256]));
  assert.deepEqual(fixtureHashes(local), fixtureHashes(candidate), "WAV inputs differ");
  assert.deepEqual(local.source_sha256, candidate.source_sha256, "Code changed between the two runs");
}

function findCall(report, caseId) {
  return report.calls.find(call => call.case_id === caseId);
}

function findTurn(call, phase) {
  const matches = call.turns.filter(turn => turn.phase === phase);
  assert.ok(matches.length <= 1, `Duplicate ${call.case_id}/${phase}`);
  return matches[0];
}

function decisionOf(turn) {
  return turn?.dialogue_decision || turn?.stamp_decision;
}

function hasAudio(turn) {
  return Number.isFinite(turn?.browser_first_audio_ms) && turn.browser_first_audio_ms >= 0;
}

function resultFor(call, phase, fixture) {
  const turn = findTurn(call, phase);
  if (turn) assert.equal(turn.fixture, fixture, `Unexpected recording for ${call.case_id}/${phase}`);
  const decision = decisionOf(turn);
  return {
    passed: call.phase_checks?.[phase]?.passed ?? null,
    error: call.phase_checks?.[phase]?.error ?? null,
    transcript: turn?.transcript ?? null,
    reply: turn?.reply ?? null,
    action: decision?.action ?? null,
    applied_action: decision?.applied_action ?? null,
    source: decision?.source ?? null,
    model_error: decision?.error ?? null,
    server_stages: turn?.server_stages ?? null,
    first_audio_ms: hasAudio(turn) ? turn.browser_first_audio_ms : null,
    barge_to_mute_ms: turn?.barge_to_mute_ms ?? null,
  };
}

function normalizedASR(text) {
  return typeof text === "string" ? text.normalize("NFKC").replace(/[\s\p{P}]+/gu, "").toLowerCase() : "";
}

function percentile(samples, fraction) {
  const sorted = [...samples].sort((a, b) => a - b);
  if (!sorted.length) return null;
  const index = (sorted.length - 1) * fraction;
  const first = Math.floor(index);
  const last = Math.ceil(index);
  return Math.round((sorted[first] + (sorted[last] - sorted[first]) * (index - first)) * 10) / 10;
}

function summarize(pairs, cloudProvider) {
  const values = provider => pairs.map(pair => pair[provider].first_audio_ms);
  return {
    n: pairs.length,
    local: { p50_ms: percentile(values("local"), 0.5), p95_ms: percentile(values("local"), 0.95) },
    [cloudProvider]: { p50_ms: percentile(values(cloudProvider), 0.5), p95_ms: percentile(values(cloudProvider), 0.95) },
    [`${cloudProvider}_minus_local_paired_ms`]: {
      p50_ms: percentile(pairs.map(pair => pair[cloudProvider].first_audio_ms - pair.local.first_audio_ms), 0.5),
      p95_ms: percentile(pairs.map(pair => pair[cloudProvider].first_audio_ms - pair.local.first_audio_ms), 0.95),
    },
  };
}

function unbackedModelTurns(report) {
  return report.calls.flatMap(call => call.turns.flatMap(turn => {
    const decision = decisionOf(turn);
    const expectsModel = modelPhases.has(turn.phase) || /^(?:progresses_plan_|proposes_plan_)/.test(turn.phase);
    if ((expectsModel && decision?.source !== "model") || decision?.source === "fallback" || decision?.error) {
      return [{ case_id: call.case_id, phase: turn.phase, source: decision?.source ?? null, error: decision?.error ?? null }];
    }
    return [];
  }));
}

function compareFixedPhases(local, candidate, cloudProvider) {
  assert.equal(local.all_models && candidate.all_models, true, "Use JD_WORKBENCH_ALL_MODEL=1");
  assert.deepEqual(local.fixed_phase_fixtures, candidate.fixed_phase_fixtures, "The planned fixed workloads differ");
  return caseIds.flatMap(caseId => {
    const planned = local.fixed_phase_fixtures[caseId];
    assert.deepEqual(Object.keys(planned).sort(), mainPhases.concat(probes[caseId]).sort());
    return Object.entries(planned).map(([phase, fixture]) => {
      assert.ok(local.fixtures[fixture], `Missing WAV manifest entry: ${fixture}`);
      const pair = {
        case_id: caseId, phase, fixture, fixture_words: local.fixtures[fixture].words,
        local: resultFor(findCall(local, caseId), phase, fixture),
        [cloudProvider]: resultFor(findCall(candidate, caseId), phase, fixture),
      };
      const transcripts = [normalizedASR(pair.local.transcript), normalizedASR(pair[cloudProvider].transcript)];
      pair.asr = transcripts.includes("") ? "missing" : transcripts[0] === transcripts[1] ? "same" : "different";
      return pair;
    });
  });
}

function fixedPhaseScores(pairs, cloudProvider) {
  const graded = pairs.filter(pair => typeof pair.local.passed === "boolean" && typeof pair[cloudProvider].passed === "boolean");
  const sameASR = graded.filter(pair => pair.asr === "same");
  return {
    planned: pairs.length,
    graded_on_both: graded.length,
    local_passed_on_both_graded: graded.filter(pair => pair.local.passed).length,
    [`${cloudProvider}_passed_on_both_graded`]: graded.filter(pair => pair[cloudProvider].passed).length,
    graded_on_both_with_same_asr: sameASR.length,
    regressions_on_same_asr: sameASR.filter(pair => pair.local.passed && !pair[cloudProvider].passed)
      .map(({ case_id, phase }) => ({ case_id, phase })),
    improvements_on_same_asr: sameASR.filter(pair => !pair.local.passed && pair[cloudProvider].passed)
      .map(({ case_id, phase }) => ({ case_id, phase })),
  };
}

function flowEvidence(report) {
  return {
    rejects_wrong_identity: report.identity_guard?.phase_checks?.denies_identity?.passed === true,
    orders: report.calls.map(call => ({
      case_id: call.case_id, main_path_passed: call.passed === true,
      barge_in: call.phase_checks.interjection?.passed === true,
      refusal_no_receipt: call.phase_checks.declines_current_plan?.passed === true,
      commitment_question: call.phase_checks.commitment_question?.passed === true,
      timeout_pending: call.phase_checks.confirmation?.passed === true,
      recovered_same_receipt: call.phase_checks.receipt_retry?.passed === true && call.idempotent === true,
      automatic_hangup: call.phase_checks.auto_hangup?.passed === true && call.automatically_ended === true,
    })),
  };
}

function compareEarly(local, candidate, cloudProvider) {
  validatePair(local, candidate, "early-consent-v1", cloudProvider);
  const orders = caseIds.map(caseId => {
    const calls = { local: findCall(local, caseId), [cloudProvider]: findCall(candidate, caseId) };
    const evidence = Object.fromEntries(Object.entries(calls).map(([provider, call]) => {
      const turn = findTurn(call, "interrupts_with_consent");
      const decision = decisionOf(turn);
      return [provider, {
        verified: call.passed === true && hasAudio(turn) && turn.receipt_count === 1 && call.idempotent === true
          && call.automatically_ended === true && call.interruption?.before_plan_boundary === true
          && decision?.previous_plan_started === true && decision?.previous_plan_sent === false,
        fixture: turn?.fixture ?? null,
        transcript: turn?.transcript ?? null,
        first_audio_to_consent_ms: call.interruption?.milliseconds_from_first_audio_to_consent ?? null,
        barge_to_mute_ms: turn?.barge_to_mute_ms ?? null,
        error: call.error ?? null,
      }];
    }));
    return { case_id: caseId, ...evidence };
  });
  const modelFallbacks = { local: unbackedModelTurns(local), [cloudProvider]: unbackedModelTurns(candidate) };
  return { provided: true, orders, model_fallbacks: modelFallbacks,
    passed: Object.values(modelFallbacks).every(turns => turns.length === 0) && orders.every(order =>
      order.local.verified && order[cloudProvider].verified && order.local.fixture === order[cloudProvider].fixture) };
}

function compare(local, candidate, early) {
  const cloudProvider = candidate.health?.llm_provider;
  assert.ok(cloudProviders.includes(cloudProvider), "The candidate must report deepseek or doubao from /api/health.llm_provider");
  validatePair(local, candidate, "workbench-v1", cloudProvider);
  const pairedProviders = ["local", cloudProvider];
  const pairs = compareFixedPhases(local, candidate, cloudProvider);
  const fallback = { local: unbackedModelTurns(local), [cloudProvider]: unbackedModelTurns(candidate) };
  const audioPhases = pairs.filter(pair => pair.phase !== "identity");
  const audioPairs = audioPhases.filter(pair => pairedProviders.every(provider => pair[provider].first_audio_ms !== null));
  const validPairs = audioPairs.filter(pair => pairedProviders.every(provider => !fallback[provider].some(turn =>
    turn.case_id === pair.case_id && turn.phase === pair.phase)));
  const sameASR = validPairs.filter(pair => pair.asr === "same");
  const complete = validPairs.length === audioPhases.length && Object.values(fallback).every(turns => turns.length === 0);
  const flows = { local: flowEvidence(local), [cloudProvider]: flowEvidence(candidate) };
  return {
    comparable: complete,
    candidate_provider: cloudProvider,
    providers: { local: local.models, [cloudProvider]: candidate.models },
    fixed_phase_scores: fixedPhaseScores(pairs, cloudProvider),
    fixed_phases: pairs,
    asr: {
      different: pairs.filter(pair => pair.asr === "different").map(pair => ({
        case_id: pair.case_id, phase: pair.phase, fixture_words: pair.fixture_words,
        local: pair.local.transcript, [cloudProvider]: pair[cloudProvider].transcript,
      })),
      missing: pairs.filter(pair => pair.asr === "missing").map(({ case_id, phase }) => ({ case_id, phase })),
      differs_from_script_words: pairs.flatMap(pair => {
        const expected = normalizedASR(pair.fixture_words);
        const differs = pairedProviders.filter(provider => {
          const observed = normalizedASR(pair[provider].transcript);
          return expected && observed && observed !== expected;
        });
        return differs.length ? [{ case_id: pair.case_id, phase: pair.phase, providers: differs }] : [];
      }),
    },
    first_audio: {
      definition: local.latency_definition,
      planned_fixed_business_phases: audioPhases.length,
      paired_with_audio: audioPairs.length,
      missing_audio: audioPhases.filter(pair => !audioPairs.includes(pair)).map(pair => ({
        case_id: pair.case_id, phase: pair.phase,
        missing_in: pairedProviders.filter(provider => pair[provider].first_audio_ms === null),
      })),
      paired_without_fallback: summarize(validPairs, cloudProvider),
      same_asr_subset: summarize(sameASR, cloudProvider),
      dynamic_followups_excluded: Object.fromEntries(Object.entries({ local, [cloudProvider]: candidate }).map(([provider, report]) =>
        [provider, report.calls.reduce((n, call) => n + call.turns.filter(turn => /^progresses_plan_/.test(turn.phase)).length, 0)])),
    },
    skipped_or_failed_provider_turns: fallback,
    application_flow: flows,
    early_consent: early ? compareEarly(...early, cloudProvider) : { provided: false },
  };
}

function main() {
  const [local, candidate, output, flag, localEarly, candidateEarly] = process.argv.slice(2);
  if (!local || !candidate || !output || fs.existsSync(output) || (flag && (flag !== "--early" || !localEarly || !candidateEarly))
      || process.argv.length > 8) {
    throw new Error("Usage: node tests/compare_model_replays.cjs LOCAL.json DEEPSEEK_OR_DOUBAO.json NEW_COMPARISON.json [--early LOCAL_EARLY.json CANDIDATE_EARLY.json]");
  }
  const read = file => JSON.parse(fs.readFileSync(file, "utf8"));
  const report = compare(read(local), read(candidate), flag ? [read(localEarly), read(candidateEarly)] : null);
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
  console.log(JSON.stringify({ candidate_provider: report.candidate_provider, comparable: report.comparable,
    first_audio: report.first_audio, early_consent: report.early_consent.provided }));
  if (!report.comparable || (report.early_consent.provided && !report.early_consent.passed)) process.exitCode = 1;
}

if (require.main === module) {
  try { main(); } catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = { compare };
