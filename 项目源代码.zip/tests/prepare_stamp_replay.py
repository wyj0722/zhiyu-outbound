"""Seal one set of synthetic WAV inputs for both versions of the stamp experiment."""

import argparse
import hashlib
import json
import shutil
import wave
from pathlib import Path

import numpy as np

from jd_mock.speech import SpeechEngine
from jd_mock.speech_assets import DEFAULT_ASSET_DIR


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    folder = args.directory.resolve()
    source = folder / "sealed.json"
    if digest(source) != (folder / "seal.sha256").read_text("utf-8").strip():
        raise ValueError("Test manifest differs from its original seal")
    manifest = json.loads(source.read_text("utf-8"))
    fixtures = folder / "wav"
    fixtures.mkdir(exist_ok=True)
    proof = folder / "audio.json"
    if proof.exists():
        prior = json.loads(proof.read_text("utf-8"))
        if prior["seal_sha256"] != digest(source) or any(digest(fixtures / (k + ".wav")) != v for k, v in prior["files"].items()):
            raise ValueError("Frozen audio changed")
        print("Existing sealed audio verified")
        return
    if list(fixtures.iterdir()):
        raise ValueError("Audio directory contains an incomplete generation; retain it for diagnosis and use a clean directory")
    controls = Path(__file__).resolve().parent / "fixtures"
    shutil.copyfile(controls / "merchant_dialogue" / "recipient_repeat.wav", fixtures / "identity.wav")
    shutil.copyfile(controls / "merchant_identity" / "identity_yes.wav", fixtures / "identity_retry.wav")
    speech = SpeechEngine(DEFAULT_ASSET_DIR)
    for episode in manifest["episodes"]:
        for turn in episode["turns"]:
            samples, rate = speech.synthesize(turn["say"])
            pcm = (np.clip(samples, -1, 1) * 32767).astype("<i2")
            with wave.open(str(fixtures / (turn["id"] + ".wav")), "wb") as f:
                f.setparams((1, 2, rate, 0, "NONE", "not compressed"))
                f.writeframes(pcm.tobytes())
    hashes = {f.stem: digest(f) for f in sorted(fixtures.glob("*.wav"))}
    proof.write_text(json.dumps({"seal_sha256": digest(source), "files": hashes}, indent=2) + "\n", encoding="utf-8")
    print(f"Sealed {len(hashes)} WAV inputs")


if __name__ == "__main__":
    main()
