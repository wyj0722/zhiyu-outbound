import unittest

from jd_mock.cases import get_order
from jd_mock.dialogue import (
    COMMITMENT_QUESTION, PROMPTS, REVIEW, asks_for_commitment, contradicts_plan, introduce,
    material_question_fields, receipt_steps, respond,
)
from jd_mock.stamp_agent import first_replies


class DialogueTests(unittest.TestCase):
    def setUp(self):
        self.category = get_order("JD-DEMO-001")
        self.stamp = get_order("JD-DEMO-002")
        self.chain = get_order("JD-DEMO-003")

    def test_category_offers_one_complete_plan_only_after_the_merchant_chooses(self):
        opening, focus = introduce(self.category)
        self.assertIn("服装", opening)
        self.assertIn("鞋类", opening)
        self.assertEqual(focus, "category_reason")
        self.assertFalse(asks_for_commitment(respond(self.category, "好的", focus)[0]))
        self.assertFalse(asks_for_commitment(respond(self.category, "如果我只卖鞋类呢？", focus)[0]))
        for words, phrase, expected_focus in (
            ("只卖鞋类", "有经营范围限制", "category_select"),
            ("那我就只卖鞋", "有经营范围限制", "category_select"),
            ("两种都想要", "品牌授权方补一份", "category_extra_confirm"),
        ):
            with self.subTest(words=words):
                plan, new_focus = respond(self.category, words, focus)
                self.assertIn(phrase, plan)
                self.assertIn("重新提交", plan)
                self.assertTrue(asks_for_commitment(plan))
                self.assertEqual(new_focus, expected_focus)

    def test_stamp_reads_the_submitted_seal_and_gives_a_complete_offer_after_identity(self):
        reply, focus = introduce(self.stamp)
        self.assertIn("小贝塔", reply)
        self.assertIn("青禾品牌公司", reply)
        self.assertIn("盖章", reply.replace("盖公章", "盖章"))
        self.assertIn("重新提交", reply)
        self.assertEqual(reply.count("？"), 1)
        self.assertTrue(asks_for_commitment(reply))
        self.assertIn("seal", material_question_fields(self.stamp, reply))

    def test_verified_greeting_names_the_application_and_opens_one_question(self):
        reply, focus = introduce(self.category)
        self.assertIn(self.category.render("{application}"), reply)
        self.assertEqual(reply.count("？"), 1)
        self.assertEqual(focus, "category_reason")

    def test_chain_reads_submitted_parties_immediately_after_identity(self):
        reply, focus = introduce(self.chain)
        self.assertIn("入驻申请单", reply)
        self.assertIn("授权方是星桥商贸公司，被授权方是小贝塔", reply)
        self.assertIn("云杉品牌公司授权给星桥商贸公司", reply)
        self.assertEqual(reply.count("？"), 1)
        self.assertTrue(asks_for_commitment(reply))
        self.assertEqual(focus, "confirm")
        self.assertEqual(material_question_fields(self.chain, reply), ("grantor", "grantee"))

    def test_material_cue_matches_the_question_being_spoken(self):
        questions = (
            (self.category, self.category.render(PROMPTS["category_reason"]), ("scope",)),
            (self.category, self.category.render(PROMPTS["category_extra_document"]), ("scope",)),
            (self.chain, introduce(self.chain)[0], ("grantor", "grantee")),
            (self.stamp, self.stamp.render(PROMPTS["stamp_owner"]), ("seal",)),
            (self.stamp, next(reply for reply in first_replies(self.stamp) if "公章上刻的是" in reply), ("seal",)),
        )
        for order, reply, fields in questions:
            with self.subTest(reply=reply):
                self.assertEqual(material_question_fields(order, reply), fields)

    def test_material_cue_opens_the_fields_in_the_initial_readout(self):
        self.assertEqual(material_question_fields(self.category, introduce(self.category)[0]), ("scope",))
        self.assertEqual(material_question_fields(self.stamp, introduce(self.stamp)[0]), ("grantor", "seal"))

    def test_unrelated_questions_and_followups_do_not_keep_a_material_cue(self):
        for order in (self.category, self.stamp, self.chain):
            for reply in (REVIEW[order.procedure.scenario], COMMITMENT_QUESTION, "请问您是否是商家小贝塔？"):
                with self.subTest(reply=reply):
                    self.assertIsNone(material_question_fields(order, reply))
        self.assertIsNone(material_question_fields(self.chain, self.chain.render(PROMPTS["chain_contact"])))

    def test_category_navigation_moves_only_when_the_merchant_finds_the_page(self):
        reply, focus = respond(self.category, "我找不到入口", "intro")
        self.assertIn("打开", reply)
        self.assertIn("品牌申请单", reply)
        repeat, same = respond(self.category, "刚才没听清", focus)
        self.assertEqual(same, focus)
        self.assertIn("申请单", repeat)
        reply, focus = respond(self.category, "已经打开了", focus)
        self.assertIn("销售授权书下方", reply)
        self.assertNotIn("重新提交", reply)
        reply, focus = respond(self.category, "还没看到", focus)
        self.assertIn("销售授权书", reply)
        self.assertNotIn("重新提交", reply)
        reply, focus = respond(self.category, "看到了", focus)
        for term in ("鞋类", "服装"):
            self.assertIn(term, reply)
        self.assertFalse(asks_for_commitment(reply))
        self.assertTrue(asks_for_commitment(respond(self.category, "只卖鞋类", focus)[0]))

    def test_stamp_holder_can_be_identified_over_multiple_turns(self):
        reply, focus = respond(self.stamp, "我已经盖过章了", "intro")
        self.assertIn("章", reply)
        self.assertIn("？", reply)
        reply, focus = respond(self.stamp, "我们自己的", focus)
        self.assertIn("青禾品牌公司", reply)
        self.assertIn("公章", reply)
        self.assertNotIn("确认按", reply)
        reply, focus = respond(self.stamp, "联系不上品牌方", focus)
        self.assertIn("青禾品牌公司", reply)
        self.assertIn("？", reply)
        self.assertNotIn("重新提交吗", reply)

    def test_shorter_explanation_preserves_the_question_and_does_not_advise_submit_yet(self):
        reply, focus = respond(self.category, "找不到入口", "intro")
        short, after = respond(self.category, "说简单点", focus)
        self.assertEqual(focus, after)
        self.assertLess(len(short), len(reply))
        self.assertIn("申请单", short)
        self.assertNotIn("重新提交", short)
        reply, focus = respond(self.stamp, "我已经盖过了", "intro")
        short, after = respond(self.stamp, "简单点", focus)
        self.assertLess(len(short), len(reply))
        self.assertEqual(focus, after)

    def test_no_alternative_document_leaves_a_specific_next_step_without_claiming_a_follow_up(self):
        for order, company in ((self.stamp, "青禾品牌公司"), (self.chain, "云杉品牌公司")):
            _, focus = respond(order, "我联系不上品牌方", "intro")
            reply, focus = respond(order, "没有，我手头没有别的了", focus)
            self.assertIn(company, reply)
            self.assertIn("拿到", reply)
            self.assertNotIn("确认", reply)
            self.assertNotIn("回电", reply)

    def test_question_or_negation_does_not_report_the_merchant_already_did_an_action(self):
        reply, focus = respond(self.stamp, "是不是盖我们自己的章", "intro")
        self.assertIn("青禾品牌公司", reply)
        self.assertNotIn("您手上这份盖的是", reply)
        reply, focus = respond(self.stamp, "我没有盖过章", "intro")
        self.assertIn("青禾品牌公司", reply)
        self.assertNotEqual(focus, "stamp_owner")
        reply, focus = respond(self.chain, "我没交过材料", "intro")
        self.assertIn("云杉品牌公司", reply)
        self.assertNotEqual(focus, "chain_parties")

    def test_chain_answer_uses_both_parties_on_the_existing_document(self):
        reply, focus = respond(self.chain, "我已经交过一份了", "intro")
        self.assertIn("授权方是星桥商贸公司，被授权方是小贝塔", reply)
        self.assertNotIn("？", reply)
        reply, focus = respond(self.chain, "星桥给我的", focus)
        self.assertIn("云杉品牌公司授权给星桥商贸公司", reply)
        self.assertIn("补", reply)
        reply, focus = respond(self.chain, "然后呢", focus)
        self.assertIn("上传", reply)

    def test_chain_replaces_old_role_questions_with_the_work_order_readout(self):
        for old_focus in ("chain_parties", "chain_grantor", "chain_grantee"):
            with self.subTest(old_focus=old_focus):
                reply, focus = respond(self.chain, "没听清", old_focus)
                self.assertEqual(focus, "chain_request")
                self.assertEqual(material_question_fields(self.chain, reply), ("grantor", "grantee"))
                self.assertIn("授权方是星桥商贸公司，被授权方是小贝塔", reply)
                self.assertIn("云杉品牌公司授权给星桥商贸公司", reply)
                self.assertNotIn("？", reply)
                self.assertFalse(asks_for_commitment(reply))

    def test_chain_does_not_affirm_unclear_or_conflicting_document_roles(self):
        for words in ("星桥跟小贝塔", "星桥对于小贝塔的"):
            with self.subTest(words=words):
                reply, focus = respond(self.chain, words, "chain_parties")
                self.assertIn("已提交", reply)
                self.assertNotIn("这段可以保留", reply)
                self.assertEqual(focus, "chain_request")
        for text in (
            "授权方不是星桥商贸公司", "授权方是星桥商贸有限公司", "小贝塔授权给星桥商贸公司",
            "被授权方是星桥，授权方是小贝塔", "授权方是星桥，被授权方不是小贝塔",
        ):
            with self.subTest(text=text):
                reply, focus = respond(self.chain, text, "chain_parties")
                self.assertNotIn("这段可以保留", reply)
                self.assertFalse(asks_for_commitment(reply))
        reply, focus = respond(self.chain, "先别，我要再看看，授权方是星桥商贸公司", "chain_parties")
        self.assertIn("先不记录", reply)
        self.assertEqual(focus, "chain_parties")

    def test_chain_treats_volunteered_names_as_material_context(self):
        for words in (
            "授权方是星桥，被授权方是小贝塔", "被授权方是小贝塔，授权方是星桥商贸公司",
            "小贝塔是被授权方，星桥商贸公司是授权方",
        ):
            with self.subTest(words=words):
                reply, focus = respond(self.chain, words, "chain_parties")
                self.assertIn("授权方是星桥商贸公司，被授权方是小贝塔", reply)
                self.assertEqual(focus, "chain_request")

    def test_repeat_unclear_and_review_do_not_lose_the_previous_question(self):
        for order, user, short, next_text, concrete in (
                (self.stamp, "我已经盖过了", "章", "青禾盖的", "上传"),
                (self.chain, "材料已经提交了", "授权", "星桥给我的", "云杉品牌公司")):
            reply, focus = respond(order, user, "intro")
            reply, same = respond(order, "能不能说简单点", focus)
            self.assertEqual(same, focus)
            self.assertIn(short, reply)
            _, after = respond(order, "这样一定能通过吗", focus)
            self.assertEqual(after, focus)
            unknown, after = respond(order, "我还有个事", after)
            self.assertEqual(after, focus)
            self.assertIn("？", unknown)
            self.assertIn(concrete, respond(order, next_text, after)[0])

    def test_general_how_and_why_give_short_case_bound_answers(self):
        for order, facts in ((self.category, ("鞋类", "服装")), (self.stamp, ("青禾品牌公司", "公章")),
                             (self.chain, ("云杉品牌公司", "星桥商贸公司"))):
            for question in ("我想了解原因", "我到底要改什么"):
                reply, focus = respond(order, question, "")
                self.assertLessEqual(len(reply), 95)
                self.assertNotIn("第一", reply)
                self.assertLessEqual(reply.count("？"), 1)
                for fact in facts:
                    self.assertIn(fact, reply)

    def test_only_an_explicit_question_about_the_agreed_plan_accepts_a_short_yes(self):
        for focus in ("category_select", "category_extra_request"):
            reply, next_focus = respond(self.category, "然后呢", focus)
            self.assertTrue(asks_for_commitment(reply))
            review, _ = respond(self.category, "一定能过吗", next_focus)
            self.assertFalse(asks_for_commitment(review))
        self.assertFalse(asks_for_commitment(introduce(self.category)[0]))

    def test_extra_authorization_survives_followups_and_an_explicit_switch(self):
        order = self.category
        reply, focus = respond(order, "这批服装我还想卖", "intro")
        self.assertTrue(focus.startswith("category_extra_"))
        self.assertIn("销售授权书", reply)
        for question in ("补好就能过吗", "没听清", "到底要改什么"):
            reply, focus = respond(order, question, focus)
            self.assertTrue(focus.startswith("category_extra_"))
        self.assertIn("服装", reply)
        self.assertNotIn("去掉", "".join(receipt_steps(order, focus)))
        self.assertTrue(contradicts_plan(order, "我确认只保留鞋类后重新提交", focus))
        self.assertFalse(contradicts_plan(order, "我确认补齐服装授权后重新提交", focus))
        reply, focus = respond(order, "那我先只卖鞋类", focus)
        self.assertFalse(focus.startswith("category_extra_"))
        self.assertEqual(receipt_steps(order, focus), order.steps)

    def test_short_choices_are_understood_in_the_question_that_prompted_them(self):
        _, choose = respond(self.category, "我想听原因", "intro")
        for text, expected in (("鞋类", "category_select"), ("服装", "category_extra_confirm")):
            self.assertEqual(respond(self.category, text, choose)[1], expected)
        for text in ("有", "没有"):
            self.assertEqual(respond(self.category, text, "category_extra_document")[1], "category_extra_confirm")
        for text, expected in (("能联系上", "stamp_upload"), ("能", "stamp_upload"), ("不能", "stamp_contact")):
            self.assertEqual(respond(self.stamp, text, "stamp_request")[1], expected)
        for text in ("青禾", "青禾品牌公司"):
            self.assertEqual(respond(self.stamp, text, "stamp_owner")[1], "stamp_upload")
        self.assertEqual(respond(self.chain, "要是拿到了呢", "chain_contact")[1], "chain_upload")
        reply, next_focus = respond(self.chain, "有", "chain_contact")
        self.assertEqual(next_focus, "chain_upload")
        self.assertIn("上传", reply)
        self.assertNotIn("？", reply)
        self.assertEqual(respond(self.stamp, "要是拿到了呢", "stamp_contact")[1], "stamp_upload")
        reply, next_focus = respond(self.stamp, "有", "stamp_contact")
        self.assertIn("？", reply)
        self.assertNotEqual(next_focus, "stamp_contact")

    def test_category_collects_both_requested_categories_and_preserves_the_new_document_plan(self):
        _, focus = respond(self.category, "说下原因吧", "intro")
        reply, focus = respond(self.category, "两种都想经营", focus)
        self.assertEqual(focus, "category_extra_confirm")
        self.assertIn("覆盖服装", reply)
        self.assertTrue(asks_for_commitment(reply))
        self.assertIn("品牌授权方补一份", respond(self.category, "品牌方还没给我", focus)[0])
        reply, focus = respond(self.category, "已经拿到新的一份", focus)
        self.assertEqual(focus, "category_extra_confirm")
        self.assertNotIn("补一份", reply)
        self.assertIn("按新范围勾选", reply)

    def test_category_answers_the_current_step_when_the_merchant_sees_the_control(self):
        _, focus = respond(self.category, "入口在哪里", "intro")
        reply, focus = respond(self.category, "我看到了，这里应该怎么勾？", focus)
        self.assertEqual(focus, "category_reason")
        self.assertIn("勾选鞋类", reply)
        self.assertFalse(asks_for_commitment(reply))
        _, focus = respond(self.category, "只卖鞋类", focus)
        reply, _ = respond(self.category, "已经勾好了，在哪儿重新提交？", focus)
        self.assertIn("重新提交", reply)
        self.assertTrue(asks_for_commitment(reply))
        reply, _ = respond(self.category, "我不打算重新提交", "category_select")
        self.assertIn("先不记录", reply)
        self.assertFalse(asks_for_commitment(reply))

    def test_chain_corrects_reversed_direction_and_answers_upload_location(self):
        _, focus = respond(self.chain, "我已经交过一份了", "intro")
        reply, focus = respond(self.chain, "落款是星桥给云杉开的", focus)
        self.assertIn("方向反了", reply)
        self.assertIn("云杉品牌公司授权给星桥商贸公司", reply)
        self.assertFalse(asks_for_commitment(reply))
        reply, focus = respond(self.chain, "补的文件从哪儿传上去？", focus)
        self.assertIn("拿到", reply)
        self.assertIn("入驻申请单", reply)
        self.assertFalse(asks_for_commitment(reply))
        reply, focus = respond(self.chain, "文件找到了，是云杉出给星桥的", focus)
        self.assertEqual(focus, "chain_upload")
        self.assertIn("一起上传", reply)
        reply, _ = respond(self.chain, "上传好后是直接过审吗？", focus)
        self.assertIn("复审", reply)
        self.assertFalse(asks_for_commitment(reply))
        reply, focus = respond(self.chain, "这份已经传上去了", "intro")
        self.assertEqual(focus, "chain_request")
        self.assertIn("授权方是星桥商贸公司，被授权方是小贝塔", reply)
