// Say yes while the concrete plan is speaking, after checking that an
// acknowledgment during the identity prompt cannot create a receipt.
const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, readCall, waitForAutoClose } = require("./verify_browser.cjs");
const { start, play, readyForNextTurn, json, checkProvider, hashSources } = require("./verify_workbench.cjs");

const root = path.resolve(__dirname, "..");
const fixtures = {
  identity: "tests/fixtures/merchant_dialogue/recipient_repeat.wav",
  yes: ".runtime/consent-loop/fixtures/yes.wav",
  requested: ".runtime/consent-loop/fixtures/requested.wav",
  consent: ".runtime/assent-voice/chain_positive.wav",
  stamp_owner: ".runtime/stamp-llm-eval/wav/u02.wav",
  stamp_submit: ".runtime/headset-method-replay/method-confirm.wav",
  chain_question: ".runtime/identity-v2-replay-fixtures/matrix_question.wav",
  next: ".runtime/all-model-fixtures/next.wav",
};
const cases = {
  "JD-DEMO-001": { offer: "requested", confirmation: "consent", steps: /服装.*授权/ },
  "JD-DEMO-002": { offer: "stamp_owner", confirmation: "stamp_submit", steps: /青禾品牌公司.*公章/ },
  "JD-DEMO-003": { offer: "chain_question", confirmation: "yes", steps: /云杉品牌公司.*授权给.*星桥商贸公司/ },
};

async function beginOffer(page, call, fixture) {
  for (let step = 0; step <= 4; step += 1) {
    const marker = await page.evaluate(() => window.jdAcceptance.trace.length);
    const phase = `proposes_plan_${step}`;
    const turn = await play(page, call, step === 0 ? fixture : "next", phase, { consumeReply: false });
    assert.equal(turn.receipt_count, 0);
    if (turn.reply.endsWith("您打算按这个办法处理吗？")) return { marker, phase };
    await readyForNextTurn(page, marker);
  }
  throw new Error("Did not reach a concrete offer after four follow-ups");
}

async function verify(page, call) {
  const settings = cases[call.case_id];
  const historyPath = `/api/cases/${call.case_id}/receipts`;
  assert.equal((await json(page, historyPath)).receipt_count, 0, "Use an empty acceptance database");
  await start(page, call, false);
  if (!call.plan_only) {
    const initialAck = await play(page, call, "yes", "acknowledges_opening");
    assert.equal(initialAck.verified, false);
    assert.equal(initialAck.state, "verify");
    assert.equal(initialAck.receipt_count, 0);
    assert.match(call.turns.at(-1).transcript, /好/);
  }
  const identity = await play(page, call, "identity", "identity");
  assert.equal(identity.verified, true);

  const offer = await beginOffer(page, call, settings.offer);
  // Let the first audible words reach the merchant, then interrupt well
  // before the plan's body has had time to play.
  await page.waitForTimeout(250);
  const confirmation = await play(page, call, settings.confirmation, "interrupts_with_consent",
    { consumeReply: false, barge: true });
  call.interruption = await page.evaluate(({ marker, phase }) => {
    const events = window.jdAcceptance.trace.slice(marker);
    const firstSpeech = events.findIndex(event => event.type === "state" && event.state === "speaking");
    const interrupt = events.findIndex((event, index) => index > firstSpeech && event.type === "interrupt");
    const started = window.jdAcceptance.turns.find(turn => turn.phase === phase);
    const consent = window.jdAcceptance.turns.find(turn => turn.phase === "interrupts_with_consent");
    return {
      before_plan_boundary: firstSpeech >= 0 && interrupt > firstSpeech
        && !events.slice(firstSpeech, interrupt).some(event =>
          event.type === "plan-ready" || (event.type === "state" && event.state === "listening")),
      milliseconds_from_first_audio_to_consent: Math.round((consent.voiceStart - started.firstAudioAt) * 1000),
    };
  }, offer);
  assert.equal(call.interruption.before_plan_boundary, true);
  assert.ok(call.interruption.milliseconds_from_first_audio_to_consent > 0
    && call.interruption.milliseconds_from_first_audio_to_consent < 1200, JSON.stringify(call.interruption));
  assert.equal(confirmation.state, "complete");
  const decision = confirmation.dialogue_decision || confirmation.stamp_decision;
  assert.equal(decision?.previous_plan_started, true);
  assert.equal(decision?.previous_plan_sent, false);
  assert.equal(confirmation.receipt_count, 1);
  assert.equal(confirmation.pending_writeback, false);
  assert.match(call.turns.at(-1).transcript, /好|就按|没问题|按这个方法/);
  await waitForAutoClose(page);
  call.automatically_ended = true;

  const retryPath = `/api/calls/${call.call_id}/retry`;
  assert.equal(confirmation.receipt.call_id, call.call_id);
  assert.equal(confirmation.receipt.case_id, call.case_id);
  assert.match(confirmation.receipt.action_steps.join(" "), settings.steps);
  assert.deepEqual((await json(page, retryPath, true)).receipt, confirmation.receipt);
  const history = await json(page, historyPath);
  assert.equal(history.receipt_count, 1);
  assert.equal(history.latest_receipt.receipt_id, confirmation.receipt.receipt_id);
  assert.equal(await page.locator("#start-call").isEnabled(), true);
  call.receipt = confirmation.receipt;
  call.idempotent = true;
  call.passed = true;
}

async function main() {
  const [baseURL, output, caseId, mode] = process.argv.slice(2);
  const planOnly = mode === "--plan-only";
  if (!baseURL || !output || fs.existsSync(output) || (caseId && !Object.hasOwn(cases, caseId)) || (mode && (!planOnly || !caseId))) {
    throw new Error("Usage: node tests/verify_early_consent.cjs http://127.0.0.1:TEST_PORT NEW_RESULT.json [CASE_ID [--plan-only]]");
  }
  const url = new URL(baseURL);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || url.port === "8779") {
    throw new Error("Use an isolated loopback service with an empty database.");
  }
  const recordings = Object.fromEntries(Object.entries(fixtures).map(([key, file]) => {
    const wav = fs.readFileSync(path.join(root, file));
    return [key, { file, encoded: wav.toString("base64"), sha256: createHash("sha256").update(wav).digest("hex") }];
  }));
  const browser = await chromium.launch({ executablePath: browserPath, headless: true,
    args: ["--autoplay-policy=no-user-gesture-required"] });
  const report = {
    replay_suite: planOnly ? "early-consent-plan-only-v1" : "early-consent-v1",
    base_url: baseURL, browser: browser.version(), started_at: new Date().toISOString(),
    fixtures: Object.fromEntries(Object.entries(recordings).map(([key, { encoded, ...meta }]) => [key, meta])),
    source_sha256: hashSources("tests/verify_early_consent.cjs"),
    calls: (caseId ? [caseId] : Object.keys(cases)).map(id => ({ case_id: id, turns: [], plan_only: planOnly, passed: false })),
    passed: false,
  };
  try {
    const page = await browser.newPage({ baseURL });
    await installFixtureMicrophone(page, recordings, { meterEnabled: true, measureReprompts: true });
    await page.goto("/");
    await page.locator('#health[data-health="ready"]').waitFor();
    report.health = await json(page, "/api/health");
    checkProvider(report.health);
    report.models = report.health.dialogue_models;
    for (const call of report.calls) {
      try {
        assert.ok(report.models?.[call.case_id], "Use the model-enabled workbench");
        await verify(page, call);
        console.log(call.case_id, "PASS", JSON.stringify(call.interruption));
      } catch (error) {
        call.error = error.message;
        if (call.call_id) {
          call.last_state = await readCall(page, call.call_id).catch(() => null);
          await json(page, `/api/calls/${call.call_id}/end`, true).catch(() => {});
        }
        await page.reload();
        console.error(call.case_id, error.message);
      }
    }
    report.passed = report.calls.every(call => call.passed);
  } finally {
    report.ended_at = new Date().toISOString();
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
    await browser.close();
  }
  if (!report.passed) process.exitCode = 1;
}

main().catch(error => { console.error(error); process.exitCode = 1; });
