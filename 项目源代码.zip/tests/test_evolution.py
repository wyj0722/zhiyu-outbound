"""Deterministic publication and isolation checks for autonomous evolution."""

import copy
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path

from jd_mock.evolution import EvolutionError, EvolutionService, _suite, _topic


FACTS = {
    "upstream": "甲公司", "downstream": "乙公司", "missing_segment": "甲公司授权给乙公司",
    "review_phase": "未重新提交", "relationship_check": "未确认关联",
    "relationship_record": "本单审核记录未查到两家公司的持股关系，也未查到相同的法定代表人。",
}
GOOD = "本单核验记录未查到两家公司的持股关系，也未查到相同的法定代表人，所以仍缺甲公司授权给乙公司的证明。"
DIRECTION = "缺的是甲公司授权给乙公司的证明，请补齐后重新提交。"
PENDING = "这笔申请目前暂无关联核验结果，需要先核实两家公司的关系。"


def snapshot():
    return {
        "call_id": "test-call", "scene": "授权链路不完整", "opening": "您好，请问是乙公司负责人吗？",
        "facts": copy.deepcopy(FACTS),
        "qa": [
            {"turn_id": "QA_1", "question": "具体缺哪段？", "answer": DIRECTION},
            {"turn_id": "QA_2", "question": "甲公司和我们是一家啊，怎么还要补授权书？", "answer": "您先补齐授权再提交。"},
            {"turn_id": "QA_3", "question": "我是问你们没查到我们有关联吗？", "answer": GOOD},
            {"turn_id": "QA_4", "question": "好，我会补齐再提交。", "answer": "好的，感谢接听。"},
        ],
    }


class ScriptedModel:
    """The external scorer/teacher boundary, with scores derived from replies."""

    def __init__(self, strategies, *, no_candidate=False):
        base = next(row for row in strategies if row["strategy_id"] == "POP-AUTH-CHAIN-01")
        self.operation = {
            "operation": "modify_strategy", "strategy_id": base["strategy_id"],
            "expected_version": base["version"], "new_version": base["version"] + 1,
            "changes": {"actions": base["actions"] + [
                "商家质疑公司关联时，先查看本单核验结果，有记录时据实解释，暂无结果时说明需要核实。"
            ]},
        }
        self.no_candidate = no_candidate
        self.requests = []

    def __call__(self, messages):
        payload = json.loads(messages[-1]["content"])
        self.requests.append(payload)
        if payload["task"] == "teacher":
            return {
                "source_turn": payload["turn_id"], "diagnosis": "原回复漏答补件原因。",
                "candidates": [] if self.no_candidate else [{
                    "candidate_id": "B", "change_summary": "按核验状态解释关联异议。",
                    "replay_checks": ["有结果时解释原因", "无结果时说明待核实"],
                    "update": copy.deepcopy(self.operation),
                }],
            }
        reply = payload["current_a"]
        low = reply == "您先补齐授权再提交。"
        return {
            "turn_id": payload["turn_id"], "effectiveness": 1 if low else 5,
            "clarity": 3 if low else 5, "tact": 3 if low else 4,
            "intent": "质疑关联公司补授权原因" if low else "当前问题",
            "main_issue": "漏答原因" if low else "无",
            "evidence": reply, "improvement": "依据本单记录回答。",
        }


def answering(question, facts, history, strategies):
    changed = any("暂无结果时说明需要核实" in action for row in strategies for action in row["actions"])
    if "缺谁" in question or "具体缺哪段" in question:
        return DIRECTION
    if facts["relationship_check"] == "暂无结果":
        return PENDING
    return GOOD if changed else "您先补齐授权再提交。"


class AffiliationEvidenceSuiteTests(unittest.TestCase):
    def test_how_to_verify_variants_receive_same_intent_counterfactuals(self):
        questions = (
            "那具体要怎么合实这个观联关系",
            "具体要怎么核实这个观连关系",
            "要用什么材料证明这两家公司有关联？",
            "怎么证明我们两家是一家公司？",
            "关联关系应该提供哪些证据？",
            "你们用什么方法来核实我们两家的关系？",
        )
        for question in questions:
            with self.subTest(question=question):
                row = {"turn_id": "QA_5", "question": question, "facts": copy.deepcopy(FACTS), "history": [{"role": "assistant", "content": GOOD}]}
                suite = _suite(row)
                self.assertEqual(_topic(question), "affiliation_evidence")
                self.assertEqual(len(suite), 4)
                self.assertEqual(suite[0]["question"], question)
                self.assertEqual(suite[1]["question"], "要用什么材料证明这两家公司有关联？")
                self.assertEqual(suite[0]["kind"], "affiliation_evidence")
                self.assertEqual(suite[0]["facts"], FACTS)
                self.assertEqual(suite[1]["history"], row["history"])
                self.assertEqual([case["must_improve"] for case in suite], [True, True, False, False])
                self.assertEqual(suite[2]["kind"], "direction")
                self.assertEqual(suite[3]["facts"]["relationship_check"], "暂无结果")
                self.assertEqual(suite[3]["facts"]["relationship_record"], "")

    def test_why_still_required_is_distinct_from_how_to_prove(self):
        for question in (
            "我们是同一个老板，为什么还要补？",
            "我们两家是一家，怎么还要提交授权证明？",
            "这个观联关系还不够吗，为什么还要交证明？",
        ):
            with self.subTest(question=question):
                self.assertEqual(_topic(question), "affiliation")

    def test_typo_without_association_context_does_not_guess_a_topic(self):
        for question in ("是的，我是商家小贝塔", "这个怎么合实", "观联天气如何", "合实这个观联"):
            with self.subTest(question=question):
                self.assertEqual(_topic(question), "")


class EvolutionTests(unittest.TestCase):
    def setUp(self):
        from jd_mock.strategy import StrategyLibrary
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.library = StrategyLibrary(Path(self.temp.name) / "strategies.sqlite3")
        self.active = self.library.list_active("授权链路不完整")

    def test_only_counterfactually_improved_candidate_is_persisted(self):
        model = ScriptedModel(self.active)
        service = EvolutionService(self.library, model, answering)
        result = service.run(snapshot())
        self.assertEqual(result["status"], "ready")
        self.assertEqual(len(result["updates"]), 1)
        self.assertEqual(result["low_turns"], ["QA_2"])
        self.assertEqual(result["scores"][1]["total"], 36)
        self.assertTrue(result["validation"]["passed"])
        updated = next(row for row in self.library.list_active("授权链路不完整") if row["strategy_id"] == "POP-AUTH-CHAIN-01")
        self.assertEqual(updated["version"], 2)
        self.assertEqual([item["test_id"] for item in result["validation"]["tests"]], ["T1", "T2", "T3", "T4"])
        scored_second = next(req for req in model.requests if req["task"] == "score" and req["turn_id"] == "QA_2")
        self.assertEqual(len(scored_second["history"]), 3)
        self.assertNotIn("我是问你们没查到", json.dumps(scored_second, ensure_ascii=False))

    def test_published_strategy_from_reopened_database_drives_the_next_call(self):
        from jd_mock.business import Store
        from jd_mock.case_agent import CaseAgent
        from jd_mock.chain_strategy_agent import ChainStrategyAgent
        from jd_mock.strategy import StrategyLibrary

        result = EvolutionService(self.library, ScriptedModel(self.active), answering).run(snapshot())
        self.assertEqual(result["status"], "ready")

        class DialogueTransport:
            model = "test-model"

            def chat_text(self, messages, *, max_tokens):
                self.received = messages
                return "本单关联核验未确认两家公司的关系，需要补交云杉品牌公司授权给星桥商贸公司的证明。"

        def embed(phrases):
            return [(1.0, 0.0) for _ in phrases]

        path = Path(self.temp.name) / "strategies.sqlite3"
        reopened = StrategyLibrary(path, embed=embed)
        transport = DialogueTransport()
        fallback = CaseAgent(transport)
        chain = ChainStrategyAgent(reopened, transport, fallback)
        store = Store(path, case_agent=fallback, chain_agent=chain)
        call_id = store.start_call("JD-DEMO-003")["call_id"]
        store.turn(call_id, "是的，我是商家小贝塔", "identity")
        text = "我们两家公司是一家，怎么还要补授权书？"
        reply = store.turn(call_id, text, "relationship")
        strategy = reply["dialogue_decision"]["retrieval"]["strategies"][0]
        self.assertEqual((strategy["strategy_id"], strategy["version"]), ("POP-AUTH-CHAIN-01", 2))
        self.assertIn("暂无结果时说明需要核实", transport.received[0]["content"])
        self.assertEqual(transport.received[-1], {"role": "user", "content": text})

    def test_empty_teacher_candidates_returns_no_update(self):
        model = ScriptedModel(self.active, no_candidate=True)
        result = EvolutionService(self.library, model, answering).run(snapshot())
        self.assertEqual(result["status"], "no_update")
        self.assertEqual(result["updates"], [])
        self.assertEqual(self.library.list_active("授权链路不完整"), self.active)

    def test_teacher_selects_the_review_question_even_when_acknowledgements_score_lower(self):
        data = snapshot()
        unresolved = {"identity_verified": False}
        data["qa"] = [
            {"turn_id": "QA_1", "question": "自己学", "answer": "您先补齐授权再提交。", "facts": unresolved},
            {"turn_id": "QA_2", "question": "我补权了就能给我过吗", "answer": "结果仍要等复审。"},
            {"turn_id": "QA_3", "question": "好吧", "answer": "您先补齐授权再提交。"},
            {"turn_id": "QA_4", "question": "好的", "answer": "您打算按这个办法处理吗？"},
            {"turn_id": "QA_5", "question": "可以", "answer": "我把您确认的处理办法记下了，再见。"},
        ]
        model = ScriptedModel(self.active, no_candidate=True)
        result = EvolutionService(self.library, model, answering).run(data)
        self.assertEqual(len(result["scores"]), 5)
        self.assertEqual(result["low_turns"], ["QA_2"])
        teacher_questions = [r["current_q"] for r in model.requests if r["task"] == "teacher"]
        self.assertEqual(teacher_questions, ["我补权了就能给我过吗"])
        self.assertEqual({r["turn_id"] for r in result["skipped_turns"]},
                         {"QA_1", "QA_3", "QA_4", "QA_5"})
        self.assertEqual(result["reason_code"], "no_candidates")

    def test_only_confirmation_does_not_invoke_the_teacher_or_replay(self):
        data = snapshot()
        data["qa"] = [{"turn_id": "QA_1", "question": "可以。", "answer": "好，我记录下来了。"}]
        model = ScriptedModel(self.active)
        result = EvolutionService(self.library, model, answering).run(data)
        self.assertEqual(result["reason_code"], "no_eligible_turns")
        self.assertEqual(result["updates"], [])
        self.assertEqual([r["task"] for r in model.requests], ["score"])

    def test_fabricated_pending_verification_is_rejected_even_with_high_scores(self):
        def unsafe_answer(question, facts, history, strategies):
            if facts["relationship_check"] == "暂无结果":
                return GOOD
            return answering(question, facts, history, strategies)

        result = EvolutionService(self.library, ScriptedModel(self.active), unsafe_answer).run(snapshot())
        self.assertEqual(result["status"], "no_update")
        self.assertEqual(result["outcome"], "rejected")
        self.assertEqual(self.library.list_active("授权链路不完整"), self.active)
        self.assertIn("unsupported_relationship_record", json.dumps(result, ensure_ascii=False))

    def test_scoring_uses_turn_facts_and_rejects_out_of_range_values(self):
        model = ScriptedModel(self.active)
        data = snapshot()
        data["qa"][1]["facts"] = {**FACTS, "relationship_check": "暂无结果", "relationship_record": ""}

        def invalid_score(messages):
            result = model(messages)
            if json.loads(messages[-1]["content"])["task"] == "score":
                result["effectiveness"] = 6
            return result

        with self.assertRaises(EvolutionError) as raised:
            EvolutionService(self.library, invalid_score, answering).run(data)
        self.assertEqual(raised.exception.stage, "score")
        self.assertEqual(self.library.list_active("授权链路不完整"), self.active)

    def test_honest_negative_guarantee_can_pass(self):
        def cautious(question, facts, history, strategies):
            reply = answering(question, facts, history, strategies)
            return reply + "补件后也不一定通过审核。" if reply == DIRECTION else reply

        result = EvolutionService(self.library, ScriptedModel(self.active), cautious).run(snapshot())
        self.assertEqual(result["status"], "ready")

    def test_percentage_without_a_trusted_record_blocks_publication(self):
        def invented_number(question, facts, history, strategies):
            reply = answering(question, facts, history, strategies)
            return reply + "系统核实持股比例为80%。" if reply == GOOD else reply

        result = EvolutionService(self.library, ScriptedModel(self.active), invented_number).run(snapshot())
        self.assertEqual(result["status"], "no_update")
        self.assertIn("unsupported_relationship_percentage", json.dumps(result))
        self.assertEqual(self.library.list_active("授权链路不完整"), self.active)

    def test_claiming_completed_check_cannot_satisfy_pending_explanation(self):
        def invented_completion(question, facts, history, strategies):
            if facts["relationship_check"] == "暂无结果":
                return "经核实，两家公司没有持股关系，仍需补授权。"
            return answering(question, facts, history, strategies)

        result = EvolutionService(self.library, ScriptedModel(self.active), invented_completion).run(snapshot())
        self.assertEqual(result["status"], "no_update")
        self.assertIn("unsupported_relationship_record", json.dumps(result))
        self.assertEqual(self.library.list_active("授权链路不完整"), self.active)

    def test_independent_top_k_is_combined_and_regressing_lower_rank_is_removed(self):
        from jd_mock.strategy import StrategyLibrary

        for interference, count in ((False, 2), (True, 1)):
            with self.subTest(interference=interference):
                library = StrategyLibrary(Path(self.temp.name) / f"combine-{interference}.sqlite3")
                active = library.list_active("授权链路不完整")
                base_model = ScriptedModel(active)
                review = next(row for row in active if row["strategy_id"] == "POP-REVIEW-001")

                def model(messages):
                    payload = json.loads(messages[-1]["content"])
                    result = base_model(messages)
                    if payload["task"] == "teacher" and "过审" in payload["current_q"]:
                        result["candidates"][0].update(candidate_id="R", change_summary="明确复审要求。")
                        result["candidates"][0]["update"] = {
                            "operation": "modify_strategy", "strategy_id": review["strategy_id"],
                            "expected_version": 1, "new_version": 2,
                            "changes": {"actions": review["actions"] + ["先回答能否通过，再按提交进度说明复审要求。"]},
                        }
                    return result

                def replay(question, facts, history, strategies):
                    improved_chain = any(row["strategy_id"] == "POP-AUTH-CHAIN-01" and row["version"] == 2 for row in strategies)
                    improved_review = any(row["strategy_id"] == "POP-REVIEW-001" and row["version"] == 2 for row in strategies)
                    if facts["relationship_check"] == "暂无结果":
                        return GOOD if interference and improved_chain and improved_review else PENDING
                    if "缺谁" in question:
                        return DIRECTION
                    if "过审" in question or "通过" in question:
                        return "现在无法确定，需要以完整材料的审核结果为准。" if improved_review else "您先补齐授权再提交。"
                    return GOOD if improved_chain else "您先补齐授权再提交。"

                data = snapshot()
                data["qa"] = [data["qa"][1], {"turn_id": "REVIEW", "question": "补齐就能过审吗？", "answer": "您先补齐授权再提交。"}]
                data["qa"] += [{"turn_id": f"OK-{i}", "question": "具体缺哪段？", "answer": DIRECTION} for i in range(6)]
                result = EvolutionService(library, model, replay).run(data)
                self.assertEqual(result["status"], "ready")
                self.assertEqual(len(result["updates"]), count)
                combination = result["validation"]["combinations"][0]
                self.assertEqual(combination["passed"], not interference)
                self.assertTrue(all(candidate["passed"] for candidate in result["validation"]["candidates"]))

    def test_running_job_is_deduplicated_and_owns_immutable_snapshot(self):
        entered, release = threading.Event(), threading.Event()
        model = ScriptedModel(self.active, no_candidate=True)

        def blocking(messages):
            entered.set()
            release.wait(5)
            return model(messages)

        service = EvolutionService(self.library, blocking, answering)
        data = snapshot()
        job = service.start(data)
        self.assertTrue(entered.wait(2))
        data["qa"].clear()
        self.assertEqual(service.start(snapshot())["id"], job["id"])
        with self.assertRaises(KeyError):
            service.get(job["id"], call_id="different-call")
        copy_job = service.get(job["id"])
        copy_job["qa_count"] = 999
        self.assertEqual(service.get(job["id"])["qa_count"], 4)
        release.set()
        deadline = time.monotonic() + 5
        completed = service.get(job["id"])
        while completed["status"] == "running" and time.monotonic() < deadline:
            release.wait(0.005)
            completed = service.get(job["id"])
        self.assertEqual(completed["status"], "completed")
        self.assertEqual(completed["result"]["status"], "no_update")
        self.assertEqual(completed["progress"], 100)

    def test_background_error_reports_step_without_model_secret(self):
        def unavailable(messages):
            raise RuntimeError("API_KEY=secret-should-not-escape")

        service = EvolutionService(self.library, unavailable, answering)
        job = service.start(snapshot())
        deadline = time.monotonic() + 5
        while job["status"] == "running" and time.monotonic() < deadline:
            threading.Event().wait(0.005)
            job = service.get(job["id"])
        self.assertEqual(job["status"], "failed")
        self.assertEqual(job["error"]["stage"], "score")
        self.assertNotIn("secret-should-not-escape", json.dumps(job))


if __name__ == "__main__":
    unittest.main()
