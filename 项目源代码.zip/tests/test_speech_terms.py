import asyncio
import time
import unittest
from threading import Event, Lock
from unittest.mock import AsyncMock, Mock, patch

import numpy as np

from jd_mock.asr_vocabulary import default_vocabulary
from jd_mock.cases import get_order
from jd_mock.media import CallMedia, use_stamp_asr
from jd_mock.dialogue import COMMITMENT_QUESTION, chain_submitted_material, stamp_submitted_material
from jd_mock.speech import SpeechStream, StampSpeechStream


class SpeechTermsTest(unittest.TestCase):
    def finish(self, raw, *, business_terms=True):
        recognizer = Mock()
        recognizer.is_ready.return_value = False
        recognizer.get_result.return_value = raw
        stream = SpeechStream(recognizer, Lock(), business_terms=business_terms)
        return stream.finish()

    def test_restores_category_names_in_local_business_phrases(self):
        cases = (
            ("一下眼泪在哪里选", "一下鞋类在哪里选"),
            ("眼泪在哪里勾选", "鞋类在哪里勾选"),
            ("节类还要补什么材料", "鞋类还要补什么材料"),
            ("我在哪里选择授权内目", "我在哪里选择授权类目"),
            ("我在哪里选择授权类幕", "我在哪里选择授权类目"),
            ("这个授权内幕是在哪改的", "这个授权类目是在哪改的"),
            ("我在哪里选授权内目", "我在哪里选授权类目"),
            ("我想选鞋嘞报到哪里修改权类", "我想选鞋类报到哪里修改权类"),
            ("我想选鞋报道哪里修改授权类", "我想选鞋类道哪里修改授权类目"),
        )
        for raw, corrected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(self.finish(raw), corrected)

    def test_leaves_other_words_and_unrecoverable_fragments_alone(self):
        cases = (
            "我刚才流了眼泪",
            "我因为鞋类被驳回流了眼泪，接下来在哪里选",
            "我想了解授权内幕",
            "我在哪里查授权内幕",
            "我在哪里选择授权目录",
            "我想了解授权类",
            "我只想选鞋",
            "我该选类吗",
            "我的验证码是四八二六",
            "我不同意按步骤修改",
            "我该选鞋类吗",
        )
        for raw in cases:
            with self.subTest(raw=raw):
                self.assertEqual(self.finish(raw), raw)

    def test_business_rewrites_only_apply_to_opt_in_utterances(self):
        raw = "一下眼泪在哪里选"
        self.assertEqual(self.finish(raw, business_terms=False), raw)


class StampAudioTest(unittest.TestCase):
    def test_verified_stamp_only(self):
        for verified, scenario, state, expected in (
            (False, "授权书内容不完整", "verify", False),
            (True, "授权书内容不完整", "need", True),
            (True, "授权书内容不完整", "explain", True),
            (True, "授权书内容不完整", "closed", False),
            (True, "品牌类目不符", "explain", False),
            (True, "授权链路不完整", "explain", False),
        ):
            with self.subTest(verified=verified, scenario=scenario, state=state):
                self.assertEqual(use_stamp_asr(dict(verified=verified, scenario=scenario, state=state)), expected)

    def test_audio_is_grouped_once_per_utterance(self):
        recognizer = Mock()
        stream = recognizer.create_stream.return_value
        stream.result.text = " 章面是别家单位。 "
        utterance = StampSpeechStream(recognizer, Lock())
        utterance.feed(np.array([0.1, 0.2], dtype=np.float32))
        utterance.feed(np.array([0.3], dtype=np.float32))
        self.assertEqual(utterance.finish(), "章面是别家单位。")
        self.assertEqual(utterance.finish(), "章面是别家单位。")
        recognizer.decode_stream.assert_called_once_with(stream)
        sample_rate, pcm = stream.accept_waveform.call_args.args
        self.assertEqual(sample_rate, 16000)
        np.testing.assert_allclose(pcm, [0.1, 0.2, 0.3])


class InterruptedStampAudioTest(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.plan = "请找授权方补盖公章，再提交完整授权书。" + COMMITMENT_QUESTION
        self.call = {"call_id": "one", "verified": True, "state": "explain", "scenario": "授权书内容不完整",
                     "dialogue_focus": "stamp_owner",
                     "reply": self.plan, "stamp_decision": {"latency_ms": 1, "context": {"plan_offered": True,
                                                                                       "plan": "request_stamp"}}}
        self.media = CallMedia(Mock(), Mock(stamp_asr_ready=True), "one", False, Mock(), {}, _webrtc=False)
        self.media.store.get_call.return_value = self.call
        self.media.store.turn.return_value = self.call
        self.media.input_generation = 1
        self.media.send = Mock()
        self.media._reply = Mock()
        self.media.delivered_reply = ""
        self.media.verified = True
        self.media.order = get_order("JD-DEMO-002")
        self.media.vocabulary = default_vocabulary()
        self.media.dialogue_focus = self.call["dialogue_focus"]

    async def finish(self, text, heard):
        self.media._finish_turn(text, 3.0, {}, heard)
        await asyncio.gather(*self.media.turn_tasks)

    async def test_punctuation_interrupt_repeats_current_plan_without_creating_a_turn(self):
        await self.finish("。，……", "")
        self.media.store.turn.assert_not_called()
        self.media._reply.assert_called_once_with(self.plan, 3.0, {})
        self.assertEqual(self.media.delivered_reply, "")
        self.assertNotIn("transcript", [c.args[0] for c in self.media.send.call_args_list])

    async def test_empty_recognition_after_plan_played_keeps_delivery_for_next_answer(self):
        await self.finish("", self.plan)
        self.media.store.turn.assert_not_called()
        self.media._reply.assert_not_called()
        self.assertEqual(self.media.delivered_reply, self.plan)
        self.media.send.assert_called_with("state", state="listening")
        await self.finish("好。", self.media.delivered_reply)
        self.assertEqual(self.media.store.turn.call_args.kwargs["delivered_reply"], self.plan)
        self.assertEqual(self.media.store.turn.call_args.args[1], "好。")

    async def test_empty_recognition_never_replays_old_or_unverified_business_details(self):
        self.call.update(verified=False, state="verify", reply="请问您是否是商家小贝塔？")
        await self.finish("。", self.plan)
        self.media._reply.assert_called_once_with("刚才没听清，请再说一遍。", 3.0, {})
        self.media.store.turn.assert_not_called()
        self.call.update(verified=True, state="closed", reply="再见。")
        self.media._reply.reset_mock()
        await self.finish("。", self.plan)
        self.media._reply.assert_not_called()

    async def test_new_speech_during_decode_discards_previous_transcript(self):
        started, proceed = Event(), Event()

        def finish():
            started.set()
            proceed.wait(timeout=3)
            return "我同意办理。"

        media = Mock(closed=False, input_generation=1)
        task = asyncio.create_task(CallMedia._decode_stamp(media, Mock(finish=finish), 0, time.monotonic(), {}, 1))
        self.assertTrue(await asyncio.to_thread(started.wait, 2))
        media.input_generation = 2
        proceed.set()
        await task
        media._finish_turn.assert_not_called()

    async def test_unconfirmed_stamp_audio_only_interrupts_for_recognized_speech(self):
        self.media._confirm_user_speech = Mock()
        self.media._finish_turn = Mock()
        for words in ("", "。，"):
            await self.media._decode_stamp(
                Mock(finish=Mock(return_value=words)), 1, time.monotonic(), {}, 1, confirmation_pending=True,
            )
        self.media._confirm_user_speech.assert_not_called()
        self.media._finish_turn.assert_not_called()

        await self.media._decode_stamp(
            Mock(finish=Mock(return_value="好的。")), 1, time.monotonic(), {}, 1, "", self.plan,
            confirmation_pending=True,
        )
        self.media._confirm_user_speech.assert_called_once()
        self.media._finish_turn.assert_called_once_with("好的。", 1, self.media._finish_turn.call_args.args[2], "", self.plan)

    async def test_vocabulary_corrects_final_transcript_and_passes_original_to_store(self):
        self.media.order = get_order("JD-DEMO-003")
        raw = "是不是新桥上贸公司授权给云山品牌公司？"
        corrected = "是不是星桥商贸公司授权给云杉品牌公司？"
        self.media._finish_recognition(raw, 1, {}, "", "", confirmation_pending=False)
        await asyncio.gather(*self.media.turn_tasks)
        self.media.send.assert_any_call("transcript", text=corrected, final=True, role="user", raw_text=raw)
        self.assertEqual(self.media.store.turn.call_args.args[1], corrected)
        self.assertEqual(self.media.store.turn.call_args.kwargs["raw_text"], raw)

    async def test_vocabulary_is_bypassed_before_identity_verification(self):
        self.media.verified = False
        self.media.vocabulary = Mock()
        self.media._finish_recognition("我是小贝塔。", 1, {}, "", "", confirmation_pending=False)
        await asyncio.gather(*self.media.turn_tasks)
        self.media.vocabulary.correct.assert_not_called()
        self.assertEqual(self.media.store.turn.call_args.args[1], "我是小贝塔。")

    async def test_chain_vocabulary_uses_the_current_material_question(self):
        self.media.order = get_order("JD-DEMO-003")
        self.media.dialogue_focus = "chain_grantee"
        self.media._finish_recognition("小贝他", 1, {}, "", "", confirmation_pending=False)
        await asyncio.gather(*self.media.turn_tasks)
        self.assertEqual(self.media.store.turn.call_args.args[1], "小贝塔")
        self.assertEqual(self.media.store.turn.call_args.kwargs["raw_text"], "小贝他")


class PlanPlaybackTest(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.media = CallMedia(Mock(), Mock(), "test", False, Mock(), {
            "请补盖公章。": (np.ones(960, dtype=np.float32), 48_000),
            "然后重新提交。": (np.ones(960, dtype=np.float32), 48_000),
            COMMITMENT_QUESTION: (np.ones(19_200, dtype=np.float32), 48_000),
        })
        self.prefix = "请补盖公章。然后重新提交。"
        self.reply = self.prefix + COMMITMENT_QUESTION
        self.media.send = Mock()

    async def asyncTearDown(self):
        await self.media.close()

    def emit(self, now):
        available = bool(self.media.output.frames)
        if available:
            self.media.output.frames.popleft()
        with patch("jd_mock.media.time.monotonic", return_value=now):
            self.media._on_output_frame(available)

    async def test_plan_is_marked_only_after_the_last_step_and_playout_margin(self):
        self.media._reply(self.reply)
        await self.media.reply_task
        self.emit(1.00)   # First instruction
        self.emit(1.02)   # Last instruction
        self.emit(1.10)   # Confirmation question has started
        self.assertEqual(self.media.delivered_reply, "")
        self.emit(1.20)
        self.assertEqual(self.media.delivered_reply, self.prefix)
        self.media.send.assert_any_call("plan-ready")
        while self.media.output.frames:
            self.emit(1.22)
        self.emit(1.24)
        self.assertEqual(self.media.delivered_reply, self.reply)
        self.assertEqual(self.media.send.call_args_list.count((("plan-ready",), {})), 1)

    async def test_replaying_same_text_clears_an_inflight_plan_boundary(self):
        self.media._reply(self.reply)
        await self.media.reply_task
        self.emit(1.00)
        self.emit(1.02)
        self.media._reply(self.reply)
        await self.media.reply_task
        self.emit(2.00)  # Still only the first instruction of the new playback
        self.assertEqual(self.media.delivered_reply, "")
        self.emit(2.02)
        self.emit(2.10)
        self.assertEqual(self.media.delivered_reply, "")

    async def test_unfinished_offer_is_available_after_audio_starts_and_playout_margin(self):
        self.media._reply(self.reply)
        await self.media.reply_task
        self.assertEqual(self.media._playback_at_onset(1.30), ("", ""))
        self.emit(1.00)
        self.assertEqual(self.media._playback_at_onset(1.10), ("", ""))
        self.assertEqual(self.media._playback_at_onset(1.20), ("", self.reply))
        self.media._reply(self.reply)
        await self.media.reply_task
        self.assertEqual(self.media._playback_at_onset(1.50), ("", ""))

    async def test_submitted_facts_do_not_authorize_consent_until_the_remedy_starts(self):
        for case_id, known_facts, remedy in (
            ("JD-DEMO-002", stamp_submitted_material, "请联系青禾品牌公司补盖公章。"),
            ("JD-DEMO-003", chain_submitted_material, "请补云杉品牌公司授权给星桥商贸公司的证明。"),
        ):
            with self.subTest(case_id=case_id):
                self.media.order = get_order(case_id)
                preface = known_facts(self.media.order)
                self.media.prepared_audio[preface] = (np.ones(9_600, dtype=np.float32), 48_000)
                self.media.prepared_audio[remedy] = (np.ones(1_920, dtype=np.float32), 48_000)
                plan = preface + remedy
                reply = plan + COMMITMENT_QUESTION
                self.media._reply(reply)
                await self.media.reply_task

                for index in range(10):
                    self.emit(1.00 + index * 0.02)
                self.assertEqual(self.media._playback_at_onset(1.19), ("", ""))
                self.emit(1.20)
                self.emit(1.22)
                self.assertEqual(self.media._playback_at_onset(1.35), ("", ""))
                self.assertEqual(self.media._playback_at_onset(1.37), ("", reply))
                self.emit(1.39)
                self.assertEqual(self.media._playback_at_onset(1.39), (plan, reply))
                self.media.send.assert_any_call("plan-ready")

    async def test_chain_preface_cannot_start_the_plan_during_a_synthesis_gap(self):
        self.media.order = get_order("JD-DEMO-003")
        preface = chain_submitted_material(self.media.order)
        self.media.prepared_audio[preface] = (np.ones(960, dtype=np.float32), 48_000)
        remedy = "请补云杉品牌公司授权给星桥商贸公司的证明。"
        reply = preface + remedy + COMMITMENT_QUESTION
        waiting, release = Event(), Event()

        def synthesize(sentence):
            self.assertEqual(sentence, remedy)
            waiting.set()
            release.wait(timeout=3)
            return np.ones(960, dtype=np.float32), 48_000

        self.media.engine.synthesize.side_effect = synthesize
        self.media._reply(reply)
        try:
            self.assertTrue(await asyncio.to_thread(waiting.wait, 2))
            self.emit(1.00)
            self.emit(1.22)  # The informational queue has drained.
            self.assertEqual(self.media._playback_at_onset(1.23), ("", ""))
        finally:
            release.set()
        await self.media.reply_task
        self.emit(2.00)
        self.assertEqual(self.media._playback_at_onset(2.15), ("", ""))
        self.assertEqual(self.media._playback_at_onset(2.17), ("", reply))

    async def test_drained_queue_during_synthesis_is_not_a_plan_boundary(self):
        waiting, release = Event(), Event()
        missing = self.media.prepared_audio.pop("然后重新提交。")

        def synthesize(_sentence):
            waiting.set()
            release.wait(timeout=3)
            return missing

        self.media.engine.synthesize.side_effect = synthesize
        self.media._reply(self.reply)
        try:
            self.assertTrue(await asyncio.to_thread(waiting.wait, 2))
            self.emit(1.00)
            self.emit(1.30)
            self.assertEqual(self.media.delivered_reply, "")
        finally:
            release.set()
        await self.media.reply_task
        self.emit(2.00)
        self.emit(2.19)
        self.assertEqual(self.media.delivered_reply, self.prefix)

    async def test_unqueued_plan_audio_cannot_be_used_to_confirm(self):
        self.media.prepared_audio["然后重新提交。"] = (np.array([], dtype=np.float32), 48_000)
        self.media._reply(self.reply)
        await self.media.reply_task
        self.emit(1.00)
        self.emit(1.02)
        self.emit(1.30)
        self.assertEqual(self.media.delivered_reply, "")
        self.assertFalse(any(call.args == ("plan-ready",) for call in self.media.send.call_args_list))

    async def test_completed_call_drains_audio_and_ends_without_updating_the_receipt(self):
        reply = "结果已登记。"
        receipt = {"receipt_id": "persisted"}
        snapshot = {"state": "complete", "verified": True, "scenario": "授权书内容不完整",
                    "reply": reply, "pending_writeback": False, "receipt": receipt}
        self.media.prepared_audio[reply] = (np.ones(960, dtype=np.float32), 48_000)
        self.media.store.turn.return_value = snapshot
        self.media._close_after_farewell = AsyncMock()
        await self.media._process_turn("好", 0, {}, 0, self.reply)
        self.assertTrue(self.media.ending)
        self.media.send.assert_any_call("update", data=snapshot)
        await self.media.reply_task
        self.emit(1.00)
        self.media._close_after_farewell.assert_not_called()
        self.emit(1.02)
        await asyncio.sleep(0)
        self.media._close_after_farewell.assert_awaited_once()
        self.media.store.end_call.assert_not_called()
        self.media.store.retry_writeback.assert_not_called()
        self.assertFalse(any(call.kwargs == {"state": "listening"} for call in self.media.send.call_args_list))

    async def test_durable_completion_survives_new_speech_and_keeps_timeout_retriable(self):
        reply = "暂未收到回写响应，请重试查询本次回执。"
        snapshot = {"state": "complete", "verified": True, "scenario": "授权书内容不完整",
                    "reply": reply, "pending_writeback": True, "receipt": None}
        self.media.prepared_audio[reply] = (np.ones(960, dtype=np.float32), 48_000)

        def commit_then_receive_audio(*_args, **_kwargs):
            self.media.input_generation += 1
            return snapshot

        self.media.store.turn.side_effect = commit_then_receive_audio
        await self.media._process_turn("好", 0, {}, 0, self.reply)
        self.assertTrue(self.media.ending)
        again = self.media.input_generation
        await self.media._process_turn("好的", 0, {}, again, "")
        self.media.store.turn.assert_called_once()
        self.media.send.assert_any_call("update", data=snapshot)
        self.media.store.retry_writeback.assert_not_called()


if __name__ == "__main__":
    unittest.main()
