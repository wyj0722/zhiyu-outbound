"""Blind response coding and per-turn SQLite auditing for the sealed stamp experiment.

prepare DIR OUTDIR --run label report.json database.sqlite3 [--run ...]
score DIR OUTDIR --annotations OUTDIR/labels.json
Never use these files to construct model input. Authors grade responses without seeing version labels.
"""

import argparse
import hashlib
import json
import random
import secrets
import sqlite3
from collections import Counter
from math import ceil, floor
from pathlib import Path


def load(path):
    return Path(path).read_text(encoding="utf-8")


def dump(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def timing(values, expected):
    values = sorted(v for v in values if isinstance(v, (int, float)))
    def pct(q):
        if not values:
            return None
        pos = (len(values) - 1) * q
        return round(values[floor(pos)] + (pos % 1) * (values[ceil(pos)] - values[floor(pos)]), 1)
    return {"n": len(values), "planned": expected, "p50_ms": pct(.5), "p95_ms": pct(.95)}


def prepare(args, manifest):
    args.out.mkdir(parents=True, exist_ok=True)
    if (args.out / "bindings.json").exists():
        raise ValueError("Use a fresh output folder")
    salt = secrets.token_bytes(32)
    episodes = {e["id"]: e for e in manifest["episodes"]}
    rows, bindings, audit = [], {}, {}
    for label, report_path, db_path in args.run:
        report = json.loads(load(report_path))
        if report["seal_sha256"] != sha(args.directory / "sealed.json") or not report.get("ended_at"):
            raise ValueError("Unsealed or unfinished experiment")
        audit[label] = {"report_sha256": sha(report_path), "db": str(Path(db_path).resolve()), "calls": []}
        if "business_first_audio_ms" in report:
            voiced = [t for e in report["episodes"] for t in e["turns"]]
            controls = [t for e in report["episodes"] for t in e["controls"]]
            planned = sum(len(e["turns"]) for e in manifest["episodes"])
            audit[label]["business_first_audio_ms"] = timing([t["first_audio_ms"] for t in voiced], planned)
            audit[label]["including_identity_first_audio_ms"] = timing(
                [t["first_audio_ms"] for t in voiced + controls], planned + len(controls))
        with sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True) as db:
            for episode in report["episodes"]:
                count, case_id = db.execute("""
                    select (select count(*) from receipts where call_id=calls.call_id),case_id
                    from calls where call_id=?
                """, (episode["call_id"],)).fetchone()
                if count != episode["final_state"]["receipt_count"] or case_id != manifest["order"] or count > 1:
                    raise ValueError("Final SQLite receipt count/case ID and observed runtime state disagree")
                payloads = [json.loads(row[0]) for row in db.execute(
                    "select payload from receipts where call_id=?", (episode["call_id"],))]
                if any(p.get("call_id") != episode["call_id"] or p.get("case_id") != case_id for p in payloads):
                    raise ValueError("Persisted receipt bound to wrong case or call")
                audit[label]["calls"].append({"episode": episode["id"], "call_id": episode["call_id"],
                                            "receipt_count": count, "receipt_ids": [p["receipt_id"] for p in payloads]})
                observed = {t["id"]: t for t in episode["turns"]}
                for expect in episodes[episode["id"]]["turns"]:
                    turn = observed.get(expect["id"])
                    key = hashlib.sha256(salt + (label + "/" + expect["id"]).encode()).hexdigest()[:12]
                    bindings[key] = {
                        "run": label, "episode": episode["id"], "turn": expect["id"],
                        "completed": turn is not None, "receipt_count": turn["receipt_count"] if turn else None,
                        "reply": turn["reply"] if turn else None,
                        "transcript": turn["transcript"] if turn else None,
                        "first_audio_ms": turn.get("first_audio_ms") if turn else None,
                    }
                    if turn:
                        meta = turn.get("stamp_decision") or (turn.get("update") or {}).get("stamp_decision")
                        if meta:
                            proof = db.execute(
                                "select trace from stamp_decisions where call_id=? and turn_id=?",
                                (episode["call_id"], meta["turn_id"])).fetchone()
                            if not proof or json.loads(proof[0]) != meta:
                                raise ValueError("Candidate trace not independently confirmed in SQLite")
                            bindings[key]["decision_source"] = meta.get("source")
                            bindings[key]["decision_trace"] = meta
                        rows.append({"key": key, "merchant": expect["say"], "reply": turn["reply"]})
            if len(report["episodes"]) != len(episodes):
                raise ValueError("Not every planned episode was attempted")
    random.SystemRandom().shuffle(rows)
    dump(args.out / "blind.json", rows)
    dump(args.out / "bindings.json", bindings)
    dump(args.out / "sqlite-audit.json", audit)
    print(len(rows), "blinded responses ready")


def relation(value):
    return "not_grantor" if value in {"merchant", "third", "not_grantor"} else value


def score(args, manifest):
    labels = json.loads(load(args.annotations))
    bindings = json.loads(load(args.out / "bindings.json"))
    if {k for k, v in bindings.items() if v["completed"]} != set(labels):
        raise ValueError("Blind annotations do not cover the completed responses")
    truth = {t["id"]: t for e in manifest["episodes"] for t in e["turns"]}
    subgroups_file = args.directory / "subgroups.json"
    subgroups = json.loads(load(subgroups_file)) if subgroups_file.exists() else {}
    if subgroups and subgroups["seal_sha256"] != sha(args.directory / "sealed.json"):
        raise ValueError("Subgroup definitions relate to a different sealed dataset")
    tallies, detail = {}, []
    for key, row in bindings.items():
        expected = truth[row["turn"]]
        observed_owner, action = labels.get(key, ["unobserved", "unobserved"])
        if observed_owner not in {"unknown","merchant","grantor","third","not_grantor","unobserved","na"}:
            raise ValueError("Unknown owner code")
        if action not in {"ASK_OWNER","GET_GRANTOR","UPLOAD","HOLD","COMMIT","REVIEW","unobserved","other"}:
            raise ValueError("Unknown action code")
        committed = row["receipt_count"] == 1
        count = tallies.setdefault(row["run"], Counter())
        count["planned"] += 1
        count["observed"] += int(row["completed"])
        if "decision_source" in row:
            count["decisions_" + str(row["decision_source"])] += 1
        if expected["owner"]:
            count["owner_n"] += 1
            count["owner_exact"] += int(observed_owner == expected["owner"])
            count["owner_relation"] += int(relation(observed_owner) == relation(expected["owner"]))
            if "decision_trace" in row:
                fact = row["decision_trace"]["owner"]
                db_owner = "third" if fact == "third_party" else fact
                count["model_db_owner_n"] += 1
                count["model_db_owner_exact"] += int(db_owner == expected["owner"])
        if row["turn"] in subgroups.get("handler_only", []):
            count["handler_only_n"] += 1
            count["handler_only_asked_owner"] += int(action == "ASK_OWNER")
            count["handler_only_assumed_plan"] += int(action in {"UPLOAD", "GET_GRANTOR", "COMMIT"})
        if expected["should_have_receipt"]:
            count["consent_n"] += 1
            count["correct_positive_write"] += int(committed)
        else:
            count["no_write_n"] += 1
            count["audited_negative_turns"] += int(row["receipt_count"] is not None)
            count["false_positive_writes"] += int(committed)
        correct = ((committed and action == "COMMIT") if expected["action"] == "COMMIT"
                   else (action == expected["action"] and not committed))
        count["next_action_correct"] += int(correct)
        detail.append(dict(row, expected_owner=expected["owner"], observed_owner=observed_owner,
                           expected_action=expected["action"], observed_action=action, action_correct=correct))
    dump(args.out / "scores.json", {k: dict(v) for k, v in tallies.items()})
    dump(args.out / "scored-turns.json", detail)
    audit = json.loads(load(args.out / "sqlite-audit.json"))
    comparison = {
        "seal_sha256": sha(args.directory / "sealed.json"),
        "wav_manifest_sha256": sha(args.directory / "audio.json"),
        "case_id": manifest["order"],
        "episodes": len(manifest["episodes"]),
        "measurement": manifest["metrics"]["latency"],
        "grading": "Observable owner and action are graded on the response heard by the merchant; authorization-role treats merchant/third-party as not granted. Internal owner is separately graded on candidate SQLite decisions only. Voice measures include ASR errors; text diagnostic feeds sealed oracle phrases to fresh calls.",
        "runs": {},
    }
    for name, count in tallies.items():
        info = audit[name]
        comparison["runs"][name] = dict(count,
            source_report_sha256=info["report_sha256"],
            sqlite_checked_calls=len(info["calls"]),
            sqlite_receipts=sum(c["receipt_count"] for c in info["calls"]),
            business_first_audio_ms=info.get("business_first_audio_ms"),
            including_identity_first_audio_ms=info.get("including_identity_first_audio_ms"))
    dump(args.out / "comparison.json", comparison)
    if args.secondary_annotations:
        secondary = json.loads(load(args.secondary_annotations))
        if secondary.keys() != labels.keys():
            raise ValueError("The independent rater must cover the same anonymous rows")
        comparison["blind_ratings"] = {
            "version_blind_rows": len(labels),
            "action_agreement": sum(labels[k][1] == secondary[k][1] for k in labels),
            "owner_agreement": sum(labels[k][0] == secondary[k][0] for k in labels),
            "sources": [args.annotations.name, args.secondary_annotations.name],
            "method": "two independent AI graders with blinded version, same pre-sealed codebook; not human inter-rater validation",
        }
        comparison["provenance"] = json.loads(load(args.directory / "provenance.json"))
        for name, summary in comparison["runs"].items():
            subset = [r for r in detail if r["run"] == name]
            known = [r for r in subset if r["expected_owner"] in {"merchant", "grantor", "third"}]
            summary["known_owner_n"] = len(known)
            summary["known_owner_exact_visible"] = sum(r["observed_owner"] == r["expected_owner"] for r in known)
            summary["known_owner_exact_db"] = None
            summary["known_owner_db_distribution"] = None
            summary["review_and_hold_expected_n"] = sum(r["expected_action"] in {"HOLD","REVIEW"} for r in subset)
            if any("decision_trace" in r for r in subset):
                summary["known_owner_exact_db"] = sum(r["decision_trace"]["owner"] ==
                    {"third":"third_party"}.get(r["expected_owner"], r["expected_owner"]) for r in known)
                summary["known_owner_db_distribution"] = dict(Counter(r["decision_trace"]["owner"] for r in known))
                summary["fallback_reasons"] = dict(Counter(r["decision_trace"]["error"]
                    for r in subset if r["decision_source"] == "fallback"))
                summary["missed_positive_applied_actions"] = dict(Counter(r["decision_trace"]["applied_action"]
                    for r in subset if r["expected_action"] == "COMMIT" and r["receipt_count"] != 1))
        # Qualitative experiment interpretation is recorded once by the evaluator, outside the scorer.
        notes = args.directory / "interpretation.json"
        if notes.exists():
            interpretation = json.loads(load(notes))
            comparison.update(conclusion=interpretation["conclusion"], limitations=interpretation["limitations"])
        dump(args.directory / "comparison.json", comparison)
    print(json.dumps(tallies, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "score"))
    parser.add_argument("directory", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--run", action="append", nargs=3, default=[], metavar=("LABEL", "REPORT", "DATABASE"))
    parser.add_argument("--annotations", type=Path)
    parser.add_argument("--secondary-annotations", type=Path)
    args = parser.parse_args()
    if sha(args.directory / "sealed.json") != load(args.directory / "seal.sha256").strip():
        raise ValueError("Sealed cases have changed")
    manifest = json.loads(load(args.directory / "sealed.json"))
    (prepare if args.mode == "prepare" else score)(args, manifest)


if __name__ == "__main__":
    main()
