"""Synthesize the extra browser acceptance fixtures using the project's local voice."""

import argparse
import wave
from pathlib import Path

import numpy as np

from jd_mock.speech import SpeechEngine
from jd_mock.speech_assets import DEFAULT_ASSET_DIR


PHRASES = {
    "keep_both": "鞋类和服装我都想留，怎么办？",
    "keep_available": "那我就只卖鞋类。",
    "reverse_chain": "是不是星桥商贸公司授权给云杉品牌公司？",
    "next": "接下来呢？",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(".runtime/all-model-fixtures"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    engine = SpeechEngine(DEFAULT_ASSET_DIR)
    for key, phrase in PHRASES.items():
        audio, rate = engine.synthesize(phrase)
        samples = (np.clip(audio, -1, 1) * 32767).astype("<i2")
        wav = args.output / f"{key}.wav"
        with wave.open(str(wav), "wb") as stream:
            stream.setparams((1, 2, rate, 0, "NONE", "not compressed"))
            stream.writeframes(samples.tobytes())


if __name__ == "__main__":
    main()
