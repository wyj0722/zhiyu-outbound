"""Compare raw decoding, frozen category corrections, and the configured vocabulary."""

import argparse
import hashlib
import json
import re
import wave
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from jd_mock import asr_vocabulary
from jd_mock.speech import ASR_SAMPLE_RATE, SpeechEngine
from jd_mock.speech_assets import ASR, DEFAULT_ASSET_DIR, STAMP_ASR


ROOT = Path(__file__).resolve().parents[1]
CATEGORY = "JD-DEMO-001"
STAMP = "JD-DEMO-002"
CHAIN = "JD-DEMO-003"
ZIPFORMER = "zipformer"
SENSEVOICE = "sensevoice"

# (name, WAV, script text, vocabulary scope, recognizer, exact expected words)
CASES = (
    ("shoe_location", ".runtime/voice-fixtures/interrupt.wav", "等一下，鞋类在哪里选？",
     CATEGORY, ZIPFORMER, ("鞋类",)),
    ("shoe_materials", ".runtime/terms-audio/shoes_supplement.wav", "鞋类还要补什么材料？",
     CATEGORY, ZIPFORMER, ("鞋类",)),
    ("authorization_location", ".runtime/terms-audio/auth_prompt.wav", "我在哪里选择授权类目？",
     CATEGORY, ZIPFORMER, ("授权类目",)),
    ("authorization_short", ".runtime/terms-audio/auth_simple.wav", "授权类目怎么选？",
     CATEGORY, ZIPFORMER, ("授权类目",)),
    ("keep_both", ".runtime/all-model-fixtures/keep_both.wav", "鞋类和服装我都想留，怎么办？",
     CATEGORY, ZIPFORMER, ("鞋类", "服装")),
    ("keep_available", ".runtime/all-model-fixtures/keep_available.wav", "那我就只卖鞋类。",
     CATEGORY, ZIPFORMER, ("鞋类",)),
    ("stamp_owner_read", ".runtime/stamp-llm-eval/wav/u05.wav", "我核过印章全称了，是青禾品牌公司这六个字。",
     STAMP, SENSEVOICE, ("青禾品牌公司",)),
    ("stamp_grantor_document", ".runtime/stamp-llm-eval/wav/u14.wav",
     "印文显示青禾品牌公司，我手里这份授权书盖得很清楚。", STAMP, SENSEVOICE, ("青禾品牌公司", "授权书")),
    ("stamp_grantor_match", ".runtime/stamp-llm-eval/wav/u18.wav", "我让她读了印章上的单位，是青禾品牌公司，跟授权方一致。",
     STAMP, SENSEVOICE, ("青禾品牌公司",)),
    ("stamp_third_party_negates_match", ".runtime/stamp-llm-eval/wav/u13.wav",
     "放大看清了，是外面的代理公司的印，和青禾不是一家公司。", STAMP, SENSEVOICE, ("青禾",)),
    ("reverse_chain", ".runtime/all-model-fixtures/reverse_chain.wav", "是不是星桥商贸公司授权给云杉品牌公司？",
     CHAIN, ZIPFORMER, ("星桥商贸公司", "云杉品牌公司")),
    ("chain_existing_document", ".runtime/consent-loop/fixtures/chain_have.wav", "我手里有一份授权书。",
     CHAIN, ZIPFORMER, ("授权书",)),
    ("ordinary_tears", ".runtime/terms-audio/tears.wav", "我刚才流了眼泪。", CATEGORY, ZIPFORMER, ()),
    ("ordinary_inside", ".runtime/terms-audio/inside.wav", "我没有听说过授权内幕。", CATEGORY, ZIPFORMER, ()),
    ("refusal", ".runtime/terms-audio/refusal.wav", "我不同意按步骤修改。", CATEGORY, ZIPFORMER, ()),
    ("unrelated_order", ".runtime/terms-audio/auth_prompt.wav", "我在哪里选择授权类目？", CHAIN, ZIPFORMER, ()),
    ("before_identity", ".runtime/terms-audio/auth_prompt.wav", "我在哪里选择授权类目？", None, ZIPFORMER, ()),
    ("identity_digits", ".runtime/terms-audio/verifier.wav", "我的验证码是四八二六。", None, ZIPFORMER, ()),
)


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decode(engine, wav, backend):
    with wave.open(str(wav), "rb") as recording:
        if recording.getsampwidth() != 2 or recording.getnchannels() != 1:
            raise ValueError(f"Expected mono 16-bit PCM: {wav}")
        rate = recording.getframerate()
        original = np.frombuffer(recording.readframes(recording.getnframes()), dtype="<i2").astype(np.float32) / 32768
    output_samples = np.arange(round(original.size * ASR_SAMPLE_RATE / rate)) * rate / ASR_SAMPLE_RATE
    pcm = np.interp(output_samples, np.arange(original.size), original).astype(np.float32)
    stream = engine.new_stamp_stream() if backend == SENSEVOICE else engine.new_stream()
    for offset in range(0, len(pcm), ASR_SAMPLE_RATE // 50):
        stream.feed(pcm[offset:offset + ASR_SAMPLE_RATE // 50])
    return stream.finish(), rate, round(original.size * 1000 / rate, 1)


def legacy_correction(text, case_id, backend, rules):
    if case_id == CATEGORY and backend == ZIPFORMER:
        for pattern, replacement in rules:
            text = pattern.sub(replacement, text)
    return text


def summarize(rows):
    return {
        "expected_exact_terms": sum(len(row["expected_terms"]) for row in rows),
        "raw_exact_hits": sum(len(row["raw_hits"]) for row in rows),
        "legacy_exact_hits": sum(len(row["legacy_hits"]) for row in rows),
        "configured_exact_hits": sum(len(row["configured_hits"]) for row in rows),
        "changed_vs_legacy_rows": sum(row["configured_text"] != row["legacy_text"] for row in rows),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--asset-dir", type=Path, default=DEFAULT_ASSET_DIR)
    parser.add_argument("--legacy", type=Path, default=ROOT / "results/asr-vocabulary/offline-01.json",
                        help="Frozen legacy rule manifest, or a prior report containing it")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a new report path to preserve existing evidence.")
    legacy = json.loads(args.legacy.read_text(encoding="utf-8"))
    legacy = legacy.get("legacy_rules", legacy)
    rules = [(re.compile(row["pattern"], row["flags"]), row["replacement"]) for row in legacy["rules"]]
    configured = asr_vocabulary.default_vocabulary()
    engine = SpeechEngine(args.asset_dir, stamp_asr=True)
    decoded = {}
    rows = []
    for name, file, script, case_id, backend, expected in CASES:
        key = (file, backend)
        if key not in decoded:
            wav = ROOT / file
            raw, rate, duration = decode(engine, wav, backend)
            decoded[key] = raw, rate, duration, file_hash(wav)
        raw, rate, duration, wav_hash = decoded[key]
        old = legacy_correction(raw, case_id, backend, rules)
        new = configured.correct(case_id, raw) if case_id else raw
        rows.append({
            "id": name, "input_wav": file, "wav_sha256": wav_hash, "input_sample_rate_hz": rate,
            "duration_ms": duration, "recognizer": backend, "script": script,
            "active_case_scope": case_id, "scope_basis": "verified business turn" if case_id else "identity bypass",
            "expected_terms": expected, "raw_text": raw, "legacy_text": old, "configured_text": new,
            "raw_hits": [term for term in expected if term in raw],
            "legacy_hits": [term for term in expected if term in old],
            "configured_hits": [term for term in expected if term in new],
            "expect_unchanged": not expected,
            "unchanged": raw == new,
        })

    negative = [row for row in rows if row["expect_unchanged"]]
    chain = next(row for row in rows if row["id"] == "reverse_chain")
    denied_match = next(row for row in rows if row["id"] == "stamp_third_party_negates_match")
    report = {
        "suite": "asr-vocabulary-offline-v1", "finished_at": datetime.now(timezone.utc).isoformat(),
        "method": "Decode each original WAV once, then apply the frozen and configured rules to identical raw text. "
                  "Zipformer uses 20 ms input chunks; SenseVoice uses the complete clip. Identity control bypass is simulated.",
        "recognizer_assets": {ZIPFORMER: ASR.name, SENSEVOICE: STAMP_ASR.name},
        "legacy_scope": "Only Zipformer for verified category turns in explain applied these rules",
        "legacy_rules": legacy,
        "configured_vocabulary": configured.metadata,
        "configured_module_sha256": file_hash(Path(asr_vocabulary.__file__)),
        "terms": summarize(rows),
        "per_order": {case: summarize([row for row in rows if row["active_case_scope"] == case])
                      for case in (CATEGORY, STAMP, CHAIN)},
        "negative_controls": {"n": len(negative), "unchanged": sum(row["unchanged"] for row in negative)},
        "spoken_relation_checks": {
            "reverse_chain_recognized_in_spoken_direction": bool(re.search(
                r"星桥商贸公司[^。！？]*授权给云杉品牌公司", chain["configured_text"])),
            "stamp_third_party_raw_negation_present": "不是" in denied_match["raw_text"],
            "stamp_third_party_configured_negation_present": "不是" in denied_match["configured_text"],
        },
        "limitations": ["Exact glossary term presence is not whole-transcript accuracy or business correctness.",
                        "Clips are synthetic and uncompressed. No browser, live VAD, codec, or writeback path was exercised."],
        "rows": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({"terms": report["terms"], "negative_controls": report["negative_controls"]}, ensure_ascii=False))
    if not all(row["unchanged"] for row in negative):
        raise SystemExit(1)

if __name__ == "__main__":
    main()
