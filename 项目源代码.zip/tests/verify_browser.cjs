const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");

const root = path.resolve(__dirname, "..");
const baseURL = process.argv[2] || process.env.JD_BASE_URL || "http://127.0.0.1:8765";
const dialogue = process.env.JD_CASE_DIALOGUE === "1";
const caseMatrix = dialogue || process.env.JD_CASE_MATRIX === "1";
const identityOnly = process.env.JD_IDENTITY_ONLY === "1";
const screenshot = process.argv[3] || process.env.JD_VERIFY_SCREENSHOT;
const rsi = process.env.JD_RSI === "1";
const legacyIdentity = rsi && !caseMatrix;
const legacyHangup = legacyIdentity || process.env.JD_WORKBENCH_LEGACY_HANGUP === "1";
const fixturesDir = process.env.JD_VERIFY_FIXTURES || path.join(
  root, ".runtime", legacyIdentity ? "rsi-round-01/fixtures" : caseMatrix ? "identity-v2-matrix-fixtures" : "identity-v2-fixtures",
);
const benchmark = rsi || process.env.JD_BENCHMARK === "1";
const runCount = rsi ? 3 : Number(process.env.JD_VERIFY_RUNS || (benchmark ? 6 : 1));
const output = process.env.JD_VERIFY_RESULTS;
const interruptFixtures = benchmark ? ["interrupt", "interrupt_alt", "interrupt_both"] : ["interrupt"];
const expectedTerms = {
  interrupt: ["鞋类"],
  interrupt_alt: ["授权类目"],
  interrupt_both: ["鞋类", "授权类目"],
};
const identityFixture = legacyIdentity ? "verify" : "identity_yes";
const obstacleFixtures = ["stamp_already", "stamp_ours", "review_outcome"];
const dialogueFixtures = ["recipient_repeat", ...obstacleFixtures];
const fixtureNames = identityOnly ? [identityFixture] : caseMatrix
  ? [identityFixture, "identity_no", "identity_ambiguous", "identity_digits", "reason", "matrix_question", "matrix_negative", "matrix_confirm", "matrix_confirm_retry", ...(dialogue ? dialogueFixtures : [])]
  : [identityFixture, "reason", ...interruptFixtures, "confirm", ...(rsi ? ["wrong"] : [])];
const matrixCases = {
  "JD-DEMO-001": {
    name: "品牌类目不符",
    topic: /类目|授权范围/,
    anchors: ["销售授权书", "鞋类"],
    otherCaseTerms: ["青禾品牌公司", "云杉品牌公司", "星桥商贸公司"],
  },
  "JD-DEMO-002": {
    name: "授权书缺少公章",
    topic: /授权书|公章|盖章/,
    anchors: ["青禾品牌公司", "公章"],
    otherCaseTerms: ["鞋类", "云杉品牌公司", "星桥商贸公司"],
  },
  "JD-DEMO-003": {
    name: "授权链路不完整",
    topic: /授权材料|授权链|哪一段|授权关系/,
    anchors: ["云杉品牌公司", "星桥商贸公司", "授权"],
    otherCaseTerms: ["鞋类", "青禾品牌公司"],
  },
};
const browserPath = process.env.JD_BROWSER_PATH || [
  process.env["ProgramFiles(x86)"],
  process.env.ProgramFiles,
  process.env.LOCALAPPDATA,
].filter(Boolean).map((directory) => path.join(directory, "Microsoft", "Edge", "Application", "msedge.exe"))
  .find((candidate) => fs.existsSync(candidate));
const timeout = 45_000;
const inputRms = 0.009;
const outputRms = 0.006;

function readFixtures() {
  return Object.fromEntries(fixtureNames.map((name) => {
    let directory = fixturesDir;
    if (!process.env.JD_VERIFY_FIXTURES && !legacyIdentity) {
      if (name.startsWith("identity_")) directory = path.join(root, "tests", "fixtures", "merchant_identity");
      if (dialogueFixtures.includes(name)) directory = path.join(root, "tests", "fixtures", "merchant_dialogue");
    }
    const buffer = fs.readFileSync(path.join(directory, name + ".wav"));
    return [name, {
      encoded: buffer.toString("base64"),
      sha256: createHash("sha256").update(buffer).digest("hex"),
    }];
  }));
}

async function installFixtureMicrophone(page, fixtures, { meterEnabled = benchmark || caseMatrix, measureReprompts = false } = {}) {
  const encoded = Object.fromEntries(Object.entries(fixtures).map(([name, file]) => [name, file.encoded]));
  const voiceBounds = Object.fromEntries(Object.entries(fixtures).filter(([, file]) => file.voiceBounds)
    .map(([name, file]) => [name, file.voiceBounds]));
  const iceAddress = process.env.JD_VERIFY_ICE_ADDRESS;
  await page.addInitScript(({ encoded, voiceBounds, benchmark, measureReprompts, inputRms, outputRms, iceAddress }) => {
    const trace = [];
    const audioChecks = [];
    const turns = [];
    let context;
    let destination;
    let buffers;
    let source;
    let remoteAudio;
    let peer;
    let meter;
    let activeTurn;

    async function setupMeter() {
      const code = [
        "class RemoteLevelMeter extends AudioWorkletProcessor {",
        "  count = 0;",
        "  energy = 0;",
        "  windowSize = Math.round(sampleRate / 100);",
        "  process(inputs) {",
        "    const channel = inputs[0]?.[0];",
        "    if (!channel) return true;",
        "    for (let index = 0; index < channel.length; index++) {",
        "      this.energy += channel[index] ** 2;",
        "      this.count += 1;",
        "      if (this.count === this.windowSize) {",
        "        this.port.postMessage({ end: (currentFrame + index + 1) / sampleRate,",
        "          rms: Math.sqrt(this.energy / this.count) });",
        "        this.count = 0;",
        "        this.energy = 0;",
        "      }",
        "    }",
        "    return true;",
        "  }",
        "}",
        "registerProcessor('remote-level-meter', RemoteLevelMeter);",
      ].join("\n");
      const url = URL.createObjectURL(new Blob([code], { type: "text/javascript" }));
      try {
        await context.audioWorklet.addModule(url);
      } finally {
        URL.revokeObjectURL(url);
      }
      meter = new AudioWorkletNode(context, "remote-level-meter");
      meter.connect(context.destination);
      meter.port.onmessage = ({ data: { end, rms } }) => {
        const turn = activeTurn;
        if (!turn || turn.firstAudioAt !== undefined) return;
        if (turn.mutedAt !== undefined && end >= turn.mutedAt && rms < outputRms) {
          turn.quietAfterMute = true;
        }
        if (turn.speakingAt === undefined || end < Math.max(turn.speakingAt, turn.voiceEnd)
          || !remoteAudio || remoteAudio.muted || rms < outputRms
          || (turn.interruptAt !== undefined && !turn.quietAfterMute)) return;
        turn.firstAudioAt = end;
      };
    }

    function voicedRange(buffer) {
      const samples = buffer.getChannelData(0);
      const width = Math.round(buffer.sampleRate / 50);
      let first;
      let last;
      for (let offset = 0; offset < samples.length; offset += width) {
        const end = Math.min(offset + width, samples.length);
        let energy = 0;
        for (let index = offset; index < end; index++) energy += samples[index] ** 2;
        if (Math.sqrt(energy / (end - offset)) >= inputRms) {
          first ??= offset;
          last = end;
        }
      }
      if (last === undefined) throw new Error("No speech detected in WAV fixture");
      return [first / buffer.sampleRate, last / buffer.sampleRate];
    }

    navigator.mediaDevices.getUserMedia = async () => {
      context = new AudioContext();
      destination = context.createMediaStreamDestination();
      // A microphone still emits quiet frames between utterances for endpoint detection.
      const silence = context.createConstantSource();
      silence.offset.value = 0;
      silence.connect(destination);
      silence.start();
      buffers = Object.fromEntries(await Promise.all(
        Object.entries(encoded).map(async ([name, data]) => {
          const bytes = Uint8Array.from(atob(data), (char) => char.charCodeAt(0));
          return [name, await context.decodeAudioData(bytes.buffer)];
        }),
      ));
      if (benchmark) await setupMeter();
      await context.resume();
      return destination.stream;
    };

    const NativeAudio = window.Audio;
    window.Audio = function (...args) {
      const audio = new NativeAudio(...args);
      audio.addEventListener("playing", () => {
        if (audio.srcObject && remoteAudio !== audio) {
          remoteAudio = audio;
          if (meter) context.createMediaStreamSource(audio.srcObject).connect(meter);
        }
      });
      audio.addEventListener("volumechange", () => {
        if (!audio.srcObject) return;
        trace.push({ type: "playback-mute", muted: audio.muted });
        if (activeTurn && audio.muted && activeTurn.interruptAt !== undefined) {
          activeTurn.mutedAt ??= context.currentTime;
        }
      });
      return audio;
    };
    window.Audio.prototype = NativeAudio.prototype;

    if (iceAddress) {
      // On hosts with VPN adapters, keep replay on the selected physical interface.
      const setRemote = RTCPeerConnection.prototype.setRemoteDescription;
      RTCPeerConnection.prototype.setRemoteDescription = function (answer) {
        const lines = answer.sdp.split("\r\n");
        const selected = line => line.split(" ")[4] === iceAddress;
        if (!lines.some(line => line.startsWith("a=candidate:") && selected(line))) {
          throw new Error("No server ICE candidate for " + iceAddress);
        }
        return setRemote.call(this, { type: answer.type, sdp: lines.filter(
          line => !line.startsWith("a=candidate:") || selected(line)
        ).join("\r\n") });
      };
    }

    const createDataChannel = RTCPeerConnection.prototype.createDataChannel;
    RTCPeerConnection.prototype.createDataChannel = function (...args) {
      const channel = createDataChannel.apply(this, args);
      if (channel.label === "call-events") {
        peer = this;
        channel.addEventListener("message", ({ data }) => {
          const event = JSON.parse(data);
          trace.push(event);
          const turn = activeTurn;
          if (!turn) return;
          if (event.type === "transcript" && event.final) turn.transcript = event.text;
          if (event.type === "update") {
            turn.updated = true;
            turn.state = event.data.state;
          }
          if (event.type === "interrupt") turn.interruptAt ??= context.currentTime;
          if (event.type === "state" && event.state === "processing") turn.processing = true;
          if (event.type === "state" && event.state === "speaking" && (turn.updated || (measureReprompts && turn.processing))) {
            turn.speakingAt ??= context.currentTime;
          }
          if (event.type === "timing") {
            turn.serverFirstAudioMs ??= event.server_first_audio_ms;
            const fields = ["endpoint_ms", "asr_backend", "asr_finalize_ms", "business_ms", "model_ms", "tts_first_ms", "cached_first_sentence"];
            turn.serverTiming = Object.fromEntries(
              fields.filter((name) => Object.hasOwn(event, name)).map((name) => [name, event[name]]),
            );
          }
        });
      }
      return channel;
    };

    async function sampleSender(fixture, elapsed) {
      const sample = { fixture, elapsed, clock: context.currentTime, state: context.state };
      for (const report of (await peer.getStats()).values()) {
        if (report.kind !== "audio") continue;
        if (report.type === "outbound-rtp") sample.packets = report.packetsSent;
        if (report.type === "media-source") {
          sample.audioLevel = report.audioLevel;
          sample.audioEnergy = report.totalAudioEnergy;
        }
      }
      audioChecks.push(sample);
    }

    window.jdAcceptance = {
      trace,
      audioChecks,
      turns,
      async reset() {
        activeTurn = undefined;
        if (source) source.stop();
        if (context && context.state !== "closed") await context.close();
        source = undefined;
        remoteAudio = undefined;
        meter = undefined;
        peer = undefined;
        trace.length = 0;
        turns.length = 0;
        audioChecks.length = 0;
      },
      get remotePlaying() {
        return Boolean(remoteAudio && !remoteAudio.paused && remoteAudio.readyState >= 2);
      },
      play(name, phase) {
        if (!buffers?.[name] || source) throw new Error("Fixture microphone is busy or unavailable");
        source = context.createBufferSource();
        source.buffer = buffers[name];
        source.connect(destination);
        source.addEventListener("ended", () => { source = undefined; }, { once: true });
        for (const elapsed of [0, 250, 500, source.buffer.duration * 1000 + 700]) {
          setTimeout(() => void sampleSender(name, elapsed).catch(() => {}), elapsed);
        }
        if (benchmark) {
          const start = context.currentTime + 0.06;
          const [first, last] = voiceBounds[name] || voicedRange(source.buffer);
          activeTurn = { fixture: name, phase, voiceStart: start + first, voiceEnd: start + last };
          turns.push(activeTurn);
          source.start(start);
        } else {
          source.start();
        }
      },
    };
  }, { encoded, voiceBounds, benchmark: meterEnabled, measureReprompts, inputRms, outputRms, iceAddress });
}

async function waitFor(page, condition, argument) {
  const handle = await page.waitForFunction(condition, argument, { timeout });
  await handle.dispose();
}

async function waitForStage(page, stage) {
  await page.locator(`#progress [data-step="${stage}"][aria-current="step"]`).waitFor({ timeout });
}

async function traceLength(page) {
  return page.evaluate(() => window.jdAcceptance.trace.length);
}

async function playTurn(page, fixture, expectedState, phase = fixture) {
  const marker = await traceLength(page);
  await page.evaluate(({ fixture, phase }) => window.jdAcceptance.play(fixture, phase), { fixture, phase });
  const update = await page.waitForFunction((index) => {
    const events = window.jdAcceptance.trace.slice(index);
    const result = events.find(event => event.type === "update");
    if (result) return result.data.state;
    // The server emits "processing" before updating state on a recognized turn.
    // An empty recognition can instead finish by replaying or silently listening.
    const processing = events.findIndex(event => event.type === "state" && event.state === "processing");
    return processing >= 0 && events.slice(processing + 1).some(event =>
      event.type === "state" && ["speaking", "listening"].includes(event.state)) && "no transcript";
  }, marker, { timeout });
  const state = await update.jsonValue();
  await update.dispose();
  if (Array.isArray(expectedState)) {
    assert.ok(expectedState.includes(state), `${fixture}.wav should reach one of ${expectedState.join(", ")}`);
  } else {
    assert.equal(state, expectedState, `${fixture}.wav should reach state ${expectedState}`);
  }
  return marker;
}

async function waitForRenderedReply(page, phase) {
  if (!benchmark && !caseMatrix) return;
  await waitFor(page, (name) => window.jdAcceptance.turns.some(
    (turn) => turn.phase === name && turn.firstAudioAt !== undefined,
  ), phase);
}

async function waitForReplyToFinish(page, start) {
  await waitFor(page, (index) => {
    const events = window.jdAcceptance.trace.slice(index);
    const speaking = events.findIndex((event) => event.type === "state" && event.state === "speaking");
    return speaking >= 0 && events.slice(speaking + 1).some(
      (event) => event.type === "state" && event.state === "listening",
    );
  }, start);
}

async function readCall(page, callId) {
  const response = await page.request.get("/api/calls/" + encodeURIComponent(callId));
  assert.equal(response.status(), 200, "Call state is available from the same server");
  return response.json();
}

async function selectWorkOrder(page, caseId, options = { timeout }) {
  await (await page.waitForFunction(id => Array.from(
    document.getElementById("case-select")?.options || [],
  ).some(option => option.value === id), caseId, options)).dispose();
  const card = page.locator(`[data-case-id="${caseId}"]`).first();
  if (await card.isVisible()) {
    await card.click(options);
    assert.equal(await card.getAttribute("aria-pressed"), "true");
  } else {
    await page.locator("#case-select").selectOption(caseId, options);
  }
  assert.equal(await page.locator("#case-select").inputValue(), caseId);
  assert.equal(await page.locator("#case-id").innerText(), caseId);
}

async function openCall(page, fixtures, simulateTimeout, { reusePage = false } = {}) {
  if (!reusePage) {
    await installFixtureMicrophone(page, fixtures);
    await page.goto("/");
  } else {
    await page.evaluate(async () => window.jdAcceptance.reset());
  }
  await page.locator('#health[data-health="ready"]').waitFor({ timeout });
  await page.locator("#simulate-timeout").setChecked(simulateTimeout);

  const started = page.waitForResponse(
    (response) => new URL(response.url()).pathname === "/api/calls"
      && response.request().method() === "POST" && response.ok(),
    { timeout },
  );
  await page.locator("#start-call").click();
  const { call_id: callId } = await (await started).json();
  await waitForReplyToFinish(page, 0);
  await waitFor(page, () => window.jdAcceptance.remotePlaying);
  assert.match(await page.locator('#messages [data-role="agent"]').first().innerText(), /AI/);
  if (!legacyIdentity) {
    assert.ok((await page.locator('#messages [data-role="agent"]').first().innerText()).includes("请问您是否是商家小贝塔？"));
  }
  return callId;
}

async function hangUpCall(page, callId) {
  const hangup = page.waitForResponse(
    (response) => new URL(response.url()).pathname === `/api/calls/${callId}/end` && response.ok(),
    { timeout },
  );
  await page.locator("#end-call").click();
  const ended = await (await hangup).json();
  assert.equal(ended.state, "closed");
  return ended;
}

async function waitForAutoClose(page, timeoutMs = timeout) {
  await (await page.waitForFunction(() =>
    window.jdAcceptance.trace.some(event => event.type === "ended"), null, { timeout: timeoutMs })).dispose();
  await page.locator("#rail-indicator[data-state='closed']").waitFor({ timeout: timeoutMs });
  assert.equal(await page.locator("#end-call").isDisabled(), true);
  assert.equal(await page.locator("#mute-call").isDisabled(), true);
}

async function finishVerifiedCall(page, callId) {
  if (legacyHangup) return hangUpCall(page, callId);
  await waitForAutoClose(page);
  return readCall(page, callId);
}

async function verifyWrongCode(page, fixtures) {
  const callId = await openCall(page, fixtures, false);
  await playTurn(page, "wrong", "verify", "wrong_code");
  await waitForStage(page, "verify");
  await waitForRenderedReply(page, "wrong_code");

  const wrongAttempt = await readCall(page, callId);
  assert.equal(wrongAttempt.verified, false);
  assert.equal(wrongAttempt.turn_count, 1);
  assert.equal(wrongAttempt.receipt_count, 0);
  assert.equal(wrongAttempt.receipt, null);
  assert.equal(wrongAttempt.pending_writeback, false);
  assert.equal(await page.locator("#retry-writeback").isVisible(), false);

  const agents = await page.locator('#messages [data-role="agent"] p').allTextContents();
  const disclosure = /驳回原因|鞋类|服装|销售授权书|有经营范围限制|选择授权类目|重新提交/;
  assert.ok(agents.length >= 2, "The failed identity check returned a spoken reply");
  assert.ok(agents.every((reply) => !disclosure.test(reply)), "Agent replies disclosed no case details");

  const transcripts = await page.locator('#messages [data-role="merchant"] p').allTextContents();
  assert.equal(transcripts.length, 1);
  assert.ok(transcripts[0].trim());
  const ended = await hangUpCall(page, callId);
  assert.equal(ended.verified, false);
  assert.equal(ended.receipt_count, 0);
  return {
    passed: true,
    fixture: "wrong",
    transcript: transcripts[0],
    verified: ended.verified,
    disclosed_case_details: false,
    receipt_count: ended.receipt_count,
    pending_writeback: ended.pending_writeback,
    final_state: ended.state,
  };
}

async function verifySpokenIdentityGuards(page, fixtures, caseId) {
  const before = await caseHistory(page, caseId);
  const callId = await openCall(page, fixtures, false, { reusePage: true });
  const checks = [];
  for (const [fixture, state] of [
    ["identity_digits", "verify"], ["identity_ambiguous", "verify"], ["identity_no", "closed"],
  ]) {
    await playTurn(page, fixture, state, fixture);
    await waitForRenderedReply(page, fixture);
    const snapshot = await readCall(page, callId);
    assert.equal(snapshot.case_id, caseId);
    assert.equal(snapshot.verified, false);
    assert.equal(snapshot.receipt_count, 0);
    assert.equal(snapshot.receipt, null);
    assert.equal(snapshot.pending_writeback, false);
    const transcript = await page.locator('#messages [data-role="merchant"] p').last().innerText();
    assert.ok(transcript.trim(), "Identity guard uses an actual ASR transcript");
    const agents = await page.locator('#messages [data-role="agent"] p').allTextContents();
    assert.ok(agents.every((text) => !/鞋类|服装|公章|销售授权书|云杉|星桥|青禾|重新提交/.test(text)));
    checks.push({ fixture, transcript, state: snapshot.state, verified: false, receipt_count: 0 });
    if (state === "verify") {
      await waitForStage(page, "verify");
      const marker = await page.evaluate(() => {
        const lastUpdate = window.jdAcceptance.trace.findLastIndex((event) => event.type === "update");
        return lastUpdate;
      });
      await waitForReplyToFinish(page, marker);
    }
  }
  await page.locator('#rail-indicator[data-state="closed"]').waitFor({ timeout });
  assert.deepEqual(await caseHistory(page, caseId), before);
  return { passed: true, protocol: "spoken_identity_v2", call_id: callId, verified: false, receipt_count: 0, checks };
}

async function verifyCall(page, fixtures, interruptFixture) {
  const callId = await openCall(page, fixtures, true);
  let marker = await playTurn(page, identityFixture, "need", "verify");
  await waitForStage(page, "need");
  await waitForRenderedReply(page, "verify");
  await waitForReplyToFinish(page, marker);

  await playTurn(page, "reason", "explain");
  await waitForStage(page, "explain");
  await page.locator('#rail-indicator[data-state="speaking"]').waitFor({ timeout });
  const reasonReply = await page.locator('#messages [data-role="agent"]').last().innerText();
  if (legacyIdentity) assert.match(reasonReply, /选择授权类目/);
  else {
    assert.match(reasonReply, /鞋类/);
    assert.match(reasonReply, /服装/);
  }
  await waitForRenderedReply(page, "reason");

  marker = await playTurn(page, interruptFixture, "explain", "interrupt");
  await waitFor(page, (index) => {
    const events = window.jdAcceptance.trace.slice(index);
    const interrupted = events.findIndex((event) => event.type === "interrupt");
    const muted = events.findIndex((event) => event.type === "playback-mute" && event.muted);
    return interrupted >= 0 && muted > interrupted;
  }, marker);
  await waitForRenderedReply(page, "interrupt");
  await waitForReplyToFinish(page, marker);
  assert.ok(Number(await page.locator("#interrupt-count").innerText()) >= 1, "UI counted the barge-in");
  assert.match(await page.locator('#messages [data-role="agent"]').last().innerText(), /销售授权书/);
  assert.equal(await page.locator('#messages [data-role="merchant"]').count(), 3);

  await playTurn(page, "confirm", "complete");
  const retry = page.locator("#retry-writeback");
  await retry.waitFor({ timeout });
  assert.match(await page.locator("#receipt-status").innerText(), /超时/);
  assert.equal(await page.locator("#receipt-fields").isVisible(), false);
  const pending = await readCall(page, callId);
  assert.equal(pending.pending_writeback, true);
  assert.equal(pending.receipt_count, 1);
  assert.equal(pending.receipt, null);
  assert.ok(pending.turn_count >= 3);
  await waitForRenderedReply(page, "confirm");

  await retry.click();
  await page.locator('#receipt-badge[data-status="saved"]').waitFor({ timeout });
  assert.match(await page.locator("#receipt-status").innerText(), /1 条凭证/);
  const saved = await readCall(page, callId);
  assert.equal(saved.pending_writeback, false);
  assert.equal(saved.receipt_count, 1);
  assert.ok(saved.receipt?.receipt_id);
  assert.match(await page.locator("#receipt-fields").innerText(), /场景汇总/);

  const repeated = await page.request.post("/api/calls/" + encodeURIComponent(callId) + "/retry");
  assert.equal(repeated.status(), 200);
  const afterRepeat = await repeated.json();
  assert.equal(afterRepeat.receipt_count, 1);
  assert.deepEqual(afterRepeat.receipt, saved.receipt);

  const ended = await finishVerifiedCall(page, callId);
  assert.equal(ended.receipt_count, 1);
  assert.equal(ended.receipt.receipt_id, saved.receipt.receipt_id);
  return {
    turn_count: saved.turn_count,
    interrupt_count: Number(await page.locator("#interrupt-count").innerText()),
    receipt_count: saved.receipt_count,
    server_first_audio_ms: await page.evaluate(() => window.jdAcceptance.trace
      .filter((event) => event.type === "timing").map((event) => event.server_first_audio_ms)),
  };
}

function percentile(values, fraction) {
  const sorted = values.filter(Number.isFinite).toSorted((a, b) => a - b);
  if (!sorted.length) return null;
  const index = (sorted.length - 1) * fraction;
  const lower = sorted[Math.floor(index)];
  const upper = sorted[Math.ceil(index)];
  return Math.round((lower + (upper - lower) * (index % 1)) * 10) / 10;
}

function stats(values, planned) {
  const numbers = values.filter(Number.isFinite);
  return {
    n: numbers.length,
    planned,
    missing: planned - numbers.length,
    p50: percentile(numbers, 0.5),
    p95: percentile(numbers, 0.95),
  };
}

function milliseconds(from, to) {
  return Number.isFinite(from) && Number.isFinite(to) ? Math.round((to - from) * 10_000) / 10 : null;
}

async function measuredTurns(page) {
  const raw = await page.evaluate(() => window.jdAcceptance?.turns || []).catch(() => []);
  return raw.map((turn) => {
    const expected = expectedTerms[turn.fixture] || [];
    return {
      phase: turn.phase,
      fixture: turn.fixture,
      transcript: turn.transcript || null,
      state: turn.state || null,
      expected_terms: expected,
      recognized_terms: expected.filter((term) => turn.transcript?.includes(term)),
      browser_render_ms: milliseconds(turn.voiceEnd, turn.firstAudioAt),
      barge_in_to_mute_ms: milliseconds(turn.voiceStart, turn.mutedAt),
      server_first_audio_ms: turn.serverFirstAudioMs ?? null,
      ...(turn.serverTiming && Object.keys(turn.serverTiming).length ? { server_timing: turn.serverTiming } : {}),
    };
  });
}

async function diagnostics(page) {
  return page.evaluate(() => ({
    health: document.getElementById("health-text")?.textContent,
    notice: document.getElementById("notice")?.textContent,
    phase: document.getElementById("rail-status")?.textContent,
    messages: document.getElementById("messages")?.innerText,
    events: window.jdAcceptance?.trace.map((event) => event.state || event.type),
    audioChecks: window.jdAcceptance?.audioChecks,
  })).catch(() => ({}));
}

async function caseHistory(page, caseId) {
  const response = await page.request.get("/api/cases/" + encodeURIComponent(caseId) + "/receipts");
  assert.equal(response.status(), 200, "Work-order receipt history is available");
  const history = await response.json();
  assert.equal(history.case_id, caseId);
  return history;
}

function assertCaseAnswer(text, details, { actionExpected = true } = {}) {
  for (const term of details.anchors) assert.ok(text.includes(term), "Case answer includes " + term);
  for (const term of details.otherCaseTerms) assert.ok(!text.includes(term), "Case answer excludes stale detail " + term);
  if (actionExpected) assert.match(text, /补|改|选|盖|提交|勾|去掉|保留/, "Case answer gives an action");
}

async function verifyStampConversation(page, callId, turns) {
  for (const fixture of obstacleFixtures) {
    const marker = await playTurn(page, fixture, "explain");
    await waitForRenderedReply(page, fixture);
    const snapshot = await readCall(page, callId);
    const reply = await page.locator('#messages [data-role="agent"] p').last().innerText();
    const transcript = await page.locator('#messages [data-role="merchant"] p').last().innerText();
    turns.push({ fixture, transcript, reply, state: snapshot.state, receipt_count: snapshot.receipt_count });
    assert.equal(snapshot.receipt_count, 0, "Questions and short contextual answers do not authorize writeback");
    assert.equal(snapshot.pending_writeback, false);
    assert.equal(snapshot.case_id, "JD-DEMO-002");
    assert.doesNotMatch(reply, /鞋类|云杉|星桥|您确认按这些步骤|整改可以分三步/);
    if (fixture === "stamp_already") {
      assert.match(reply, /谁|哪家|哪一[家方]|哪(?:个|位|一)?(?:公司|单位|方)|还是/);
      assert.match(reply, /[?？]/, "Ask whose company seal is already on the document");
    } else if (fixture === "stamp_ours") {
      assert.match(reply, /青禾品牌公司/);
      assert.match(reply, /公章|盖章/, "Interpret the elliptical answer using the previous question");
    } else {
      assert.match(reply, /复审|重新审核|审核结果|审核人员|审核为准/);
      assert.doesNotMatch(reply, /(?:可以保证|肯定能|一定会)通过[。！]/);
    }
    await waitForReplyToFinish(page, marker);
  }
}

async function runCaseMatrix(browser, fixtures) {
  const selected = process.env.JD_CASE_ID ? [process.env.JD_CASE_ID] : Object.keys(matrixCases);
  const repeat = Number(process.env.JD_CASE_REPEAT || 1);
  if (!Number.isInteger(repeat) || repeat < 1) throw new Error("JD_CASE_REPEAT must be a positive integer");
  if (selected.some((caseId) => !matrixCases[caseId])) throw new Error("Unknown JD_CASE_ID");
  const plan = Array.from({ length: repeat }, () => selected).flat();
  const page = await browser.newPage({ baseURL, viewport: { width: 1440, height: 1050 } });
  const calls = [];
  const completed = [];
  const historySnapshots = new Map();
  let identity;
  let integrityVerified = false;
  let matrixError;
  let matrixDiagnostics;
  try {
    await installFixtureMicrophone(page, fixtures);
    await page.goto("/");
    const picker = page.locator("#case-select");
    await selectWorkOrder(page, plan[0]);
    identity = await verifySpokenIdentityGuards(page, fixtures, plan[0]);

    for (const caseId of plan) {
      const call = { case_id: caseId, name: matrixCases[caseId].name };
      calls.push(call);
      try {
        await selectWorkOrder(page, caseId);
        const before = await caseHistory(page, caseId);
        const callId = await openCall(page, fixtures, true, { reusePage: true });
        call.call_id = callId;
        assert.equal(await picker.inputValue(), caseId);
        assert.equal((await readCall(page, callId)).case_id, caseId);
        assert.equal((await page.locator("#case-id").innerText()).trim(), caseId);
        assert.equal(await page.locator("#messages > li").count(), 1);
        assert.equal(await page.locator("#receipt-fields").isVisible(), false);
        assert.equal(Number(await page.locator("#turn-count").innerText()), 0);
        assert.equal(Number(await page.locator("#interrupt-count").innerText()), 0);
        assert.equal(await picker.isDisabled(), true);

        let marker = await playTurn(page, identityFixture, dialogue ? ["need", "verify"] : "need", "verify");
        await waitForRenderedReply(page, "verify");
        await waitForReplyToFinish(page, marker);
        if (dialogue && (await readCall(page, callId)).state === "verify") {
          const unclear = await readCall(page, callId);
          assert.equal(unclear.verified, false);
          assert.equal(unclear.receipt_count, 0);
          assert.equal(unclear.reply, "请问您是否是商家小贝塔？");
          call.identity_reprompt = await page.locator('#messages [data-role="merchant"] p').last().innerText();
          marker = await playTurn(page, "recipient_repeat", "need", "verify_retry");
          await waitForRenderedReply(page, "verify_retry");
          await waitForReplyToFinish(page, marker);
        }
        if (dialogue) {
          call.invitation = await page.locator('#messages [data-role="agent"] p').last().innerText();
          assert.match(call.invitation, /[?？]|告诉我|跟我说|您说/);
          assert.match(call.invitation, matrixCases[caseId].topic, "The invitation names the issue the merchant is being called about");
          assert.equal((await readCall(page, callId)).receipt_count, 0);
          if (caseId === "JD-DEMO-002") {
            call.stamp_dialogue = [];
            await verifyStampConversation(page, callId, call.stamp_dialogue);
          }
        }
        await playTurn(page, "reason", "explain");
        await waitForRenderedReply(page, "reason");
        assertCaseAnswer(await page.locator('#messages [data-role="agent"]').last().innerText(), matrixCases[caseId], { actionExpected: false });

        marker = await playTurn(page, "matrix_question", "explain", "question");
        await waitFor(page, (index) => {
          const events = window.jdAcceptance.trace.slice(index);
          const interrupted = events.findIndex((event) => event.type === "interrupt");
          return interrupted >= 0 && events.slice(interrupted + 1).some(
            (event) => event.type === "playback-mute" && event.muted,
          );
        }, marker);
        await waitForRenderedReply(page, "question");
        await waitForReplyToFinish(page, marker);
        const questionAnswer = await page.locator('#messages [data-role="agent"]').last().innerText();
        assertCaseAnswer(questionAnswer, matrixCases[caseId]);

        marker = await playTurn(page, "matrix_negative", "explain", "negative");
        await waitForRenderedReply(page, "negative");
        await waitForReplyToFinish(page, marker);
        assert.equal((await readCall(page, callId)).receipt_count, 0);
        assert.equal(await page.locator("#retry-writeback").isVisible(), false);

        marker = await playTurn(page, "matrix_confirm", ["complete", "explain"], "confirmation");
        await waitForRenderedReply(page, "confirmation");
        const primaryConfirmation = await readCall(page, callId);
        call.primary_confirm_state = primaryConfirmation.state;
        call.clarification_required = primaryConfirmation.state === "explain";
        call.confirmation_attempts = call.clarification_required ? 2 : 1;
        if (process.env.JD_CASE_EXPECT_CLARIFICATION === "1") {
          assert.equal(call.clarification_required, true, "Diagnostic primary must request clarification");
        }
        if (call.clarification_required) {
          assert.equal(primaryConfirmation.case_id, caseId);
          assert.equal(primaryConfirmation.verified, true);
          assert.equal(primaryConfirmation.receipt_count, 0);
          assert.equal(primaryConfirmation.receipt, null);
          assert.equal(primaryConfirmation.pending_writeback, false);
          assert.equal(await page.locator("#retry-writeback").isVisible(), false);
          assert.match(
            await page.locator('#messages [data-role="agent"]').last().innerText(),
            /确认|再说|没听清|是否|哪一步|卡在哪里/,
            "Unclear confirmation receives an explicit clarification prompt",
          );
          await waitForReplyToFinish(page, marker);
          await playTurn(page, "matrix_confirm_retry", "complete", "confirmation_retry");
          await waitForRenderedReply(page, "confirmation_retry");
        }
        const pending = await readCall(page, callId);
        assert.equal(pending.case_id, caseId);
        assert.equal(pending.pending_writeback, true);
        assert.equal(pending.receipt_count, 1);
        assert.equal(pending.receipt, null);
        assert.equal(pending.turn_count, 4 + Number(Boolean(call.identity_reprompt)) + (call.stamp_dialogue?.length || 0) + call.confirmation_attempts);
        assert.equal(await page.locator("#receipt-fields").isVisible(), false);
        assert.equal((await caseHistory(page, caseId)).receipt_count, before.receipt_count);
        await page.locator("#retry-writeback").click();
        await page.locator('#receipt-badge[data-status="saved"]').waitFor({ timeout });
        const saved = await readCall(page, callId);
        assert.equal(saved.pending_writeback, false);
        assert.equal(saved.receipt_count, 1);
        assert.equal(saved.receipt.case_id, caseId);
        assert.equal(saved.receipt.call_id, callId);
        assertCaseAnswer(JSON.stringify(saved.receipt), matrixCases[caseId]);
        const repeated = await page.request.post("/api/calls/" + encodeURIComponent(callId) + "/retry");
        assert.equal(repeated.status(), 200);
        assert.deepEqual((await repeated.json()).receipt, saved.receipt);
        const after = await caseHistory(page, caseId);
        assert.equal(after.receipt_count, before.receipt_count + 1);
        assert.equal(after.latest_receipt.receipt_id, saved.receipt.receipt_id);
        await waitFor(page, ({ count, receiptId }) => {
          return document.getElementById("case-history-count")?.textContent.trim() === String(count)
            && document.getElementById("last-receipt-id")?.textContent.trim() === receiptId;
        }, { count: after.receipt_count, receiptId: saved.receipt.receipt_id });
        const updateBindings = await page.evaluate(() => window.jdAcceptance.trace
          .filter((event) => event.type === "update").map((event) => ({
            case_id: event.data.case_id, call_id: event.data.call_id,
          })));
        assert.ok(updateBindings.length >= 5);
        assert.ok(updateBindings.every((binding) => binding.case_id === caseId && binding.call_id === callId));

        await finishVerifiedCall(page, callId);
        completed.push({ callId, caseId, receipt: saved.receipt });
        historySnapshots.set(caseId, after);
        call.passed = true;
        call.turn_count = saved.turn_count;
        call.interrupt_count = Number(await page.locator("#interrupt-count").innerText());
        call.receipt_id = saved.receipt.receipt_id;
        call.question_answer = questionAnswer;
        call.turns = await measuredTurns(page);
      } catch (error) {
        call.passed = false;
        call.error = error.message;
        call.diagnostics = await diagnostics(page);
        if (call.call_id) await page.request.post("/api/calls/" + encodeURIComponent(call.call_id) + "/end").catch(() => {});
        console.error(JSON.stringify(call, null, 2));
        break;
      }
      console.error("Case matrix " + caseId + ": PASS");
    }
    assert.equal(new Set(completed.map((call) => call.receipt.receipt_id)).size, completed.length);
    for (const previous of completed) {
      const persisted = await readCall(page, previous.callId);
      assert.equal(persisted.case_id, previous.caseId);
      assert.equal(persisted.receipt_count, 1);
      assert.deepEqual(persisted.receipt, previous.receipt);
    }
    for (const [caseId, expected] of historySnapshots) {
      assert.deepEqual(await caseHistory(page, caseId), expected, "Switching cases preserves each history");
    }
    integrityVerified = completed.length === plan.length;
  } catch (error) {
    matrixError = error.message;
    identity ??= { passed: false, error: error.message };
    matrixDiagnostics = await diagnostics(page);
    console.error(JSON.stringify(matrixDiagnostics, null, 2));
  } finally {
    if (screenshot) await page.screenshot({ path: screenshot, fullPage: true });
    await page.close();
  }
  const result = {
    mode: "case_matrix",
    base_url: baseURL,
    browser_version: browser.version(),
    fixture_sha256: Object.fromEntries(Object.entries(fixtures).map(([name, file]) => [name, file.sha256])),
    plan,
    primary_fixture: {
      declared_text: process.env.JD_CASE_PRIMARY_TEXT || "我确认按步骤修改后重新提交。",
      purpose: process.env.JD_CASE_PRIMARY_PURPOSE || "confirmation",
    },
    identity,
    independent_receipts: integrityVerified,
    passed: identity?.passed === true && integrityVerified && calls.length === plan.length && calls.every((call) => call.passed),
    ...(matrixError ? { error: matrixError } : {}),
    ...(matrixDiagnostics ? { diagnostics: matrixDiagnostics } : {}),
    calls,
  };
  if (output) fs.writeFileSync(output, JSON.stringify(result, null, 2) + "\n");
  console.log(JSON.stringify(result));
  if (!result.passed) process.exitCode = 1;
}

async function main() {
  if (!Number.isInteger(runCount) || runCount < 1) throw new Error("JD_VERIFY_RUNS must be a positive integer");
  const fixtures = readFixtures();
  const browser = await chromium.launch({
    executablePath: browserPath,
    headless: process.env.JD_VERIFY_HEADED !== "1",
    args: ["--autoplay-policy=no-user-gesture-required"],
  });
  if (identityOnly) {
    const page = await browser.newPage({ baseURL, viewport: { width: 1440, height: 1050 } });
    try {
      const callId = await openCall(page, fixtures, false);
      await playTurn(page, identityFixture, "need", "verify");
      const snapshot = await readCall(page, callId);
      assert.equal(snapshot.verified, true);
      assert.equal(snapshot.receipt_count, 0);
      const result = {
        mode: "spoken_identity_only", passed: true,
        transcript: await page.locator('#messages [data-role="merchant"] p').last().innerText(),
        state: snapshot.state, verified: snapshot.verified, receipt_count: snapshot.receipt_count,
        fixture_sha256: fixtures[identityFixture].sha256,
      };
      await hangUpCall(page, callId);
      if (output) fs.writeFileSync(output, JSON.stringify(result, null, 2) + "\n");
      console.log(JSON.stringify(result));
    } catch (error) {
      console.error(JSON.stringify(await diagnostics(page), null, 2));
      throw error;
    } finally {
      await page.close();
      await browser.close();
    }
    return;
  }
  if (caseMatrix) {
    try {
      await runCaseMatrix(browser, fixtures);
    } finally {
      await browser.close();
    }
    return;
  }
  const calls = [];
  const pageOptions = { baseURL, viewport: { width: 1440, height: 1050 } };
  let identity;
  try {
    if (rsi) {
      const page = await browser.newPage(pageOptions);
      try {
        identity = await verifyWrongCode(page, fixtures);
      } catch (error) {
        identity = { passed: false, fixture: "wrong", error: error.message, diagnostics: await diagnostics(page) };
        console.error(JSON.stringify(identity, null, 2));
      } finally {
        await page.close();
      }
      console.error(`Wrong-code browser call: ${identity.passed ? "PASS" : "FAIL"}`);
    }
    for (let index = 0; index < runCount; index++) {
      const interruptFixture = interruptFixtures[index % interruptFixtures.length];
      const page = await browser.newPage(pageOptions);
      const call = { index: index + 1, interrupt_fixture: interruptFixture };
      try {
        call.acceptance = await verifyCall(page, fixtures, interruptFixture);
        call.passed = true;
      } catch (error) {
        call.passed = false;
        call.error = error.message;
        call.diagnostics = await diagnostics(page);
        console.error(JSON.stringify({ index: call.index, error: call.error, ...call.diagnostics }, null, 2));
      } finally {
        if (benchmark) call.turns = await measuredTurns(page);
        calls.push(call);
        if (screenshot) await page.screenshot({ path: screenshot, fullPage: true });
        await page.close();
      }
      if (benchmark) console.error(`Browser call ${call.index}/${runCount}: ${call.passed ? "PASS" : "FAIL"}`);
    }
  } finally {
    await browser.close();
  }

  if (benchmark) {
    const turns = calls.flatMap((call) => call.turns);
    const phases = ["verify", "reason", "interrupt", "confirm"];
    const latency = (rows, planned) => stats(rows.map((turn) => turn.browser_render_ms), planned);
    const expected = turns.flatMap((turn) => turn.expected_terms);
    const recognized = turns.flatMap((turn) => turn.recognized_terms);
    const plannedTerms = calls.flatMap((call) => expectedTerms[call.interrupt_fixture]);
    const result = {
      base_url: baseURL,
      browser_version: browser.version(),
      fixture_sha256: Object.fromEntries(Object.entries(fixtures).map(([name, file]) => [name, file.sha256])),
      measurement: "Scheduled end of last 20 ms fixture block above input RMS to first 10 ms rendered WebRTC output block above output RMS after that turn's speaking event; linear percentiles of observed timings, including partial calls",
      input_rms: inputRms,
      output_rms: outputRms,
      requested_calls: runCount,
      passed_calls: calls.filter((call) => call.passed).length,
      failed_calls: calls.filter((call) => !call.passed).length,
      browser_render_ms: {
        overall: latency(turns, runCount * phases.length),
        by_phase: Object.fromEntries(phases.map((phase) => [
          phase, latency(turns.filter((turn) => turn.phase === phase), runCount),
        ])),
      },
      barge_in_to_mute_ms: stats(turns.map((turn) => turn.barge_in_to_mute_ms), runCount),
      term_hits: {
        recognized: recognized.length,
        expected: expected.length,
        planned: plannedTerms.length,
        by_term: Object.fromEntries([...new Set(Object.values(expectedTerms).flat())].map((term) => [
          term, { recognized: recognized.filter((value) => value === term).length,
            expected: expected.filter((value) => value === term).length,
            planned: plannedTerms.filter((value) => value === term).length },
        ])),
      },
      calls,
      ...(rsi ? { identity } : {}),
    };
    if (output) fs.writeFileSync(output, JSON.stringify(result, null, 2) + "\n");
    console.log(JSON.stringify(result));
  } else {
    for (const call of calls) if (call.passed) console.log(JSON.stringify(call.acceptance));
  }
  if (calls.some((call) => !call.passed) || identity?.passed === false) process.exitCode = 1;
}

module.exports = { installFixtureMicrophone, waitForReplyToFinish, waitForAutoClose, readCall, selectWorkOrder, browserPath, stats, milliseconds };
if (require.main === module) {
  main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
}
