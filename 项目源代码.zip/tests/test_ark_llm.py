import json
import unittest
from unittest.mock import patch

from jd_mock.ark_llm import ArkTransport


MODEL = "doubao-seed-2-1-pro-260915"
KEY = "mock-test-key"
MESSAGES = [{"role": "system", "content": "请只输出选项编码。"}, {"role": "user", "content": "模拟商家发言"}]
CHOICES = ("A", "B/-", "Z")


def provider_body(content, finish_reason="stop"):
    return json.dumps({"choices": [{"message": {"content": content}, "finish_reason": finish_reason}]}).encode()


class ArkTransportTests(unittest.TestCase):
    def setUp(self):
        self.transport = ArkTransport(KEY, MODEL)
        self.https = self.enterContext(patch("jd_mock.ark_llm.HTTPSConnection"))
        self.connection = self.https.return_value
        self.response = self.connection.getresponse.return_value
        self.response.status = 200

    def test_env_defaults_and_override(self):
        env = {"ARK_API_KEY": KEY, "JD_ARK_MODEL": MODEL}
        with patch.dict("os.environ", env, clear=True):
            transport = ArkTransport.from_env()
        self.assertEqual((transport.provider, transport.model, transport.timeout), ("doubao", MODEL, 6.0))
        with patch.dict("os.environ", {**env, "JD_ARK_TIMEOUT": "2.5"}, clear=True):
            self.assertEqual(ArkTransport.from_env().timeout, 2.5)

    def test_env_rejects_missing_credentials_model_or_invalid_timeout(self):
        env = {"ARK_API_KEY": KEY, "JD_ARK_MODEL": MODEL}
        invalid = [{"ARK_API_KEY": ""}, {"JD_ARK_MODEL": " "}]
        invalid.extend({"JD_ARK_TIMEOUT": value} for value in ("NaN", "inf", "no", "0", "-1"))
        for override in invalid:
            with self.subTest(override=override), patch.dict("os.environ", {**env, **override}, clear=True):
                with self.assertRaises(ValueError) as error:
                    ArkTransport.from_env()
                self.assertNotIn(KEY, str(error.exception))
        self.https.assert_not_called()

    def test_posts_schema_and_returns_the_exact_choice(self):
        self.response.read.return_value = provider_body('{"choice":"B/-"}')
        self.assertEqual(self.transport.complete(MESSAGES, CHOICES), "B/-")
        self.https.assert_called_once_with("ark.cn-beijing.volces.com", timeout=6.0)
        method, path, body, headers = self.connection.request.call_args.args
        self.assertEqual((method, path), ("POST", "/api/v3/chat/completions"))
        self.assertEqual(headers, {"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
        payload = json.loads(body)
        self.assertEqual(payload["model"], MODEL)
        self.assertEqual(payload["thinking"], {"type": "disabled"})
        self.assertEqual(payload["messages"][1], MESSAGES[1])
        self.assertIn("JSON", payload["messages"][0]["content"])
        self.assertEqual(MESSAGES[0]["content"], "请只输出选项编码。")
        response_format = payload["response_format"]
        self.assertEqual(response_format["type"], "json_schema")
        self.assertTrue(response_format["json_schema"]["strict"])
        self.assertEqual(response_format["json_schema"]["schema"], {
            "type": "object", "required": ["choice"], "additionalProperties": False,
            "properties": {"choice": {"type": "string", "enum": list(CHOICES)}},
        })
        self.connection.close.assert_called_once()

    def test_rejects_invalid_or_oversized_output(self):
        for wire in (
            provider_body('{"choice":"Q"}'), provider_body('{"choice":"B/- "}'),
            provider_body('{"choice":"A","other":"no"}'), provider_body('{"choice":"Z","choice":"A"}'),
            provider_body(['A']), provider_body('{"choice":"A"}', "length"),
            provider_body(KEY), b"{" + b" " * 65_536,
        ):
            with self.subTest(wire_length=len(wire)):
                self.response.read.return_value = wire
                with self.assertRaises(ValueError) as error:
                    self.transport.complete(MESSAGES, CHOICES)
                self.assertNotIn(KEY, str(error.exception))
                self.assertNotIn(MESSAGES[1]["content"], str(error.exception))

    def test_sanitizes_provider_rejection_and_timeout(self):
        self.response.status = 401
        with self.assertRaises(OSError) as error:
            self.transport.complete(MESSAGES, CHOICES)
        self.assertIn("401", str(error.exception))
        self.response.read.assert_not_called()
        self.connection.request.side_effect = TimeoutError(KEY)
        with self.assertRaises(TimeoutError) as error:
            self.transport.complete(MESSAGES, CHOICES)
        self.assertNotIn(KEY, str(error.exception))
        self.assertEqual(self.connection.close.call_count, 2)
