"""Generate Sherpa WAVs for the authorization expiry and legal ID cases."""

import argparse
from pathlib import Path
import wave

import numpy as np

from jd_mock.speech import SpeechEngine
from jd_mock.speech_assets import DEFAULT_ASSET_DIR


PHRASES = {
    "expiry_reason": "这份授权书为什么被驳回？",
    "expiry_upload": "新的销售授权书要上传到哪里？",
    "legal_reason": "为什么我上传的法人证件没有通过？",
    "legal_upload": "请问法人的身份证应该在哪里上传？",
    "reoffer": "接下来我具体要怎么改？",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(".runtime/additional-work-orders/fixtures"))
    output = parser.parse_args().output
    output.mkdir(parents=True, exist_ok=True)
    engine = SpeechEngine(DEFAULT_ASSET_DIR)
    for name, phrase in PHRASES.items():
        audio, rate = engine.synthesize(phrase)
        pcm = (np.clip(audio, -1, 1) * 32767).astype("<i2")
        with wave.open(str(output / f"{name}.wav"), "wb") as recording:
            recording.setparams((1, 2, rate, 0, "NONE", "not compressed"))
            recording.writeframes(pcm.tobytes())


if __name__ == "__main__":
    main()
