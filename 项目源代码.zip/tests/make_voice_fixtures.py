"""Generate synthetic merchant audio for the browser acceptance runner."""

import argparse
import shutil
import wave
from pathlib import Path

import numpy as np

from jd_mock.speech import SpeechEngine
from jd_mock.speech_assets import DEFAULT_ASSET_DIR


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-matrix", action="store_true")
    parser.add_argument("--legacy-rsi", action="store_true", help="Generate the archived four-digit identity protocol in a separate directory.")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--only", nargs="+", help="Generate only these fixture names.")
    parser.add_argument("--reuse-business", type=Path, help="Reuse existing non-identity WAVs for unchanged business phrases, generating any missing files.")
    options = parser.parse_args()
    if options.legacy_rsi and options.case_matrix:
        parser.error("--legacy-rsi and --case-matrix use different identity protocols")
    destination = options.output or DEFAULT_ASSET_DIR.parent / (
        "legacy-rsi-fixtures" if options.legacy_rsi else
        "identity-v2-matrix-fixtures" if options.case_matrix else "identity-v2-fixtures"
    )
    destination.mkdir(parents=True, exist_ok=True)
    phrases = {
        "identity_yes": "是的，我是商家小贝塔。",
        "identity_no": "不是，我不是商家小贝塔。",
        "identity_ambiguous": "我不太确定，你先说什么事情。",
        "identity_digits": "四八二六。",
        "reason": "是的，我想了解原因。",
        "interrupt": "等一下，鞋类在哪里选？",
        "interrupt_alt": "等一下，我在哪里选授权类目？",
        "interrupt_both": "我想选鞋类，要到哪里修改授权类目？",
        "confirm": "我确认按步骤修改后重新提交。",
    }
    if options.case_matrix:
        phrases = {
            **{name: phrase for name, phrase in phrases.items() if name.startswith("identity_")},
            "reason": phrases["reason"],
            "matrix_question": "我到底要改什么？",
            "matrix_negative": "我不确认，也不打算重新提交。",
            "matrix_confirm": phrases["confirm"],
            "matrix_confirm_retry": "我同意按步骤修改后重新提交。",
            "matrix_undecided": "我还没有决定，请再解释一下。",
            "recipient_repeat": "是的，我是本人。",
            "stamp_already": "我已经盖过公章了。",
            "stamp_ours": "是我们自己的。",
            "stamp_ack": "是的。",
            "review_outcome": "盖好公章就一定能通过审核吗？",
        }
    if options.legacy_rsi:
        phrases = {name: phrase for name, phrase in phrases.items() if not name.startswith("identity_")}
        phrases.update(wrong="一二三四。", verify="我的验证码是四八二六。")
    if options.only:
        unknown = set(options.only) - phrases.keys()
        if unknown:
            parser.error("Unknown fixtures: " + ", ".join(sorted(unknown)))
        phrases = {name: phrases[name] for name in options.only}
    speech = None
    for name, phrase in phrases.items():
        group = "merchant_identity" if name.startswith("identity_") else "merchant_dialogue"
        pinned = Path(__file__).resolve().parent / "fixtures" / group / (name + ".wav")
        if pinned.is_file():
            destination_file = destination / (name + ".wav")
            if pinned.resolve() != destination_file.resolve():
                shutil.copy2(pinned, destination_file)
            continue
        reusable = options.reuse_business / (name + ".wav") if options.reuse_business else None
        if not name.startswith("identity_") and reusable and reusable.is_file():
            destination_file = destination / (name + ".wav")
            if reusable.resolve() != destination_file.resolve():
                shutil.copy2(reusable, destination_file)
            continue
        if speech is None:
            speech = SpeechEngine(DEFAULT_ASSET_DIR)
        samples, rate = speech.synthesize(phrase)
        pcm = (np.clip(samples, -1, 1) * 32767).astype("<i2")
        with wave.open(str(destination / (name + ".wav")), "wb") as output:
            output.setparams((1, 2, rate, 0, "NONE", "not compressed"))
            output.writeframes(pcm.tobytes())
    print(f"Prepared {len(phrases)} test recordings in {destination}")


if __name__ == "__main__":
    main()
