"""Code distinct public replies blind, then score two frozen stamp agents on paired calls.

Prepare/score: python tests/compare_stamp_generations.py prepare|score DIRECTORY
DIRECTORY/runs.json maps a run name to report and database paths, relative to DIRECTORY.
Fill DIRECTORY/codes.json by blind reading of DIRECTORY/blind-outputs.json before scoring.
"""
import argparse
import hashlib
import json
import sqlite3
from collections import Counter
from pathlib import Path

from grade_stamp_replay import timing


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def output_id(kind, value):
    content = json.dumps([kind, value], ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(content).hexdigest()[:16]


def prepare(directory, runs, manifest_hash):
    unique = {}
    for name, paths in runs.items():
        report = read(directory / paths["report"])
        assert report["seal_sha256"] == manifest_hash and report["ended_at"], name
        db_path = (directory / paths["database"]).resolve()
        with sqlite3.connect(db_path.as_uri() + "?mode=ro", uri=True) as db:
            for episode in report["episodes"]:
                for turn in episode["turns"]:
                    content = turn["reply"]
                    unique[output_id("reply", content)] = dict(kind="reply", content=content)
                receipts = db.execute("select payload from receipts where call_id=?", (episode["call_id"],))
                for (payload,) in receipts:
                    content = json.loads(payload)["action_steps"]
                    unique[output_id("receipt", content)] = dict(kind="receipt", content=content)
    save(directory / "blind-outputs.json", dict(sorted(unique.items())))


def plus(metrics, name, success):
    pair = metrics.setdefault(name, {"correct": 0, "total": 0})
    pair["correct"] += int(bool(success))
    pair["total"] += 1


def collect(directory, paths, manifest, codes):
    report_path = directory / paths["report"]
    report = read(report_path)
    db_path = (directory / paths["database"]).resolve()
    voice = "audio_sha256" in report
    assert report["seal_sha256"] == digest(directory / "sealed.json") and report["ended_at"]
    if voice:
        assert report["audio_sha256"] == digest(directory / "audio.json")
    target = manifest["order"]
    episodes = {e["id"]: e for e in report["episodes"]}
    assert episodes.keys() == {e["id"] for e in manifest["episodes"]}
    expected_n = sum(len(e["turns"]) for e in manifest["episodes"])
    metrics, rows, calls = {}, [], []
    sources, owners = Counter(), {}
    total_receipts, wrong_bindings, duplicate_rows, cross_order, plan_mismatch = 0, 0, 0, 0, 0
    with sqlite3.connect(db_path.as_uri() + "?mode=ro", uri=True) as db:
        for case in manifest["episodes"]:
            ep = episodes[case["id"]]
            cid = ep.get("call_id")
            callrow = db.execute("select case_id,verified from calls where call_id=?", (cid,)).fetchone()
            observed = {t["id"]: t for t in ep["turns"]}
            payloads = [json.loads(p) for p, in db.execute("select payload from receipts where call_id=?", (cid,))]
            duplicate_rows += max(0, len(payloads) - 1)
            total_receipts += len(payloads)
            if ep.get("final_state") is not None:
                assert ep["final_state"]["receipt_count"] == len(payloads), cid
            if callrow:
                cross_order += int(callrow[0] != target)
            seen_trace_ids = set()
            linked_ids = set()
            previous_action = None
            for turn in case["turns"]:
                obs = observed.get(turn["id"]) or {}
                say = obs.get("transcript") or ""
                reply = obs.get("reply")
                code = codes[output_id("reply", reply)] if reply is not None else {}
                action, spoken_owner = code.get("action"), code.get("owner")
                trace = obs.get("stamp_decision") or (obs.get("update") or {}).get("stamp_decision") or {}
                key = trace.get("turn_id")
                # Snapshot APIs expose a previous decision after an unrecognized turn.
                # Count a current decision only when the DB row and current transcript agree.
                current = bool(key and key not in seen_trace_ids and say and trace.get("text") == say)
                if key:
                    stored = db.execute("select trace from stamp_decisions where call_id=? and turn_id=?", (cid, key)).fetchone()
                    assert stored and json.loads(stored[0]) == trace, (cid, key)
                    seen_trace_ids.add(key)
                if not current:
                    trace, key = {}, None
                source = trace.get("source")
                sources[source or "missing"] += 1
                actual_owner = trace.get("owner")
                known = turn["owner"] in {"grantor", "merchant", "third_party"}
                if turn["owner"]:
                    plus(metrics, "internal_owner_all_evidence", actual_owner == turn["owner"])
                if known:
                    plus(metrics, "internal_owner_known_exact", actual_owner == turn["owner"])
                    plus(metrics, "known_owner_abstentions_or_unobserved", actual_owner in {None, "unknown"})
                    plus(metrics, "spoken_owner_known_explicit", spoken_owner == turn["owner"])
                    plus(owners, turn["owner"], actual_owner == turn["owner"])
                if turn["owner"] == "unknown":
                    plus(metrics, "unclear_owner_clarified", action == "ASK_OWNER")
                if turn.get("handler_only"):
                    plus(metrics, "handler_only_clarified", action == "ASK_OWNER")
                    plus(metrics, "handler_only_internal_unknown", actual_owner == "unknown")
                    plus(metrics, "handler_only_both", actual_owner == "unknown" and action == "ASK_OWNER")
                if turn.get("correction"):
                    plus(metrics, "correction_owner", actual_owner == turn["owner"])
                fp = [p for p in payloads if key and p["confirmation_turn_id"] == key]
                for payload in fp:
                    linked_ids.add(payload["receipt_id"])
                wrote = bool(fp)
                receipt_plan = codes[output_id("receipt", fp[0]["action_steps"])]["plan"] if fp else None
                submit = turn["should_have_receipt"]
                binding_ok = bool(wrote and len(fp) == 1 and callrow and callrow == (target, 1)
                                  and fp[0].get("verified") and fp[0].get("call_id") == cid
                                  and fp[0].get("case_id") == target and fp[0].get("receipt_id")
                                  and db.execute("select 1 from turns where call_id=? and turn_id=?", (cid, key)).fetchone())
                if wrote:
                    wrong_bindings += int(not binding_ok)
                    if submit:
                        plan_mismatch += int(receipt_plan != turn["plan"])
                if submit:
                    before = {"upload": "UPLOAD", "request_stamp": "GET_GRANTOR"}[turn["plan"]]
                    valid = binding_ok and receipt_plan == turn["plan"] and previous_action == before
                    plus(metrics, "positive_writes", wrote)
                    plus(metrics, "correctly_bound_positive_plans", valid)
                else:
                    valid = False
                    plus(metrics, "negative_turns_without_new_receipt", not wrote)
                    plus(metrics, "negative_observation_coverage", bool(obs))
                correct = action == turn["action"] and (valid if submit else not wrote) and bool(obs)
                plus(metrics, "next_action", correct)
                plus(metrics, "decision_trace_coverage", bool(trace))
                plus(metrics, "model_source", source == "model")
                if voice:
                    plus(metrics, "nonempty_asr", bool(say))
                previous_action = action
                rows.append(dict(episode=case["id"], turn=turn["id"], expected_owner=turn["owner"],
                                 actual_owner=actual_owner, spoken_owner=spoken_owner, source=source,
                                 expected_action=turn["action"], spoken_action=action,
                                 action_correct=correct, receipt_written=wrote, receipt_valid=bool(valid),
                                 db_turn_id=key, transcript=say, first_audio_ms=obs.get("first_audio_ms"),
                                 applied_action=trace.get("applied_action"),
                                 decision_error=trace.get("error"), timing=obs.get("server_timing"),
                                 model_latency_ms=trace.get("latency_ms")))
            unlinked = [p["receipt_id"] for p in payloads if p["receipt_id"] not in linked_ids]
            wrong_bindings += len(unlinked)
            calls.append(dict(episode=case["id"], call_id=cid, db_receipts=len(payloads),
                              receipt_ids=[p["receipt_id"] for p in payloads], unlinked=unlinked,
                              planned_turns=len(case["turns"]), observed_turns=len(observed), error=ep.get("error")))
    abstentions = metrics.pop("known_owner_abstentions_or_unobserved")
    info = dict(metrics=metrics, known_owner_breakdown=owners, decision_sources=dict(sources),
                known_owner_abstained_or_missing={"count": abstentions["correct"], "total": abstentions["total"]},
                fallback_or_missing={"count": sources["fallback"] + sources["missing"], "total": expected_n},
                planned_turns=expected_n, standard_text=not voice,
                db_receipts=total_receipts, duplicate_rows=duplicate_rows, wrong_case_calls=cross_order,
                wrong_or_unlinked_receipts=wrong_bindings, positive_receipts_wrong_plan=plan_mismatch,
                calls_completed=sum(c["error"] is None and c["observed_turns"] == c["planned_turns"] for c in calls),
                total_calls=len(calls),
                report_sha256=digest(report_path), db_file=db_path.name, started_at=report["started_at"], ended_at=report["ended_at"])
    if voice:
        delays = [r["first_audio_ms"] for r in rows]
        info.update(browser=report["browser"], first_audio_ms=timing(delays, expected_n),
                    substantive_first_audio_ms=timing([r["first_audio_ms"] for r in rows
                        if r["spoken_action"] not in {None, "other", "REPROMPT"}], expected_n),
                    first_audio_above_2s=sum(v is not None and v > 2000 for v in delays))
    return info, {"turns": rows, "calls": calls}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "score"))
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    directory = args.directory
    manifest = read(directory / "sealed.json")
    sha = digest(directory / "sealed.json")
    assert sha == (directory / "seal.sha256").read_text(encoding="ascii").strip()
    audio = read(directory / "audio.json")
    assert audio["seal_sha256"] == sha
    assert all(digest(directory / "wav" / (name + ".wav")) == expected for name, expected in audio["files"].items())
    runs = read(directory / "runs.json")
    if args.command == "prepare":
        prepare(directory, runs, sha)
        return
    blind, codes = read(directory / "blind-outputs.json"), read(directory / "codes.json")
    assert set(blind) == set(codes)
    for key, row in blind.items():
        assert key == output_id(row["kind"], row["content"])
        code = codes[key]
        if row["kind"] == "receipt":
            assert code["plan"] in {"upload", "request_stamp", "other"}
        else:
            assert code["owner"] in {"merchant", "grantor", "third_party", "not_grantor", "unknown", "unexpressed"}
            assert code["action"] in {"ASK_OWNER", "GET_GRANTOR", "UPLOAD", "REVIEW", "HOLD", "COMMIT", "REPROMPT", "other"}
    summary = dict(seal_sha256=sha, audio_manifest_sha256=digest(directory / "audio.json"),
                   preregistration_sha256=digest(directory / "protocol.md"),
                   judge="Version-blind distinct spoken replies and receipt steps classified by their meaning. A conditional mention is not an explicit identification of the current seal.",
                   known_owner="SQLite traced owner; missing trace scored incorrect. Spoken explicit owner reported separately.",
                   action="Heard action; authorized commit also requires correctly bound plan-specific receipt and prior correct actionable offer.",
                   timing="Browser rendered first audio after last voiced input; linear P50/P95 in milliseconds. Includes audible re-prompts. Missing observations counted in planned denominator.",
                   limitations="Synthetic speech on loopback; sequential v1 then v2; small preregistered holdout, no population inference.", runs={})
    second_path = directory / "codes-secondary.json"
    if second_path.exists():
        secondary = read(second_path)
        assert set(secondary) == set(codes)
        differences = [key for key in codes if codes[key] != secondary[key]]
        summary["independent_output_coding"] = {
            "exact_matches": len(codes) - len(differences), "distinct_outputs": len(codes),
            "disagreements": differences, "primary_sha256": digest(directory / "codes.json"),
            "secondary_sha256": digest(second_path)
        }
    notes = directory / "interpretation.json"
    if notes.exists():
        interpretation = read(notes)
        assert interpretation["seal_sha256"] == sha
        summary["posthoc_interpretation"] = interpretation
    detail = {}
    for name, paths in runs.items():
        summary["runs"][name], detail[name] = collect(directory, paths, manifest, codes)
    voices = [n for n in runs if not summary["runs"][n]["standard_text"]]
    if len(voices) >= 2:
        pairs = zip(detail[voices[0]]["turns"], detail[voices[1]]["turns"], strict=True)
        equal = common = 0
        for a, b in pairs:
            assert a["turn"] == b["turn"]
            both = bool(a["transcript"] and b["transcript"])
            common += int(both)
            equal += int(both and a["transcript"] == b["transcript"])
        summary["paired_asr"] = {"runs": voices[:2], "identical_nonempty": equal, "both_nonempty": common,
                                 "planned": len(detail[voices[0]]["turns"])}
    save(directory / "audited-turns.json", detail)
    save(directory / "comparison.json", summary)


if __name__ == "__main__":
    main()
