import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path
from threading import Barrier

from jd_mock.business import Store


class StoreTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.db_path = Path(directory.name) / "calls.sqlite3"
        self.store = Store(self.db_path)
        call = self.store.start_call()
        self.call_id = call["call_id"]

    def turn(self, text, turn_id, **kwargs):
        return self.store.turn(self.call_id, text, turn_id, **kwargs)

    def open_explanation(self):
        self.turn("我是商家小贝塔", "verify")
        return self.turn("我想了解为什么被驳回", "need")

    def test_opening_and_ambiguous_replies_ask_the_same_identity_question(self):
        question = "请问您是否是商家小贝塔？"
        opening = self.store.get_call(self.call_id)
        self.assertIn("AI", opening["reply"])
        self.assertTrue(opening["reply"].endswith(question))
        self.assertEqual(opening["state"], "verify")
        for n, text in enumerate(("0826", "4826", "零八二六", "我的验证码是四八二六",
                                  "小贝塔", "商家小贝塔", "您是找小贝塔吗", "是我吗？", "是的？",
                                  "我不确定", "你是说是不是小贝塔", "是不是打错电话了？", "你是谁",
                                  "我还没听清", "应该是吧", "我认识商家小贝塔", "这单怎么改", "我叫")):
            with self.subTest(text=text):
                result = self.turn(text, str(n))
                self.assertEqual(result["state"], "verify")
                self.assertFalse(result["verified"])
                self.assertEqual(result["reply"], question)
                self.assertEqual(result["receipt_count"], 0)

    def test_refusing_verification_closes_without_disclosure(self):
        result = self.turn("我不方便确认身份", "decline")
        self.assertEqual(result["state"], "closed")
        self.assertFalse(result["verified"])
        self.assertNotIn("销售授权书", result["reply"])
        self.assertIsNone(result["receipt"])

    def test_verified_merchant_can_ask_a_question_in_the_same_breath(self):
        result = self.turn("是的，我是商家小贝塔，我想了解为什么被驳回", "verify")
        self.assertTrue(result["verified"])
        self.assertEqual(result["state"], "explain")
        self.assertIn("鞋类", result["reply"])
        self.assertEqual(result["receipt_count"], 0)

    def test_explanation_gives_authorized_category_selection_and_answers_followup(self):
        explanation = self.open_explanation()
        self.assertEqual(explanation["state"], "explain")
        for fact in ("服装", "鞋类"):
            self.assertIn(fact, explanation["reply"])
        self.assertNotIn("第三", explanation["reply"])
        self.assertLess(len(explanation["reply"]), 95)
        answer = self.turn("这样就能通过吗？", "followup")
        self.assertIn("复审", answer["reply"])
        self.assertEqual(answer["state"], "explain")
        self.assertEqual(answer["receipt_count"], 0)

    def test_contextual_request_to_explain_the_reason(self):
        self.turn("我就是", "verify")
        result = self.turn("我想了解原因", "ask-reason")
        self.assertEqual(result["state"], "explain")
        self.assertIn("销售授权书", result["reply"])

    def test_barge_in_location_answer_gives_the_entry_in_a_short_first_sentence(self):
        self.open_explanation()
        answer = self.turn("等一下，鞋类在哪里选？", "barge-in")
        first_sentence = answer["reply"].split("。", 1)[0]
        self.assertIn("销售授权书下方", first_sentence)
        self.assertLessEqual(len(first_sentence), 18)
        self.assertTrue(any(step in answer["reply"] for step in ("有经营范围限制", "选择授权类目")))
        self.assertEqual(answer["receipt_count"], 0)

    def test_busy_merchant_can_end_without_commitment(self):
        self.turn("是的我是本人", "id")
        reply = self.turn("我在开会，现在不方便接电话", "busy")
        self.assertEqual((reply["state"], reply["receipt_count"]), ("closed", 0))
        self.assertNotIn("重新提交", reply["reply"])

    def test_stamp_diagnosis_remembers_answer_and_never_treats_it_as_consent(self):
        case_id = self.store.start_call("JD-DEMO-002")["call_id"]
        self.store.turn(case_id, "是的我是本人", "id")
        asked = self.store.turn(case_id, "我已经盖过章了", "stamped")
        self.assertRegex(asked["reply"], "谁|哪家|哪一方|哪.*章|哪.*公司|还是")
        with self.subTest("duplicate turn leaves the same question pending"):
            self.assertEqual(self.store.turn(case_id, "我已经盖过章了", "stamped"), asked)
        reopened = Store(self.db_path)
        stated = reopened.turn(case_id, "我们自己的", "answer")
        self.assertIn("青禾品牌公司", stated["reply"])
        self.assertEqual(stated["receipt_count"], 0)
        self.assertNotEqual(asked["reply"], stated["reply"])

    def test_short_acknowledgment_of_the_page_is_not_writeback_agreement(self):
        self.turn("是的我是本人", "id")
        self.turn("我找不到入口", "where")
        answer = self.turn("确认", "ack-page")
        self.assertEqual((answer["state"], answer["receipt_count"]), ("explain", 0))

    def test_hypothetical_or_postponed_confirmation_cannot_write(self):
        self.open_explanation()
        for n, text in enumerate(("我确认之前还要再看看怎么重新提交", "我想先考虑一下再说", "我确认身份，不是确认重新提交")):
            self.assertEqual(self.turn(text, str(n))["receipt_count"], 0)

    def test_natural_yes_binds_to_the_last_question(self):
        def reach_decision():
            call_id = self.store.start_call()["call_id"]
            for n, text in enumerate(("是的我是本人", "我想先卖鞋类", "那下一步呢")):
                answer = self.store.turn(call_id, text, str(n))
            self.assertIn("？", answer["reply"])
            return call_id

        call_id = reach_decision()
        agreed = self.store.turn(call_id, "行，就这么办", "agree", simulate_timeout=True)
        self.assertTrue(agreed["pending_writeback"])
        self.assertEqual(self.store.retry_writeback(call_id)["receipt_count"], 1)
        other = reach_decision()
        self.store.turn(other, "那就一定能过吗", "review")
        self.assertEqual(self.store.turn(other, "是的", "ack")["receipt_count"], 0)

    def test_negative_or_ambiguous_response_does_not_write_back(self):
        self.open_explanation()
        answers = (
            "我不确认",
            "好的",
            "我确认这样就一定能过吗？",
            "确认后在哪里重新提交",
            "如果能通过我确认修改后重新提交",
            "我会考虑重新提交",
            "我会再决定要不要重新提交",
        )
        for turn_id, answer in enumerate(answers):
            result = self.turn(answer, str(turn_id))
            self.assertEqual(result["state"], "explain")
            self.assertEqual(result["receipt_count"], 0)

    def test_reapplication_without_changes_does_not_write_back(self):
        for answer in (
            "我确认先不修改，直接重新提交。",
            "我确认无需调整，直接重提。",
            "我确认按原样重新提交。",
        ):
            with self.subTest(answer=answer):
                self.call_id = self.store.start_call()["call_id"]
                self.open_explanation()
                result = self.turn(answer, "skip-changes")
                self.assertEqual((result["state"], result["receipt_count"]), ("explain", 0))

        self.call_id = self.store.start_call()["call_id"]
        self.open_explanation()
        result = self.turn("我确认修改好后直接重新提交。", "after-changes")
        self.assertEqual((result["state"], result["receipt_count"]), ("complete", 1))

    def test_explicit_affirmations_advance_only_to_need(self):
        for text in ("是", "是的", "对", "我是", "我是商家小贝塔", "是的我是", "我就是",
                     "嗯，是我本人", "对，我就是小贝塔", "是的，我是本人", "我叫小贝塔"):
            with self.subTest(text=text):
                call_id = self.store.start_call()["call_id"]
                answer = self.store.turn(call_id, text, "identity")
                self.assertEqual((answer["state"], answer["verified"]), ("need", True))
                self.assertIn("销售授权书只覆盖鞋类", answer["reply"])
                self.assertNotIn("您打算按这个办法处理吗", answer["reply"])
                self.assertEqual(answer["receipt_count"], 0)

    def test_denying_identity_and_answering_for_another_person_close_privately(self):
        for text in ("不是", "不是本人", "我不是商家小贝塔", "不是小贝塔", "不是商家小贝塔",
                     "我不是，你打错人了", "是的，您打错了", "你找错人了",
                     "不是我，我帮他接的", "我是小贝塔的同事", "是的我是他同事代接",
                     "我叫小林", "我是商家小林", "小贝塔不在，是我代接的", "不是，我想了解驳回原因"):
            with self.subTest(text=text):
                call_id = self.store.start_call()["call_id"]
                reply = self.store.turn(call_id, text, "decline")
                self.assertEqual((reply["state"], reply["verified"], reply["receipt_count"]), ("closed", False, 0))
                self.assertNotIn("销售授权书", reply["reply"])
                self.assertEqual(self.store.turn(call_id, "是的", "late"), reply)

    def test_short_assent_before_plan_playback_ends_replays_both_rule_plans(self):
        for case_id in ("JD-DEMO-001", "JD-DEMO-003"):
            with self.subTest(case_id=case_id):
                call = self.store.start_call(case_id)["call_id"]
                self.store.turn(call, "我是本人", "identity")
                words = "只卖鞋类" if case_id == "JD-DEMO-001" else "下一步呢"
                plan = self.store.turn(call, words, "plan")
                self.assertIn("您打算按这个办法处理吗？", plan["reply"])
                early = self.store.turn(call, "好的", "early", delivered_reply="")
                self.assertEqual(early["receipt_count"], 0)
                self.assertEqual(early["reply"], plan["reply"])
                late = self.store.turn(call, "好的", "late", delivered_reply=early["reply"])
                self.assertEqual(late["receipt_count"], 1)

    def test_rule_tickets_bind_colloquial_commitments_to_the_current_plan(self):
        for case_id in ("JD-DEMO-001", "JD-DEMO-003"):
            for acceptance in ("行行，就这么处理。", "可以，照你说的来。", "好的，按刚才那套方案办。",
                               "没问题又这么定了。", "行，又这样定了。"):
                with self.subTest(case_id=case_id, acceptance=acceptance):
                    call = self.store.start_call(case_id)["call_id"]
                    self.store.turn(call, "我是本人", "identity")
                    words = "只卖鞋类" if case_id == "JD-DEMO-001" else "下一步呢"
                    plan = self.store.turn(call, words, "plan")["reply"]
                    early = self.store.turn(call, acceptance, "early", delivered_reply="")
                    self.assertEqual((early["receipt_count"], early["reply"]), (0, plan))
                    self.assertEqual(self.store.turn(call, acceptance, "later", delivered_reply=plan)["receipt_count"], 1)

    def test_corrected_text_cannot_manufacture_identity_or_consent(self):
        rejected = self.store.turn(self.call_id, "我是小贝塔", "not-me", raw_text="我不是小贝塔")
        self.assertFalse(rejected["verified"])
        self.call_id = self.store.start_call()["call_id"]
        self.turn("我是小贝塔", "identity")
        self.assertEqual(self.turn("好的", "choice-unclear")["receipt_count"], 0)
        plan = self.turn("只卖鞋类", "plan")["reply"]
        self.assertIn("您打算按这个办法处理吗？", plan)
        answer = self.turn("好的", "decline", delivered_reply=plan, raw_text="我不同意")
        self.assertEqual(answer["receipt_count"], 0)

    def test_recognized_reverse_chain_cannot_create_a_receipt(self):
        self.call_id = self.store.start_call("JD-DEMO-003")["call_id"]
        self.turn("我是小贝塔", "identity")
        self.turn("我到底要改什么", "instructions")
        self.turn("下一步呢", "more")
        plan = self.turn("下一步呢", "plan")["reply"]
        self.assertIn("您打算按这个办法处理吗？", plan)
        answer = self.turn(
            "我确认让星桥商贸公司授权给云杉品牌公司后重新提交", "reverse", delivered_reply=plan,
            raw_text="我确认让新桥上贸公司授权给云山品牌公司后重新提交",
        )
        self.assertEqual(answer["receipt_count"], 0)

    def test_rule_tickets_distinguish_future_commitment_from_reports_and_hesitation(self):
        for utterance in (
            "我同意重新提交，先别登记。",
            "我确认已经重新提交了。",
            "我同意，我先问问同事再重新提交。",
            "可以照你说的来吗？",
            "没问题又这么定了吗？",
            "又这么定了。",
            "好，如果老板同意我就按这个来。",
        ):
            with self.subTest(utterance=utterance):
                self.call_id = self.store.start_call()["call_id"]
                self.open_explanation()
                self.assertEqual(self.turn(utterance, "candidate-" + utterance)["receipt_count"], 0)

    def test_role_homophone_only_applies_to_explicit_identity_denial(self):
        for text, expected in (
            ("我不是上家小贝塔", "closed"),
            ("我确实不是上家小贝塔本人", "closed"),
            ("我不是商家小塔", "closed"),
            ("我不是商家小辈", "closed"),
            ("我不是商家小倍塔", "closed"),
            ("我不是商家小辈吗？", "verify"),
            ("你说我不是商家小辈", "verify"),
            ("我是商家小辈", "closed"),
            ("我不是商家小塔吗", "verify"),
            ("我是商家小塔", "closed"),
            ("我不是商家小林", "verify"),
            ("我不是上家小贝塔吗", "verify"),
            ("我不确定自己是不是上家小贝塔", "verify"),
            ("我不是上家小贝塔的同事", "verify"),
            ("我是上家小贝塔", "verify"),
            ("我不是小林", "verify"),
        ):
            with self.subTest(text=text):
                call_id = self.store.start_call()["call_id"]
                answer = self.store.turn(call_id, text, "identity")
                self.assertEqual((answer["state"], answer["verified"], answer["receipt_count"]),
                                 (expected, False, 0))
                self.assertNotIn("销售授权书", answer["reply"])

    def test_legacy_unverified_call_reconnects_with_current_question(self):
        for turns in (0, 2):
            with self.subTest(turns=turns):
                call_id = self.store.start_call()["call_id"]
                with closing(sqlite3.connect(self.db_path)) as connection, connection:
                    connection.execute("UPDATE calls SET turn_count=?, reply=? WHERE call_id=?",
                                       (turns, "请提供四位演示验证码。", call_id))
                pending = Store(self.db_path).get_call(call_id)
                self.assertTrue(pending["reply"].endswith("请问您是否是商家小贝塔？"))
                self.assertEqual("AI" in pending["reply"], turns == 0)
                self.assertEqual(pending["turn_count"], turns)
                self.assertFalse(pending["verified"])
                self.assertEqual(self.store.turn(call_id, "4826", "old-code")["state"], "verify")
                self.assertEqual(self.store.turn(call_id, "是的我是", "verify")["state"], "need")

    def test_replayed_turn_does_not_advance_current_call(self):
        verified = self.turn("对，我是", "verify")
        replayed = self.turn("是的", "verify")
        self.assertEqual(replayed, verified)
        self.assertEqual(self.turn("是的", "need")["state"], "explain")

    def test_confirmed_receipt_survives_timeout_and_retries(self):
        self.open_explanation()
        confirmation = "我确认按步骤修改后重新提交"
        timed_out = self.turn(confirmation, "agree", simulate_timeout=True)
        self.assertEqual(timed_out["state"], "complete")
        self.assertIsNone(timed_out["receipt"])
        self.assertTrue(timed_out["pending_writeback"])
        self.assertEqual(timed_out["receipt_count"], 1)
        self.assertEqual(self.turn(confirmation, "agree"), timed_out)

        reopened = Store(self.db_path)
        self.assertEqual(reopened.get_call(self.call_id), timed_out)
        recovered = reopened.retry_writeback(self.call_id)
        self.assertFalse(recovered["pending_writeback"])
        self.assertEqual(recovered["receipt_count"], 1)
        self.assertEqual(recovered["receipt"]["scenario"], "品牌类目不符")
        self.assertTrue(recovered["receipt"]["verified"])
        self.assertTrue(recovered["receipt"]["evidence_refs"])
        self.assertEqual(reopened.retry_writeback(self.call_id), recovered)
        self.assertEqual(reopened.turn(self.call_id, confirmation, "another-agree"), recovered)

    def test_concurrent_confirmation_creates_one_receipt(self):
        self.open_explanation()
        other_store = Store(self.db_path)
        barrier = Barrier(2)

        def submit(store, turn_id):
            barrier.wait(timeout=3)
            return store.turn(self.call_id, "我确认按步骤修改后重新提交", turn_id)

        with ThreadPoolExecutor(max_workers=2) as executor:
            first = executor.submit(submit, self.store, "agree-a")
            second = executor.submit(submit, other_store, "agree-b")
            first_result, second_result = first.result(), second.result()

        self.assertEqual(first_result, second_result)
        self.assertEqual(first_result["receipt_count"], 1)
        self.assertEqual(first_result["turn_count"], 3)

    def test_end_is_idempotent_and_prevents_further_changes(self):
        self.open_explanation()
        closed = self.store.end_call(self.call_id)
        self.assertEqual(closed["state"], "closed")
        self.assertEqual(closed["receipt_count"], 0)
        self.assertEqual(self.turn("我确认按步骤修改后重新提交", "late"), closed)
        self.assertEqual(self.store.end_call(self.call_id), closed)


if __name__ == "__main__":
    unittest.main()
