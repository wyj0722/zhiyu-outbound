import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from tools.compare_rsi_round import compare_round


class CompareRoundTest(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        baseline = self.write("baseline/jd_mock/speech.py", "baseline speech")
        self.write("candidate/jd_mock/speech.py", "candidate speech")
        settings = self.write("baseline/requirements.txt", "pinned dependencies")
        self.write("candidate/requirements.txt", "pinned dependencies")
        names = ("verify", "reason", "interrupt", "interrupt_alt", "interrupt_both", "confirm", "wrong")
        hashes = {name: self.write(f"fixtures/{name}.wav", name) for name in names}
        self.write_json("freeze.json", {
            "baseline_source_sha256": {"jd_mock/speech.py": baseline, "requirements.txt": settings},
            "fixture_sha256": hashes,
        })
        self.write_json("baseline-results.json", self.results(hashes, target="我想选鞘报道哪里修改授权类目"))
        self.candidate = self.results(hashes, target="我想选鞋类，要到哪里修改授权类目")
        self.write_json("candidate-results.json", self.candidate)

    def write(self, name, content):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        data = content.encode("utf-8")
        path.write_bytes(data)
        return hashlib.sha256(data).hexdigest()

    def write_json(self, name, data):
        self.write(name, json.dumps(data, ensure_ascii=False))

    @staticmethod
    def results(hashes, *, target):
        calls = []
        interruptions = [
            ("interrupt", "鞋类在哪里选", ["鞋类"]),
            ("interrupt_alt", "在哪里选择授权类目", ["授权类目"]),
            ("interrupt_both", target, ["鞋类", "授权类目"]),
        ]
        for index, (fixture, transcript, terms) in enumerate(interruptions, start=1):
            turns = [
                {"fixture": phase, "phase": phase, "transcript": text, "expected_terms": [],
                 "recognized_terms": [], "browser_render_ms": duration, "barge_in_to_mute_ms": None}
                for phase, text, duration in (
                    ("verify", "四八二六", 1500),
                    ("reason", "我想了解原因", 1500),
                    ("confirm", "我确认修改后重新提交", 1500),
                )
            ]
            turns.insert(2, {
                "fixture": fixture, "phase": "interrupt", "transcript": transcript,
                "expected_terms": terms, "recognized_terms": [term for term in terms if term in transcript],
                "browser_render_ms": 1500, "barge_in_to_mute_ms": 250,
            })
            calls.append({
                "index": index, "interrupt_fixture": fixture, "passed": True, "turns": turns,
                "acceptance": {"turn_count": 4, "interrupt_count": 1, "receipt_count": 1},
            })
        return {
            "browser_version": "Edge example", "measurement": "Browser render", "input_rms": 0.009,
            "output_rms": 0.006, "fixture_sha256": hashes, "requested_calls": 3,
            "passed_calls": 3, "failed_calls": 0, "calls": calls,
            "identity": {"passed": True, "fixture": "wrong", "transcript": "一二三四", "verified": False,
                         "disclosed_case_details": False, "receipt_count": 0, "pending_writeback": False,
                         "final_state": "closed"},
        }

    def test_promotes_only_the_intended_term_improvement(self):
        result = compare_round(self.root)
        self.assertEqual(result["decision"], "GO")
        self.assertEqual(result["candidate"]["latency"]["n"], 12)
        self.assertEqual(result["candidate"]["latency"]["p50_ms"], 1500)
        self.assertEqual(result["target"]["candidate"]["recognized_terms"], ["鞋类", "授权类目"])

    def test_fails_on_a_modified_frozen_fixture_or_unrelated_source(self):
        self.write("fixtures/verify.wav", "changed recording")
        self.write("candidate/requirements.txt", "changed dependencies")
        result = compare_round(self.root)
        self.assertEqual(result["decision"], "NO-GO")
        self.assertTrue(any("fixture" in reason.lower() for reason in result["reasons"]))
        self.assertTrue(any("candidate source" in reason.lower() for reason in result["reasons"]))

    def test_fails_when_a_control_loses_a_term_or_a_turn_is_unmeasured(self):
        control = self.candidate["calls"][1]["turns"][2]
        control.update(transcript="我在哪里选择授权内幕", recognized_terms=[])
        self.candidate["calls"][2]["turns"][3]["browser_render_ms"] = None
        self.write_json("candidate-results.json", self.candidate)
        result = compare_round(self.root)
        self.assertEqual(result["decision"], "NO-GO")
        self.assertEqual(result["candidate"]["latency"]["n"], 11)
        self.assertTrue(any("interrupt_alt" in reason for reason in result["reasons"]))


if __name__ == "__main__":
    unittest.main()
