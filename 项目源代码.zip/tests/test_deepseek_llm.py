import json
import unittest
from unittest.mock import patch

from jd_mock.deepseek_llm import DeepSeekTransport


MESSAGES = [{"role": "system", "content": "只答编码。"}, {"role": "user", "content": "模拟商家发言"}]
CHOICES = ("A", "B/-", "Z")


class DeepSeekTransportTests(unittest.TestCase):
    def setUp(self):
        self.https = self.enterContext(patch("jd_mock.deepseek_llm.HTTPSConnection"))
        self.connection = self.https.return_value
        self.response = self.connection.getresponse.return_value
        self.response.status = 200
        with patch.dict("os.environ", {"DEEPSEEK_API_KEY": "mock-key"}, clear=True):
            self.transport = DeepSeekTransport.from_env()

    def set_model_output(self, content, finish_reason="stop"):
        self.response.read.return_value = json.dumps({"choices": [
            {"message": {"content": content}, "finish_reason": finish_reason},
        ]}).encode()

    def test_defaults_and_optional_overrides(self):
        self.assertEqual(self.transport.provider, "deepseek")
        self.assertEqual(self.transport.model, "deepseek-flash")
        self.assertEqual(self.transport.timeout, 6.0)
        override = {"DEEPSEEK_API_KEY": "mock-key", "JD_DEEPSEEK_MODEL": "deepseek-v4-pro", "JD_DEEPSEEK_TIMEOUT": "4.5"}
        with patch.dict("os.environ", override, clear=True):
            transport = DeepSeekTransport.from_env()
        self.assertEqual((transport.model, transport.timeout), ("deepseek-v4-pro", 4.5))
        self.https.assert_not_called()

    def test_missing_key_and_invalid_timeout_are_rejected(self):
        with patch.dict("os.environ", {}, clear=True), self.assertRaisesRegex(ValueError, "DEEPSEEK_API_KEY"):
            DeepSeekTransport.from_env()
        for timeout in ("inf", "NaN", "0", "-8", "invalid"):
            with self.subTest(timeout=timeout), patch.dict("os.environ", {
                "DEEPSEEK_API_KEY": "mock-key", "JD_DEEPSEEK_TIMEOUT": timeout,
            }, clear=True), self.assertRaisesRegex(ValueError, "JD_DEEPSEEK_TIMEOUT"):
                DeepSeekTransport.from_env()

    def test_json_object_prompt_and_exact_choice(self):
        self.set_model_output('{"choice":"B/-"}')
        self.assertEqual(self.transport.complete(MESSAGES, CHOICES), "B/-")
        self.https.assert_called_once_with("api.deepseek.com", timeout=6.0)
        method, path, body, headers = self.connection.request.call_args.args
        self.assertEqual((method, path), ("POST", "/chat/completions"))
        self.assertEqual(headers["Authorization"], "Bearer mock-key")
        payload = json.loads(body)
        self.assertEqual(payload["model"], "deepseek-flash")
        self.assertEqual(payload["thinking"], {"type": "disabled"})
        self.assertEqual(payload["response_format"], {"type": "json_object"})
        system_prompt, user_prompt = payload["messages"]
        self.assertEqual(user_prompt, MESSAGES[1])
        self.assertIn('{"choice":"A"}', system_prompt["content"])
        self.assertIn('["A","B/-","Z"]', system_prompt["content"])
        self.assertIn("json", system_prompt["content"].lower())
        self.assertEqual(MESSAGES[0]["content"], "只答编码。")
        self.connection.close.assert_called_once()

    def test_empty_unlisted_or_truncated_choices_and_provider_failures(self):
        for content, reason in [("  ", "stop"), ('{"choice":"Q"}', "stop"), ('{"choice":"A"}', "length")]:
            with self.subTest(content=content, reason=reason):
                self.set_model_output(content, reason)
                with self.assertRaisesRegex(ValueError, "invalid choice"):
                    self.transport.complete(MESSAGES, CHOICES)
        self.response.status = 429
        with self.assertRaisesRegex(OSError, "DeepSeek returned HTTP 429"):
            self.transport.complete(MESSAGES, CHOICES)
        self.connection.request.side_effect = TimeoutError("mock-key")
        with self.assertRaisesRegex(TimeoutError, r"^DeepSeek request timed out\.$"):
            self.transport.complete(MESSAGES, CHOICES)
