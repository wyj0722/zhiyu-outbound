import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock

from jd_mock.business import COMPLETED, Store
from jd_mock.case_agent import CaseDecision
from jd_mock.cases import get_order
from jd_mock.dialogue import COMMITMENT_QUESTION, commitment_plan_text


class AllModelStoreTest(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / "calls.sqlite3"
        self.model = Mock()
        self.store = Store(self.path, case_agent=self.model)

    def test_agent_runs_only_after_verification_and_traces_grounded_reply(self):
        call_id = self.store.start_call("JD-DEMO-003")["call_id"]
        before = self.store.turn(call_id, "先说为什么没过", "before")
        self.assertFalse(before["verified"])
        self.assertIsNone(before["dialogue_decision"])
        self.model.decide.assert_not_called()
        self.store.turn(call_id, "是的，我是本人", "identity")
        order = get_order("JD-DEMO-003")
        self.model.decide.return_value = CaseDecision(
            "缺云杉品牌公司给星桥商贸公司的证明。", "chain_request",
            "request_segment", "model", None, 20, order.evidence,
        )
        routed = self.store.turn(call_id, "哪一段需要补上？", "business")
        self.assertEqual(routed["dialogue_decision"]["action"], "request_segment")
        self.assertEqual(routed["dialogue_decision"]["source"], "model")
        self.assertEqual(routed["dialogue_decision"]["turn_id"], "business")
        self.assertEqual(routed["receipt_count"], 0)
        self.assertEqual(Store(self.path, case_agent=self.model).get_call(call_id), routed)

    def test_voice_confirmation_stays_bound_to_spoken_plan_and_receipt(self):
        call_id = self.store.start_call("JD-DEMO-001")["call_id"]
        self.store.turn(call_id, "我是本人", "identity")
        order = get_order("JD-DEMO-001")
        offer = "请去掉服装，保留鞋类，再重新提交。" + COMMITMENT_QUESTION
        self.model.decide.return_value = CaseDecision(
            offer, "confirm", "next", "model", None, 20, order.evidence,
        )
        self.store.turn(call_id, "接下来怎么办", "offer")
        early = self.store.turn(call_id, "行，就这么办", "early", delivered_reply="")
        self.assertEqual(early["reply"], offer)
        self.assertEqual(early["receipt_count"], 0)
        saved = self.store.turn(call_id, "行，就这么办", "accept", delivered_reply=commitment_plan_text(offer))
        self.assertEqual(saved["receipt_count"], 1)
        self.assertEqual(saved["receipt"]["case_id"], order.case_id)
        self.assertEqual(saved["receipt"]["confirmation_text"], "行，就这么办")
        self.assertEqual(self.store.retry_writeback(call_id)["receipt"], saved["receipt"])
        self.model.decide.assert_called_once()

    def test_chain_finishes_after_one_assent_to_the_first_offer(self):
        case_id = "JD-DEMO-003"
        call_id = self.store.start_call(case_id)["call_id"]
        offered = self.store.turn(call_id, "我是本人", "identity")
        self.assertEqual(offered["state"], "explain")
        self.assertTrue(offered["reply"].endswith(COMMITMENT_QUESTION))
        self.assertIn("授权方是星桥商贸公司，被授权方是小贝塔", offered["reply"])
        self.assertIn("一起上传到入驻申请单，再重新提交", offered["reply"])
        self.assertEqual(offered["receipt_count"], 0)
        signed = self.store.turn(call_id, "行", "accept", delivered_reply="", started_plan=offered["reply"])
        self.assertEqual((signed["state"], signed["receipt_count"]), ("complete", 1))
        self.assertEqual(signed["receipt"]["case_id"], case_id)
        self.assertEqual(self.store.retry_writeback(call_id)["receipt"], signed["receipt"])
        self.model.decide.assert_not_called()

    def test_chain_early_acknowledgment_gets_only_the_actionable_part(self):
        call_id = self.store.start_call("JD-DEMO-003")["call_id"]
        self.store.turn(call_id, "我是本人", "identity")
        too_early = self.store.turn(call_id, "好的", "before-plan", delivered_reply="")
        self.assertEqual(too_early["receipt_count"], 0)
        self.assertNotIn("被授权方", too_early["reply"])
        self.assertIn("云杉品牌公司", too_early["reply"])
        self.assertTrue(too_early["reply"].endswith(COMMITMENT_QUESTION))
        self.model.decide.assert_not_called()

    def test_case_memory_survives_reopen_and_is_scoped_to_the_current_call(self):
        order = get_order("JD-DEMO-001")
        call_id = self.store.start_call(order.case_id)["call_id"]
        self.store.turn(call_id, "我是本人", "identity")
        context = {"remedy": "expanded_authorization", "document": "available"}
        self.model.decide.return_value = CaseDecision(
            "请上传覆盖服装的销售授权书。" + COMMITMENT_QUESTION,
            "category_extra_upload", "upload_authorization", "model", None, 20, order.evidence,
            context=context,
        )
        self.store.turn(call_id, "拿到新的授权书了", "business")
        reopened = Store(self.path, case_agent=self.model)
        self.model.decide.return_value = CaseDecision(
            "还需要复审。", "category_extra_upload", "review", "model", None, 20, order.evidence,
            context=context,
        )
        result = reopened.turn(call_id, "补了就能过吗？", "review")
        self.assertEqual(result["dialogue_decision"]["context"], context)
        self.assertEqual(result["receipt_count"], 0)
        self.assertEqual(self.model.decide.call_args.kwargs["context"], context)
        other_id = reopened.start_call(order.case_id)["call_id"]
        reopened.turn(other_id, "我是本人", "identity")
        reopened.turn(other_id, "我想听原因", "business")
        self.assertEqual(self.model.decide.call_args.kwargs["context"], {})

    def test_started_but_unfinished_offer_allows_voice_confirmation_on_both_cases(self):
        for case_id, focus in (("JD-DEMO-001", "category_extra_upload"), ("JD-DEMO-003", "chain_upload")):
            with self.subTest(case_id=case_id):
                order = get_order(case_id)
                call_id = self.store.start_call(case_id)["call_id"]
                self.store.turn(call_id, "我是本人", "identity")
                offer = "".join(order.steps) + COMMITMENT_QUESTION
                self.model.decide.return_value = CaseDecision(
                    offer, focus, "next", "model", None, 20, order.evidence,
                )
                self.store.turn(call_id, "下一步怎么办", "offer")
                stale = self.store.turn(
                    call_id, "好的", "stale", delivered_reply="", started_plan="另一轮的方案" + COMMITMENT_QUESTION,
                )
                self.assertEqual(stale["receipt_count"], 0)
                saved = self.store.turn(call_id, "好的", "consent", delivered_reply="", started_plan=offer)
                self.assertEqual((saved["state"], saved["reply"], saved["receipt_count"]), ("complete", COMPLETED, 1))
                self.assertEqual(saved["receipt"]["case_id"], case_id)
                self.assertEqual(self.store.retry_writeback(call_id)["receipt"], saved["receipt"])

    def test_conditional_or_conflicting_pledges_do_not_write_even_after_hearing_a_plan(self):
        for case_id, focus, words in (
            ("JD-DEMO-001", "category_extra_upload", "我确认等老板批准后补文件再重新提交"),
            ("JD-DEMO-001", "category_select", "我会继续卖服装，按原来的授权书重新提交"),
            ("JD-DEMO-003", "chain_upload", "我会把星桥商贸公司给我的那份授权书上传后重新提交"),
        ):
            with self.subTest(words=words):
                order = get_order(case_id)
                call_id = self.store.start_call(case_id)["call_id"]
                self.store.turn(call_id, "我是本人", "identity")
                offer = order.steps[-1] + COMMITMENT_QUESTION
                self.model.decide.return_value = CaseDecision(
                    offer, focus, "next", "model", None, 20, order.evidence,
                )
                self.store.turn(call_id, "接下来怎么办", "offer")
                heard = commitment_plan_text(offer)
                result = self.store.turn(call_id, words, "uncertain", delivered_reply=heard)
                self.assertEqual((result["state"], result["receipt_count"]), ("explain", 0))
                result = self.store.turn(
                    call_id, "我同意按步骤修改后重新提交。", "accept", delivered_reply=heard,
                )
                self.assertEqual((result["state"], result["receipt_count"]), ("complete", 1))

    def test_user_can_end_open_case_without_agreeing_to_an_offer(self):
        for words in ("先到这里。", "没有别的问题了。", "请挂断。"):
            with self.subTest(words=words):
                call_id = self.store.start_call("JD-DEMO-001")["call_id"]
                self.store.turn(call_id, "我是本人", "identity")
                result = self.store.turn(call_id, words, "end")
                self.assertEqual((result["state"], result["receipt_count"]), ("closed", 0))
        self.model.decide.assert_not_called()
