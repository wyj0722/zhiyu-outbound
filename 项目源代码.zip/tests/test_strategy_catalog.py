"""Question intent and evidence boundaries for the four extra audit scenes."""

import json
import unittest

from jd_mock.strategy_catalog import EXTRA_SEEDS, EXTRA_SEED_INTENTS, intent_keys_for_scene


class StrategyCatalogTests(unittest.TestCase):
    def test_current_question_routes_to_a_source_backed_scene_rule(self):
        self.assertIsNotNone(intent_keys_for_scene)
        examples = (
            ("品牌类目不符", "为什么我这张申请被驳回了？", "category_reason"),
            ("品牌类目不符", "我还想经营其他类目，授权要怎么办？", "category_scope"),
            ("品牌类目不符", "销售授权书下面在哪里选择类目？", "category_location"),
            ("品牌类目不符", "我已经拿到新的销售授权书了", "category_scope"),
            ("品牌类目不符", "鞋类应该在哪里勾选", "category_location"),
            ("授权书内容不完整", "这次缺什么材料？", "stamp_reason"),
            ("授权书内容不完整", "我已经盖章了，怎么还说缺章？", "stamp_owner"),
            ("授权书内容不完整", "盖我们自己公司的章可以吗？", "stamp_owner"),
            ("授权书内容不完整", "盖好后在哪里上传？", "stamp_upload"),
            ("授权书内容不完整", "这份授权书需要找哪家公司盖公章", "stamp_owner"),
            ("授权时间到期", "这份授权是哪一天到期的？", "expiry_reason"),
            ("授权时间到期", "能自己把日期改一下吗？", "expiry_reissue"),
            ("授权时间到期", "这份过期的授权书还能继续用吗？", "expiry_reissue"),
            ("授权时间到期", "我已经拿到新授权书了，该传到哪里？", "expiry_upload"),
            ("授权时间到期", "重新开好的授权书应该上传到哪里", "expiry_upload"),
            ("法人证件类型", "这单应该传什么证件？", "document_reason"),
            ("法人证件类型", "不换附件，只把证件类型改成护照行不行？", "document_replace"),
            ("法人证件类型", "在哪个栏目换传法人证件？", "document_upload"),
            ("法人证件类型", "法人身份证应该在哪个位置上传", "document_upload"),
            ("法人证件类型", "法人证件该换身份证还是护照", "document_replace"),
        )
        for scene, question, expected in examples:
            with self.subTest(scene=scene, question=question):
                self.assertEqual(intent_keys_for_scene(scene, question), (expected,))
                matched = [row for row in EXTRA_SEEDS if row["scene"] == scene and expected in EXTRA_SEED_INTENTS[row["strategy_id"]]]
                self.assertTrue(matched)
                self.assertTrue(all(row["evidence_refs"] for row in matched))

    def test_review_requires_an_outcome_question_and_takes_priority_over_materials(self):
        self.assertIsNotNone(intent_keys_for_scene)
        for scene, question in (
            ("品牌类目不符", "我把这个补上，这单就没问题了吗？"),
            ("授权书内容不完整", "盖完这个章就能通过审核了吗？"),
            ("授权时间到期", "换成新授权书后就一定能过审吗？"),
            ("法人证件类型", "身份证上传以后能保证通过吗？"),
        ):
            with self.subTest(scene=scene):
                self.assertEqual(intent_keys_for_scene(scene, question), ("review",))
        mailed = intent_keys_for_scene("授权书内容不完整", "授权方通过邮件给了我盖好章的授权书，在哪里上传？")
        self.assertEqual(mailed, ("stamp_upload",))
        self.assertEqual(intent_keys_for_scene("法人证件类型", "这个可以吗？"), ())

    def test_acknowledgement_and_consent_never_become_a_retrieval_intent(self):
        self.assertIsNotNone(intent_keys_for_scene)
        for scene in ("品牌类目不符", "授权书内容不完整", "授权时间到期", "法人证件类型"):
            for question in ("好的", "我明白了", "我同意", "行，就这么办", "我会补好后再提交", "我这就换传身份证后重新提交", "明天天气怎么样"):
                with self.subTest(scene=scene, question=question):
                    self.assertEqual(intent_keys_for_scene(scene, question), ())

    def test_seed_sources_are_bound_to_the_official_scenario_rows(self):
        self.assertIsNotNone(EXTRA_SEEDS)
        allowed = {
            "品牌类目不符": ("A29:E29", "A60:E60"),
            "授权书内容不完整": ("A17:E17", "A50:E50", "A79:E79"),
            "授权时间到期": ("A21:E21", "A51:E51"),
            "法人证件类型": ("A49:E49", "A76:E76"),
        }
        seen = set()
        for row in EXTRA_SEEDS:
            self.assertNotIn(row["strategy_id"], seen)
            seen.add(row["strategy_id"])
            self.assertEqual(row["version"], 1)
            self.assertEqual(row["status"], "active")
            self.assertTrue(row["title"])
            self.assertTrue(EXTRA_SEED_INTENTS[row["strategy_id"]])
            self.assertTrue(all(isinstance(value, list) for value in row["conditions"].values()))
            self.assertTrue(any("场景汇总!" + address in reference for address in allowed[row["scene"]] for reference in row["evidence_refs"]))
            content = json.dumps([row["actions"], row["reply_requirements"]], ensure_ascii=False)
            for synthetic_name in ("小贝塔", "青禾品牌公司", "海棠品牌公司"):
                self.assertNotIn(synthetic_name, content)
        self.assertEqual(set(EXTRA_SEED_INTENTS), seen)


if __name__ == "__main__":
    unittest.main()
