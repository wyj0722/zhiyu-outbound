// Current model-enabled workbench acceptance. Records synthetic microphone input,
// received browser audio, UI state and durable receipts from isolated loopback.
const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, readCall, selectWorkOrder, stats, milliseconds, waitForAutoClose } = require("./verify_browser.cjs");

const root = path.resolve(__dirname, "..");
const timeout = Number(process.env.JD_WORKBENCH_TIMEOUT || 65_000);
const screenshots = process.env.JD_WORKBENCH_SCREENSHOTS;
const identityOnly = process.env.JD_WORKBENCH_IDENTITY_ONLY === "1";
const allModels = process.env.JD_WORKBENCH_ALL_MODEL === "1";
const legacyHangup = process.env.JD_WORKBENCH_LEGACY_HANGUP === "1";
const expectedProvider = process.env.JD_WORKBENCH_EXPECT_PROVIDER;
const commitmentQuestion = "您打算按这个办法处理吗？";
const recordings = {
  identity: ["tests/fixtures/merchant_dialogue/recipient_repeat.wav", "是的，我是本人。"],
  wrong_person: ["tests/fixtures/merchant_identity/identity_no.wav", "不是，我不是商家小贝塔。"],
  reason: [".runtime/identity-v2-replay-fixtures/reason.wav", "是的，我想了解原因。"],
  category_interrupt: [".runtime/voice-fixtures/interrupt.wav", "等一下，鞋类在哪里选？"],
  category_choice: [".runtime/consent-loop/fixtures/requested.wav", "我还想卖服装。"],
  stamp_owner: [".runtime/stamp-llm-eval/wav/u02.wav", "刚翻到印文，印的是我们店铺登记的全名。"],
  stamp_interrupt: ["tests/fixtures/merchant_dialogue/review_outcome.wav", "盖好公章就一定能通过审核吗？"],
  question: [".runtime/identity-v2-replay-fixtures/matrix_question.wav", "我到底要改什么？"],
  decline: [".runtime/identity-v2-replay-fixtures/matrix_negative.wav", "我不确认，也不打算重新提交。"],
  submit: [".runtime/identity-v2-replay-fixtures/matrix_confirm_retry.wav", "我同意按步骤修改后重新提交。"],
  stamp_submit: [".runtime/headset-method-replay/method-confirm.wav", "好的，我按这个方法来办。"],
};
const modelRecordings = {
  keep_both: [".runtime/all-model-fixtures/keep_both.wav", "鞋类和服装我都想留，怎么办？"],
  keep_available: [".runtime/all-model-fixtures/keep_available.wav", "那我就只卖鞋类。"],
  reverse_chain: [".runtime/all-model-fixtures/reverse_chain.wav", "是不是星桥商贸公司授权给云杉品牌公司？"],
  next: [".runtime/all-model-fixtures/next.wav", "接下来呢？"],
};
const checks = [
  {
    id: "JD-DEMO-001", name: "品牌类目不符", main_row: 29,
    first: "reason", interrupt: "category_interrupt", offer: "category_choice", confirm: "submit",
    issue: /服装.*鞋类|鞋类.*服装/,
    interjection: /销售授权书|经营范围|授权类目/,
    step: /鞋类.*服装|服装.*鞋类|覆盖服装.*授权/,
    receiptTerms: ["鞋类", "服装"],
  },
  {
    id: "JD-DEMO-002", name: "授权书内容不完整", main_row: 79,
    first: "stamp_owner", interrupt: "stamp_interrupt", offer: "stamp_owner", confirm: "stamp_submit",
    issue: /店铺.*青禾品牌公司.*公章/,
    interjection: /复审|审核人员.*完整材料/,
    step: /青禾品牌公司.*公章.*重新提交/,
    receiptTerms: ["青禾品牌公司", "公章"],
  },
  {
    id: "JD-DEMO-003", name: "授权链路不完整", main_row: 52,
    first: "reason", interrupt: "question", offer: "question", confirm: "submit",
    issue: /云杉品牌公司.*授权给.*星桥商贸公司/,
    interjection: /云杉品牌公司.*星桥商贸公司/,
    step: /云杉品牌公司.*星桥商贸公司/,
    receiptTerms: ["云杉品牌公司", "星桥商贸公司"],
  },
];

function fixedPhaseFixtures(plan) {
  const probes = {
    "JD-DEMO-001": { discusses_both_categories: "keep_both", chooses_current_authorization: "keep_available" },
    "JD-DEMO-003": { reverses_authorization_direction: "reverse_chain" },
  };
  return {
    identity: "identity", diagnosis: plan.first, interjection: plan.interrupt, declines_current_plan: "decline",
    ...(allModels ? probes[plan.id] : {}), revisits_plan: plan.offer, confirmation: plan.confirm,
  };
}

function checkProvider(health) {
  if (!expectedProvider) return;
  assert.ok(["local", "deepseek", "doubao"].includes(expectedProvider), "Expected provider must be local, deepseek or doubao");
  assert.equal(health.llm_provider, expectedProvider, "Replay connected to a different model provider");
  assert.equal(health.stamp_warmup?.source, "model", `Model warmup did not succeed (${health.stamp_warmup?.error || "missing result"})`);
}

function hashSources(...testFiles) {
  const sources = fs.readdirSync(path.join(root, "jd_mock")).filter(file => /\.(py|json)$/.test(file))
    .map(file => `jd_mock/${file}`);
  const web = fs.readdirSync(path.join(root, "jd_mock/web")).filter(file => /\.(css|html|js)$/.test(file))
    .map(file => `jd_mock/web/${file}`);
  return Object.fromEntries([...sources, ...web, "tests/verify_browser.cjs", "tests/verify_workbench.cjs", ...testFiles]
    .sort().map(file => [file, createHash("sha256").update(fs.readFileSync(path.join(root, file))).digest("hex")]));
}

async function until(page, predicate, arg) {
  await (await page.waitForFunction(predicate, arg, { timeout })).dispose();
}

async function readyForNextTurn(page, marker) {
  await until(page, start => {
    const events = window.jdAcceptance.trace.slice(start);
    const speaking = events.findIndex(event => event.type === "state" && event.state === "speaking");
    return speaking >= 0 && events.slice(speaking + 1).some(event => event.type === "state" && event.state === "listening");
  }, marker);
}

async function json(page, url, post = false) {
  const response = await (post ? page.request.post(url) : page.request.get(url));
  assert.ok(response.ok(), url + " returned " + response.status());
  return response.json();
}

async function start(page, call, timeoutSimulation) {
  await selectWorkOrder(page, call.case_id, { timeout });
  await page.locator("#start-call").waitFor({ timeout });
  assert.equal(await page.locator("#case-id").innerText(), call.case_id);
  await page.evaluate(() => window.jdAcceptance.reset());
  await page.locator("#simulate-timeout").setChecked(timeoutSimulation, { timeout });
  const started = page.waitForResponse(r => r.request().method() === "POST"
    && new URL(r.url()).pathname === "/api/calls" && r.ok(), { timeout });
  await page.locator("#start-call").click({ timeout });
  const opening = await (await started).json();
  call.call_id = opening.call_id;
  call.opening = opening.reply;
  assert.equal(opening.case_id, call.case_id);
  assert.match(opening.reply, /我是.*请问您是否是商家小贝塔/);
  await readyForNextTurn(page, 0);
  assert.equal(await page.locator("#case-select").isDisabled(), true);
  assert.equal(await page.locator('#progress [data-step="verify"]').getAttribute("aria-current"), "step");
  assert.equal(await page.locator("#receipt-fields").isVisible(), false);
}

async function play(page, call, fixture, phase, { consumeReply = true, barge = false } = {}) {
  const marker = await page.evaluate(() => window.jdAcceptance.trace.length);
  await page.evaluate(([name, phase]) => window.jdAcceptance.play(name, phase), [fixture, phase]);
  await until(page, start => window.jdAcceptance.trace.slice(start).some(event => event.type === "update"), marker);
  await until(page, name => window.jdAcceptance.turns.some(turn => turn.phase === name && turn.firstAudioAt !== undefined), phase);
  const raw = await page.evaluate(name => window.jdAcceptance.turns.find(turn => turn.phase === name), phase);
  const state = await readCall(page, call.call_id);
  call.turns.push({
    phase, fixture, transcript: raw.transcript ?? null, reply: state.reply, state: state.state,
    receipt_count: state.receipt_count, pending_writeback: state.pending_writeback,
    stamp_decision: state.stamp_decision || null, dialogue_decision: state.dialogue_decision || null,
    focus: state.dialogue_focus,
    browser_first_audio_ms: milliseconds(raw.voiceEnd, raw.firstAudioAt),
    barge_to_mute_ms: milliseconds(raw.voiceStart, raw.mutedAt), server_first_audio_ms: raw.serverFirstAudioMs,
    server_stages: raw.serverTiming,
  });
  assert.equal(state.case_id, call.case_id);
  if (barge) {
    assert.ok(raw.interruptAt !== undefined && raw.mutedAt !== undefined && raw.quietAfterMute,
      phase + ": new reply follows local mute of interrupted audio");
    assert.ok(Number(await page.locator("#interrupt-count").innerText()) > 0);
  }
  if (consumeReply) await readyForNextTurn(page, marker);
  return state;
}

async function endViaButton(page, call) {
  const ended = page.waitForResponse(response => new URL(response.url()).pathname ===
    "/api/calls/" + call.call_id + "/end" && response.ok(), { timeout });
  await page.locator("#end-call").click({ timeout });
  assert.equal((await (await ended).json()).state, "closed");
  await page.locator("#case-select:enabled").waitFor({ state: "attached", timeout });
}

async function verifyIdentity(page, call) {
  await start(page, call, false);
  const decline = await play(page, call, "wrong_person", "denies_identity", { consumeReply: false });
  assert.equal(decline.verified, false);
  assert.equal(decline.receipt_count, 0);
  assert.equal(decline.state, "closed");
  assert.equal(decline.dialogue_decision ?? decline.stamp_decision ?? null, null);
  assert.doesNotMatch(decline.reply, /鞋类|服装|青禾|云杉|星桥/);
  await page.locator("#case-select:enabled").waitFor({ state: "attached", timeout });
  call.passed = true;
}

async function verifyPhase(call, phase, run) {
  try {
    const result = await run();
    call.phase_checks[phase] = { passed: true };
    return result;
  } catch (error) {
    call.phase_checks[phase] = { passed: false, error: error.message };
    throw error;
  }
}

function assertModelDecision(state, phase, action) {
  const trace = state.dialogue_decision || state.stamp_decision;
  assert.equal(trace?.source, "model", phase + ": expected a real model decision");
  if (action) assert.equal(trace.action, action, phase + ": model chose the expected plan");
  return trace;
}

async function verifyModelChoice(page, call) {
  const failures = [];
  async function probe(phase, run) {
    try {
      await verifyPhase(call, phase, run);
    } catch (error) {
      if (!(error instanceof assert.AssertionError)) throw error;
      // A wrong answer should not remove the later fixed recording from the
      // pair. Only continue with an active call and no receipt to protect state.
      const current = await readCall(page, call.call_id);
      assert.equal(current.state, "explain");
      assert.equal(current.receipt_count, 0);
      failures.push({ phase, error: error.message });
    }
  }
  if (call.case_id === "JD-DEMO-001") {
    await probe("discusses_both_categories", async () => {
      const both = await play(page, call, "keep_both", "discusses_both_categories");
      assertModelDecision(both, "both categories", "retain_requested");
      assert.match(both.reply, /服装.*授权|授权.*服装/);
      assert.equal(both.receipt_count, 0);
    });
    await probe("chooses_current_authorization", async () => {
      const one = await play(page, call, "keep_available", "chooses_current_authorization");
      assertModelDecision(one, "current authorization", "solely_authorized");
      assert.match(one.reply, /鞋类/);
      assert.equal(one.receipt_count, 0);
    });
  } else if (call.case_id === "JD-DEMO-003") {
    await probe("reverses_authorization_direction", async () => {
      const inverse = await play(page, call, "reverse_chain", "reverses_authorization_direction");
      const trace = assertModelDecision(inverse, "reversed direction");
      // Restate the grounded direction when ASR did not identify both parties.
      assert.ok(["reverse_direction", "request_segment"].includes(trace.action));
      assert.match(inverse.reply, /云杉品牌公司.{0,22}(?:授权给|给|向).{0,18}星桥商贸公司/);
      assert.equal(inverse.receipt_count, 0);
    });
  }
  call.model_choice_probe = { passed: failures.length === 0, failures };
}

async function reachConfirmationQuestion(page, call, offer) {
  let state = offer;
  for (let step = 1; step <= 4 && !state.reply.endsWith(commitmentQuestion); step += 1) {
    const phase = "progresses_plan_" + step;
    state = await verifyPhase(call, phase, async () => {
      const reply = await play(page, call, "next", phase);
      assertModelDecision(reply, "plan follow-up " + step);
      assert.equal(reply.receipt_count, 0);
      return reply;
    });
  }
  assert.ok(state.reply.endsWith(commitmentQuestion), "Expected a specific plan and a confirmation question");
  return state;
}

async function verifyWorkOrder(page, call, plan) {
  const receiptURL = "/api/cases/" + call.case_id + "/receipts";
  const before = await json(page, receiptURL);
  assert.equal(before.receipt_count, 0, "Use an empty test database for all three orders");
  await start(page, call, true);
  await verifyPhase(call, "identity", async () => {
    const identity = await play(page, call, "identity", "identity");
    const identityStep = plan.id === "JD-DEMO-001" ? "need" : "explain";
    assert.equal(identity.state, identityStep);
    assert.equal(identity.verified, true);
    if (plan.id === "JD-DEMO-002") {
      assert.equal(identity.stamp_decision?.source, "policy");
      assert.match(identity.reply, /小贝塔.*青禾品牌公司.*补盖公章/);
    } else if (allModels) {
      assert.equal(identity.dialogue_decision ?? identity.stamp_decision ?? null, null);
    }
    assert.equal(await page.locator(`#progress [data-step="${identityStep}"]`).getAttribute("aria-current"), "step");
  });
  await verifyPhase(call, "diagnosis", async () => {
    const issue = await play(page, call, plan.first, "diagnosis", { consumeReply: false });
    if (allModels) assertModelDecision(issue, "diagnosis");
    assert.match(issue.reply, plan.issue);
    if (plan.id === "JD-DEMO-002") {
      assert.equal(issue.stamp_decision.source, "model");
      assert.equal(issue.stamp_decision.owner, "merchant");
    }
    assert.equal(issue.receipt_count, 0);
  });
  await verifyPhase(call, "interjection", async () => {
    const reply = await play(page, call, plan.interrupt, "interjection", { barge: true });
    if (allModels) assertModelDecision(reply, "interruption");
    assert.match(reply.reply, plan.interjection);
    assert.doesNotMatch(reply.reply, /保证.{0,5}(?:通过|过审)|一定(?:会)?通过/);
    assert.equal(reply.receipt_count, 0);
  });
  await verifyPhase(call, "declines_current_plan", async () => {
    const decline = await play(page, call, "decline", "declines_current_plan");
    assert.equal(decline.state, "explain");
    assert.equal(decline.receipt_count, 0);
    assert.equal(decline.pending_writeback, false);
    assert.equal(await page.locator("#retry-writeback").isVisible(), false);
  });
  if (allModels && plan.id !== "JD-DEMO-002") await verifyModelChoice(page, call);
  const offer = await verifyPhase(call, "revisits_plan", async () => {
    const reply = await play(page, call, plan.offer, "revisits_plan");
    if (allModels) {
      assertModelDecision(reply, "plan");
      const relevantReplies = call.turns.filter(turn => [
        "chooses_current_authorization", "reverses_authorization_direction", "revisits_plan",
      ].includes(turn.phase));
      assert.ok(relevantReplies.some(turn => plan.step.test(turn.reply)), "The offered plan uses the correct case facts");
    } else {
      assert.match(reply.reply, plan.step);
    }
    assert.equal(reply.receipt_count, 0);
    return reply;
  });
  if (allModels) await verifyPhase(call, "commitment_question", () => reachConfirmationQuestion(page, call, offer));
  await verifyPhase(call, "confirmation", async () => {
    const confirmation = await play(page, call, plan.confirm, "confirmation", { consumeReply: false });
    assert.equal(confirmation.state, "complete");
    assert.equal(confirmation.pending_writeback, true);
    assert.equal(confirmation.receipt_count, 1);
    assert.equal(confirmation.receipt, null);
    assert.equal(await page.locator("#retry-writeback").isVisible(), true);
    assert.equal((await json(page, receiptURL)).receipt_count, 0);
  });
  if (!legacyHangup) {
    await verifyPhase(call, "auto_hangup", () => waitForAutoClose(page, timeout));
    call.automatically_ended = true;
  }
  await verifyPhase(call, "receipt_retry", async () => {
    await page.locator("#retry-writeback").click({ timeout });
    await page.locator('#receipt-badge[data-status="saved"]').waitFor({ timeout });
    const saved = await readCall(page, call.call_id);
    const again = await json(page, "/api/calls/" + call.call_id + "/retry", true);
    assert.equal(saved.pending_writeback, false);
    assert.equal(saved.receipt_count, 1);
    assert.equal(again.receipt_count, 1);
    assert.equal(saved.receipt.call_id, call.call_id);
    assert.equal(saved.receipt.case_id, call.case_id);
    assert.equal(saved.receipt.verified, true);
    assert.equal(saved.receipt.channel, "电话");
    assert.equal(await page.locator('#progress [data-step="complete"]').getAttribute("data-status"), "done");
    assert.deepEqual(again.receipt, saved.receipt);
    for (const name of plan.receiptTerms) assert.ok(saved.receipt.action_steps.join(" ").includes(name));
    if (allModels && plan.id === "JD-DEMO-001") {
      assert.match(saved.receipt.action_steps.join(" "), /(?:勾选|保留)鞋类.*(?:去掉|取消).{0,20}服装/);
    }
    if (allModels && plan.id === "JD-DEMO-003") {
      assert.match(saved.receipt.action_steps.join(" "), /云杉品牌公司.{0,12}授权给星桥商贸公司/);
    }
    assert.ok(saved.receipt.evidence_refs.some(ref => ref.includes("A" + plan.main_row + ":E" + plan.main_row)));
    const history = await json(page, receiptURL);
    assert.equal(history.receipt_count, 1);
    assert.equal(history.latest_receipt.receipt_id, saved.receipt.receipt_id);
    const fields = await page.locator("#receipt-fields").innerText();
    assert.ok(fields.includes(saved.receipt.receipt_id));
    assert.ok(fields.includes(call.case_id));
    if (plan.id === "JD-DEMO-002") {
      assert.equal(saved.receipt.confirmation_text, call.turns.at(-1).transcript);
      assert.match(saved.receipt.confirmation_text, /方法.*办/);
    }
    call.receipt = saved.receipt;
    call.idempotent = true;
  });
  if (legacyHangup) await endViaButton(page, call);
  call.passed = true;
}

async function verifyMobile(browser, baseURL) {
  const viewport = { width: 390, height: 844 };
  const page = await browser.newPage({ baseURL, viewport });
  try {
    await page.goto("/");
    await page.locator('#health[data-health="ready"]').waitFor({ timeout });
    await until(page, () => document.getElementById("start-call")?.disabled === false);
    await selectWorkOrder(page, "JD-DEMO-003", { timeout });
    assert.equal(await page.locator("#start-call").isEnabled(), true);
    if (screenshots) await page.screenshot({ path: path.join(screenshots, "mobile.png"), fullPage: true, animations: "disabled" });
    const measured = await page.evaluate(() => ({
      viewport_width: window.innerWidth,
      content_width: document.documentElement.scrollWidth,
    }));
    assert.ok(measured.content_width <= measured.viewport_width, "390px viewport is free of horizontal overflow");
    return { ...measured, selected_case: "JD-DEMO-003", can_start: true, passed: true };
  } finally {
    await page.close();
  }
}

async function main() {
  const [baseURL, output] = process.argv.slice(2);
  if (!baseURL || !output || fs.existsSync(output)) {
    throw new Error("Usage: node tests/verify_workbench.cjs http://127.0.0.1:TEST_PORT NEW_RESULT.json");
  }
  const url = new URL(baseURL);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || url.port === "8779") {
    throw new Error("Use an isolated loopback service and an empty database.");
  }
  if (expectedProvider) assert.ok(allModels && !identityOnly && !legacyHangup, "Use an all-model, auto-hangup replay for a provider comparison");
  const selectedRecordings = identityOnly ? { wrong_person: recordings.wrong_person }
    : (allModels ? { ...recordings, ...modelRecordings } : recordings);
  const activeChecks = identityOnly ? [] : checks;
  const assets = Object.fromEntries(Object.entries(selectedRecordings).map(([key, [file, words]]) => {
    const source = process.env.JD_WORKBENCH_WAVS ? path.join(process.env.JD_WORKBENCH_WAVS, key + ".wav") : path.join(root, file);
    const wav = fs.readFileSync(source);
    return [key, { file: path.relative(root, source), words, encoded: wav.toString("base64"),
      sha256: createHash("sha256").update(wav).digest("hex") }];
  }));
  const browser = await chromium.launch({ executablePath: browserPath, headless: true,
    args: ["--autoplay-policy=no-user-gesture-required"] });
  const report = {
    replay_suite: "workbench-v1",
    base_url: baseURL, browser: browser.version(), started_at: new Date().toISOString(),
    all_models: allModels,
    input: "固定合成普通话录音注入浏览器麦克风，WebRTC + 实际模型 + 隔离 SQLite。使用已有回归素材。",
    latency_definition: "毫秒。从录音最后一个有声窗口到浏览器首个可听的后续答复，无人工操作和身份核验轮。线性分位数。",
    fixtures: Object.fromEntries(Object.entries(assets).map(([key, { encoded, ...meta }]) => [key, meta])),
    source_sha256: hashSources("tests/make_all_model_fixtures.py"),
    fixed_phase_fixtures: Object.fromEntries(activeChecks.map(check => [check.id, fixedPhaseFixtures(check)])),
    identity_guard: { case_id: "JD-DEMO-002", turns: [], phase_checks: {} },
    calls: activeChecks.map(({ id, name }) => ({ case_id: id, name, turns: [], phase_checks: {} })),
    passed: false,
  };
  const page = await browser.newPage({ baseURL, viewport: { width: 1440, height: 1000 } });
  page.setDefaultTimeout(timeout);
  async function safely(call, check) {
    try {
      await check();
      console.log(call.name || "identity guard", "PASS",
        call.model_choice_probe?.passed === false ? "with model-choice probe failure" : "");
    } catch (error) {
      call.passed = false;
      call.error = error.message;
      call.last_state = call.call_id ? await readCall(page, call.call_id).catch(() => null) : null;
      if (call.call_id) await json(page, "/api/calls/" + call.call_id + "/end", true).catch(() => {});
      console.error(call.name || "identity guard", error.message);
      await page.reload();
    }
  }
  try {
    await installFixtureMicrophone(page, assets, { meterEnabled: true, measureReprompts: true });
    report.health = await json(page, "/api/health");
    assert.ok(report.health.speech_ready);
    checkProvider(report.health);
    const catalog = await json(page, "/api/cases");
    const stamp = catalog.cases?.find(caseItem => caseItem.case_id === "JD-DEMO-002");
    assert.ok(stamp?.dialogue_model, "Use the model-enabled build");
    if (allModels) {
      report.models = Object.fromEntries(catalog.cases.map(item => [item.case_id, item.dialogue_model ?? null]));
      for (const { id } of checks) {
        assert.ok(report.models[id], id + " must advertise its configured model");
        if (expectedProvider) {
          assert.equal(catalog.cases.find(item => item.case_id === id).dialogue_provider, expectedProvider,
            id + " must use the expected model provider");
        }
      }
    }
    await page.goto("/");
    await page.locator('#health[data-health="ready"]').waitFor({ timeout });
    await until(page, () => document.getElementById("start-call")?.disabled === false);
    if (screenshots) await page.screenshot({ path: path.join(screenshots, "desktop.png"), fullPage: true, animations: "disabled" });
    if (!identityOnly) report.mobile = await verifyMobile(browser, baseURL);
    await safely(report.identity_guard, () => verifyPhase(report.identity_guard, "denies_identity",
      () => verifyIdentity(page, report.identity_guard)));
    for (const [index, plan] of activeChecks.entries()) {
      const call = report.calls[index];
      await safely(call, () => verifyWorkOrder(page, call, plan));
    }
    const savedReceipts = report.calls.filter(call => call.passed).map(call => call.receipt.receipt_id);
    report.passed = report.identity_guard.passed && report.calls.every(call => call.passed)
      && report.calls.every(call => call.model_choice_probe?.passed !== false)
      && new Set(savedReceipts).size === activeChecks.length;
    for (const call of report.calls) if (call.passed) {
      assert.deepEqual((await readCall(page, call.call_id)).receipt, call.receipt);
    }
  } catch (error) {
    report.passed = false;
    report.error = error.message;
    console.error(error.message);
  } finally {
    const values = report.calls.flatMap(call => call.turns.filter(turn => turn.phase !== "identity")
      .map(turn => turn.browser_first_audio_ms));
    const plannedTurns = allModels ? report.calls.reduce((count, call) =>
      count + Math.max(call.turns.filter(turn => turn.phase !== "identity").length,
        5 + (call.case_id === "JD-DEMO-001" ? 2 : call.case_id === "JD-DEMO-003" ? 1 : 0)), 0)
      : activeChecks.length * 5;
    report.first_audio_ms = stats(values, plannedTurns);
    report.ended_at = new Date().toISOString();
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
    await browser.close();
  }
  if (!report.passed) process.exitCode = 1;
}

module.exports = { start, play, readyForNextTurn, json, checkProvider, hashSources, endViaButton };
if (require.main === module) {
  main().catch(error => { console.error(error); process.exitCode = 1; });
}
