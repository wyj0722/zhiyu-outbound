import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from dataclasses import replace
from pathlib import Path

from jd_mock.business import Store
from jd_mock.case_agent import CaseAgent, first_replies
from jd_mock.cases import list_cases


class WorkOrderTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.db = Path(directory.name) / "work-orders.sqlite3"

    def test_order_listing_returns_the_submitted_authorization_for_each_order(self):
        materials = {
            order["case_id"]: order["submitted_authorization"] for order in list_cases()
            if "submitted_authorization" in order
        }
        expected = {
            "JD-DEMO-001": ("销售授权书", "", "鞋类", "", "服装"),
            "JD-DEMO-002": ("销售授权书", "青禾品牌公司", "", "小贝塔", "缺少授权方青禾品牌公司的公章"),
            "JD-DEMO-003": ("销售授权证明", "星桥商贸公司", "", "", "缺少云杉品牌公司到星桥商贸公司的授权关系证明"),
        }
        self.assertEqual(materials.keys(), expected.keys())
        for case_id, (title, grantor, scope, seal, note) in expected.items():
            with self.subTest(case_id=case_id):
                material = materials[case_id]
                self.assertEqual(
                    {key: value for key, value in material.items() if key != "review_note"},
                    {"title": title, "grantor": grantor, "grantee": "小贝塔", "scope": scope, "seal": seal},
                )
                self.assertIn(note, material["review_note"])

    def test_new_orders_keep_their_submitted_fields_and_citations(self):
        from jd_mock.cases import get_order
        from jd_mock.dialogue import introduce, material_question_fields

        catalog = {order["case_id"]: order for order in list_cases()}
        examples = (
            ("JD-DEMO-004", {"grantor": "海棠品牌公司", "expires_on": "2026年6月30日"}, "A21:E21"),
            ("JD-DEMO-005", {"expected_type": "身份证", "submitted_type": "护照"}, "A76:E76"),
        )
        for case_id, fields, source in examples:
            with self.subTest(case_id=case_id):
                order = get_order(case_id)
                material = catalog[case_id]["submitted_material"]
                self.assertEqual({field["key"]: field["value"] for field in material["fields"]}, fields)
                reply, _ = introduce(order)
                self.assertEqual(material_question_fields(order, reply), tuple(fields))
                self.assertIn(source, order.evidence[0])
                self.assertIn(order.guidance, first_replies(order))

    def test_new_orders_use_model_answers_but_only_policy_can_write_the_receipt(self):
        class Model:
            model = "deepseek-test"
            provider = "deepseek"

            def _complete(self, messages, grammar, *, choices):
                self.last_prompt = messages[-1]["content"]
                return choices[0]

        model = Model()
        store = Store(self.db, case_agent=CaseAgent(model))
        examples = (
            ("JD-DEMO-004", "旧授权书照常上传后重提", "销售授权书", "海棠品牌公司"),
            ("JD-DEMO-005", "继续上传护照后重新提交", "法人证件", "身份证"),
        )
        for case_id, wrong, upload, required in examples:
            with self.subTest(case_id=case_id):
                call_id = store.start_call(case_id)["call_id"]
                verified = store.turn(call_id, "是的，我是商家小贝塔", "verify")
                self.assertIn(required, verified["reply"])
                unheard = store.turn(call_id, "好的", "unheard", delivered_reply="")
                self.assertEqual(unheard["receipt_count"], 0)
                bad = store.turn(call_id, "我确认" + wrong, "wrong")
                self.assertEqual(bad["receipt_count"], 0)
                self.assertIn(required, bad["reply"])
                answer = store.turn(call_id, "应该往哪里传？", "where")
                self.assertIn(upload, answer["reply"])
                self.assertEqual(answer["dialogue_decision"]["source"], "model")
                self.assertEqual(answer["dialogue_decision"]["action"], "upload")
                self.assertIn("正确的材料上传位置", model.last_prompt)
                plan = store.turn(call_id, "我同意按步骤修改后重新提交", "reoffer")
                self.assertEqual(plan["receipt_count"], 0)
                store.turn(call_id, "应该往哪里传？", "ask-where-again")
                plan = store.turn(call_id, "接下来我具体要怎么改", "ask-next")
                self.assertEqual(plan["dialogue_decision"]["model_action"], "upload")
                self.assertEqual(plan["dialogue_decision"]["applied_action"], "next")
                self.assertIn(required, plan["reply"])
                self.assertEqual((plan["state"], plan["receipt_count"], plan["pending_writeback"]),
                                 ("explain", 0, False))
                unheard = store.turn(call_id, "我同意按步骤修改后重新提交", "confirm-before-audio",
                                     delivered_reply="")
                self.assertEqual((unheard["state"], unheard["receipt_count"], unheard["reply"]),
                                 ("explain", 0, plan["reply"]))
                complete = store.turn(call_id, "嗯，好的", "confirm", simulate_timeout=True,
                                      delivered_reply="", started_plan=plan["reply"])
                self.assertEqual(complete["dialogue_decision"]["source"], "policy")
                self.assertTrue(complete["pending_writeback"])
                self.assertEqual(store.case_receipts(case_id)["receipt_count"], 0)
                receipt = store.retry_writeback(call_id)["receipt"]
                self.assertEqual(receipt["case_id"], case_id)
                self.assertIn(required, "".join(receipt["action_steps"]))
                self.assertEqual(store.retry_writeback(call_id)["receipt"], receipt)
                self.assertEqual(store.case_receipts(case_id)["receipt_count"], 1)

    def test_interleaved_calls_answer_and_write_back_to_the_selected_order(self):
        store = Store(self.db)
        cases = (
            ("JD-DEMO-001", "品牌类目不符", "鞋类", "服装", "销售授权书下方", "在哪里选？", "A29:E29"),
            ("JD-DEMO-002", "授权书内容不完整", "青禾品牌公司", "公章", "青禾品牌公司", "谁盖章？", "A79:E79"),
            ("JD-DEMO-003", "授权链路不完整", "云杉品牌公司", "星桥商贸公司", "云杉品牌公司", "找谁开？", "A52:E52"),
        )
        calls = {}
        for case_id, *_ in cases:
            calls[case_id] = store.start_call(case_id)["call_id"]
        reopened = Store(self.db)
        for case_id, scenario, fact, second_fact, answer, question, evidence_row in reversed(cases):
            with self.subTest(case=case_id):
                call_id = calls[case_id]
                wrong = reopened.turn(call_id, "我还没听清，我到底要改什么？", "unclear")
                self.assertFalse(wrong["verified"])
                self.assertNotIn(fact, wrong["reply"])
                reopened.turn(call_id, "是的，我是商家小贝塔", "verify")
                reason = reopened.turn(call_id, "我到底要改什么？", "need")
                self.assertEqual((reason["case_id"], reason["state"]), (case_id, "explain"))
                self.assertIn(fact, reason["reply"])
                self.assertIn(second_fact, reason["reply"])
                self.assertIn(fact, reopened.turn(call_id, "到底要改什么", "repeat")["reply"])
                self.assertIn(answer, reopened.turn(call_id, question, "ask")["reply"])
                self.assertIn("复审", reopened.turn(call_id, "这样就能过吗？", "pass")["reply"])
                result = reopened.turn(call_id, "我明白了，就按你说的修改后再提交。", "yes", simulate_timeout=True)
                self.assertTrue(result["pending_writeback"])
                self.assertEqual(reopened.case_receipts(case_id)["receipt_count"], 0)
                receipt = reopened.retry_writeback(call_id)["receipt"]
                self.assertEqual((receipt["case_id"], receipt["call_id"], receipt["scenario"]), (case_id, call_id, scenario))
                self.assertIn(fact, receipt["reason"])
                self.assertIn(second_fact, receipt["reason"])
                self.assertIn(evidence_row, " ".join(receipt["evidence_refs"]))
                reopened.end_call(call_id)
                self.assertEqual(reopened.retry_writeback(call_id)["receipt"], receipt)
                self.assertEqual(reopened.case_receipts(case_id), {
                    "case_id": case_id, "receipt_count": 1, "latest_receipt": receipt,
                })

    def test_refusing_or_skipping_required_material_does_not_create_receipt(self):
        store = Store(self.db)
        examples = (
            ("JD-DEMO-002", "我确认不盖章直接重新提交", "公章"),
            ("JD-DEMO-003", "我确认不用补授权链路就重新提交", "云杉品牌公司"),
        )
        for case_id, text, fact in examples:
            with self.subTest(case=case_id):
                call_id = store.start_call(case_id)["call_id"]
                identity = store.turn(call_id, "是的，我是商家小贝塔", "verify")
                if identity["state"] == "need":
                    store.turn(call_id, "是的", "need")
                answer = store.turn(call_id, text, "negative")
                self.assertEqual((answer["state"], answer["receipt_count"]), ("explain", 0))
                self.assertIn(fact, answer["reply"])
                answer = store.turn(call_id, "我不确认，也不打算重新提交", "decline")
                self.assertEqual(answer["receipt_count"], 0)
                answer = store.turn(call_id, "我确认把鞋类改好后重新提交", "other-plan")
                self.assertEqual(answer["receipt_count"], 0)

    def test_explicit_wrong_stamp_or_reversed_authorization_is_corrected_before_writeback(self):
        store = Store(self.db)
        examples = (
            ("JD-DEMO-002", "我确认盖我们自己公司的章后重新提交", "青禾品牌公司",
             "我确认让青禾品牌公司盖好公章后重新提交"),
            ("JD-DEMO-003", "我确认让星桥商贸公司授权给云杉品牌公司后重新提交", "云杉品牌公司授权给星桥商贸公司",
             "我确认补云杉品牌公司授权给星桥商贸公司的证明后重新提交"),
        )
        for case_id, wrong, correction, agreed in examples:
            with self.subTest(case_id):
                call_id = store.start_call(case_id)["call_id"]
                identity = store.turn(call_id, "是的，我是商家小贝塔", "verify")
                if identity["state"] == "need":
                    store.turn(call_id, "是的", "need")
                result = store.turn(call_id, wrong, "wrong")
                self.assertEqual((result["state"], result["receipt_count"]), ("explain", 0))
                self.assertIn(correction, result["reply"])
                self.assertEqual(store.turn(call_id, agreed, "yes")["receipt_count"], 1)

    def test_natural_short_company_names_cannot_bypass_chain_direction_validation(self):
        store = Store(self.db)
        call_id = store.start_call("JD-DEMO-003")["call_id"]
        store.turn(call_id, "是的，我是商家小贝塔", "verify")
        store.turn(call_id, "哪两家要补授权？", "need")
        wrong = store.turn(call_id, "我确认让星桥给云杉开授权后重新提交。", "wrong")
        self.assertEqual(wrong["receipt_count"], 0)
        self.assertIn("云杉品牌公司授权给星桥商贸公司", wrong["reply"])
        correct = store.turn(call_id, "我确认让云杉给星桥开授权后重新提交。", "right")
        self.assertEqual(correct["receipt_count"], 1)
        self.assertIn("星桥商贸公司", correct["receipt"]["action_steps"][0])

    def test_reversed_authorization_roles_are_rejected_even_in_separate_clauses(self):
        from jd_mock.cases import get_order

        order = get_order("JD-DEMO-003")
        for text, reversed_roles in (
            ("云杉是被授权方，开出文件的是星桥", True),
            ("星桥是授权方，云杉是被授权方", True),
            ("开出授权书的是星桥商贸公司，云杉品牌公司是被授权单位", True),
            ("星桥是被授权方，开出文件的是云杉", False),
            ("云杉是授权方，星桥是被授权方", False),
            ("星桥不是授权方，云杉也不是被授权方", False),
        ):
            with self.subTest(text=text):
                self.assertEqual(order.contradicts_action(text), reversed_roles)

    def test_confirming_an_unfinished_or_reversed_action_does_not_write_back(self):
        store = Store(self.db)
        for case_id, wrong, anchor in (
            ("JD-DEMO-002", "我确认我没盖章直接重新提交", "青禾品牌公司"),
            ("JD-DEMO-002", "我确认我还没有盖公章就重新提交", "青禾品牌公司"),
            ("JD-DEMO-003", "我确认授权关系还没补就重新提交", "星桥商贸公司"),
            ("JD-DEMO-001", "我确认删掉鞋类后重新提交", "鞋类"),
            ("JD-DEMO-001", "我确认保留服装类目重新提交", "鞋类"),
        ):
            with self.subTest(case=case_id, utterance=wrong):
                call_id = store.start_call(case_id)["call_id"]
                identity = store.turn(call_id, "是的，我是", "verify")
                if identity["state"] == "need":
                    store.turn(call_id, "是的", "need")
                result = store.turn(call_id, wrong, "wrong")
                self.assertEqual((result["state"], result["receipt_count"]), ("explain", 0))
                self.assertIn(anchor, result["reply"])

    def test_unknown_case_fails_without_creating_a_call(self):
        store = Store(self.db)
        with self.assertRaises(ValueError):
            store.start_call("JD-DEMO-missing")
        with self.assertRaises(ValueError):
            store.case_receipts("JD-DEMO-missing")
        with closing(sqlite3.connect(self.db)) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM calls").fetchone()[0], 0)

    def test_followups_distinguish_past_rejection_from_future_review(self):
        store = Store(self.db)
        call_id = store.start_call("JD-DEMO-002")["call_id"]
        store.turn(call_id, "是的，我是", "verify")
        future = store.turn(call_id, "补了就能过吗？", "outcome")
        self.assertEqual(future["state"], "explain")
        self.assertIn("公章", future["reply"])
        self.assertIn("复审", future["reply"])
        past = store.turn(call_id, "为什么没通过审核？", "why")
        self.assertIn("缺少", past["reply"])
        self.assertIn("公章", past["reply"])
        self.assertEqual(past["receipt_count"], 0)

    def test_request_to_keep_an_unauthorized_category_explains_new_authorization(self):
        store = Store(self.db)
        call_id = store.start_call()["call_id"]
        store.turn(call_id, "是的，我是", "verify")
        store.turn(call_id, "是的", "need")
        reply = store.turn(call_id, "我还想申请服装怎么办？", "keep-category")["reply"]
        self.assertIn("服装", reply)
        self.assertIn("授权", reply)
        before = store.get_call(call_id)
        self.assertEqual(before["receipt_count"], 0)
        reopened = Store(self.db)
        reopened.turn(call_id, "补了就肯定能过吗", "review")
        saved = reopened.turn(call_id, "我确认补好服装授权后重新提交", "confirm")
        self.assertEqual(saved["receipt_count"], 1)
        action = "".join(saved["receipt"]["action_steps"])
        self.assertIn("服装", action)
        self.assertNotIn("去掉", action)
        self.assertEqual(reopened.retry_writeback(call_id)["receipt"], saved["receipt"])

    def test_adding_new_category_authorization_cannot_write_a_remove_category_receipt(self):
        store = Store(self.db)
        call_id = store.start_call("JD-DEMO-001")["call_id"]
        store.turn(call_id, "是的，我是商家小贝塔", "verify")
        store.turn(call_id, "我想先卖鞋类", "select")
        result = store.turn(call_id, "我确认先补齐服装授权再重新提交。", "switch")
        self.assertEqual(result["receipt_count"], 0)
        store.turn(call_id, "我还想卖服装", "explain")
        saved = store.turn(call_id, "我确认补齐服装授权后重新提交。", "confirm")
        self.assertEqual(saved["receipt_count"], 1)
        self.assertNotIn("去掉", "".join(saved["receipt"]["action_steps"]))

    def test_seven_source_rows_render_their_own_application_context(self):
        from jd_mock.cases import get_order

        for case_id, variants in (
            ("JD-DEMO-001", {29: "品牌", 60: "入驻"}),
            ("JD-DEMO-002", {17: "品牌", 50: "入驻", 79: "商品"}),
            ("JD-DEMO-003", {22: "品牌", 52: "入驻"}),
        ):
            for row, area in variants.items():
                with self.subTest(row=row):
                    order = replace(get_order(case_id), source_row=row)
                    self.assertIn(area + "申请单", "".join(order.steps))
                    self.assertIn(f"A{row}:E{row}", order.evidence[0])

    def test_old_receipt_is_readable_with_case_binding_without_rewriting_its_bytes(self):
        raw = json.dumps({"receipt_id": "previous", "call_id": "old", "scenario": "品牌类目不符"})
        with closing(sqlite3.connect(self.db)) as connection, connection:
            connection.executescript("""
                CREATE TABLE calls(call_id TEXT PRIMARY KEY, state TEXT, reply TEXT,
                                   verified INTEGER, turn_count INTEGER, pending_writeback INTEGER);
                CREATE TABLE receipts(call_id TEXT PRIMARY KEY, payload TEXT NOT NULL);
                INSERT INTO calls VALUES ('old', 'closed', '已挂断', 1, 4, 0);
            """)
            connection.execute("INSERT INTO receipts VALUES ('old',?)", (raw,))
        store = Store(self.db)
        call = store.get_call("old")
        self.assertEqual(call["case_id"], "JD-DEMO-001")
        self.assertEqual(call["receipt"]["case_id"], "JD-DEMO-001")
        self.assertEqual(store.case_receipts("JD-DEMO-001")["latest_receipt"], call["receipt"])
        with closing(sqlite3.connect(self.db)) as connection:
            self.assertEqual(connection.execute("SELECT payload FROM receipts").fetchone()[0], raw)
