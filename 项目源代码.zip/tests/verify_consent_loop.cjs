// Replays the category flow that became stuck before confirmation.
const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, readCall, waitForAutoClose } = require("./verify_browser.cjs");
const { start, play, json } = require("./verify_workbench.cjs");

const root = path.resolve(__dirname, "..");
const id = "JD-DEMO-001";
const receiptURL = "/api/cases/" + id + "/receipts";
const fixtures = {
  identity: ["tests/fixtures/merchant_dialogue/recipient_repeat.wav", "是的，我是本人。"],
  requested: [".runtime/consent-loop/fixtures/requested.wav", "我还想卖服装。"],
  missing: [".runtime/consent-loop/fixtures/missing.wav", "目前还没有。"],
  obtained: [".runtime/consent-loop/fixtures/obtained.wav", "我现在已经拿到授权书了。"],
  yes: [".runtime/consent-loop/fixtures/yes.wav", "好的。"],
};
const memoryFixtures = {
  review: [".runtime/consent-loop/fixtures/review.wav", "补完以后，就一定能通过审核吗？"],
  resume: [".runtime/consent-loop/fixtures/resume.wav", "那接下来怎么办？"],
};

function assertUploadOffer(turn) {
  assert.equal(turn.state, "explain");
  assert.equal(turn.receipt_count, 0);
  assert.match(turn.reply, /服装/);
  assert.match(turn.reply, /上传|传到|传回/);
  assert.match(turn.reply, /重新提交/);
  assert.match(turn.reply, /您打算按这个办法处理吗？$/);
  assert.match(turn.dialogue_focus, /^category_extra_(upload|confirm)$/);
  assert.doesNotMatch(turn.reply, /暂时拿不到|联系.{0,8}授权方补|手头有这份文件吗|请先补一份/);
}

async function check(page, call) {
  const before = await json(page, receiptURL);
  await start(page, call, call.simulate_timeout);
  const identity = await play(page, call, "identity", "identity");
  assert.equal(identity.verified, true);
  const requested = await play(page, call, "requested", "requests_additional_category");
  assert.match(requested.reply, /服装.*授权|授权.*服装/);
  assert.match(requested.dialogue_focus, /^category_extra/);
  assert.equal(requested.dialogue_decision?.source, "model");
  assert.equal(requested.receipt_count, 0);

  const missing = await play(page, call, "missing", "lacks_authorization");
  assert.match(missing.reply, /联系.*授权方|补一份/);
  assert.equal(missing.receipt_count, 0);

  const obtained = await play(page, call, "obtained", "reports_obtained_authorization");
  assertUploadOffer(obtained);
  assert.equal(obtained.dialogue_decision?.source, "model");
  assert.equal(obtained.dialogue_decision?.action, "upload_authorization");

  if (call.checks_memory) {
    const review = await play(page, call, "review", "asks_about_future_review");
    assert.match(call.turns.at(-1).transcript, /能通过审核|能过审/);
    assert.match(review.reply, /复审|审核人员|人工审核/);
    assert.equal(review.state, "explain");
    assert.equal(review.dialogue_decision?.action, "review");
    assert.equal(review.dialogue_decision?.context?.document, "available");
    assert.equal(review.receipt_count, 0);
    assert.equal(review.pending_writeback, false);
    assert.equal((await json(page, receiptURL)).receipt_count, before.receipt_count);
    const resume = await play(page, call, "resume", "resumes_offered_upload");
    assert.match(call.turns.at(-1).transcript, /接着|接下来|然后|下一步/);
    assertUploadOffer(resume);
    assert.equal(resume.dialogue_decision?.action, "upload_authorization");
    assert.equal(resume.dialogue_decision?.context?.document, "available");
    assert.doesNotMatch(resume.reply, /拿到.{0,30}(?:之后|以后|后)/);
    assert.equal((await json(page, receiptURL)).receipt_count, before.receipt_count);
  }

  const confirmation = await play(page, call, "yes", "confirmation", { consumeReply: false });
  assert.equal(confirmation.state, "complete");
  assert.equal(confirmation.dialogue_decision?.action, "record");
  assert.equal(confirmation.receipt_count, 1);
  assert.equal(confirmation.pending_writeback, call.simulate_timeout);
  await waitForAutoClose(page);
  call.automatically_ended = true;

  if (call.simulate_timeout) {
    assert.equal(confirmation.receipt, null);
    assert.equal((await json(page, receiptURL)).receipt_count, before.receipt_count);
    assert.equal(await page.locator("#start-call").isDisabled(), true);
    await page.locator("#retry-writeback").click();
    await page.locator('#receipt-badge[data-status="saved"]').waitFor();
  }
  const saved = await readCall(page, call.call_id);
  const repeated = await json(page, "/api/calls/" + call.call_id + "/retry", true);
  const history = await json(page, receiptURL);
  assert.equal(saved.receipt.case_id, id);
  assert.equal(saved.receipt.call_id, call.call_id);
  assert.equal(saved.receipt_count, 1);
  assert.equal(repeated.receipt_count, 1);
  assert.equal(repeated.pending_writeback, false);
  assert.deepEqual(repeated.receipt, saved.receipt);
  assert.equal(history.receipt_count, before.receipt_count + 1);
  assert.equal(history.latest_receipt.receipt_id, saved.receipt.receipt_id);
  const steps = saved.receipt.action_steps.join(" ");
  assert.match(steps, /服装.*授权|授权.*服装/);
  assert.doesNotMatch(steps, /去掉.*服装/);
  assert.equal(await page.locator("#start-call").isEnabled(), true);
  call.receipt = saved.receipt;
  call.retry_is_idempotent = true;
  call.can_start_next_call = true;
  call.passed = true;
}

async function main() {
  const [baseURL, output, mode] = process.argv.slice(2);
  if (!baseURL || !output || fs.existsSync(output) || (mode && mode !== "--memory")) {
    throw new Error("Usage: node tests/verify_consent_loop.cjs http://127.0.0.1:TEST_PORT NEW_RESULT.json [--memory]");
  }
  const checksMemory = mode === "--memory";
  const url = new URL(baseURL);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || url.port === "8779") {
    throw new Error("Use an isolated loopback service with an empty database.");
  }
  const recordings = checksMemory ? { ...fixtures, ...memoryFixtures } : fixtures;
  const assets = Object.fromEntries(Object.entries(recordings).map(([key, [file, phrase]]) => {
    const wav = fs.readFileSync(path.join(root, file));
    return [key, { file, phrase, encoded: wav.toString("base64"),
      sha256: createHash("sha256").update(wav).digest("hex") }];
  }));
  const browser = await chromium.launch({ executablePath: browserPath, headless: true,
    args: ["--autoplay-policy=no-user-gesture-required"] });
  const report = {
    base_url: baseURL, browser: browser.version(), started_at: new Date().toISOString(),
    fixtures: Object.fromEntries(Object.entries(assets).map(([key, { encoded, ...meta }]) => [key, meta])),
    calls: (checksMemory ? [false] : [false, true]).map(simulate_timeout => ({
      case_id: id, simulate_timeout, checks_memory: checksMemory, turns: [], passed: false,
    })),
    passed: false,
  };
  try {
    const page = await browser.newPage({ baseURL });
    await installFixtureMicrophone(page, assets, { meterEnabled: true, measureReprompts: true });
    await page.goto("/");
    await page.locator('#health[data-health="ready"]').waitFor();
    assert.equal((await json(page, receiptURL)).receipt_count, 0, "Use an empty database");
    for (const call of report.calls) {
      const scenario = call.checks_memory ? "memory" : call.simulate_timeout ? "timeout" : "normal";
      try {
        await check(page, call);
        console.log(scenario, "PASS");
      } catch (error) {
        call.error = error.message;
        if (call.call_id) {
          call.last_state = await readCall(page, call.call_id).catch(() => null);
          await json(page, "/api/calls/" + call.call_id + "/end", true).catch(() => {});
        }
        await page.reload();
        console.error(scenario, error.message);
      }
    }
    report.passed = report.calls.every(call => call.passed);
  } finally {
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
    await browser.close();
  }
  if (!report.passed) process.exitCode = 1;
}

main().catch(error => { console.error(error); process.exitCode = 1; });
