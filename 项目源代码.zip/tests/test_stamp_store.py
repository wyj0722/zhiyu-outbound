import tempfile
import unittest
from dataclasses import replace
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Event
from unittest.mock import Mock

from jd_mock.business import COMPLETED, Store
from jd_mock.cases import get_order
from jd_mock.dialogue import COMMITMENT_QUESTION, stamp_confirmation, stamp_submitted_material
from jd_mock.stamp_agent import StampDecision


def decision(action):
    offered = action in {"request_stamp", "record"}
    plan = "request_stamp" if offered else ""
    reply = "请补盖授权方公章并重新提交。" + COMMITMENT_QUESTION if offered else "章面上写的是谁的名字？"
    return StampDecision(reply, action, "merchant" if offered else "unknown", "unknown", action == "record",
                         {"plan_offered": offered, "plan": plan}, "model", None, 12, ("模拟工单依据",))


class StampStoreTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.path = Path(tmp.name) / "calls.sqlite3"
        self.agent = Mock()
        self.store = Store(self.path, stamp_agent=self.agent)
        self.call = self.store.start_call("JD-DEMO-002")["call_id"]

    def turn(self, text, key, **kwargs):
        return self.store.turn(self.call, text, key, **kwargs)

    def test_verified_stamp_call_explains_submitted_facts_and_accepts_one_spoken_consent(self):
        order = get_order("JD-DEMO-002")
        reply, focus = stamp_confirmation(order, include_submitted=True)
        opening = self.turn("我是本人", "id")
        self.assertEqual((opening["state"], opening["reply"], opening["dialogue_focus"]), ("explain", reply, focus))
        self.assertEqual(opening["receipt_count"], 0)
        trace = opening["stamp_decision"]
        self.assertEqual((trace["source"], trace["context"]["owner_source"]), ("policy", "submitted_material"))
        self.assertEqual(trace["context"]["owner_evidence"], order.submitted_authorization["seal"])
        self.assertTrue(trace["context"]["plan_offered"])
        self.agent.decide.assert_not_called()

        self.store = Store(self.path, stamp_agent=self.agent)
        saved = self.turn("好的。", "accept", delivered_reply="", started_plan=reply, simulate_timeout=True)
        self.assertTrue(saved["pending_writeback"])
        self.assertEqual(saved["receipt_count"], 1)
        recovered = self.store.retry_writeback(self.call)
        self.assertEqual(recovered["receipt"]["confirmation_text"], "好的。")
        self.assertEqual(recovered, self.store.retry_writeback(self.call))
        self.agent.decide.assert_not_called()

    def test_acknowledging_the_submitted_stamp_preface_only_repeats_the_remedy(self):
        order = get_order("JD-DEMO-002")
        opening = self.turn("我是本人", "id")
        preface = stamp_submitted_material(order)
        remedy, _ = stamp_confirmation(order)
        self.assertTrue(opening["reply"].startswith(preface))
        too_early = self.turn("嗯，好的。", "early", delivered_reply=preface)
        self.assertEqual((too_early["receipt_count"], too_early["reply"]), (0, remedy))
        self.assertFalse(too_early["stamp_decision"]["previous_plan_started"])
        stale = self.turn("好。", "stale", delivered_reply="", started_plan=opening["reply"])
        self.assertEqual((stale["receipt_count"], stale["reply"]), (0, remedy))
        saved = self.turn("好。", "after-remedy", delivered_reply=remedy.removesuffix(COMMITMENT_QUESTION))
        self.assertEqual((saved["receipt_count"], saved["reply"]), (1, COMPLETED))
        self.agent.decide.assert_not_called()

    def test_only_verified_stamp_order_uses_model(self):
        self.turn("我想问原因", "precheck")
        self.turn("我是本人", "id")
        for case_id in ("JD-DEMO-001", "JD-DEMO-003"):
            call = self.store.start_call(case_id)["call_id"]
            self.store.turn(call, "我是本人", "id")
            self.store.turn(call, "想听原因", "need")
        self.agent.decide.assert_not_called()
        self.agent.decide.return_value = decision("ask_owner")
        answer = self.turn("我有个问题", "business")
        self.assertEqual(answer["stamp_decision"]["action"], "ask_owner")
        self.assertEqual(answer["receipt_count"], 0)

    def test_explicit_interruption_accepts_started_stamp_offer_without_another_model_turn(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        offer = self.turn("这份盖的是我的章", "plan")["reply"]
        self.agent.decide.side_effect = TimeoutError("No extra model decision is needed to accept this offer")
        result = self.turn("嗯，好的。", "agree", delivered_reply="", started_plan=offer)
        self.assertEqual((result["state"], result["reply"], result["receipt_count"]), ("complete", COMPLETED, 1))
        self.assertFalse(result["stamp_decision"]["previous_reply_sent_in_full"])
        self.assertTrue(result["stamp_decision"]["previous_plan_started"])
        self.assertEqual(self.store.retry_writeback(self.call)["receipt"], result["receipt"])
        self.agent.decide.assert_called_once()

    def test_model_never_commits_by_itself_and_consent_is_idempotent(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("record")
        early = self.turn("我同意", "early")
        self.assertEqual(early["receipt_count"], 0)
        self.assertNotEqual(early["stamp_decision"]["applied_action"], "record")
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("这份盖的是我的章", "plan")
        self.agent.decide.return_value = decision("record")
        no = self.turn("我只是看看，还没决定", "hold")
        self.assertEqual(no["receipt_count"], 0)
        self.assertNotIn("已收到", no["reply"])
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("请再讲一次怎么补", "plan-again")
        self.agent.decide.return_value = decision("record")
        self.store = Store(self.path, stamp_agent=self.agent)
        yes = self.turn("我确认补好授权方的章后重新提交", "yes", simulate_timeout=True)
        self.assertTrue(yes["pending_writeback"])
        self.assertEqual(yes["stamp_decision"]["applied_action"], "record")
        self.assertEqual(yes, self.turn("我确认补好授权方的章后重新提交", "yes"))
        receipt = self.store.retry_writeback(self.call)
        self.assertEqual(receipt["receipt_count"], 1)
        self.assertEqual(receipt, self.store.retry_writeback(self.call))

    def test_hangup_during_inference_can_commit_without_waiting_for_model(self):
        self.turn("我是本人", "id")
        entered, release = Event(), Event()
        def stalled(*args, **kwargs):
            entered.set()
            release.wait(4)
            return decision("request_stamp")
        self.agent.decide.side_effect = stalled
        with ThreadPoolExecutor(2) as pool:
            turn = pool.submit(self.turn, "我有个问题", "pending")
            try:
                self.assertTrue(entered.wait(2))
                closed = pool.submit(self.store.end_call, self.call).result(timeout=1)
            finally:
                release.set()
            self.assertEqual(turn.result(timeout=2), closed)
        self.assertEqual(closed["receipt_count"], 0)

    def test_superseded_model_reply_cannot_write_after_a_new_utterance(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        offer = self.turn("章上写的是我们店", "offer")["reply"]
        entered, release, interrupted = Event(), Event(), Event()

        def decide(_order, text, _context, _reply):
            if text == "我会补好公章，然后重新上传材料":
                entered.set()
                release.wait(4)
                return decision("record")
            return decision("hold")

        self.agent.decide.side_effect = decide
        with ThreadPoolExecutor(2) as pool:
            stale = pool.submit(
                self.turn, "我会补好公章，然后重新上传材料", "older",
                delivered_reply=offer, cancelled=interrupted.is_set,
            )
            try:
                self.assertTrue(entered.wait(2))
                interrupted.set()
                newer = self.turn("先等等，我还没决定。", "newer")
            finally:
                release.set()
            self.assertEqual(stale.result(timeout=2), newer)
        self.assertEqual(newer["stamp_decision"]["turn_id"], "newer")
        self.assertEqual(newer["receipt_count"], 0)

    def test_self_contained_commitment_can_correct_a_missed_model_intent(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("ask_owner")
        self.turn("我有这份授权书", "business")
        yes = self.turn("我同意请授权方补盖公章，再把完整授权书重新提交。", "yes", simulate_timeout=True)
        self.assertTrue(yes["pending_writeback"])
        trace = yes["stamp_decision"]
        self.assertEqual((trace["action"], trace["applied_action"]), ("ask_owner", "record"))
        self.assertEqual(trace["receipt_basis"], "explicit_remedy")
        self.assertEqual(trace["context"]["plan"], "request_stamp")
        self.store = Store(self.path, stamp_agent=self.agent)
        recovered = self.store.retry_writeback(self.call)
        self.assertEqual(recovered, self.turn("我同意请授权方补盖公章，再把完整授权书重新提交。", "yes"))
        self.assertEqual(recovered["receipt"]["case_id"], "JD-DEMO-002")
        self.assertEqual(recovered["receipt_count"], 1)

    def test_clear_assent_to_a_spoken_plan_survives_model_intent_error(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("印的是我店的名字", "plan")
        self.agent.decide.return_value = decision("ask_owner")
        confirmed = self.turn("好的，我就按您说的办法处理", "yes")
        self.assertEqual(confirmed["receipt_count"], 1)
        self.assertEqual(confirmed["stamp_decision"]["receipt_basis"], "accepted_spoken_plan")

    def test_acknowledgments_uncertainty_and_wrong_stamp_cannot_authorize_writing(self):
        samples = ("我确认那是我们的名字", "如果我同意请品牌方补盖章再提交呢",
                   "我按这个方法来办吗？", "以前我按这个方法来办过。", "我按这个方法来办，但先别登记。",
                   "我同意请经销商补盖章再重新提交", "我同意先问问能不能盖授权方的公章再提交",
                   "我同意请授权方补盖公章再重新提交，先别登记", "我会考虑重新提交",
                   "你是说我同意请授权方补盖公章再重新提交", "我会把旧照片重新提交",
                   "我确认上个月找授权方盖过章，也已经提交过了", "我同意先问问授权方盖章后怎么提交",
                   "我同意请授权方盖章，但这只是举个例子，说的不是这张单")
        for sample in samples:
            with self.subTest(sample=sample):
                call = self.store.start_call("JD-DEMO-002")["call_id"]
                self.store.turn(call, "我是本人", "id")
                self.agent.decide.return_value = decision("request_stamp")
                self.store.turn(call, "我需要做什么", "plan")
                self.agent.decide.return_value = decision("record")
                self.assertEqual(self.store.turn(call, sample, "try")["receipt_count"], 0)

    def test_model_outage_or_acknowledging_an_owner_question_cannot_confirm_a_plan(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("印的是我们店", "plan")
        self.agent.decide.return_value = replace(decision("ask_owner"), source="fallback")
        self.assertEqual(self.turn("我同意请品牌方补盖公章再重新提交", "outage")["receipt_count"], 0)
        self.agent.decide.return_value = decision("record")
        self.assertEqual(self.turn("好的", "yes")["receipt_count"], 0)

    def test_previous_web_confirmation_and_existing_grantor_document(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("这是我们自己的章", "plan")
        self.agent.decide.return_value = decision("record")
        self.assertEqual(self.turn("我确认按步骤修改后重新提交", "yes")["receipt_count"], 1)
        call = self.store.start_call("JD-DEMO-002")["call_id"]
        self.store.turn(call, "我是本人", "id")
        upload = replace(decision("request_stamp"), action="upload", owner="grantor",
                         context={"plan": "upload", "owner": "grantor", "plan_offered": True})
        self.agent.decide.return_value = upload
        self.store.turn(call, "青禾品牌公司的章已经盖好了", "plan")
        self.agent.decide.return_value = decision("ask_owner")
        saved = self.store.turn(call, "我会把完整授权书上传后再提交", "yes")
        self.assertEqual(saved["receipt_count"], 1)
        self.assertIn("核对现有完整授权书", saved["receipt"]["action_steps"][0])

    def test_short_assent_requires_the_current_spoken_plan_to_finish(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        plan = self.turn("是我们店铺的章", "plan")["reply"]
        self.agent.decide.return_value = decision("record")
        for index, heard in enumerate(("", "刚才没听清，请再说一遍。")):
            answer = self.turn("是的", f"early-{index}", delivered_reply=heard)
            self.assertEqual(answer["receipt_count"], 0)
            self.assertEqual(answer["reply"], plan)
            self.assertEqual(answer["stamp_decision"]["applied_action"], "request_stamp")
        self.assertEqual(self.turn("是的", "late", delivered_reply=plan)["receipt_count"], 1)

    def test_filler_plus_agreement_binds_to_the_heard_plan_including_during_the_question(self):
        for in_question in (False, True):
            with self.subTest(in_question=in_question):
                call_id = self.store.start_call("JD-DEMO-002")["call_id"]
                self.store.turn(call_id, "我是本人", "identity")
                self.agent.decide.return_value = decision("request_stamp")
                plan = self.store.turn(call_id, "这是我们公司的章", "offer")["reply"]
                self.agent.decide.return_value = decision("ask_owner")
                early = self.store.turn(call_id, "嗯，好的。", "interrupted", delivered_reply="")
                self.assertEqual(early["receipt_count"], 0)
                self.assertEqual(early["reply"], plan)
                heard = plan.removesuffix(COMMITMENT_QUESTION) if in_question else plan
                result = self.store.turn(call_id, "嗯，好的。", "agreed", delivered_reply=heard)
                self.assertEqual(result["receipt_count"], 1)
                self.assertTrue(result["stamp_decision"]["previous_plan_sent"])
                self.assertEqual(result["stamp_decision"]["previous_reply_sent_in_full"], not in_question)
                self.assertEqual(result["receipt"]["confirmation_text"], "嗯，好的。")
                self.assertEqual(self.store.retry_writeback(call_id)["receipt"], result["receipt"])

    def test_backchannel_does_not_write_or_discard_the_active_offer(self):
        self.turn("我是本人", "identity")
        self.agent.decide.return_value = decision("request_stamp")
        plan = self.turn("这是我们公司的章", "offer")["reply"]
        self.agent.decide.return_value = decision("ask_owner")
        for index, words in enumerate(("嗯。", "好的？", "嗯，好的，我先看看。")):
            result = self.turn(words, str(index), delivered_reply=plan)
            self.assertEqual(result["receipt_count"], 0)
            if words == "嗯。":
                self.assertEqual(result["reply"], plan)

    def test_repeated_acknowledgments_and_plan_references_compose_with_different_offers(self):
        expressions = (
            "好的好的。",
            "行，那就这样定了。",
            "可以，照您刚才说的来。",
            "成，听您的。",
            "那我们就按刚才那个方案处理。",
            "对，我们就依照你说的方法执行。",
        )
        for text in expressions:
            for plan_type in ("request_stamp", "upload"):
                with self.subTest(text=text, plan=plan_type):
                    call_id = self.store.start_call("JD-DEMO-002")["call_id"]
                    self.store.turn(call_id, "我是本人", "identity")
                    plan = decision("request_stamp")
                    if plan_type == "upload":
                        plan = replace(
                            plan, action="upload", owner="grantor",
                            reply="把这份盖章齐全的授权书重新上传提交。" + COMMITMENT_QUESTION,
                            context={"plan_offered": True, "plan": "upload", "owner": "grantor"},
                        )
                    self.agent.decide.return_value = plan
                    self.store.turn(call_id, "我看完章了", "plan")
                    self.agent.decide.return_value = decision("record")
                    early = self.store.turn(call_id, text, "early", delivered_reply="")
                    self.assertEqual((early["receipt_count"], early["reply"]), (0, plan.reply))
                    result = self.store.turn(call_id, text, "confirm", delivered_reply=plan.reply.removesuffix(COMMITMENT_QUESTION))
                    self.assertEqual(result["receipt_count"], 1)
                    self.assertEqual(result["stamp_decision"]["context"]["plan"], plan_type)

    def test_understanding_the_offer_keeps_it_available_for_later_consent(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        plan = self.turn("我们公司的章", "plan")["reply"]
        self.agent.decide.return_value = decision("ask_owner")
        understood = self.turn("收到，我听明白了。", "heard", delivered_reply=plan)
        self.assertEqual(understood["receipt_count"], 0)
        self.assertEqual(understood["reply"], plan)
        self.assertEqual(self.turn("没问题，就按这个来。", "accept", delivered_reply=plan)["receipt_count"], 1)

    def test_clear_first_person_commitment_survives_unclear_acknowledgment(self):
        for words, expected in (
            ("对以我就照您说的处理。", 1),
            ("嗯哟我就按你说的办法办。", 1),
            ("好像我就照您说的处理。", 0),
            ("对方说我就照您说的处理。", 0),
            ("不对，我就照您说的处理。", 0),
            ("对以我就照您说的处理，可以吗？", 0),
        ):
            with self.subTest(words=words):
                call = self.store.start_call("JD-DEMO-002")["call_id"]
                self.store.turn(call, "我是本人", "identity")
                self.agent.decide.return_value = decision("request_stamp")
                plan = self.store.turn(call, "我们公司的章", "offer")["reply"]
                # Even a valid model response can miss the intent when the
                # first syllable is noisy. The tail and playback are known.
                self.agent.decide.return_value = decision("ask_owner")
                if expected:
                    early = self.store.turn(call, words, "too_early", delivered_reply="")
                    self.assertEqual((early["receipt_count"], early["reply"]), (0, plan))
                result = self.store.turn(call, words, "accept", delivered_reply=plan.removesuffix(COMMITMENT_QUESTION))
                self.assertEqual(result["receipt_count"], expected)

    def test_model_agreement_can_authorize_a_paraphrased_matching_remedy(self):
        statements = (
            "我同意整改，我会找授权方重新盖章，再把授权书提交。",
            "可以，我按这个方案请品牌方补盖公章，再去重新提交。",
            "我答应按刚才的办法补盖授权方公章，改好后再提交申请。",
        )
        for text in statements:
            with self.subTest(text=text):
                call = self.store.start_call("JD-DEMO-002")["call_id"]
                self.store.turn(call, "我是本人", "identity")
                self.agent.decide.return_value = decision("request_stamp")
                self.store.turn(call, "这枚章是我们自己的", "plan")
                self.agent.decide.return_value = decision("record")
                result = self.store.turn(call, text, "accept")
                self.assertEqual(result["receipt_count"], 1)
                self.assertEqual(result["stamp_decision"]["context"]["plan"], "request_stamp")

    def test_ambiguous_negative_stamp_requests_confirmation_before_any_write(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("本店的章", "plan")
        self.agent.decide.return_value = decision("upload")
        query = self.turn("可以，我去请品牌方不盖公章，再去重新提交", "ambiguous")
        self.assertEqual(query["receipt_count"], 0)
        self.assertEqual(query["stamp_decision"]["applied_action"], "clarify_stamp")
        self.assertIn("盖章这一步", query["reply"])
        self.agent.decide.return_value = decision("record")
        yes = self.turn("我同意办理", "confirmed", delivered_reply=query["reply"])
        self.assertEqual(yes["receipt_count"], 1)

    def test_first_person_pledge_can_refer_back_to_a_delivered_plan(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        plan = self.turn("盖的是本店的章", "plan")["reply"]
        self.agent.decide.return_value = decision("record")
        result = self.turn("明白了，我会补好公章，然后重新上传材料", "consent", delivered_reply=plan)
        self.assertEqual(result["receipt_count"], 1)

    def test_commitment_to_the_offered_plan_can_be_expressed_in_ordinary_speech(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("我需要做什么", "plan")
        self.agent.decide.return_value = decision("record")
        uncertain = self.turn("等我问过老板，再看能不能按您说的办", "later")
        self.assertEqual(uncertain["receipt_count"], 0)
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("请再解释一下", "new-plan")
        self.agent.decide.return_value = decision("record")
        committed = self.turn("行，我就按您说的办法处理", "consent")
        self.assertEqual(committed["receipt_count"], 1)

    def test_headset_assent_after_interruption_commits_the_replayed_plan_once(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        offered = self.turn("我们公司。", "owner")["reply"]
        self.agent.decide.return_value = decision("record")
        interrupted = self.turn("好。", "early", delivered_reply="")
        self.assertEqual(interrupted["receipt_count"], 0)
        self.assertEqual(interrupted["reply"], offered)
        words = "好的，我按这个方法来办。"
        self.assertEqual(self.turn(words, "still_early", delivered_reply="")["receipt_count"], 0)
        accepted = self.turn(words, "yes", delivered_reply=offered)
        self.assertEqual(accepted["receipt_count"], 1)
        self.assertEqual(accepted["receipt"]["confirmation_text"], words)
        self.assertEqual(accepted["receipt"]["case_id"], "JD-DEMO-002")
        self.assertEqual(self.turn("没有了。", "end")["receipt"], accepted["receipt"])

    def test_ambiguous_acceptance_can_be_clarified_without_losing_the_plan(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        offered = self.turn("是我们公司的章", "plan")["reply"]
        self.agent.decide.return_value = decision("record")
        unclear = self.turn("我听明白你的意思了", "ack", delivered_reply=offered)
        self.assertEqual(unclear["receipt_count"], 0)
        self.assertEqual(unclear["stamp_decision"]["context"]["plan"], "request_stamp")
        self.assertTrue(unclear["reply"].endswith(COMMITMENT_QUESTION))
        self.assertEqual(self.turn("我同意办理", "yes", delivered_reply=unclear["reply"])["receipt_count"], 1)

    def test_no_further_questions_after_deferral_ends_without_a_receipt(self):
        self.turn("我是本人", "id")
        self.agent.decide.return_value = decision("request_stamp")
        self.turn("印的是自己的章", "plan")
        self.agent.decide.return_value = decision("record")
        hold = self.turn("我还没有决定", "wait")
        self.assertEqual(hold["stamp_decision"]["applied_action"], "hold")
        self.agent.decide.return_value = decision("ask_owner")
        done = self.turn("没有了。", "end", delivered_reply=hold["reply"])
        self.assertEqual((done["state"], done["receipt_count"]), ("closed", 0))

    def test_future_upload_commitment_binds_to_spoken_verified_grantor_plan(self):
        self.turn("我是本人", "id")
        offer = replace(decision("request_stamp"), action="upload", owner="grantor",
                        reply="请把盖好章的当前授权书上传到商品申请单再重新提交。" + COMMITMENT_QUESTION,
                        context={"plan": "upload", "owner": "grantor", "plan_offered": True})
        self.agent.decide.return_value = offer
        plan = self.turn("是青禾品牌公司的章。", "plan")
        self.agent.decide.return_value = decision("record")
        for spoken in ("我明早可能才把这份材料传上去重新提交。", "我昨天把这份材料传上去了。",
                       "那我下午把那份旧材料传上去重新提交。", "好，那我把这份材料传上去就会过吗？"):
            with self.subTest(text=spoken):
                self.assertEqual(self.turn(spoken, spoken, delivered_reply=plan["reply"])["receipt_count"], 0)
                self.agent.decide.return_value = offer
                plan = self.turn("请再说一遍。", "offer-" + spoken)
                self.agent.decide.return_value = decision("record")
        next_turn = "那就这么定，我今天把这份材料传上去，重新提交。"
        early = self.turn(next_turn, "early", delivered_reply="")
        self.assertEqual((early["receipt_count"], early["reply"]), (0, plan["reply"]))
        result = self.turn(next_turn, "confirmed", delivered_reply=early["reply"], simulate_timeout=True)
        self.assertEqual(result["stamp_decision"]["receipt_basis"], "accepted_upload")
        self.assertTrue(result["pending_writeback"])
        saved = self.store.retry_writeback(self.call)
        self.assertIn("核对现有完整授权书", saved["receipt"]["action_steps"][0])
        self.assertEqual(self.store.retry_writeback(self.call), saved)
