// Replay a sealed set through the normal microphone/WebRTC/ASR path.
// Only WAV bytes enter the page. No ground truth, prompts, or case labels enter the service.
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require(process.env.JD_PLAYWRIGHT_PATH || "playwright");
const { browserPath, installFixtureMicrophone, waitForReplyToFinish, readCall, selectWorkOrder, stats, milliseconds } = require("./verify_browser.cjs");

const [url, directory, output] = process.argv.slice(2);
const hash = (bytes) => crypto.createHash("sha256").update(bytes).digest("hex");
const read = (file) => fs.readFileSync(path.join(directory, file));
const load = (file) => JSON.parse(read(file).toString("utf8"));
const timeout = 65000;

async function play(page, callId, label, wav) {
  const marker = await page.evaluate(() => window.jdAcceptance.trace.length);
  await page.evaluate(({ name, label }) => window.jdAcceptance.play(name, label), { name: wav, label });
  const finished = await page.waitForFunction((marker) => {
    const events = window.jdAcceptance.trace.slice(marker);
    const first = events.findIndex((e) => e.type === "state" && e.state === "speaking");
    return first >= 0 && events.slice(first + 1).some((e) =>
      e.type === "ended" || (e.type === "state" && e.state === "listening"));
  }, marker, { timeout });
  await finished.dispose();
  const data = await page.evaluate(({ marker, label }) => {
    const events = window.jdAcceptance.trace.slice(marker);
    const turn = window.jdAcceptance.turns.find((t) => t.phase === label);
    return {
      transcript: events.find((e) => e.type === "transcript" && e.final)?.text || "",
      update: events.find((e) => e.type === "update")?.data || null,
      voice_end: turn.voiceEnd, first_audio: turn.firstAudioAt ?? null,
      server_timing: turn.serverTiming || null,
    };
  }, { marker, label });
  const state = await readCall(page, callId);
  const last = page.locator('#messages [data-role="agent"] p').last();
  return {
    id: label, transcript: data.transcript, reply: await last.innerText(),
    first_audio_ms: milliseconds(data.voice_end, data.first_audio), server_timing: data.server_timing,
    receipt_count: state.receipt_count, receipt_id: state.receipt?.receipt_id ?? null,
    state: state.state, verified: state.verified, update: data.update,
  };
}

async function main() {
  if (!output || fs.existsSync(output)) throw new Error("Supply URL, sealed directory, and a new output JSON");
  const manifest = load("sealed.json");
  const audio = load("audio.json");
  const seal = read("seal.sha256").toString().trim();
  assert.equal(hash(read("sealed.json")), seal);
  assert.equal(audio.seal_sha256, seal);
  const fixtures = Object.fromEntries(Object.entries(audio.files).map(([name, expected]) => {
    const bytes = read("wav/" + name + ".wav");
    assert.equal(hash(bytes), expected);
    return [name, { encoded: bytes.toString("base64") }];
  }));
  const browser = await chromium.launch({
    executablePath: browserPath, headless: true, args: ["--autoplay-policy=no-user-gesture-required"],
  });
  const report = {
    url, browser: browser.version(), seal_sha256: seal, audio_sha256: hash(read("audio.json")),
    started_at: new Date().toISOString(), episodes: [],
  };
  const planned = manifest.episodes.reduce((n, episode) => n + episode.turns.length, 0);
  function save() {
    const times = report.episodes.flatMap((e) => e.turns.map((t) => t.first_audio_ms));
    report.business_first_audio_ms = stats(times, planned);
    fs.writeFileSync(output + ".partial", JSON.stringify(report, null, 2) + "\n");
    fs.renameSync(output + ".partial", output);
  }
  try {
    for (const episode of manifest.episodes) {
      const test = { id: episode.id, controls: [], turns: [] };
      report.episodes.push(test);
      const page = await browser.newPage({ baseURL: url, viewport: { width: 1440, height: 1000 } });
      try {
        await installFixtureMicrophone(page, fixtures, { meterEnabled: true, measureReprompts: true });
        await page.goto("/");
        await page.locator('#health[data-health="ready"]').waitFor({ timeout });
        await selectWorkOrder(page, manifest.order, { timeout });
        const created = page.waitForResponse((r) => new URL(r.url()).pathname === "/api/calls" && r.ok());
        await page.locator("#start-call").click();
        test.call_id = (await (await created).json()).call_id;
        await waitForReplyToFinish(page, 0);
        for (const fixture of ["identity", "identity_retry"]) {
          const answer = await play(page, test.call_id, fixture, fixture);
          test.controls.push(answer);
          if (answer.verified) break;
        }
        if (!test.controls.at(-1).verified) throw new Error("Both identity controls failed");
        for (const turn of episode.turns) {
          const answer = await play(page, test.call_id, turn.id, turn.id);
          test.turns.push(answer);
          save();
          if (answer.state === "complete" || answer.state === "closed") break;
        }
      } catch (error) {
        test.error = String(error.message);
      } finally {
        if (test.call_id) {
          await page.request.post("/api/calls/" + test.call_id + "/end").catch(() => {});
          test.final_state = await readCall(page, test.call_id).catch(() => null);
        }
        await page.close();
        save();
        console.log(episode.id, test.turns.length, "of", episode.turns.length, test.error || "");
      }
    }
  } finally {
    await browser.close();
  }
  report.ended_at = new Date().toISOString();
  save();
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
