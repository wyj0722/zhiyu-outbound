import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from jd_mock.asr_vocabulary import Vocabulary, default_vocabulary


CATEGORY = "JD-DEMO-001"
STAMP = "JD-DEMO-002"
CHAIN = "JD-DEMO-003"


class VocabularyTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / "domain-terms.json"

    def write_rules(self, rules):
        self.path.write_text(json.dumps({"version": 1, "rules": rules}, ensure_ascii=False), encoding="utf-8")

    def test_default_vocabulary_preserves_legacy_scope_and_rule_order(self):
        vocabulary = default_vocabulary()
        self.assertIs(vocabulary, default_vocabulary())
        for raw, expected in (
            ("眼泪在哪里勾选", "鞋类在哪里勾选"),
            ("节类还要补什么材料", "鞋类还要补什么材料"),
            ("我想选鞋嘞报到哪里修改权类", "我想选鞋类报到哪里修改权类"),
            ("这个授权内幕是在哪改的", "这个授权类目是在哪改的"),
            ("我在哪里选授权内目", "我在哪里选授权类目"),
            ("怎么勾选授权类？", "怎么勾选授权类目？"),
            ("我想选鞋报道哪里修改授权类", "我想选鞋类道哪里修改授权类目"),
            ("我想了解授权内幕", "我想了解授权内幕"),
            ("我想选鞋报这个牌子再修改授权类目", "我想选鞋报这个牌子再修改授权类目"),
        ):
            with self.subTest(raw=raw):
                self.assertEqual(vocabulary.correct(CATEGORY, raw), expected)
                self.assertEqual(vocabulary.correct(STAMP, raw), raw)

    def test_new_corrections_need_context_and_preserve_chain_direction(self):
        vocabulary = default_vocabulary()
        for case_id, raw, expected in (
            (CATEGORY, "些类合服中我都想怎么办", "鞋类和服装我都想怎么办"),
            (CATEGORY, "些类合服中我不想都留", "些类合服中我不想都留"),
            (CHAIN, "是不是新桥上贸公司授权给云山品牌公司", "是不是星桥商贸公司授权给云杉品牌公司"),
            (CHAIN, "我要找云山品牌公司", "我要找云山品牌公司"),
            (STAMP, "授权书上盖了公张", "授权书上盖了公章"),
            (STAMP, "我认识公张", "我认识公张"),
        ):
            with self.subTest(raw=raw):
                self.assertEqual(vocabulary.correct(case_id, raw), expected)

    def test_category_homophones_require_sales_or_authorization_context(self):
        vocabulary = default_vocabulary()
        for raw, expected in (
            ("我就只卖鞋嘞", "我就只卖鞋类"),
            ("目前先经营鞋累。", "目前先经营鞋类。"),
            ("我不只卖鞋嘞，还想卖服装", "我不只卖鞋类，还想卖服装"),
            ("只经营已经获得授权的血类", "只经营已经获得授权的鞋类"),
            ("等一下，鞋嘞在哪里选？", "等一下，鞋类在哪里选？"),
            ("这个鞋嘞是我刚买的", "这个鞋嘞是我刚买的"),
            ("我想查看血类检测结果", "我想查看血类检测结果"),
        ):
            with self.subTest(raw=raw):
                self.assertEqual(vocabulary.correct(CATEGORY, raw), expected)
                self.assertEqual(vocabulary.correct(STAMP, raw), raw)

    def test_custom_vocabulary_checks_literal_context_and_records_version(self):
        self.write_rules([{
            "case_id": CHAIN, "term": "审核门槛", "aliases": ["审和", "审和门砍"],
            "before": ["想问", "核对"], "after": ["是什么", "在哪看"], "requires": ["授权", "工单"],
        }])
        vocabulary = Vocabulary.from_file(self.path)
        self.assertEqual(vocabulary.metadata, {
            "source": self.path.name, "rules": 1, "sha256": hashlib.sha256(self.path.read_bytes()).hexdigest(),
        })
        self.assertEqual(vocabulary.correct(CHAIN, "授权工单想问审和门砍是什么"), "授权工单想问审核门槛是什么")
        self.assertEqual(vocabulary.correct(CHAIN, "授权工单核对审和在哪看"), "授权工单核对审核门槛在哪看")
        for raw in ("授权想问审和门砍是什么，工单在哪", "授权工单前面想问一下审和在哪看", "授权工单核对审和"):
            self.assertEqual(vocabulary.correct(CHAIN, raw), raw)
        self.assertEqual(vocabulary.correct(CATEGORY, "授权工单核对审和在哪看"), "授权工单核对审和在哪看")

    def test_chain_party_names_from_spoken_role_answers(self):
        vocabulary = default_vocabulary()
        for focus, raw, expected in (
            ("chain_parties", "授权方式新桥商贸公司", "授权方是星桥商贸公司"),
            ("chain_grantee", "备授权方式小贝他", "被授权方是小贝塔"),
            ("chain_grantor", "授权风是星球", "授权方是星桥商贸公司"),
            ("chain_parties", "新桥对于小塔的", "星桥对于小贝塔的"),
            ("chain_parties", "新桥跟小塔", "星桥跟小贝塔"),
            ("chain_grantee", "是小贝他。", "是小贝塔。"),
            ("chain_grantor", "新桥商贸公司", "星桥商贸公司"),
            ("chain_grantor", "云山品牌公司", "云杉品牌公司"),
            ("chain_parties", "我说的不是新桥科技公司", "我说的不是新桥科技公司"),
            ("chain_parties", "星球", "星球"),
            ("chain_parties", "授权方是新桥商贸公司办事处", "授权方是新桥商贸公司办事处"),
            ("chain_request", "我说的是新桥公司", "我说的是新桥公司"),
            ("chain_request", "云山品牌公司", "云山品牌公司"),
            ("chain_request", "云山品牌公司授权给新桥商贸公司", "云杉品牌公司授权给星桥商贸公司"),
            ("chain_request", "授权方式新桥商贸公司", "授权方式新桥商贸公司"),
        ):
            with self.subTest(focus=focus, raw=raw):
                self.assertEqual(vocabulary.correct(CHAIN, raw, focus=focus), expected)
                self.assertEqual(vocabulary.correct(STAMP, raw, focus=focus), raw)

    def test_configuration_errors_name_file_rule_and_field(self):
        base = {"case_id": CATEGORY, "term": "鞋类", "aliases": ["鞋报"], "before": ["选"]}
        for key, value, field in (
            ("case_id", "wrong", "case_id"), ("aliases", [], "aliases"), ("term", "", "term"),
            ("after", [0], "after"), ("right_pattern", "(", "right_pattern"), ("unused", True, "unused"),
        ):
            with self.subTest(field=field):
                self.write_rules([{**base, key: value}])
                with self.assertRaisesRegex(ValueError, rf"domain-terms\.json.*rules\[0\]\.{field}"):
                    Vocabulary.from_file(self.path)
        self.write_rules([{key: value for key, value in base.items() if key != "before"}])
        with self.assertRaisesRegex(ValueError, r"rules\[0\].*context guard"):
            Vocabulary.from_file(self.path)
        self.path.write_text('\n{"version":}', encoding="utf-8")
        with self.assertRaisesRegex(ValueError, r"domain-terms\.json.*line 2"):
            Vocabulary.from_file(self.path)
