import tempfile
import unittest
from pathlib import Path

from jd_mock.business import Store
from jd_mock.case_agent import CaseAgent
from jd_mock.stamp_agent import StampAgent


class Transport:
    model = "test-model"
    provider = "deepseek"

    def complete(self, messages, choices):
        self.sent = messages
        return choices[0]


class StrategyLookup:
    def __init__(self):
        self.requests = []

    def retrieve(self, text, *, facts, history, scene):
        self.requests.append((scene, text, facts, history))
        row = {
            "strategy_id": "TEST-" + scene,
            "version": 1,
            "intent": "处理当前工单",
            "conditions": {"identity_verified": [True]},
            "actions": ["根据本单核实事实选择处理动作"],
            "reply_requirements": ["审核结果以复审为准"],
        }
        return {"query": text, "strategies": [row], "encoder": "test", "reason": "matched"}


class StrategyWorkbenchTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.transport = Transport()
        self.lookup = StrategyLookup()
        stamp = StampAgent(cloud=self.transport)
        self.store = Store(Path(directory.name) / "calls.sqlite3",
                           stamp_agent=stamp, case_agent=CaseAgent(stamp),
                           strategy_library=self.lookup)

    def test_each_new_scene_supplies_its_matched_strategy_to_the_existing_agent(self):
        scenarios = (
            ("JD-DEMO-001", "品牌类目不符", "只经营授权范围怎么选", "鞋类"),
            ("JD-DEMO-002", "授权书内容不完整", "这份授权书应该找谁盖章", "青禾品牌公司"),
            ("JD-DEMO-004", "授权时间到期", "新的授权书要上传到哪儿", "海棠品牌公司"),
            ("JD-DEMO-005", "法人证件类型", "我应该换传什么证件", "身份证"),
        )
        for case_id, expected_scene, question, fact in scenarios:
            with self.subTest(case_id=case_id):
                call_id = self.store.start_call(case_id)["call_id"]
                lookup_count = len(self.lookup.requests)
                before_verify = self.store.turn(call_id, question, "unverified")
                self.assertFalse(before_verify["verified"])
                self.assertEqual(len(self.lookup.requests), lookup_count)
                self.store.turn(call_id, "是的，我是商家小贝塔", "verify")
                self.assertEqual(len(self.lookup.requests), lookup_count)
                turn = self.store.turn(call_id, question, "business")
                kind = "stamp_decision" if case_id == "JD-DEMO-002" else "dialogue_decision"
                trace = turn[kind]
                scene, original, facts, _ = self.lookup.requests[-1]
                self.assertEqual((scene, original), (expected_scene, question))
                self.assertTrue(facts["identity_verified"])
                self.assertIn(fact, str(facts))
                self.assertIn("TEST-" + expected_scene, self.transport.sent[0]["content"])
                self.assertIn("TEST-" + expected_scene, trace["retrieval"]["strategies"][0]["strategy_id"])
                self.assertEqual(turn["receipt_count"], 0)

    def test_confirmation_does_not_call_the_strategy_library_or_model(self):
        call_id = self.store.start_call("JD-DEMO-004")["call_id"]
        offer = self.store.turn(call_id, "是的，我是商家小贝塔", "verify")
        self.assertIn("海棠品牌公司", offer["reply"])
        saved = self.store.turn(call_id, "我同意按步骤修改后重新提交", "consent",
                                delivered_reply="", started_plan=offer["reply"])
        self.assertEqual(self.lookup.requests, [])
        self.assertEqual(saved["receipt_count"], 1)
        self.assertEqual(saved["receipt"]["case_id"], "JD-DEMO-004")
        self.assertEqual(self.store.retry_writeback(call_id)["receipt"], saved["receipt"])
