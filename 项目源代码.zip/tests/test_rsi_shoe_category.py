import unittest
from threading import Lock
from unittest.mock import Mock

from jd_mock.speech import SpeechStream


def recognize(raw, **options):
    recognizer = Mock()
    recognizer.is_ready.return_value = False
    recognizer.get_result.return_value = raw
    return SpeechStream(recognizer, Lock(), **options).finish()


class ShoeCategoryContextTest(unittest.TestCase):
    def test_corrects_shoe_category_in_an_authorization_location_question(self):
        cases = (
            ("我想选鞋报道哪里修改授权类", "我想选鞋类道哪里修改授权类目"),
            ("我想选鞋报到哪里修改授权类目", "我想选鞋类到哪里修改授权类目"),
            ("我想选鞘报道哪里修改授权类目", "我想选鞋类道哪里修改授权类目"),
            ("我先勾选鞋报，要在哪儿改授权类目", "我先勾选鞋类，要在哪儿改授权类目"),
            ("选择 鞋报去哪里更改授权类目", "选择 鞋类去哪里更改授权类目"),
        )
        for raw, corrected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(recognize(raw, business_terms=True), corrected)

    def test_preserves_ambiguous_or_unrelated_words(self):
        cases = (
            "我想选鞋包到哪里修改授权类目",
            "我想选《鞋报》，到哪里修改授权类目",
            "我想选鞋报这个牌子再修改授权类目",
            "我想选鞋报到哪里找报价",
            "我想选鞋报",
            "我想选鞘报",
            "我想选剑鞘到哪里修改授权类目",
            "我想选报到哪里修改授权类目",
        )
        for raw in cases:
            with self.subTest(raw=raw):
                self.assertEqual(recognize(raw, business_terms=True), raw)

    def test_requires_business_context(self):
        raw = "我想选鞋报到哪里修改授权类目"
        self.assertEqual(recognize(raw), raw)


if __name__ == "__main__":
    unittest.main()
