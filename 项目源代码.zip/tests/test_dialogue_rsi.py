import json
from pathlib import Path
import tempfile
import unittest

from tools.run_dialogue_rsi import CATEGORY, POLICIES, STAMP, build_suite, compare, load_profile, profile, propose


def outcome(trial_id, *, scenario="category_expand", order=CATEGORY, failures=(), unsafe=()):
    return {"trial_id": trial_id, "scenario": scenario, "order": order,
            "passed": not (failures or unsafe), "turns": [{
                "failures": failures, "unsafe": unsafe, "elapsed_ms": 20, "requires_model": True,
            }]}


class DialogueRsiTests(unittest.TestCase):
    def test_seeded_development_and_holdout_have_disjoint_user_lines(self):
        suite = build_suite(43, 2)
        self.assertEqual(suite, build_suite(43, 2))
        phrasing = [{turn["text"] for trial in split for turn in trial["turns"]} for split in suite.values()]
        self.assertFalse(phrasing[0].intersection(phrasing[1]))

    def test_propose_uses_failure_labels_to_select_only_known_policy(self):
        development = (
            outcome("a", failures=("grounding_missing",)),
            outcome("b", scenario="category_control", failures=("model_unavailable",)),
            outcome("c", scenario="review_limits", order=STAMP, failures=("wrong_action",)),
        )
        proposal, failures = propose(profile(), development)
        self.assertEqual(proposal["rule_ids"], ["category_expand"])
        self.assertEqual(proposal["instruction"], POLICIES["category_expand"])
        self.assertEqual(failures, {"category_expand": 1})

    def test_heldout_improvement_needs_no_new_failures_or_unsafe_outcomes(self):
        baseline = profile()
        candidate = profile(POLICIES["category_expand"], ("category_expand",))
        before = [outcome("h1", failures=("wrong_action",)), outcome("h2")]
        self.assertEqual(compare(baseline, candidate, before, [outcome("h1"), outcome("h2")])["decision"],
                         "recommend_candidate")
        rejected = compare(baseline, candidate, before, [outcome("h1"), outcome("h2", unsafe=("unexpected_receipt",))])
        self.assertEqual(rejected["recommended_profile"], baseline["profile_id"])
        self.assertEqual(rejected["rollback_profile"], baseline["profile_id"])
        self.assertFalse(rejected["modified_live_configuration"])
        self.assertEqual(rejected["regressions"], ["h2"])
        self.assertIn("unsafe_outcome", rejected["reasons"])

    def test_reusable_profile_rejects_modified_instruction(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "candidate.json"
            configuration = profile(POLICIES["chain_direction"], ("chain_direction",))
            path.write_text(json.dumps(configuration), encoding="utf-8")
            self.assertEqual(load_profile(path), configuration)
            path.write_text(json.dumps({**configuration, "instruction": "modified"}), encoding="utf-8")
            with self.assertRaises(ValueError):
                load_profile(path)
