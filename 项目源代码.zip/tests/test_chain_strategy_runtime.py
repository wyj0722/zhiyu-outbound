from pathlib import Path
import tempfile
import unittest

from jd_mock.business import OPENING, Store
from jd_mock.case_agent import CaseAgent
from jd_mock.chain_strategy_agent import ChainStrategyAgent
from jd_mock.cases import CHAIN
from jd_mock.dialogue import REVIEW


class Library:
    def retrieve(self, text, *, facts, history, scene):
        review = "过" in text
        row = {
            "strategy_id": "POP-REVIEW-001" if review else "POP-AUTH-CHAIN-01",
            "version": 2 if review else 1,
            "intent": "能否过审" if review else "说明缺哪段授权",
            "conditions": {},
            "actions": ["说明审核结论"] if review else ["说清谁授权给谁"],
            "reply_requirements": [],
        }
        self.last_request = (text, facts, history, scene)
        return {
            "query": "补交授权证明后能否通过审核" if review else text,
            "intent_key": "review" if review else "segment",
            "strategies": [row], "encoder": "test-encoder",
        }


class Transport:
    model = "deepseek-test"

    def __init__(self):
        self.last_messages = []

    def _complete(self, messages, grammar, *, choices):
        return choices[0]

    def chat_text(self, messages, *, max_tokens):
        self.last_messages = messages
        if "过" in messages[-1]["content"]:
            return "审核时会核对两份授权能不能接起来。"
        return "目前缺云杉品牌公司授权给星桥商贸公司的证明。"


class ChainRuntimeTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.library = Library()
        self.transport = Transport()
        self.fallback = CaseAgent(self.transport)
        chain = ChainStrategyAgent(self.library, self.transport, self.fallback)
        self.store = Store(Path(directory.name) / "calls.sqlite3", case_agent=self.fallback, chain_agent=chain)
        self.call_id = self.store.start_call("JD-DEMO-003")["call_id"]

    def play(self, text, turn_id):
        return self.store.turn(self.call_id, text, turn_id, delivered_reply="")

    def test_later_turn_uses_review_strategy_and_preserves_original_question(self):
        identity = self.play("是的，我是商家小贝塔", "identity")
        self.assertEqual(identity["completed_qa_count"], 0)
        self.store.record_spoken_reply(self.call_id, "identity", identity["reply"])
        problem = self.play("缺哪一段授权？", "gap")
        self.assertEqual(problem["dialogue_decision"]["retrieval"]["strategies"][0]["strategy_id"],
                         "POP-AUTH-CHAIN-01")
        self.store.record_spoken_reply(self.call_id, "gap", problem["reply"])
        raw = "我把这个补上就能过吗？"
        result = self.store.turn(self.call_id, "我把授权补上就能过吗？", "review", delivered_reply="",
                                 raw_text=raw)
        trace = result["dialogue_decision"]
        self.assertEqual(trace["retrieval"]["strategies"][0]["version"], 2)
        self.assertEqual(self.transport.last_messages[-1], {"role": "user", "content": raw})
        self.assertIn("POP-REVIEW-001", self.transport.last_messages[0]["content"])
        self.assertIn({"role": "assistant", "content": problem["reply"]}, self.transport.last_messages[1:-1])
        preface = REVIEW[CHAIN.scenario].split("。")[0] + "。"
        self.assertEqual(result["reply"], preface + "审核时会核对两份授权能不能接起来。")
        self.assertIn(preface, self.transport.last_messages[0]["content"])
        self.assertEqual(result["receipt_count"], 0)

    def test_evolution_capture_uses_only_spoken_prefix_and_freezes_order(self):
        identity = self.play("是的我是商家小贝塔", "identity")
        first_sentence = identity["reply"].split("。")[0] + "。"
        self.store.record_spoken_reply(self.call_id, "identity", first_sentence)
        self.store.record_spoken_reply(self.call_id, "identity", first_sentence)
        self.play("缺哪一段授权", "gap")
        snapshot = self.store.evolution_snapshot(self.call_id)
        self.assertEqual(snapshot["opening"], OPENING)
        self.assertEqual([t["turn_id"] for t in snapshot["qa"]], ["QA_1"])
        self.assertEqual(snapshot["qa"][0]["answer"], first_sentence)
        self.assertEqual(snapshot["qa"][0]["question"], "是的我是商家小贝塔")
        self.assertEqual(self.store.get_call(self.call_id)["completed_qa_count"], 1)


if __name__ == "__main__":
    unittest.main()
