import importlib.util
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from jd_mock.strategy import MODEL, MODEL_CACHE, SCENE, StrategyLibrary, project


class FakeEncoder:
    name = "controlled-test-encoder"

    def __init__(self):
        self.inputs = []

    def __call__(self, texts):
        self.inputs.extend(texts)
        for text in texts:
            if any(word in text for word in ("通过", "过审", "能过", "问题了吗")):
                yield (1, 0, 0)
            elif any(word in text for word in ("关联", "一家", "同一个")):
                yield (0, 1, 0)
            else:
                yield (0, 0, 1)


def change(update_id, strategy_id="POP-AUTH-CHAIN-01", version=1):
    return {
        "operation": "modify_strategy", "update_id": update_id, "strategy_id": strategy_id,
        "expected_version": version, "new_version": version + 1,
        "changes": {"query_examples": ["是不是一家？"]},
    }


class StrategyLibraryTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.db = Path(self.folder.name) / "workbench.sqlite3"
        self.encoder = FakeEncoder()
        self.library = StrategyLibrary(self.db, embed=self.encoder)
        self.facts = {"missing_segment": "云杉品牌公司给星桥商贸公司的授权证明",
                      "review_phase": "未重新提交", "relationship_check": "未确认关联"}

    def test_retrieval_grounds_reference_and_checks_phase_and_duration(self):
        review = self.library.retrieve("那我把这个补上就能过吗？", facts=self.facts,
                                       history=[{"role": "assistant", "content": "请把缺少的授权证明补齐。"}])
        self.assertEqual(review["intent_key"], "review")
        self.assertIn(self.facts["missing_segment"], review["query"])
        self.assertEqual([r["strategy_id"] for r in review["strategies"]], ["POP-REVIEW-001"])
        self.assertEqual(self.library.retrieve("补齐了能过审吗？", facts={})["strategies"], [])
        duration = self.library.retrieve("审核一般等多久？", facts=self.facts)
        self.assertEqual(duration["intent_key"], "duration")
        self.assertEqual(duration["strategies"], [])
        self.assertEqual(self.library.retrieve("这个呢？", facts={})["intent_key"], "ambiguous")
        segment = self.library.retrieve("我们两家有关联。您直接告诉我，缺谁给谁的授权？", facts=self.facts)
        self.assertEqual(segment["intent_key"], "segment")
        self.assertEqual(segment["strategies"][0]["strategy_id"], "POP-AUTH-CHAIN-01")

    def test_project_apply_idempotence_and_refresh_only_changed_vectors(self):
        before = self.library.list_active()
        self.library.retrieve("缺哪段授权？", facts=self.facts)
        self.encoder.inputs.clear()
        update = change("chain-qa-2")
        projected = project(before, update)
        self.assertEqual(next(row for row in projected if row["strategy_id"] == "POP-AUTH-CHAIN-01")["version"], 2)
        self.assertEqual(self.library.list_active(), before)
        self.assertTrue(self.library.apply(update)["applied"])
        self.assertFalse(self.library.apply(update)["applied"])
        after = self.library.retrieve("两家是一家怎么还要补授权？", facts=self.facts)
        self.assertEqual(after["strategies"][0]["version"], 2)
        self.assertIn("是不是一家？", self.encoder.inputs)
        self.assertNotIn("授权书补齐了就能过审吗？", self.encoder.inputs)
        self.assertEqual(StrategyLibrary(self.db, embed=self.encoder).list_active(), projected)
        self.assertEqual([row["status"] for row in self.library.list_versions("POP-AUTH-CHAIN-01")],
                         ["superseded", "active"])
        with self.assertRaises(ValueError):
            self.library.apply(change("stale"))

    def test_batch_rolls_back_and_add_assigns_replay_safe_id(self):
        before = self.library.list_active()
        with self.assertRaises(ValueError):
            self.library.apply_batch([change("first"), change("stale")])
        self.assertEqual(self.library.list_active(), before)
        strategy = {
            "scene": SCENE, "intent": "商家对公司关联提出异议",
            "conditions": {"relationship_check": ["未确认关联"]},
            "query_examples": ["明明有关联还要再补？"], "actions": ["核对本单关联记录"],
            "reply_requirements": ["按单据事实作答"],
        }
        update = {"operation": "add_strategy", "strategy_id": None, "expected_version": None, "new_version": 1,
                  "strategy": strategy}
        candidate = project(before, update)[-1]
        update["update_id"] = "add-related"
        actual = self.library.apply(update)
        self.assertEqual(candidate["strategy_id"], actual["strategy"]["strategy_id"])
        self.assertEqual(candidate["version"], 1)
        self.assertFalse(self.library.apply(update)["applied"])

    def test_identity_condition_normalizes_and_applies_only_to_matching_booleans(self):
        before = self.library.list_active()
        for shape in (True, [True], False, [False]):
            with self.subTest(shape=shape):
                required = shape[0] if isinstance(shape, list) else shape
                update = change("verified-mock")
                update["changes"] = {"conditions": {"identity_verified": shape}}
                projected = project(before, update)
                row = next(row for row in projected if row["strategy_id"] == "POP-AUTH-CHAIN-01")
                self.assertEqual(row["conditions"], {"identity_verified": [required]})
                self.assertIs(row["conditions"]["identity_verified"][0], required)
                for fact in (True, False, "true", "false", 0, 1, None):
                    facts = dict(self.facts, identity_verified=fact)
                    found = self.library.retrieve("缺哪段授权？", facts=facts, strategies=projected)
                    self.assertEqual(bool(found["strategies"]), fact is required, (shape, fact))
                missing = self.library.retrieve("缺哪段授权？", facts=self.facts, strategies=projected)
                self.assertFalse(missing["strategies"])

        update["changes"] = {"conditions": {"identity_verified": True}}
        self.assertEqual(self.library.list_active(), before)
        saved = self.library.apply(update)
        self.assertEqual(saved["strategy"]["conditions"], {"identity_verified": [True]})
        self.assertFalse(self.library.apply(update)["applied"])
        reopened = StrategyLibrary(self.db, embed=self.encoder)
        found = reopened.retrieve("缺哪段授权？", facts=dict(self.facts, identity_verified=True))
        self.assertEqual(found["strategies"][0]["version"], 2)
        self.assertFalse(reopened.retrieve("缺哪段授权？", facts=dict(self.facts, identity_verified=False))["strategies"])
        self.assertEqual(reopened.list_versions("POP-AUTH-CHAIN-01")[0]["conditions"], {})

    def test_conditions_reject_mixed_or_string_identity_values_and_other_booleans(self):
        before = self.library.list_active()
        invalid = [
            ("identity_verified", value) for value in (1, None, "true", [], ["true"], [True, 1])
        ] + [("review_phase", value) for value in (True, [True], "未重新提交")]
        for field, value in invalid:
            with self.subTest(field=field, value=value):
                update = change("invalid-condition")
                update["changes"] = {"conditions": {field: value}}
                with self.assertRaisesRegex(ValueError, field):
                    project(before, update)
                with self.assertRaisesRegex(ValueError, field):
                    self.library.apply(update)
        self.assertEqual(self.library.list_active(), before)

    def test_existing_chain_database_seeds_new_scenes_without_replacing_history(self):
        self.library.apply(change("old-chain"))
        with closing(sqlite3.connect(self.db)) as connection, connection:
            connection.execute("DELETE FROM strategy_versions WHERE scene <> ?", (SCENE,))
            before = connection.execute("SELECT * FROM strategy_versions ORDER BY strategy_id, version").fetchall()
        reopened = StrategyLibrary(self.db, embed=self.encoder)
        scene_names = {row["scene"] for row in reopened.list_all_active()}
        self.assertEqual(scene_names, {SCENE, "品牌类目不符", "授权书内容不完整", "授权时间到期", "法人证件类型"})
        self.assertEqual(reopened.list_active(), reopened.list_active(SCENE))
        self.assertEqual([row["version"] for row in reopened.list_versions("POP-AUTH-CHAIN-01")], [1, 2])
        self.assertFalse(reopened.apply(change("old-chain"))["applied"])
        with closing(sqlite3.connect(self.db)) as connection:
            chain_after = connection.execute(
                "SELECT * FROM strategy_versions WHERE scene = ? ORDER BY strategy_id, version", (SCENE,),
            ).fetchall()
        self.assertEqual(before, chain_after)

    def test_publication_and_retrieval_are_scoped_to_scene(self):
        scene = "授权书内容不完整"
        before = self.library.list_all_active()
        active = self.library.list_active(scene)
        row = next(item for item in active if "盖章" in item["intent"] or "公章" in item["intent"])
        update = change("stamp-only", strategy_id=row["strategy_id"])
        update["changes"] = {"conditions": {"identity_verified": True}}
        projected = project(before, update, scene=scene)
        self.assertEqual([row for row in projected if row["scene"] != scene],
                         [row for row in before if row["scene"] != scene])
        self.library.apply(update, scene=scene)
        with self.assertRaises(ValueError):
            self.library.apply(update, scene=SCENE)
        self.assertEqual(self.library.list_versions(row["strategy_id"], scene=SCENE), [])
        self.assertEqual([item["version"] for item in self.library.list_versions(row["strategy_id"], scene=scene)], [1, 2])
        self.assertEqual(self.library.retrieve("嗯，好的。", scene=scene, facts=self.facts)["strategies"], [])
        self.assertEqual(self.library.retrieve("那我就按这个办法办。", scene=scene, facts=self.facts)["strategies"], [])
        self.assertEqual(self.library.retrieve("今天的天气好吗？", scene=scene, facts=self.facts)["strategies"], [])
        self.assertEqual(self.library.retrieve("这份还能交吗？", scene=scene, facts=self.facts)["query"], "这份还能交吗？")

    def test_material_reference_needs_a_recent_agent_reply_and_uses_trusted_facts(self):
        scene = "授权时间到期"
        material = "本单销售授权书的截止日期为2025年9月30日。"
        facts = dict(self.facts, identity_verified=True, material_context=material)
        question = "那这份还可以吗？"
        user_only = [{"role": "user", "content": "我的授权书下个月才到期。"}]
        ungrounded = self.library.retrieve(question, scene=scene, facts=facts, history=user_only)
        self.assertEqual(ungrounded["query"], question)
        self.assertEqual(ungrounded["intent_key"], "ambiguous")
        history = [{"role": "assistant", "content": "您看一下已提交授权书上的有效期。"}, *user_only]
        grounded = self.library.retrieve(question, scene=scene, facts=facts, history=history)
        self.assertIn(material, grounded["query"])
        self.assertNotIn("下个月", grounded["query"])
        self.assertTrue(grounded["strategies"])
        unrelated = [*history, {"role": "assistant", "content": "您可以查看审核进度。"}]
        self.assertEqual(self.library.retrieve(question, scene=scene, facts=facts, history=unrelated)["query"], question)

    @unittest.skipUnless(importlib.util.find_spec("fastembed") and MODEL_CACHE.is_dir(), "local FastEmbed model unavailable")
    def test_real_embedding_search_is_grounded_and_isolated_in_each_scene(self):
        library = StrategyLibrary(self.db)
        for scene, question, expected_id in (
            (SCENE, "这次申请缺谁给谁的授权？", "POP-AUTH-CHAIN-01"),
            ("品牌类目不符", "服装和鞋类都能在授权范围里勾吗？", "POP-CATEGORY-SCOPE-01"),
            ("授权书内容不完整", "能不能盖我们店自己的章？", "POP-AUTH-STAMP-OWNER-01"),
            ("授权时间到期", "过期的授权书找谁重开？", "POP-AUTH-EXPIRED-REISSUE-01"),
            ("法人证件类型", "这张单的法人证件该换成身份证还是护照？", "POP-LEGAL-DOC-REPLACE-01"),
        ):
            with self.subTest(scene=scene):
                result = library.retrieve(question, scene=scene, facts=dict(self.facts, identity_verified=True))
                self.assertEqual(result["encoder"], MODEL)
                self.assertEqual(result["reason"], "matched")
                self.assertEqual(result["strategies"][0]["strategy_id"], expected_id)
                self.assertTrue(all(row["scene"] == scene for row in result["strategies"]))


if __name__ == "__main__":
    unittest.main()
