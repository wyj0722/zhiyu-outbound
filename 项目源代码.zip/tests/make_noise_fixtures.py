"""Create deterministic non-speech audio and a short consent over the same noise."""

import argparse
import hashlib
import json
import wave
from pathlib import Path

import numpy as np


SEED = 4821
RATE = 16_000
NOISE_SECONDS = 2.25
SNR_DB = 8.0


def rms(samples):
    return float(np.sqrt(np.mean(samples * samples)))


def read_mono_wav(file):
    with wave.open(str(file), "rb") as stream:
        if stream.getnchannels() != 1 or stream.getsampwidth() != 2:
            raise ValueError("Use a mono 16-bit PCM WAV consent fixture.")
        source = np.frombuffer(stream.readframes(stream.getnframes()), dtype="<i2").astype(float) / 32768
        rate = stream.getframerate()
    return np.interp(np.arange(0, len(source), rate / RATE), np.arange(len(source)), source)


def make_noise():
    rng = np.random.default_rng(SEED)
    t = np.arange(round(NOISE_SECONDS * RATE)) / RATE
    airflow = np.convolve(rng.standard_normal(t.size), np.ones(67) / 67, mode="same")
    rotor = sum(np.sin(2 * np.pi * f * t + p) / (index + 1)
                for index, (f, p) in enumerate(zip((120, 180, 240, 360), rng.uniform(0, 2 * np.pi, 4))))
    fan = (rotor + 0.65 * airflow) * (1 + 0.12 * np.sin(2 * np.pi * 2.7 * t))
    noise = fan * (0.021 / rms(fan))
    # Short broadband taps and damped knocks overlay the steady fan.
    for position, amplitude, duration in ((0.29, 0.10, 0.027), (0.73, 0.16, 0.042),
                                          (1.34, 0.12, 0.027), (1.81, 0.10, 0.036)):
        start = round(position * RATE)
        tap_t = np.arange(round(duration * RATE)) / RATE
        transient = (0.6 * rng.uniform(-1, 1, tap_t.size) + 0.4 * np.sin(2 * np.pi * 420 * tap_t))
        transient *= np.exp(-5 * tap_t / duration)
        noise[start:start + tap_t.size] += amplitude * transient
    fade_samples = round(0.035 * RATE)
    fade = np.linspace(0, 1, fade_samples)
    noise[:fade_samples] *= fade
    noise[-fade_samples:] *= fade[::-1]
    return noise


def voice_bounds(samples):
    frame = RATE // 50
    padded = np.pad(samples, (0, -len(samples) % frame))
    levels = np.sqrt(np.mean(padded.reshape(-1, frame) ** 2, axis=1))
    voiced = np.flatnonzero(levels >= 0.009)
    if not len(voiced):
        raise ValueError("The consent source has no audible speech.")
    return int(voiced[0] * frame), min(len(samples), int((voiced[-1] + 1) * frame))


def write_fixture(directory, name, samples):
    file = directory / f"{name}.wav"
    if np.max(np.abs(samples)) >= 1:
        raise ValueError(f"Clipped fixture: {name}")
    pcm = np.rint(samples * 32767).astype("<i2")
    with wave.open(str(file), "wb") as stream:
        stream.setparams((1, 2, RATE, 0, "NONE", "not compressed"))
        stream.writeframes(pcm.tobytes())
    return {
        "sha256": hashlib.sha256(file.read_bytes()).hexdigest(),
        "duration_seconds": len(samples) / RATE,
        "rms_full_scale": rms(samples),
        "peak_full_scale": float(np.max(np.abs(samples))),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--yes-wav", type=Path, default=Path(".runtime/consent-loop/fixtures/yes.wav"))
    parser.add_argument("--output", type=Path, default=Path(".runtime/noise-verification/fixtures"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    clean = read_mono_wav(args.yes_wav)
    noise = make_noise()
    start, end = voice_bounds(clean)
    lead = round(0.24 * RATE)
    speech_start, speech_end = lead + start, lead + end
    speech_noise = noise[speech_start:speech_end]
    scale = rms(speech_noise) * 10 ** (SNR_DB / 20) / rms(clean[start:end])
    mixture = noise.copy()
    mixture[lead:lead + len(clean)] += scale * clean
    first_voice_sample = int(np.flatnonzero(np.rint(noise * 32767) != np.rint(mixture * 32767))[0])
    frame = RATE // 50
    frame_rms = np.sqrt(np.mean(noise[:len(noise) // frame * frame].reshape(-1, frame) ** 2, axis=1))
    legacy_gate = frame_rms >= 0.014
    fixtures = {
        "fan_keyboard": dict(write_fixture(args.output, "fan_keyboard", noise),
                             non_speech=True, max_20ms_rms=float(max(frame_rms)),
                             exceeds_old_gate_for_60ms=bool((legacy_gate[:-2] & legacy_gate[1:-1] & legacy_gate[2:]).any())),
        "noisy_yes": dict(write_fixture(args.output, "noisy_yes", mixture), words="好的。",
                          voice_bounds_seconds=[speech_start / RATE, speech_end / RATE],
                          noise_only_prefix_seconds=first_voice_sample / RATE,
                          snr_db=20 * np.log10(rms(scale * clean[start:end]) / rms(speech_noise)),
                          trailing_noise_seconds=NOISE_SECONDS - speech_end / RATE),
    }
    (args.output / "manifest.json").write_text(json.dumps({
        "seed": SEED, "sample_rate": RATE, "consent_source": args.yes_wav.as_posix(),
        "consent_source_sha256": hashlib.sha256(args.yes_wav.read_bytes()).hexdigest(), "fixtures": fixtures,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
