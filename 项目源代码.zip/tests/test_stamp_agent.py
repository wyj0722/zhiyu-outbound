import unittest
from dataclasses import replace
from unittest.mock import Mock, patch

from jd_mock.cases import get_order
from jd_mock.case_agent import CaseAgent
from jd_mock.dialogue import COMMITMENT_QUESTION, stamp_confirmation
from jd_mock.stamp_agent import StampAgent, first_replies, _wire_codes
from jd_mock.stamp_evidence import readings


class StampAgentTests(unittest.TestCase):
    def setUp(self):
        self.order = replace(get_order("JD-DEMO-002"), facts={"grantor": "明川实业"})
        self.agent = StampAgent("http://127.0.0.1:8123/v1", "local-model", timeout=2)

    def test_cloud_provider_uses_the_same_candidate_choices_for_all_orders(self):
        cloud = Mock(provider="doubao", model="mock-doubao")
        cloud.complete.side_effect = lambda messages, choices: choices[0]
        with patch("jd_mock.ark_llm.ArkTransport.from_env", return_value=cloud):
            stamp = StampAgent.from_env(provider="doubao")
        self.assertEqual((stamp.provider, stamp.model), ("doubao", "mock-doubao"))
        case = CaseAgent(stamp)
        decisions = (
            stamp.decide(self.order, "送件的是店里的会计，跑手续的是外面的代理员，公章上刻的是明川实业。"),
            case.decide(get_order("JD-DEMO-001"), "我还想卖服装。", "intro"),
            case.decide(get_order("JD-DEMO-003"), "到底缺哪一段？", "intro"),
        )
        self.assertTrue(all(decision.source == "model" for decision in decisions))
        stamp_choices = cloud.complete.call_args_list[0].args[1]
        self.assertTrue(any("/" in token for token in stamp_choices))
        for forwarded in cloud.complete.call_args_list[1:]:
            self.assertTrue(all(token.isalpha() and len(token) == 1 for token in forwarded.args[1]))

    def decide(self, text, answer, **kwargs):
        self.options, handlers = readings(self.order, text, kwargs.get("context", {}), kwargs.get("last_reply", ""))
        codes = {v: k for k, v in _wire_codes(self.options).items()}
        action, _, actor = answer.partition("/")
        token = codes.get(action, "!") + ("/" + actor if len(handlers) > 2 else "")
        with patch.object(self.agent, "_complete", return_value=token) as request:
            result = self.agent.decide(self.order, text, **kwargs)
            self.messages, self.grammar = request.call_args.args
        return result

    def test_independent_handler_and_owner_with_verbatim_evidence(self):
        text = "店里员工送来的，章里刻着明川实业。"
        step = self.decide(text, "G/m")
        self.assertEqual((step.source, step.owner, step.handler, step.action),
                         ("model", "grantor", "merchant", "upload"))
        self.assertIn(step.context["owner_evidence"], text)
        self.assertIn("明川实业", step.context["owner_evidence"])
        self.assertIn(step.context["handler_evidence"], text)
        self.assertIn("店里员工", step.context["handler_evidence"])
        self.assertNotIn("如果", step.reply)
        self.assertIn(step.reply, first_replies(self.order))
        self.assertIn("79", str(step.evidence_refs))
        self.assertNotIn("青禾", step.reply + str(self.messages))

    def test_handler_is_not_an_owner_and_unknown_is_not_absence(self):
        step = self.decide("我亲自跑的，印得太淡，看不清。", "U/m")
        self.assertEqual((step.owner, step.handler, step.action), ("unknown", "merchant", "ask_owner"))
        self.assertNotIn("N", self.options)
        self.assertNotIn("M", self.options)
        self.assertFalse(step.context["plan_offered"])

    def test_required_seal_party_questions_receive_the_grounded_grantor(self):
        questions = (
            "这份授权书需要找哪家公司盖公章？",
            "该盖谁的章？",
            "应该请谁补盖公章？",
            "我应该联系哪家公司补章？",
            "本单要哪家的公章？",
            "盖哪个单位的公章？",
        )
        for text in questions:
            with self.subTest(text=text):
                step = self.decide(text, "S/-", strategy_context="\n按当前生效策略核对授权方。")
                self.assertEqual(step.source, "model")
                self.assertEqual(step.action, "required_stamp_party")
                self.assertIn("明川实业", step.reply)
                self.assertEqual(step.owner, "unknown")
                self.assertFalse(step.consent)
                self.assertFalse(step.context["plan_offered"])
                self.assertEqual(step.context["owner_evidence"], "")
                self.assertNotIn("C", self.options)
                self.assertIn(step.reply, first_replies(self.order))
                self.assertIn("当前生效策略", self.messages[0]["content"])

    def test_requirement_question_cannot_establish_the_seal_owner(self):
        text = "应该盖我们店的章，还是哪家公司的章？"
        step = self.decide(text, "S/-")
        self.assertEqual((step.owner, step.handler, step.consent), ("unknown", "unknown", False))
        self.assertEqual(set(self.options), {"S", "U"})
        self.assertIn("明川实业", step.reply)
        for stated in ("章面刻着明川实业。", "原来盖的是谁的章？", "上次找哪家公司盖章来着？",
                       "当初联系哪家公司盖章的？", "我会找明川实业盖章后上传并重新提交。"):
            with self.subTest(text=stated):
                options, _ = readings(self.order, stated, {}, "")
                self.assertNotIn("S", options)

    def test_required_party_question_preserves_verified_owner_without_an_offer(self):
        first = self.decide("章面刻着明川实业。", "G/-")
        asked = self.decide("我不知道应该找哪家公司补盖公章？", "S/-", context=first.context, last_reply=first.reply)
        self.assertEqual((asked.owner, asked.consent, asked.action), ("grantor", False, "required_stamp_party"))
        self.assertEqual(asked.context["owner_evidence"], first.context["owner_evidence"])
        self.assertFalse(asked.context["plan_offered"])

    def test_delivery_and_staff_mentions_do_not_offer_a_seal_owner(self):
        examples = (
            ("送件的是我店里的会计，我没看到盖章那一页。", "m"),
            ("帮忙跑手续的是外面的代理员，他没有给我看章。", "t"),
            ("中间的是我店里的会计，我没看到回张那一。", None),
            ("我只跟店铺的财务说过话。", None),
            ("店里会计的名字我记得，但我没看过章。", None),
            ("跑手续的是代理员，名片上面写着这位代理员的名字。", "t"),
            ("我现在看到了文章中间写的是我们商家自己的公司名。", None),
        )
        for text, actor in examples:
            with self.subTest(text=text):
                options, handlers = readings(self.order, text, {}, "")
                self.assertEqual(set(options), {"U"})
                if actor:
                    self.assertIn(handlers[actor].quote, text)
                    self.assertNotEqual(handlers[actor].quote, "")
                step = self.decide(text, "U/" + (actor or "-"))
                self.assertEqual((step.owner, step.action), ("unknown", "ask_owner"))
                self.assertFalse(step.context["plan_offered"])

    def test_ownership_belongs_to_the_named_party_in_the_seal_clause(self):
        examples = (
            ("材料是经销商拿来的，公章写的单位确实是明川实业。", "G", "t"),
            ("照片放大后看清楚了，章上是海洋贸易公司，是供货商自己的章。", "T", "-"),
            ("红章中间写的是我们商家自己的公司名。", "M", "-"),
            ("承办的是店里员工，章面上刻着外部代理公司的名字。", "T", "m"),
            ("我们店的。", "M", "-"),
            ("明川实业的章。", "G", "-"),
        )
        for text, expected, actor in examples:
            with self.subTest(text=text):
                options, _ = readings(self.order, text, {}, "")
                self.assertEqual(set(options), {expected, "U"})
                step = self.decide(text, expected + "/" + actor)
                self.assertEqual(step.source, "model")
                self.assertIn(step.context["owner_evidence"], text)
                self.assertIn(step.context["handler_evidence"], text)

    def test_absence_requires_affirmative_absence_evidence(self):
        no_seal = self.decide("这一整页压根没盖章。", "N/-")
        self.assertEqual((no_seal.owner, no_seal.action), ("none", "request_stamp"))
        for spoken in ["没看清章上的字。", "没盖明川的章。", "这张要是没盖章怎么办？"]:
            with self.subTest(spoken=spoken):
                self.assertFalse(self.decide(spoken, "N/-").source == "model")

    def test_wrong_owner_reply_names_owner_and_new_fact_overrides_old(self):
        old = self.decide("印的是卖场自己的名字。", "M/-")
        self.assertEqual(old.owner, "merchant")
        self.assertIn("店铺", old.reply)
        step = self.decide("看错了，刻的是代理商的名字。", "T/-", context=old.context)
        self.assertEqual(step.owner, "third_party")
        self.assertIn("第三方", step.reply)
        self.assertIn("明川实业", step.reply)
        self.assertIn("A79", "".join(step.evidence_refs))

    def test_review_then_consent_has_no_stale_confirmation(self):
        step = self.decide("办完可以保证过审吗？", "R/-",
                           context={"owner":"merchant","plan_offered": True, "plan":"request_stamp"})
        self.assertIn("复审", step.reply)
        self.assertIn("D20", "".join(step.evidence_refs))
        self.assertFalse(step.consent)

    def test_natural_plan_references_can_be_valid_model_choices(self):
        from jd_mock.dialogue import COMMITMENT_QUESTION

        context = {"plan_offered": True, "plan": "request_stamp", "owner": "merchant"}
        last_reply = "请补授权方的公章。" + COMMITMENT_QUESTION
        for phrase in ("行，那就这么办。", "好的好的。", "成，听您的。"):
            with self.subTest(phrase=phrase):
                step = self.decide(phrase, "C/-", context=context, last_reply=last_reply)
                self.assertIn("C", self.options)
                self.assertTrue(step.consent)
        self.assertFalse(self.decide("好。", "C/-", context=step.context, last_reply=step.reply).consent)

    def test_only_an_applicable_proposal_or_a_complete_new_pledge_can_record(self):
        plan = self.decide("印着我店的全称。", "M/-")
        simple = self.decide("好，就按这个办法办。", "C/-", context=plan.context, last_reply=plan.reply)
        explicit = self.decide("我同意找品牌方补盖公章再重新提交。", "C/-")
        self.assertTrue(simple.consent)
        self.assertTrue(explicit.consent)
        self.assertFalse(self.decide("我知道了。", "C/-").consent)
        for spoken in ["如果同意重交还会驳回来吗？", "我刚才没同意，请先别登记。", "好的我先查查"]:
            self.assertFalse(self.decide(spoken, "C/-", context=plan.context, last_reply=plan.reply).consent)

    def test_ambiguous_short_name_does_not_match_a_different_legal_name(self):
        self.order = replace(self.order, facts={"grantor": "明川品牌公司"})
        self.assertEqual(self.decide("我看了，章上写的是明川物流公司。", "T/-").owner, "third_party")
        self.assertNotIn("G", self.options)
        self.assertTrue(self.decide("印的是明川的章。", "G/-").owner == "grantor")

    def test_timeout_and_unsupported_answers_fail_closed(self):
        for answer in ["G/m", "C/-", "arbitrary", '{"owner":"merchant","action":"record"}']:
            step = self.decide("请稍等。", answer)
            self.assertEqual((step.source, step.consent), ("fallback", False))
        with patch.object(self.agent, "_complete", side_effect=TimeoutError):
            step = self.agent.decide(self.order, "等一下", context={"plan_offered": True})
        self.assertEqual((step.source, step.error, step.consent), ("fallback", "timeout", False))
        self.assertFalse(step.context["plan_offered"])
        self.assertGreaterEqual(step.latency_ms, 0)

    def test_strict_wire_shape_and_invalid_envelope(self):
        for raw in ["Z/-", "U/-", "C/-", "Z\n", " Z", "a"]:
            with patch.object(self.agent, "_complete", return_value=raw):
                step = self.agent.decide(self.order, "请稍等。")
                self.assertEqual((step.source, step.consent), ("fallback", False))
        from unittest.mock import MagicMock
        with patch("jd_mock.stamp_agent.http.client.HTTPConnection") as connect:
            connect.return_value.getresponse.return_value = MagicMock(status=200, read=lambda n: b'{"choices":[null]}')
            self.assertEqual(self.agent.decide(self.order, "请稍等。").error, "invalid_decision")

    def test_keep_stated_subject_and_answer_followup_question_together(self):
        step = self.decide("印的是我们店的全称，还需要我上传吗？", "M+A/-")
        self.assertEqual((step.owner, step.action), ("merchant", "request_stamp"))
        self.assertIn("店铺", step.reply)
        self.assertIn("我们店", step.context["owner_evidence"])
        step = self.decide("这份印的明川实业，现在能保证过审了吗？", "G+R/-")
        self.assertEqual((step.owner, step.action), ("grantor", "review"))
        self.assertIn("复审", step.reply)

    def test_unmatched_name_can_be_confirmed_in_a_separate_turn_without_writeback(self):
        doubt = self.decide("章面写的是鸣川实业。", "U/-")
        self.assertIn("明川实业", doubt.reply)
        confirm = self.decide("没错。", "G/-", context=doubt.context, last_reply=doubt.reply)
        self.assertEqual((confirm.owner, confirm.action, confirm.consent), ("grantor", "upload", False))

    def test_restate_the_relevant_plan_using_the_known_stamp_owner(self):
        for statement, code, action in (
            ("章面刻着明川实业。", "G", "upload"),
            ("这儿盖的是我店的公章。", "M", "request_stamp"),
        ):
            with self.subTest(action=action):
                first = self.decide(statement, code + "/-")
                step = self.decide("刚才没听清，下一步我该怎么处理？", "P/-",
                                   context=first.context, last_reply=first.reply)
                self.assertEqual((step.owner, step.action, step.consent), (first.owner, action, False))
                self.assertTrue(step.context["plan_offered"])
                self.assertIn("重新提交", step.reply)

    def test_submitted_stamp_answers_reason_and_only_asks_when_a_new_seal_is_unclear(self):
        report = {"owner": "merchant", "handler": "unknown", "owner_source": "submitted_material",
                  "plan": "request_stamp", "plan_offered": True}
        initial = stamp_confirmation(self.order, include_submitted=True)[0]
        reason = self.decide("请问为什么退回？", "W/-", context=report, last_reply=initial)
        self.assertEqual((reason.action, reason.reply, reason.consent), ("request_stamp", initial, False))
        ask = self.decide("我有个问题。", "U/-", context=report, last_reply=initial)
        self.assertNotIn("哪家公司", ask.reply)
        self.assertFalse(ask.context["plan_offered"])
        replacement = self.decide("我换了一份，章面看不清。", "U/-", context=report, last_reply=initial)
        self.assertEqual((replacement.owner, replacement.action, replacement.consent), ("unknown", "ask_owner", False))
        self.assertIn("哪家公司", replacement.reply)
        corrected = self.decide("我换了一份，章面刻着明川实业。", "G/-", context=report, last_reply=initial)
        self.assertEqual((corrected.owner, corrected.action, corrected.consent), ("grantor", "upload", False))
        self.assertEqual(corrected.context["owner_source"], "merchant_report")
        self.assertTrue(corrected.reply.endswith(COMMITMENT_QUESTION))

    def test_review_and_hold_keep_the_grounded_plan_and_handler_without_consent(self):
        first = self.decide("店里员工送来的，章里刻着明川实业。", "G/m")
        review = self.decide("办完可以保证过审吗？", "R/-", context=first.context, last_reply=first.reply)
        self.assertFalse(review.context["plan_offered"])
        self.assertEqual(review.context["plan"], "upload")
        self.assertEqual(review.handler, "merchant")
        self.assertEqual(review.context["owner_evidence"], first.context["owner_evidence"])
        self.assertEqual(review.context["handler_evidence"], first.context["handler_evidence"])

        hold = self.decide("我先考虑一下。", "H/-", context=review.context, last_reply=review.reply)
        ambiguous = self.decide("好。", "U/-", context=hold.context, last_reply=hold.reply)
        self.assertNotIn("C", self.options)
        self.assertFalse(ambiguous.consent)
        repeated = self.decide("那刚才那一步再说一下。", "P/-",
                               context=ambiguous.context, last_reply=ambiguous.reply)
        self.assertEqual((repeated.action, repeated.owner, repeated.handler), ("upload", "grantor", "merchant"))
        self.assertTrue(repeated.context["plan_offered"])
        self.assertFalse(repeated.consent)
        self.assertIn("加盖明川实业公章的完整授权书", repeated.reply)

    def test_temporary_model_failure_preserves_known_facts_without_active_offer(self):
        first = self.decide("店里员工送来的，章里刻着明川实业。", "G/m")
        with patch.object(self.agent, "_complete", side_effect=TimeoutError):
            failure = self.agent.decide(self.order, "可以保证过审吗？", first.context, first.reply)
        self.assertEqual((failure.source, failure.owner, failure.handler), ("fallback", "grantor", "merchant"))
        self.assertEqual(failure.context["plan"], "upload")
        self.assertFalse(failure.context["plan_offered"])
        self.assertFalse(failure.consent)

    def test_new_document_drops_its_predecessors_owner_handler_and_plan(self):
        first = self.decide("店里员工送来的，章里刻着明川实业。", "G/m")
        changed = self.decide("我换了一份，下一步我该怎么处理？", "U/-",
                              context=first.context, last_reply=first.reply)
        self.assertNotIn("P", self.options)
        self.assertEqual((changed.owner, changed.handler, changed.action), ("unknown", "unknown", "ask_owner"))
        for field in ("plan", "owner_evidence", "handler_evidence"):
            self.assertEqual(changed.context[field], "")

    def test_retracted_handler_does_not_erase_verified_owner(self):
        first = self.decide("店里员工送来的，章里刻着明川实业。", "G/m")
        corrected = self.decide("送件的人我记错了。", "U/-", context=first.context, last_reply=first.reply)
        self.assertEqual((corrected.owner, corrected.handler), ("grantor", "unknown"))
        self.assertEqual(corrected.context["plan"], "upload")
        self.assertEqual(corrected.context["handler_evidence"], "")

    def test_future_upload_commitment_is_a_candidate_only_after_upload_offer(self):
        first = self.decide("章面刻着明川实业。", "G/-")
        for spoken in ("那就这么定，我今天把这份材料传上去，重新提交。",
                       "好，那我们明早就把这个文件上传，提交申请。"):
            with self.subTest(text=spoken):
                completed = self.decide(spoken, "C/-", context=first.context, last_reply=first.reply)
                self.assertTrue(completed.consent)
                options, _ = readings(self.order, spoken, {}, "")
                self.assertNotIn("C", options)

    def test_retracted_owner_is_not_reused_for_the_next_step(self):
        first = self.decide("章面刻着明川实业。", "G/-")
        step = self.decide("我刚才看错了，章面好像是明川实业，下一步我该怎么处理？",
                           "U/-", context=first.context, last_reply=first.reply)
        self.assertNotIn("P", self.options)
        self.assertEqual((step.owner, step.action, step.consent), ("unknown", "ask_owner", False))

    def test_new_unverified_company_is_not_the_previous_documents_owner(self):
        first = self.decide("章面刻着明川实业。", "G/-")
        step = self.decide("我换了一份，公章上刻着恒原公司，该上传到哪里？", "A/-",
                           context=first.context, last_reply=first.reply)
        self.assertEqual((step.owner, step.action, step.consent), ("unknown", "ask_owner", False))

    def test_deciding_later_is_not_a_request_for_upload_instructions(self):
        first = self.decide("章面刻着明川实业。", "G/-")
        step = self.decide("我先问问同事，再决定要不要把这份材料上传。", "H/-",
                           context=first.context, last_reply=first.reply)
        self.assertNotIn("A", self.options)
        self.assertEqual((step.action, step.consent, step.owner), ("hold", False, "grantor"))

    def test_local_only_and_wrong_scenario(self):
        with self.assertRaises(ValueError):
            StampAgent("https://external.example/v1", "not-local")
        with self.assertRaises(ValueError):
            self.agent.decide(get_order("JD-DEMO-001"), "您好")
