param(
    [switch]$Setup,
    [int]$Port = 8765,
    [string]$Database,
    [string]$Python,
    [ValidateSet('rules','stamp','model')]
    [string]$DialogueMode = 'model',
    [ValidateSet('local','deepseek','doubao')]
    [string]$LlmProvider,
    [string]$CasePolicy,
    [ValidateSet('rules','model')]
    [string]$StampMode,
    [string]$AsrVocabulary
)

$ErrorActionPreference = 'Stop'
if ($PSBoundParameters.ContainsKey('StampMode')) {
    if ($PSBoundParameters.ContainsKey('DialogueMode')) { throw 'Use -DialogueMode or -StampMode, not both.' }
    $DialogueMode = if ($StampMode -eq 'model') { 'stamp' } else { 'rules' }
}
$bundledPython = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if (-not $Python) {
    if (Test-Path -LiteralPath $bundledPython) {
        $Python = $bundledPython
    } else {
        $Python = (Get-Command python.exe -ErrorAction SilentlyContinue).Source
    }
}
if (-not $Python) {
    throw 'Install 64-bit Python 3.12, or pass -Python C:\path\to\python.exe.'
}

Push-Location -LiteralPath $PSScriptRoot
$oldPythonPath = $env:PYTHONPATH
$restoredEnvironment = @{}
try {
    $packages = Join-Path $PSScriptRoot '.runtime/packages'
    if ($Setup) {
        & $Python -m pip install --disable-pip-version-check --only-binary=:all: --target $packages -r requirements.txt
        if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
        $modelSetup = @('--asset-dir', '.runtime/models')
        if ($DialogueMode -ne 'rules') { $modelSetup += '--stamp-asr' }
        & $Python -m jd_mock.speech_assets @modelSetup
        if ($LASTEXITCODE -ne 0) { throw 'Speech model setup failed.' }
    }
    if (-not (Test-Path -LiteralPath (Join-Path $packages 'aiortc'))) {
        throw 'First run: .\start.ps1 -Setup'
    }
    $strategyPackages = Join-Path $PSScriptRoot '.runtime/strategy-packages'
    $env:PYTHONPATH = if (Test-Path -LiteralPath $strategyPackages) {
        $packages + [IO.Path]::PathSeparator + $strategyPackages
    } else {
        $packages
    }
    $provider = if ($LlmProvider) {
        $LlmProvider
    } elseif ($env:JD_LLM_PROVIDER) {
        $env:JD_LLM_PROVIDER
    } elseif ($env:DEEPSEEK_API_KEY -or [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'User')) {
        'deepseek'
    } else {
        'local'
    }
    if ($DialogueMode -ne 'rules') {
        $providerSettings = switch ($provider) {
            'deepseek' { 'DEEPSEEK_API_KEY'; 'JD_DEEPSEEK_MODEL' }
            'doubao' { 'ARK_API_KEY'; 'JD_ARK_MODEL' }
        }
        foreach ($setting in $providerSettings) {
            $value = [Environment]::GetEnvironmentVariable($setting, 'Process')
            if (-not $value) {
                $restoredEnvironment[$setting] = $value
                [Environment]::SetEnvironmentVariable($setting, [Environment]::GetEnvironmentVariable($setting, 'User'), 'Process')
            }
        }
    }
    if ($Setup -and $provider -eq 'deepseek' -and $DialogueMode -eq 'model' -and !$CasePolicy) {
        & $Python -c 'from jd_mock.strategy import warm_embedding_model; print("Strategy embedding dimensions:", warm_embedding_model())'
        if ($LASTEXITCODE -ne 0) { throw 'Strategy embedding model setup failed.' }
    }
    Write-Host "Open http://127.0.0.1:$Port after the server is ready."
    $serviceOptions = @('--port', $Port, '--dialogue-mode', $DialogueMode, '--llm-provider', $provider)
    if ($Database) { $serviceOptions += @('--db', $Database) }
    if ($CasePolicy) { $serviceOptions += @('--case-policy', $CasePolicy) }
    if ($AsrVocabulary) { $serviceOptions += @('--asr-vocabulary', $AsrVocabulary) }
    & $Python -m jd_mock.server @serviceOptions
    if ($LASTEXITCODE -ne 0) { throw "Server exited with code $LASTEXITCODE." }
} finally {
    $env:PYTHONPATH = $oldPythonPath
    foreach ($setting in $restoredEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($setting, $restoredEnvironment[$setting], 'Process')
    }
    Pop-Location
}
